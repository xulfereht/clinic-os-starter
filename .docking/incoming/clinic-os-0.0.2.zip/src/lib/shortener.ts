
export function generateCode(length = 6) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

export async function createShortLink(db: any, url: string, expiresInMinutes?: number): Promise<{ code: string, shortUrl: string }> {
    // Try to generate unique code (retry 3 times)
    let code = '';
    let retries = 3;

    while (retries > 0) {
        code = generateCode();
        // Check collision
        try {
            const created_at = Math.floor(Date.now() / 1000);
            let expires_at = null;

            if (expiresInMinutes) {
                expires_at = created_at + (expiresInMinutes * 60);
            }

            await db.prepare(
                'INSERT INTO short_links (code, original_url, created_at, expires_at) VALUES (?, ?, ?, ?)'
            ).bind(code, url, created_at, expires_at).run();

            // Success
            return { code, shortUrl: '' }; // Caller needs to prepend origin, or we can pass it if needed. 
            // Better to return just code and let caller validation.
            // But wait, the previous implementation returned full URL. 
            // Let's just return code and let caller construct URL to avoid passing origin everywhere if not needed?
            // Actually usually we want the full URL. But `origin` depends on request context.
        } catch (e: any) {
            if (e.message && e.message.includes('UNIQUE constraint failed')) {
                retries--;
                if (retries === 0) throw new Error('Failed to generate unique code');
            } else {
                throw e;
            }
        }
    }
    throw new Error('Failed to create short link');
}
