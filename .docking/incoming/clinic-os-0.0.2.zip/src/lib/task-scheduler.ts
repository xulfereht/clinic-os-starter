export async function checkRecurringTasks(db: any) {
    const now = new Date();
    // Start of today in seconds (Unix timestamp)
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime() / 1000;
    const todayDateStr = now.toISOString().split('T')[0]; // YYYY-MM-DD
    const dayOfWeek = now.getDay(); // 0=Sun, 6=Sat

    try {
        // 1. Check Clinic Holidays
        const { results: holidays } = await db.prepare(
            `SELECT * FROM clinic_holidays WHERE date = ?`
        ).bind(todayDateStr).run();

        if (holidays.length > 0) {
            console.log(`Skipping task generation: Today is a clinic holiday (${holidays[0].description})`);
            return;
        }

        // Fetch recurring tasks
        const { results: recurringTasks } = await db.prepare(
            `SELECT * FROM tasks WHERE frequency != 'once' AND frequency IS NOT NULL`
        ).run();

        for (const task of recurringTasks) {
            let shouldGenerate = false;
            const lastGen = task.last_generated;

            // If already generated today (or in the future), skip
            if (lastGen && lastGen >= todayStart) continue;

            // 2. Check Staff Schedule & Leaves (if assigned)
            if (task.assignee_id) {
                // Check Weekly Schedule
                const { results: schedule } = await db.prepare(
                    `SELECT is_working FROM staff_schedules WHERE staff_id = ? AND day_of_week = ?`
                ).bind(task.assignee_id, dayOfWeek).run();

                // If schedule exists and is_working is 0 (false), skip
                // Note: If no schedule exists, we assume default working (so we don't skip)
                if (schedule.length > 0 && schedule[0].is_working === 0) {
                    console.log(`Skipping task ${task.title}: Staff ${task.assignee_id} is not working on day ${dayOfWeek}`);
                    continue;
                }

                // Check Leaves
                const { results: leaves } = await db.prepare(
                    `SELECT * FROM staff_leaves 
                     WHERE staff_id = ? 
                     AND start_date <= ? AND end_date >= ?
                     AND status = 'approved'`
                ).bind(task.assignee_id, todayDateStr, todayDateStr).run();

                if (leaves.length > 0) {
                    console.log(`Skipping task ${task.title}: Staff ${task.assignee_id} is on leave (${leaves[0].type})`);
                    continue;
                }
            }

            const freq = task.frequency;
            // Use created_at as the reference date for weekly/monthly
            const createdDate = new Date((task.created_at || 0) * 1000);

            if (freq === 'daily') {
                shouldGenerate = true;
            } else if (freq === 'weekly') {
                // Check if today is the same day of week as created_at
                if (now.getDay() === createdDate.getDay()) {
                    shouldGenerate = true;
                }
            } else if (freq === 'monthly') {
                // Check if today is the same day of month
                if (now.getDate() === createdDate.getDate()) {
                    shouldGenerate = true;
                }
            }

            if (shouldGenerate) {
                // Generate new task
                const newId = crypto.randomUUID();

                // Reset subtasks completion
                let newSubtasksStr = '[]';
                try {
                    const subtasks = task.subtasks ? JSON.parse(task.subtasks) : [];
                    const newSubtasks = subtasks.map((s: any) => ({ ...s, completed: false }));
                    newSubtasksStr = JSON.stringify(newSubtasks);
                } catch (e) {
                    console.error('Error parsing subtasks for task', task.id, e);
                }

                await db.prepare(
                    `INSERT INTO tasks (id, title, description, content, assignee_id, due_date, created_by, frequency, subtasks, status, created_at) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, 'once', ?, 'todo', unixepoch())`
                ).bind(
                    newId,
                    task.title,
                    task.description,
                    task.content,
                    task.assignee_id,
                    todayStart, // due_date is today
                    'system',
                    newSubtasksStr
                ).run();

                // Update last_generated
                await db.prepare(
                    `UPDATE tasks SET last_generated = ? WHERE id = ?`
                ).bind(Math.floor(Date.now() / 1000), task.id).run();

                console.log(`Generated recurring task: ${task.title} (${newId})`);
            }
        }
    } catch (error) {
        console.error('Error in checkRecurringTasks:', error);
    }
}
