import { getAligoConfig, sendAligoMessage, sendAlimTalk } from '../aligo';

// Define event types
export type CampaignTriggerEvent = 'patient_created' | 'consultation_completed' | 'payment_completed' | 'reservation_created';

interface EventPayload {
    patient_id: string | number;
    patient_name: string;
    patient_phone: string;
    [key: string]: any;
}

export class CampaignTriggerService {
    private db: any;
    private env: any;

    constructor(db: any, env: any) {
        this.db = db;
        this.env = env;
    }

    /**
     * Emit an event to trigger matching campaigns
     * This is fire-and-forget in terms of HTTP response, but awaits internally for sending
     */
    async emit(event: CampaignTriggerEvent, payload: EventPayload) {
        console.log(`[CampaignTrigger] Event emitted: ${event}`, payload);

        try {
            // 1. Find campaigns listening to this event
            // Note: DB stores trigger_type='TRIGGER' and trigger_config containing event name
            // Since trigger_config is JSON, we can't easily query matching JSON in SQLite properly without specific functions or LIKE
            // For MVP, we fetch all active TRIGGER campaigns and filter in code.
            const campaigns = await this.db.prepare(`
                SELECT * FROM campaigns 
                WHERE type = 'TRIGGER' 
                AND is_active = 1
            `).all();

            if (!campaigns.results || campaigns.results.length === 0) {
                return;
            }

            const matchedCampaigns = campaigns.results.filter((c: any) => {
                try {
                    const config = JSON.parse(c.trigger_config || '{}');
                    return config.event === event;
                } catch (e) {
                    return false;
                }
            });

            console.log(`[CampaignTrigger] Matched ${matchedCampaigns.length} campaigns`);

            for (const campaign of matchedCampaigns) {
                await this.processCampaign(campaign, payload);
            }

        } catch (e) {
            console.error('[CampaignTrigger] Error:', e);
        }
    }

    private async processCampaign(campaign: any, payload: EventPayload) {
        // 2. Validate Segment (Optional but recommended)
        // If the campaign has a segment, we should check if this user belongs to it?
        // For TRIGGER campaigns, usually the segment is implicit (everyone who does the event) OR explicit filter.
        // If segment_id is present, we check if the user satisfies the segment criteria.
        // This is complex because segment queries are usually "SELECT * FROM patients WHERE ...".
        // To check a specific user, we'd need to wrap it: "SELECT count(*) FROM (segment_query) WHERE id = ?"

        if (campaign.segment_id) {
            const segment = await this.db.prepare("SELECT query_sql FROM segments WHERE id = ?").bind(campaign.segment_id).first();
            if (segment && segment.query_sql) {
                const isMatch = await this.db.prepare(`SELECT count(*) as count FROM (${segment.query_sql}) WHERE id = ?`)
                    .bind(payload.patient_id).first();

                if (!isMatch || isMatch.count === 0) {
                    console.log(`[CampaignTrigger] User ${payload.patient_id} does not match segment for campaign ${campaign.id}`);
                    return;
                }
            }
        }

        // 3. Send Message
        const template = await this.db.prepare("SELECT * FROM message_templates WHERE id = ?").bind(campaign.template_id).first();
        if (!template) return;

        const config = await getAligoConfig(this.env, this.db);
        if (!config) return;

        // Create RUN Record (Trigger runs are 1-1 usually, but good to track)
        const runId = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        await this.db.prepare(`
            INSERT INTO campaign_runs (id, campaign_id, started_at, status, trigger_type, total_count)
            VALUES (?, ?, ?, 'running', 'TRIGGER', 1)
        `).bind(runId, campaign.id, now).run();

        // Content Sub
        let content = template.content || '';
        content = content.replace(/#{이름}|{이름}/g, payload.patient_name || '고객님');
        content = content.replace(/#{휴대폰}|{휴대폰}/g, payload.patient_phone);

        let msgType = 'SMS';
        let result;

        try {
            if ((template.channel === 'ALIMTALK' || template.channel === 'BOTH') && template.alimtalk_code) {
                msgType = 'ALIMTALK';
                let userButtonJson = template.buttons;
                if (userButtonJson) {
                    userButtonJson = userButtonJson.replace(/#{이름}|{이름}/g, payload.patient_name || '');
                    userButtonJson = userButtonJson.replace(/#{휴대폰}|{휴대폰}/g, payload.patient_phone);
                }

                result = await sendAlimTalk(config, {
                    receiver: payload.patient_phone,
                    tpl_code: template.alimtalk_code,
                    senderkey: config.senderKey || '',
                    message_1: content,
                    message: content,
                    subject_1: '알림',
                    failover: 'Y',
                    button_1: userButtonJson || undefined
                });
            } else {
                result = await sendAligoMessage(config, {
                    receiver: payload.patient_phone,
                    msg: content,
                    destination: `${payload.patient_phone}|${payload.patient_name}`,
                    title: '알림'
                });
            }

            // Log
            const rawResult = result as any;
            const isSuccess = (String(result.result_code) === '1') || (rawResult.code !== undefined && Number(rawResult.code) === 0);

            await this.db.prepare(`
                INSERT INTO message_logs (campaign_id, patient_id, patient_name, phone, message_type, content, status, sent_at, type)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'trigger')
            `).bind(
                campaign.id, payload.patient_id, payload.patient_name, payload.patient_phone, msgType, content,
                isSuccess ? 'sent' : 'failed', now
            ).run();

            // Update stats & Run
            await this.db.prepare(`
                UPDATE campaigns SET sent_count = sent_count + ?, failed_count = failed_count + ?, sent_at = ? WHERE id = ?
            `).bind(isSuccess ? 1 : 0, isSuccess ? 0 : 1, now, campaign.id).run();

            await this.db.prepare(`
                UPDATE campaign_runs SET sent_count = ?, failed_count = ?, status = 'completed', completed_at = ? WHERE id = ?
            `).bind(isSuccess ? 1 : 0, isSuccess ? 0 : 1, now, runId).run();

        } catch (e) {
            console.error('[CampaignTrigger] Send Error:', e);
            await this.db.prepare(`
                UPDATE campaign_runs SET status = 'failed', log_details = ?, completed_at = ? WHERE id = ?
            `).bind(String(e), now, runId).run();
        }
    }
}
