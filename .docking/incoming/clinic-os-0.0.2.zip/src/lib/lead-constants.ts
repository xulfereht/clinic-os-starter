
export interface LeadStatusConfig {
    label: string;
    color: string;
    requiresRemote?: boolean;
}

export type LeadStatus =
    | 'new'
    | 'pending'
    | 'consulting'
    | 'closed'
    | 'hold'
    | 'cancelled'
    | 'first_visit_reservation'
    | 'first_visit_walkin'
    | 'remote_reservation'
    | 'first_visit_hold'
    | 'remote_hold'
    | 'return_visit_reservation'
    | 'return_visit_payment'
    | 'return_visit_inquiry';

export const LEAD_STATUS_LABELS: Record<string, LeadStatusConfig> = {
    // Active States
    new: { label: '신규', color: 'bg-red-100 text-red-800' },
    pending: { label: '대기', color: 'bg-orange-100 text-orange-800' },
    consulting: { label: '상담중', color: 'bg-blue-100 text-blue-800' },

    // Outcomes
    closed: { label: '완료(일반)', color: 'bg-slate-100 text-slate-800' },
    hold: { label: '보류', color: 'bg-amber-100 text-amber-800' },
    cancelled: { label: '예약 취소', color: 'bg-slate-200 text-slate-600' },

    // First Visit
    first_visit_reservation: { label: '초진 내원 예약', color: 'bg-emerald-100 text-emerald-800' },
    first_visit_walkin: { label: '초진 워크인 내원 (미예약)', color: 'bg-purple-100 text-purple-800' },
    remote_reservation: { label: '초진 비대면 예약', color: 'bg-cyan-100 text-cyan-800', requiresRemote: true },
    first_visit_hold: { label: '초진 보류', color: 'bg-amber-100 text-amber-800' },
    remote_hold: { label: '비대면 초기 보류', color: 'bg-amber-100 text-amber-800', requiresRemote: true },

    // Return Visit
    return_visit_reservation: { label: '재진 내원 예약', color: 'bg-indigo-100 text-indigo-800' },
    return_visit_payment: { label: '재진 비대면 결제', color: 'bg-indigo-100 text-indigo-800', requiresRemote: true },
    return_visit_inquiry: { label: '재진 단순 문의', color: 'bg-slate-100 text-slate-800' },
};

// Groups for Dropdown/Select UIs
export interface LeadStatusGroup {
    label?: string; // Optional for top-level
    options: string[];
}

export const LEAD_STATUS_GROUPS: LeadStatusGroup[] = [
    {
        options: ['pending', 'consulting']
    },
    {
        label: '초진 (First Visit)',
        options: ['first_visit_reservation', 'first_visit_walkin', 'remote_reservation', 'first_visit_hold']
    },
    {
        label: '재진 (Return Visit)',
        options: ['return_visit_reservation', 'return_visit_payment', 'return_visit_inquiry']
    },
    {
        label: '기타',
        options: ['closed', 'cancelled']
    }
];

// Helper to get dropdown label (handling specific overrides like pending/new merge if needed)
export function getDropdownLabel(status: string): string {
    if (status === 'pending') return '신규/대기';
    if (status === 'consulting') return '상담 중';
    return LEAD_STATUS_LABELS[status]?.label || status;
}
