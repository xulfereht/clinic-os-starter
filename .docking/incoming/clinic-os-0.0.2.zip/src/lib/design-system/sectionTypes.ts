export type Skin =
    | "clinicLight"
    | "wellnessWarm"
    | "dataDark"
    | "hanbangClassic";

export type SectionType =
    | "Hero"
    | "Problem"
    | "Solution"
    | "Pricing"
    | "DoctorIntro"
    | "Mechanism"
    | "FAQ"
    | "TreatableConditions"
    | "RelatedDiagnosis"
    | "RelatedPosts"
    | "RelatedReviews"
    | "FeatureHighlight"
    | "SolutionTypes";

export type SectionTone = "neutral" | "accent" | "elevated" | "dark";

export type CardVariant = "plain" | "soft" | "outlined" | "elevated";

export type IconStyle = "line" | "filled" | "minimal";

export type CardRadius = "sm" | "md" | "lg" | "xl";

export interface SectionStyleTokens {
    /** Section Background Tone */
    tone: SectionTone;

    /** Card Variant */
    cardVariant?: CardVariant;

    /** Card Radius */
    cardRadius?: CardRadius;

    /** Card Shadow Strength */
    cardShadow?: "none" | "soft" | "strong";

    /** Icon Style */
    iconStyle?: IconStyle;

    /** Heading Variant */
    headingVariant?: "default" | "emphasis" | "muted" | "serif";

    /** Accent Role */
    accentRole?: "primary" | "soft";

    /** Extra Classes */
    extraSectionClassNames?: string[];
    extraCardClassNames?: string[];
}
