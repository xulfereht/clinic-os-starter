export type ColorHex = string;

export type ThemeBrandHue = "blue" | "green" | "teal" | "brown";
export type ThemeMode = "light" | "dark";
export type ThemeRounding = "sm" | "md" | "lg";
export type ThemeDensity = "compact" | "normal" | "spacious";
export type ThemeSkin = 'clean' | 'playful' | 'elegant';

export interface ThemeConfig {
    /** Brand Color Family */
    brandHue: ThemeBrandHue;
    /** Light/Dark Mode */
    mode: ThemeMode;
    /** Corner Rounding Style */
    rounding: ThemeRounding;
    /** Spacing Density */
    density: ThemeDensity;
    skin?: ThemeSkin; // Optional for backward compatibility
}

/**
 * Foundation Tokens
 * - Immutable system primitives (Palette, Spacing Scale, Radius Scale)
 */
export interface FoundationTokens {
    colors: {
        blue50: ColorHex;
        blue100: ColorHex;
        blue500: ColorHex;
        blue700: ColorHex;

        green50: ColorHex;
        green500: ColorHex;
        green700: ColorHex;

        teal50: ColorHex;
        teal500: ColorHex;
        teal700: ColorHex;

        brown50: ColorHex;
        brown500: ColorHex;
        brown700: ColorHex;

        gray25: ColorHex;
        gray50: ColorHex;
        gray100: ColorHex;
        gray200: ColorHex;
        gray700: ColorHex;
        gray800: ColorHex;
        gray900: ColorHex;

        red500: ColorHex;
    };
    radius: {
        sm: string;
        md: string;
        lg: string;
        pill: string;
    };
    shadow: {
        none: string;
        soft: string;
        strong: string;
    };
    spacing: {
        xs: string;
        sm: string;
        md: string;
        lg: string;
        xl: string;
    };
    typography: {
        fontSans: string;
        fontSansSoft: string;
        fontSerif: string;
        fontMono: string;
        headingWeight: number;
        bodyWeight: number;
    };
}

/**
 * Semantic Tokens
 * - Context-aware tokens mapped to CSS variables
 */
export interface SemanticTokens {
    // Backgrounds
    bgBody: ColorHex;
    bgSurface: ColorHex;
    surfaceElevated: ColorHex;

    // Text
    textMain: ColorHex;
    textMuted: ColorHex;
    textSubtle: ColorHex;

    // Brand / Accent
    accent: ColorHex;
    accentSoft: ColorHex;
    accentStrong: ColorHex;

    // Legacy Primary (Mapped to Accent for backward compat if needed, or removed)
    // We will keep them for now but map them to accent in themes.ts
    primary: ColorHex;
    primarySoft: ColorHex;
    primaryStrong: ColorHex;

    danger: ColorHex;
    borderSubtle: ColorHex;
}

/**
 * Final Token Bundle
 */
export interface ThemeTokens {
    foundation: FoundationTokens;
    semantic: SemanticTokens;
}
