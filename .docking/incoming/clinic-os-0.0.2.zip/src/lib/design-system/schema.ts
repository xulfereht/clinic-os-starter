import { z } from 'zod';

export const SkinIdSchema = z.enum(['clean', 'playful', 'elegant', 'brutalist', 'clinicLight', 'wellnessWarm', 'dataDark', 'hanbangClassic']);
export type SkinId = z.infer<typeof SkinIdSchema>;

export const ThemeBrandHueSchema = z.enum(['blue', 'green', 'teal', 'brown', 'violet', 'pink', 'red', 'orange', 'yellow', 'gray']);
export type ThemeBrandHue = z.infer<typeof ThemeBrandHueSchema>;

export const ThemeRoundingSchema = z.enum(['none', 'sm', 'md', 'lg', 'full']);
export type ThemeRounding = z.infer<typeof ThemeRoundingSchema>;

export const ThemeDensitySchema = z.enum(['compact', 'normal', 'spacious']);
export type ThemeDensity = z.infer<typeof ThemeDensitySchema>;

export const ThemeModeSchema = z.enum(['light', 'dark']);
export type ThemeMode = z.infer<typeof ThemeModeSchema>;

export const ThemeConfigSchema = z.object({
    skin: SkinIdSchema.default('clean'),
    brandHue: ThemeBrandHueSchema.default('blue'),
    rounding: ThemeRoundingSchema.default('md'),
    density: ThemeDensitySchema.default('normal'),
    mode: ThemeModeSchema.default('light'),
});

export type ThemeConfig = z.infer<typeof ThemeConfigSchema>;

// Default Config
export const DEFAULT_THEME_CONFIG: ThemeConfig = {
    skin: 'clean',
    brandHue: 'blue',
    rounding: 'md',
    density: 'normal',
    mode: 'light',
};
