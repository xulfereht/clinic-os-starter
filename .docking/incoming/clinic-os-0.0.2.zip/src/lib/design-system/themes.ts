import type { ThemeConfig, SkinId } from "./schema";
import type { FoundationTokens, SemanticTokens, ThemeTokens } from "./tokens";
import type { SectionType, SectionStyleTokens } from "./sectionTypes";

/** 1) Foundation: Project-wide Primitives (Palette) */
export const foundationTokens: FoundationTokens = {
    colors: {
        blue50: "#eff6ff",
        blue100: "#dbeafe",
        blue500: "#2563eb",
        blue700: "#1d4ed8",

        green50: "#ecfdf3",
        green500: "#16a34a",
        green700: "#15803d",

        teal50: "#e0f2f1",
        teal500: "#0f766e",
        teal700: "#0d5e57",

        brown50: "#f5f0ea",
        brown500: "#8b5e3c",
        brown700: "#6b4224",

        gray25: "#f9fafb",
        gray50: "#f3f4f6",
        gray100: "#e5e7eb",
        gray200: "#d1d5db",
        gray700: "#374151",
        gray800: "#1f2937",
        gray900: "#111827",

        red500: "#ef4444",
    },
    radius: {
        sm: "0.5rem",
        md: "1rem",
        lg: "1.5rem",
        pill: "999px",
    },
    shadow: {
        none: "none",
        soft: "0 10px 30px rgba(15, 23, 42, 0.08)",
        strong: "0 18px 45px rgba(15, 23, 42, 0.16)",
    },
    spacing: {
        xs: "0.25rem",
        sm: "0.5rem",
        md: "1rem",
        lg: "1.5rem",
        xl: "2rem",
    },
    typography: {
        fontSans: 'Pretendard, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        fontSansSoft: '"Spoqa Han Sans Neo", Pretendard, system-ui, sans-serif',
        fontSerif: '"Noto Serif KR", "Nanum Myeongjo", serif',
        fontMono: '"Roboto Mono", ui-monospace, monospace',
        headingWeight: 800,
        bodyWeight: 400,
    },
};

/** 2) Pure Token Builder */
export function buildThemeTokens(config: ThemeConfig): ThemeTokens {
    const c = foundationTokens.colors;

    // Default Semantic Tokens (Base)
    let semantic: SemanticTokens = {
        bgBody: c.gray25,
        bgSurface: "#ffffff",
        surfaceElevated: "#ffffff",

        textMain: c.gray900,
        textMuted: c.gray700,
        textSubtle: c.gray200,

        accent: c.blue500,
        accentSoft: c.blue100,
        accentStrong: c.blue700,

        primary: c.blue500,
        primarySoft: c.blue100,
        primaryStrong: c.blue700,

        danger: c.red500,
        borderSubtle: c.gray100,
    };

    // --- Apply Skin Overrides ---
    switch (config.skin) {
        case 'clinicLight':
        case 'clean': // Legacy mapping
            semantic.bgBody = "#f8fafc"; // Slate-50
            semantic.bgSurface = "#ffffff";
            semantic.accent = "#334155"; // Slate-700
            semantic.accentSoft = "#f1f5f9"; // Slate-100
            semantic.accentStrong = "#0f172a"; // Slate-900
            break;

        case 'wellnessWarm':
        case 'elegant': // Legacy mapping
            semantic.bgBody = "#faf5ef"; // Cream
            semantic.bgSurface = "#ffffff";
            semantic.surfaceElevated = "#fefaf5";
            semantic.textMain = "#1f2933";
            semantic.textMuted = "#6b5b4b";
            semantic.accent = "#b45309"; // Brown/Coral
            semantic.accentSoft = "#ffedd5";
            semantic.accentStrong = "#92400e";
            semantic.borderSubtle = "#e5ddd0";
            break;

        case 'dataDark':
            semantic.bgBody = "#020617"; // Navy Black
            semantic.bgSurface = "#020617";
            semantic.surfaceElevated = "#020617";
            semantic.textMain = "#e5e7eb";
            semantic.textMuted = "#9ca3af";
            semantic.textSubtle = "#6b7280";
            semantic.accent = "#22d3ee"; // Cyan
            semantic.accentSoft = "rgba(34, 211, 238, 0.16)";
            semantic.accentStrong = "#06b6d4";
            semantic.borderSubtle = "#1e293b";
            semantic.danger = "#fb7185";
            break;

        case 'hanbangClassic':
            semantic.bgBody = "#f5f0ea"; // Paper
            semantic.bgSurface = "#fdfaf5";
            semantic.surfaceElevated = "#fdfaf5";
            semantic.textMain = "#18212b";
            semantic.accent = "#166534"; // Deep Green
            semantic.accentSoft = "#dcfce7";
            semantic.accentStrong = "#14532d";
            semantic.borderSubtle = "#e5ddd0";
            semantic.danger = "#b91c1c";
            break;

        case 'playful': // Legacy
            semantic.accent = c.green500;
            semantic.accentSoft = c.green50;
            semantic.accentStrong = c.green700;
            break;
    }

    // Map Accent to Primary for backward compatibility
    semantic.primary = semantic.accent;
    semantic.primarySoft = semantic.accentSoft;
    semantic.primaryStrong = semantic.accentStrong;

    // --- Apply Brand Hue Override (Optional) ---
    if (config.brandHue && config.skin === 'clean') { // Only override for clean skin usually
        if (config.brandHue === 'green') {
            semantic.accent = c.green500;
            semantic.accentStrong = c.green700;
            semantic.accentSoft = c.green50;
        } else if (config.brandHue === 'teal') {
            semantic.accent = c.teal500;
            semantic.accentStrong = c.teal700;
            semantic.accentSoft = c.teal50;
        } else if (config.brandHue === 'brown') {
            semantic.accent = c.brown500;
            semantic.accentStrong = c.brown700;
            semantic.accentSoft = c.brown50;
        }
        // Sync Primary again
        semantic.primary = semantic.accent;
        semantic.primarySoft = semantic.accentSoft;
        semantic.primaryStrong = semantic.accentStrong;
    }

    // --- Dark Mode Override ---
    if (config.mode === 'dark' && config.skin !== 'dataDark') {
        semantic.bgBody = "#020617";
        semantic.bgSurface = "#0f172a";
        semantic.surfaceElevated = "#1e293b";
        semantic.textMain = c.gray100;
        semantic.textMuted = c.gray200;
        semantic.textSubtle = c.gray700;
        semantic.borderSubtle = "#1e293b";
    }

    return {
        foundation: foundationTokens,
        semantic,
    };
}

/** 3) Section Style Logic */
export function getSectionStyleTokens(
    skin: SkinId,
    sectionType: SectionType,
    index?: number
): SectionStyleTokens {
    // 1. If index is provided, use Dynamic Rhythm strategy for supported skins
    if (typeof index === 'number') {
        return getDynamicSectionStyle(skin, sectionType, index);
    }

    // 2. Fallback to Type-based strategy (Legacy behavior or specific overrides)
    switch (sectionType) {
        case "Hero":
            return styleForHero(skin);
        case "Problem":
            return styleForProblem(skin);
        case "Solution":
            return styleForSolution(skin);
        case "Pricing":
            return styleForPricing(skin);
        case "DoctorIntro":
            return styleForDoctorIntro(skin);
        case "Mechanism":
        case "FeatureHighlight":
        case "SolutionTypes":
        case "FAQ":
        case "TreatableConditions":
        case "RelatedDiagnosis":
        case "RelatedPosts":
        case "RelatedReviews":
            // Default to Problem style if no specific style defined, but Dynamic Rhythm will catch them if index is passed
            return styleForProblem(skin);
        default:
            return {
                tone: "neutral",
                cardVariant: "plain",
                cardRadius: "md",
                cardShadow: "soft",
                iconStyle: "line",
                headingVariant: "default",
                accentRole: "primary",
            };
    }
}

/**
 * Dynamic Rhythm Strategy
 * Calculates style based on position (index) to ensure alternating contrast.
 */
function getDynamicSectionStyle(skin: SkinId, sectionType: SectionType, index: number): SectionStyleTokens {
    const isEven = index % 2 === 0; // 0, 2, 4...

    switch (skin) {
        case "clinicLight":
        case "clean":
            // Rhythm: Neutral (Gray) <-> Elevated (White)
            const tone = isEven ? "neutral" : "elevated";

            // If Bg is Neutral (Gray) -> Cards should be Elevated (White) + Top Deco to pop.
            // If Bg is Elevated (White) -> Cards should be Soft (Subtle Blue) or Outlined to distinguish.
            return {
                tone,
                cardVariant: tone === "neutral" ? "elevated" : "soft",
                cardRadius: "md",
                cardShadow: tone === "neutral" ? "soft" : "none",
                iconStyle: "line",
                headingVariant: "default",
                accentRole: "primary",
                // Add decorative top border for cards on neutral background for that "trendy" look
                extraCardClassNames: tone === "neutral" ? ["card--deco-top"] : [],
            };

        case "wellnessWarm":
        case "elegant":
            // Rhythm: Accent (Warm) <-> Elevated (White/Cream)
            const warmTone = isEven ? "accent" : "elevated";
            return {
                tone: warmTone,
                cardVariant: warmTone === "accent" ? "elevated" : "soft",
                cardRadius: "xl", // Organic Shape
                cardShadow: "soft",
                iconStyle: "filled",
                headingVariant: "serif", // Enforce Serif
                accentRole: "soft",
                // Add organic decoration for cards on warm background
                extraCardClassNames: warmTone === "accent" ? ["card--deco-organic"] : [],
            };

        case "dataDark":
            // Rhythm: Dark (Black) <-> Darker/Elevated (Navy)
            return {
                tone: "dark",
                cardVariant: "outlined",
                cardRadius: "md",
                cardShadow: "strong",
                iconStyle: "minimal",
                headingVariant: "default",
                accentRole: "primary",
                extraSectionClassNames: ["section--problem-data"],
            };

        case "hanbangClassic":
            return {
                tone: isEven ? "neutral" : "elevated",
                cardVariant: isEven ? "outlined" : "plain",
                cardRadius: "sm",
                cardShadow: "soft",
                iconStyle: "line",
                headingVariant: "emphasis",
                accentRole: "primary",
                extraSectionClassNames: ["section--problem-hanbang"],
            };

        default:
            return { tone: "neutral" };
    }
}

function styleForHero(skin: SkinId): SectionStyleTokens {
    switch (skin) {
        case "clinicLight":
        case "clean":
            return {
                tone: "neutral",
                cardVariant: "plain",
                headingVariant: "default",
                accentRole: "primary",
                extraSectionClassNames: ["section--hero-clean"]
            };
        case "wellnessWarm":
        case "elegant":
            return {
                tone: "elevated",
                cardVariant: "soft",
                headingVariant: "emphasis",
                accentRole: "soft",
                extraSectionClassNames: ["section--hero-warm"]
            };
        case "dataDark":
            return {
                tone: "dark",
                cardVariant: "outlined",
                headingVariant: "default",
                accentRole: "primary",
                extraSectionClassNames: ["section--hero-dark"]
            };
        case "hanbangClassic":
            return {
                tone: "neutral",
                cardVariant: "plain",
                headingVariant: "emphasis",
                accentRole: "primary",
                extraSectionClassNames: ["section--hero-classic"]
            };
        default:
            return { tone: "neutral" };
    }
}

function styleForProblem(skin: SkinId): SectionStyleTokens {
    switch (skin) {
        case "clinicLight":
        case "clean":
            return {
                tone: "elevated", // White background to contrast with Gray Hero
                cardVariant: "plain",
                cardRadius: "md",
                cardShadow: "soft",
                iconStyle: "line",
                headingVariant: "default",
                accentRole: "primary",
            };

        case "wellnessWarm":
        case "elegant":
            return {
                tone: "accent",
                cardVariant: "soft",
                cardRadius: "lg",
                cardShadow: "soft",
                iconStyle: "filled",
                headingVariant: "emphasis",
                accentRole: "soft",
            };

        case "dataDark":
            return {
                tone: "dark",
                cardVariant: "outlined",
                cardRadius: "md",
                cardShadow: "strong",
                iconStyle: "minimal",
                headingVariant: "default",
                accentRole: "primary",
                extraSectionClassNames: ["section--problem-data"],
            };

        case "hanbangClassic":
            return {
                tone: "neutral",
                cardVariant: "outlined",
                cardRadius: "sm",
                cardShadow: "soft",
                iconStyle: "line",
                headingVariant: "emphasis",
                accentRole: "primary",
                extraSectionClassNames: ["section--problem-hanbang"],
            };

        default:
            return { tone: "neutral" };
    }
}

function styleForSolution(skin: SkinId): SectionStyleTokens {
    switch (skin) {
        case "clinicLight":
        case "clean":
            return {
                tone: "neutral", // Gray background to alternate with White Problem
                cardVariant: "plain",
                cardRadius: "md",
                cardShadow: "none",
                iconStyle: "line",
                headingVariant: "default",
                accentRole: "primary",
            };
        case "wellnessWarm":
        case "elegant":
            return {
                tone: "elevated",
                cardVariant: "soft",
                headingVariant: "emphasis",
                accentRole: "soft",
            };
        case "dataDark":
            return {
                tone: "dark",
                cardVariant: "outlined",
                headingVariant: "default",
                accentRole: "primary",
            };
        default:
            return { tone: "neutral" };
    }
}

function styleForPricing(skin: SkinId): SectionStyleTokens {
    switch (skin) {
        case "clinicLight":
        case "clean":
            return {
                tone: "neutral",
                cardVariant: "elevated",
                cardRadius: "md",
                cardShadow: "strong",
                iconStyle: "line",
                headingVariant: "default",
                accentRole: "primary",
                extraSectionClassNames: ["section--pricing-comparison"],
            };

        case "wellnessWarm":
        case "elegant":
            return {
                tone: "accent",
                cardVariant: "soft",
                cardRadius: "lg",
                cardShadow: "soft",
                iconStyle: "filled",
                headingVariant: "emphasis",
                accentRole: "soft",
            };

        case "dataDark":
            return {
                tone: "dark",
                cardVariant: "outlined",
                cardRadius: "md",
                cardShadow: "strong",
                iconStyle: "minimal",
                headingVariant: "default",
                accentRole: "primary",
                extraSectionClassNames: ["section--pricing-metrics"],
            };

        case "hanbangClassic":
            return {
                tone: "neutral",
                cardVariant: "plain",
                cardRadius: "sm",
                cardShadow: "soft",
                iconStyle: "line",
                headingVariant: "emphasis",
                accentRole: "primary",
                extraSectionClassNames: ["section--pricing-hanbang"],
            };

        default:
            return { tone: "neutral" };
    }
}
function styleForDoctorIntro(skin: SkinId): SectionStyleTokens {
    switch (skin) {
        case "clinicLight":
        case "clean":
            return {
                tone: "neutral",
                cardVariant: "plain",
                cardRadius: "lg",
                cardShadow: "soft",
                iconStyle: "line",
                headingVariant: "default",
                accentRole: "primary",
                extraCardClassNames: ["card--wide-deco"], // Apply wide decoration
            };

        case "wellnessWarm":
        case "elegant":
            return {
                tone: "elevated",
                cardVariant: "soft",
                cardRadius: "xl",
                cardShadow: "soft",
                iconStyle: "filled",
                headingVariant: "serif",
                accentRole: "soft",
                extraCardClassNames: ["card--wide-deco"], // Keep wide deco for Intro, or maybe organic? Let's stick to wide deco for Intro as it fits the layout better, but maybe with organic radius.
            };

        case "dataDark":
            return {
                tone: "dark",
                cardVariant: "outlined",
                cardRadius: "md",
                cardShadow: "strong",
                iconStyle: "minimal",
                headingVariant: "default",
                accentRole: "primary",
            };

        case "hanbangClassic":
            return {
                tone: "neutral",
                cardVariant: "plain",
                cardRadius: "md",
                cardShadow: "soft",
                iconStyle: "line",
                headingVariant: "emphasis",
                accentRole: "primary",
            };

        default:
            return { tone: "neutral" };
    }
}

