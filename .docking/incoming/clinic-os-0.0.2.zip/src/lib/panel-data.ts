export interface SurveyQuestion {
    id: string;
    type: 'text' | 'radio' | 'checkbox' | 'nrs' | 'textarea' | 'info' | 'time';
    label: string; // Internal label
    question: string; // User facing question
    description?: string;
    options?: { value: string | number; label: string; score?: Record<string, number> }[];
    min?: number;
    max?: number;
    step?: number;
    required?: boolean;
}

// --- Common Modules ---

export const INTAKE_BASIC_QUESTIONS: SurveyQuestion[] = [
    {
        id: 'intro',
        type: 'info',
        label: '시작하기',
        question: '진료를 시작하기 전,\n현재 상태를 파악하기 위한 설문입니다.',
        description: '약 3분 정도 소요됩니다. 편안한 마음으로 답변해 주세요.'
    }
];

// --- Diet Panel ---

export const DIET_SPECIFIC_QUESTIONS: SurveyQuestion[] = [
    {
        id: 'current_weight',
        type: 'text',
        label: '현재 체중',
        question: '현재 체중은 몇 kg 인가요?',
        description: '소수점 첫째 자리까지 적어주시면 더 좋아요.',
        required: true
    },
    {
        id: 'height',
        type: 'text',
        label: '키',
        question: '키는 몇 cm 인가요?',
        required: true
    },
    {
        id: 'target_weight',
        type: 'text',
        label: '목표 체중',
        question: '이번 프로그램을 통해\n몇 kg까지 감량하고 싶으신가요?',
        required: true
    },
    {
        id: 'diet_history',
        type: 'radio',
        label: '다이어트 경험',
        question: '이전에도 다이어트를 해보신 적이 있나요?',
        options: [
            { value: 'none', label: '이번이 처음이에요' },
            { value: '1-3', label: '1~3회 정도 해봤어요' },
            { value: 'many', label: '수도 없이 많이 해봤어요' },
            { value: 'always', label: '365일 다이어트 중이에요' }
        ]
    },
    {
        id: 'meal_regularity',
        type: 'radio',
        label: '식사 규칙성',
        question: '평소 식사는 규칙적으로 하시나요?',
        options: [
            { value: 'regular', label: '하루 3끼 규칙적으로 먹어요' },
            { value: 'irregular', label: '끼니를 자주 거르거나 불규칙해요' },
            { value: 'skip_breakfast', label: '아침은 거르고 점심/저녁만 먹어요' },
            { value: 'late_night', label: '저녁을 늦게 먹거나 야식을 자주 먹어요' }
        ]
    },
    {
        id: 'snack_habit',
        type: 'radio',
        label: '간식 습관',
        question: '식사 외에 간식이나 달콤한 음료를\n얼마나 자주 드시나요?',
        options: [
            { value: 'rarely', label: '거의 안 먹어요' },
            { value: 'sometimes', label: '가끔 생각날 때 먹어요' },
            { value: 'often', label: '하루 1번 이상은 꼭 먹어요' },
            { value: 'addicted', label: '습관적으로 계속 먹게 돼요' }
        ]
    },
    {
        id: 'alcohol_habit',
        type: 'radio',
        label: '음주 습관',
        question: '술은 일주일에 몇 번 정도 드시나요?',
        options: [
            { value: 'none', label: '안 마셔요' },
            { value: '1-2', label: '주 1~2회 정도' },
            { value: '3-4', label: '주 3~4회 정도' },
            { value: 'everyday', label: '거의 매일 마셔요' }
        ]
    },
    {
        id: 'activity_vigorous',
        type: 'radio',
        label: '고강도 운동',
        question: '평소 숨이 헐떡거릴 정도의 힘든 운동을\n일주일에 며칠이나 하시나요?',
        description: '예: 달리기, 에어로빅, 무거운 물건 나르기 등',
        options: [
            { value: '0', label: '전혀 안 해요' },
            { value: '1-2', label: '1~2일' },
            { value: '3-4', label: '3~4일' },
            { value: '5+', label: '5일 이상' }
        ]
    },
    {
        id: 'activity_moderate',
        type: 'radio',
        label: '중강도 운동',
        question: '숨이 약간 찰 정도의 운동은\n일주일에 며칠 하시나요?',
        description: '예: 빠르게 걷기, 가벼운 등산, 자전거 타기 등',
        options: [
            { value: '0', label: '전혀 안 해요' },
            { value: '1-2', label: '1~2일' },
            { value: '3-4', label: '3~4일' },
            { value: '5+', label: '5일 이상' }
        ]
    },
    {
        id: 'activity_walking',
        type: 'radio',
        label: '걷기',
        question: '운동 목적이 아니더라도,\n하루에 걷는 시간은 총 얼마나 되나요?',
        options: [
            { value: 'under_30', label: '30분 미만' },
            { value: '30-60', label: '30분 ~ 1시간' },
            { value: 'over_60', label: '1시간 이상' }
        ]
    },
    {
        id: 'nrs_stress',
        type: 'nrs',
        label: '스트레스',
        question: '최근 한 달간 느끼신\n전반적인 스트레스는 어느 정도인가요?',
        description: '0점은 스트레스 없음, 10점은 감당하기 힘든 극심한 스트레스입니다.',
        min: 0,
        max: 10
    },
    {
        id: 'nrs_body_image',
        type: 'nrs',
        label: '체형 만족도',
        question: '현재 자신의 몸매나 체중에 대해\n얼마나 스트레스를 받으시나요?',
        description: '0점은 전혀 신경 안 씀, 10점은 매우 심한 스트레스/강박을 의미합니다.',
        min: 0,
        max: 10
    }
];

// --- Sleep Panel ---

export const SLEEP_QUESTIONS: SurveyQuestion[] = [
    ...INTAKE_BASIC_QUESTIONS,
    {
        id: 'sleep_intro',
        type: 'info',
        label: '수면 설문 시작',
        question: '수면의 질과 패턴을 파악하기 위한 설문입니다.',
        description: '최근 2주간의 상태를 기준으로 답변해 주세요.'
    },
    // Section A: Sleep Structure & Quantity
    {
        id: 'bed_time',
        type: 'time',
        label: '취침 시각',
        question: '평일 기준,\n보통 몇 시쯤 잠자리에 드나요?',
        required: true
    },
    {
        id: 'wake_time',
        type: 'time',
        label: '기상 시각',
        question: '평일 기준,\n아침에 보통 몇 시쯤 일어나나요?',
        required: true
    },
    {
        id: 'sleep_onset',
        type: 'radio',
        label: '입면 소요 시간',
        question: '잠자리에 누운 뒤,\n잠이 들기까지 보통 얼마나 걸리나요?',
        options: [
            { value: 'lt_15', label: '15분 이내', score: { sleep_onset: 0 } },
            { value: '16_30', label: '16–30분', score: { sleep_onset: 1 } },
            { value: '31_60', label: '31–60분', score: { sleep_onset: 2 } },
            { value: 'gt_60', label: '60분 이상', score: { sleep_onset: 3 } }
        ]
    },
    {
        id: 'wake_count',
        type: 'radio',
        label: '중도 각성 횟수',
        question: '밤사이 깨는 횟수는 어느 정도인가요? (평균)',
        options: [
            { value: 'none', label: '거의 깨지 않는다', score: { sleep_maintenance: 0 } },
            { value: 'once', label: '1회', score: { sleep_maintenance: 1 } },
            { value: 'two_three', label: '2–3회', score: { sleep_maintenance: 2 } },
            { value: 'four_plus', label: '4회 이상', score: { sleep_maintenance: 3 } }
        ]
    },
    {
        id: 'wake_duration',
        type: 'radio',
        label: '재입면 소요 시간',
        question: '한 번 깼을 때,\n다시 잠들기까지 보통 얼마나 걸리나요?',
        options: [
            { value: 'lt_10', label: '10분 이내', score: { sleep_maintenance: 0 } },
            { value: '11_30', label: '11–30분', score: { sleep_maintenance: 1 } },
            { value: '31_60', label: '31–60분', score: { sleep_maintenance: 2 } },
            { value: 'gt_60', label: '60분 이상', score: { sleep_maintenance: 3 } }
        ]
    },
    {
        id: 'total_sleep',
        type: 'radio',
        label: '총 수면 시간',
        question: '밤에 자는 총 수면 시간은 어느 정도인가요? (평균)',
        options: [
            { value: 'lt_4h', label: '4시간 미만', score: { sleep_duration_flag: 4 } },
            { value: '4_5h', label: '4–5시간', score: { sleep_duration_flag: 3 } },
            { value: '5_6h', label: '5–6시간', score: { sleep_duration_flag: 2 } },
            { value: '6_7h', label: '6–7시간', score: { sleep_duration_flag: 1 } },
            { value: '7_8h', label: '7–8시간', score: { sleep_duration_flag: 0 } },
            { value: 'gt_8h', label: '8시간 이상', score: { sleep_duration_flag: 1 } }
        ]
    },
    // Section B: Subjective Quality & Day Function
    {
        id: 'sleep_satisfaction',
        type: 'nrs',
        label: '수면 만족도',
        question: '지난 2주 동안,\n전체적인 수면의 질에 얼마나 만족하셨나요?',
        description: '0점은 매우 불만족, 10점은 매우 만족입니다.',
        min: 0,
        max: 10
    },
    {
        id: 'daytime_fatigue',
        type: 'radio',
        label: '주간 졸림/피로',
        question: '지난 2주 동안,\n낮 시간에 피로/졸림을 얼마나 자주 느끼셨나요?',
        options: [
            { value: 'rare', label: '거의 없다', score: { daytime_impairment: 0 } },
            { value: 'sometimes', label: '가끔 있다', score: { daytime_impairment: 1 } },
            { value: 'often', label: '자주 있다', score: { daytime_impairment: 2 } },
            { value: 'almost_everyday', label: '거의 매일 있다', score: { daytime_impairment: 3 } }
        ]
    },
    {
        id: 'daytime_impairment',
        type: 'nrs',
        label: '일상 기능 방해',
        question: '수면 문제 때문에 일/집안일/학업 등\n일상 기능이 방해받는 정도는 어느 정도인가요?',
        description: '0점은 전혀 방해 없음, 10점은 매우 심한 방해를 의미합니다.',
        min: 0,
        max: 10
    },
    {
        id: 'mental_impact',
        type: 'radio',
        label: '정서적 영향',
        question: '잠 문제로 인해 기분이 예민/우울/불안해지는 것을\n어느 정도 느끼시나요?',
        options: [
            { value: 'not_at_all', label: '전혀 아니다', score: { mental_impact: 0 } },
            { value: 'a_little', label: '약간 그렇다', score: { mental_impact: 1 } },
            { value: 'quite', label: '상당히 그렇다', score: { mental_impact: 2 } },
            { value: 'very', label: '매우 그렇다', score: { mental_impact: 3 } }
        ]
    },
    // Section C: Lifestyle & Risk Factors
    {
        id: 'screen_time',
        type: 'radio',
        label: '취침 전 전자기기',
        question: '잠자기 전 2시간 이내\n스마트폰/TV/PC 화면을 보는 시간은 어느 정도인가요?',
        options: [
            { value: 'none', label: '거의 안 본다', score: { sleep_hygiene: 0 } },
            { value: 'lt_30m', label: '30분 이내', score: { sleep_hygiene: 1 } },
            { value: '30_60m', label: '30분–1시간', score: { sleep_hygiene: 2 } },
            { value: 'gt_60m', label: '1시간 이상', score: { sleep_hygiene: 3 } }
        ]
    },
    {
        id: 'caffeine_intake',
        type: 'radio',
        label: '오후 카페인 섭취',
        question: '오후 4시 이후 카페인(커피, 에너지드링크 등)\n섭취 빈도는 어느 정도인가요?',
        options: [
            { value: 'rare', label: '거의 없다', score: { sleep_hygiene: 0 } },
            { value: 'weekly_1_2', label: '주 1–2회', score: { sleep_hygiene: 1 } },
            { value: 'weekly_3_5', label: '주 3–5회', score: { sleep_hygiene: 2 } },
            { value: 'almost_daily', label: '거의 매일', score: { sleep_hygiene: 3 } }
        ]
    },
    {
        id: 'alcohol_intake',
        type: 'radio',
        label: '취침 전 음주',
        question: '잠자기 전 3시간 이내\n음주 빈도는 어느 정도인가요?',
        options: [
            { value: 'rare', label: '거의 없다', score: { sleep_hygiene: 0 } },
            { value: 'weekly_1', label: '주 1회 이하', score: { sleep_hygiene: 1 } },
            { value: 'weekly_2_3', label: '주 2–3회', score: { sleep_hygiene: 2 } },
            { value: 'weekly_4_plus', label: '주 4회 이상', score: { sleep_hygiene: 3 } }
        ]
    },
    {
        id: 'snoring_apnea',
        type: 'radio',
        label: '코골이/무호흡',
        question: '주변에서 코골이나 숨 멈춤(무호흡)에 대해\n들으신 적이 있나요?',
        options: [
            { value: 'none', label: '없다' },
            { value: 'snoring', label: '코골이만 있다고 한다' },
            { value: 'apnea', label: '숨이 멎는 것 같다고 한다' }
        ]
    },
    {
        id: 'sleep_medication',
        type: 'radio',
        label: '수면제 복용',
        question: '현재 수면제나 기타 수면에 영향을 줄 수 있는 약을\n복용 중인가요?',
        options: [
            { value: 'no', label: '아니다' },
            { value: 'sometimes', label: '가끔 복용한다 (주 1–2회)' },
            { value: 'frequent', label: '자주 복용한다 (주 3회 이상)' }
        ]
    }
];

// --- Mental Panel ---

export const MENTAL_QUESTIONS: SurveyQuestion[] = [
    ...INTAKE_BASIC_QUESTIONS,
    {
        id: 'mental_intro',
        type: 'info',
        label: '신경정신 설문 시작',
        question: '정신 건강 상태를 파악하기 위한 설문입니다.',
        description: '최근 2주간의 상태를 기준으로 답변해 주세요.'
    },
    // PHQ-9 (Depression)
    {
        id: 'phq_1',
        type: 'radio',
        label: '흥미/즐거움',
        question: '일을 하는 데에 흥미나 재미가 거의 없었나요?',
        options: [
            { value: '0', label: '전혀 아님' },
            { value: '1', label: '며칠 동안' },
            { value: '2', label: '2주 중 절반 이상' },
            { value: '3', label: '거의 매일' }
        ]
    },
    {
        id: 'phq_2',
        type: 'radio',
        label: '우울감',
        question: '가라앉은 느낌, 우울감 혹은 절망감을 느꼈나요?',
        options: [
            { value: '0', label: '전혀 아님' },
            { value: '1', label: '며칠 동안' },
            { value: '2', label: '2주 중 절반 이상' },
            { value: '3', label: '거의 매일' }
        ]
    },
    {
        id: 'phq_9',
        type: 'radio',
        label: '자해 충동',
        question: '차라리 죽는 것이 낫겠다고 생각하거나,\n자해할 생각을 했나요?',
        options: [
            { value: '0', label: '전혀 아님' },
            { value: '1', label: '며칠 동안' },
            { value: '2', label: '2주 중 절반 이상' },
            { value: '3', label: '거의 매일' }
        ]
    },
    // GAD-7 (Anxiety)
    {
        id: 'gad_1',
        type: 'radio',
        label: '불안/초조',
        question: '여러 날 동안 불안하거나 초조함을 느꼈나요?',
        options: [
            { value: '0', label: '전혀 아님' },
            { value: '1', label: '며칠 동안' },
            { value: '2', label: '2주 중 절반 이상' },
            { value: '3', label: '거의 매일' }
        ]
    },
    {
        id: 'gad_2',
        type: 'radio',
        label: '걱정 조절',
        question: '걱정을 멈추거나 조절하기 어려웠나요?',
        options: [
            { value: '0', label: '전혀 아님' },
            { value: '1', label: '며칠 동안' },
            { value: '2', label: '2주 중 절반 이상' },
            { value: '3', label: '거의 매일' }
        ]
    }
];

// --- Pain Panel ---

export const PAIN_QUESTIONS: SurveyQuestion[] = [
    ...INTAKE_BASIC_QUESTIONS,
    {
        id: 'pain_area',
        type: 'text',
        label: '통증 부위',
        question: '가장 아픈 부위는 어디인가요?',
        description: '예: 오른쪽 어깨, 허리 중앙, 왼쪽 무릎 등',
        required: true
    },
    {
        id: 'pain_duration',
        type: 'radio',
        label: '통증 기간',
        question: '언제부터 아프기 시작했나요?',
        options: [
            { value: 'acute', label: '최근 1주일 이내' },
            { value: 'subacute', label: '1주일 ~ 1달' },
            { value: 'chronic_short', label: '1달 ~ 3달' },
            { value: 'chronic_long', label: '3달 이상' }
        ]
    },
    {
        id: 'nrs_pain_current',
        type: 'nrs',
        label: '현재 통증',
        question: '지금 이 순간의 통증은 어느 정도인가요?',
        description: '0점은 통증 없음, 10점은 상상할 수 있는 가장 극심한 고통입니다.',
        min: 0,
        max: 10
    },
    {
        id: 'nrs_pain_worst',
        type: 'nrs',
        label: '최악의 통증',
        question: '최근 1주일 중 가장 아팠을 때는 어느 정도였나요?',
        description: '0점은 통증 없음, 10점은 상상할 수 있는 가장 극심한 고통입니다.',
        min: 0,
        max: 10
    },
    {
        id: 'pain_nature',
        type: 'radio',
        label: '통증 양상',
        question: '어떤 느낌으로 아픈가요?',
        options: [
            { value: 'sharp', label: '날카롭게 찌르는 듯함' },
            { value: 'dull', label: '묵직하고 뻐근함' },
            { value: 'burning', label: '화끈거리고 타는 듯함' },
            { value: 'numb', label: '저리고 감각이 둔함' },
            { value: 'throbbing', label: '욱신거림' }
        ]
    }
];

// --- Skin Panel ---

export const SKIN_QUESTIONS: SurveyQuestion[] = [
    ...INTAKE_BASIC_QUESTIONS,

    {
        id: 'skin_area',
        type: 'text',
        label: '증상 부위',
        question: '피부 증상이 있는 부위는 어디인가요?',
        description: '예: 얼굴 전체, 팔 안쪽 접히는 곳, 목 뒤 등',
        required: true
    },
    {
        id: 'nrs_itch',
        type: 'nrs',
        label: '가려움증',
        question: '최근 1주일간 가려움증은 어느 정도였나요?',
        description: '0점은 가려움 없음, 10점은 참을 수 없는 극심한 가려움입니다.',
        min: 0,
        max: 10
    },
    {
        id: 'nrs_sleep_disturb',
        type: 'nrs',
        label: '수면 방해',
        question: '가려움증으로 인해 잠을 설치는 정도는 어떤가요?',
        description: '0점은 전혀 방해받지 않음, 10점은 가려워서 한숨도 못 잠을 의미합니다.',
        min: 0,
        max: 10
    },
    // DLQI Simplified
    {
        id: 'dlqi_symptom',
        type: 'radio',
        label: '증상 불편감',
        question: '피부 때문에 따갑거나 아프거나 가려웠나요?',
        options: [
            { value: '0', label: '전혀 없음' },
            { value: '1', label: '약간' },
            { value: '2', label: '많이' },
            { value: '3', label: '매우 많이' }
        ]
    },
    {
        id: 'dlqi_feeling',
        type: 'radio',
        label: '심리적 영향',
        question: '피부 때문에 창피하거나 의식이 되었나요?',
        options: [
            { value: '0', label: '전혀 없음' },
            { value: '1', label: '약간' },
            { value: '2', label: '많이' },
            { value: '3', label: '매우 많이' }
        ]
    },
    {
        id: 'dlqi_daily',
        type: 'radio',
        label: '일상 생활',
        question: '피부 문제로 쇼핑, 집안일 등 일상생활에 지장이 있었나요?',
        options: [
            { value: '0', label: '전혀 없음' },
            { value: '1', label: '약간' },
            { value: '2', label: '많이' },
            { value: '3', label: '매우 많이' }
        ]
    }
];

export const PANEL_QUESTIONS: Record<string, SurveyQuestion[]> = {
    'diet_initial': [...INTAKE_BASIC_QUESTIONS, ...DIET_SPECIFIC_QUESTIONS],
    'sleep_initial': SLEEP_QUESTIONS,
    'mental_initial': MENTAL_QUESTIONS,
    'pain_initial': PAIN_QUESTIONS,
    'skin_initial': SKIN_QUESTIONS
};
