export interface Holiday {
    date: string;
    description: string;
}

export const KOREAN_HOLIDAYS_2025: Holiday[] = [
    { date: '2025-01-01', description: '신정' },
    { date: '2025-01-28', description: '설날 연휴' },
    { date: '2025-01-29', description: '설날' },
    { date: '2025-01-30', description: '설날 연휴' },
    { date: '2025-03-01', description: '삼일절' },
    { date: '2025-03-03', description: '대체공휴일(삼일절)' },
    { date: '2025-05-05', description: '어린이날' },
    { date: '2025-05-06', description: '대체공휴일(어린이날)' },
    { date: '2025-06-06', description: '현충일' },
    { date: '2025-08-15', description: '광복절' },
    { date: '2025-10-03', description: '개천절' },
    { date: '2025-10-05', description: '추석 연휴' },
    { date: '2025-10-06', description: '추석' },
    { date: '2025-10-07', description: '추석 연휴' },
    { date: '2025-10-08', description: '대체공휴일(추석)' },
    { date: '2025-10-09', description: '한글날' },
    { date: '2025-12-25', description: '성탄절' },
];

export const KOREAN_HOLIDAYS_2026: Holiday[] = [
    { date: '2026-01-01', description: '신정' },
    { date: '2026-02-16', description: '설날 연휴' },
    { date: '2026-02-17', description: '설날' },
    { date: '2026-02-18', description: '설날 연휴' },
    { date: '2026-03-01', description: '삼일절' },
    { date: '2026-03-02', description: '대체공휴일(삼일절)' },
    { date: '2026-05-05', description: '어린이날' },
    { date: '2026-05-24', description: '석가탄신일' },
    { date: '2026-05-25', description: '대체공휴일(석가탄신일)' },
    { date: '2026-06-06', description: '현충일' },
    { date: '2026-08-15', description: '광복절' },
    { date: '2026-08-17', description: '대체공휴일(광복절)' },
    { date: '2026-09-24', description: '추석 연휴' },
    { date: '2026-09-25', description: '추석' },
    { date: '2026-09-26', description: '추석 연휴' },
    { date: '2026-10-03', description: '개천절' },
    { date: '2026-10-05', description: '대체공휴일(개천절)' },
    { date: '2026-10-09', description: '한글날' },
    { date: '2026-12-25', description: '성탄절' },
];

export function getHolidaysForYear(year: number): Holiday[] {
    if (year === 2025) {
        return KOREAN_HOLIDAYS_2025;
    }
    if (year === 2026) {
        return KOREAN_HOLIDAYS_2026;
    }
    return [];
}

