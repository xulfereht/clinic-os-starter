import type { D1Database } from '@cloudflare/workers-types';

export interface Topic {
    id?: number;
    slug: string;
    title: string;
    summary?: string;
    thumbnail_url?: string;
    manager_id?: string;
    supervisor_id?: string;
    related_program_id?: string;
    config?: any; // JSON
    translations?: string; // JSON
    created_at?: number;
    updated_at?: number;
}

export interface FAQItem {
    id?: number;
    topic_id: number;
    condition_id?: number; // NEW: Link to condition
    category?: string; // Legacy - now use cluster
    cluster?: string; // NEW: Renamed from category
    slug?: string; // NEW: URL-friendly identifier
    question: string;
    answer_short?: string;
    answer_detail?: string;
    tags?: string[]; // Parsed JSON
    author_id?: string;
    supervisor_id?: string;
    status: 'draft' | 'review' | 'published';
    translations?: string; // JSON
    view_count?: number;
    created_at?: number;
    updated_at?: number;
    last_reviewed_at?: number;
}

export interface Condition {
    id?: number;
    topic_id: number;
    slug: string;
    name: string;
    name_en?: string;
    description?: string;
    icon?: string;
    display_order?: number;
    faq_count?: number;
    created_at?: number;
}


export class AEOStore {
    constructor(private db: D1Database) { }

    // --- TOPICS ---
    async getAllTopics() {
        const { results } = await this.db.prepare(`
            SELECT t.*, p.sections as program_sections, p.is_visible as program_visible
            FROM topics t
            LEFT JOIN programs p ON t.related_program_id = p.id
            WHERE (t.related_program_id IS NULL OR t.related_program_id = '') OR (p.is_visible = 1)
            ORDER BY t.updated_at DESC
        `).all();

        return results?.map(row => {
            const topic = this.parseTopic(row);
            // Dynamic Image Override from Program Hero
            if (row.program_sections) {
                try {
                    const sections = JSON.parse(row.program_sections as string);
                    const hero = sections.find((s: any) => s.type === 'Hero' || s.id === 'hero_main');
                    if (hero && hero.image) {
                        // console.log(`[AEOStore] Overriding thumbnail for ${row.slug} with ${hero.image}`);
                        topic.thumbnail_url = hero.image;
                    }
                } catch (e) {
                    console.error(`[AEOStore] Failed to parse sections for ${row.related_program_id}`, e);
                }
            } else {
                // console.log(`[AEOStore] No sections found for ${row.slug} (program: ${row.related_program_id})`);
            }
            return topic;
        }) || [];
    }

    async getTopicBySlug(slug: string) {
        const { results } = await this.db.prepare(`
            SELECT t.*, p.sections as program_sections
            FROM topics t
            LEFT JOIN programs p ON t.related_program_id = p.id
            WHERE t.slug = ?
        `).bind(slug).all();

        const row = results?.[0];
        if (!row) return null;

        const topic = this.parseTopic(row);

        // Dynamic Image Override from Program Hero (same logic as getAllTopics)
        if (!topic.thumbnail_url && row.program_sections) {
            try {
                const sections = JSON.parse(row.program_sections as string);
                const hero = sections.find((s: any) => s.type === 'Hero' || s.id === 'hero_main');
                if (hero && hero.image) {
                    topic.thumbnail_url = hero.image;
                }
            } catch (e) {
                console.error(`[AEOStore] Failed to parse sections for topic ${slug}`, e);
            }
        }

        return topic;
    }

    async createTopic(data: Topic) {
        const result = await this.db.prepare(`
            INSERT INTO topics (slug, title, summary, thumbnail_url, manager_id, supervisor_id, related_program_id, config, translations)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            data.slug, data.title, data.summary, data.thumbnail_url,
            data.manager_id, data.supervisor_id, data.related_program_id,
            JSON.stringify(data.config || {}),
            data.translations || '{}'
        ).run();
        return result.meta.last_row_id;
    }

    async updateTopic(id: number, data: Partial<Topic>) {
        await this.db.prepare(`
            UPDATE topics SET 
                title = COALESCE(?, title),
                summary = COALESCE(?, summary),
                thumbnail_url = COALESCE(?, thumbnail_url),
                related_program_id = COALESCE(?, related_program_id),
                supervisor_id = COALESCE(?, supervisor_id),
                config = COALESCE(?, config),
                translations = COALESCE(?, translations),
                updated_at = unixepoch()
            WHERE id = ?
        `).bind(
            data.title, data.summary, data.thumbnail_url,
            data.related_program_id, data.supervisor_id,
            data.config ? JSON.stringify(data.config) : null,
            data.translations,
            id
        ).run();
    }

    // --- FAQs ---
    async getFAQsByTopic(topicId: number, status = 'published') {
        let query = `
            SELECT f.*, c.slug as condition_slug
            FROM faq_items f
            LEFT JOIN topic_conditions c ON f.condition_id = c.id
            WHERE f.topic_id = ?
        `;
        const params: any[] = [topicId];

        if (status !== 'all') {
            query += " AND f.status = ?";
            params.push(status);
        }

        query += " ORDER BY f.category ASC, f.created_at ASC";
        const { results } = await this.db.prepare(query).bind(...params).all();
        return results?.map(this.parseFAQ) || [];
    }

    async getFAQById(id: number) {
        const faq = await this.db.prepare("SELECT * FROM faq_items WHERE id = ?").bind(id).first();
        return faq ? this.parseFAQ(faq) : null;
    }

    async createFAQ(data: FAQItem) {
        const res = await this.db.prepare(`
            INSERT INTO faq_items (
                topic_id, category, question, answer_short, answer_detail, tags, 
                author_id, supervisor_id, status, translations, last_reviewed_at,
                condition_id, slug, cluster
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, unixepoch(), ?, ?, ?)
        `).bind(
            data.topic_id, data.category, data.question, data.answer_short, data.answer_detail,
            JSON.stringify(data.tags || []), data.author_id, data.supervisor_id,
            data.status, data.translations || '{}',
            data.condition_id || null, data.slug || null, data.cluster || null
        ).run();
        return res.meta.last_row_id;
    }

    async updateFAQ(id: number, data: Partial<FAQItem>) {
        await this.db.prepare(`
            UPDATE faq_items SET 
                category = COALESCE(?, category),
                question = COALESCE(?, question),
                answer_short = COALESCE(?, answer_short),
                answer_detail = COALESCE(?, answer_detail),
                tags = COALESCE(?, tags),
                status = COALESCE(?, status),
                translations = COALESCE(?, translations),
                condition_id = COALESCE(?, condition_id),
                slug = COALESCE(?, slug),
                cluster = COALESCE(?, cluster),
                updated_at = unixepoch()
            WHERE id = ?
        `).bind(
            data.category,
            data.question, data.answer_short, data.answer_detail,
            data.tags ? JSON.stringify(data.tags) : null,
            data.status,
            data.translations,
            data.condition_id, data.slug, data.cluster,
            id
        ).run();
    }

    // --- CONDITIONS ---
    async getConditionsByTopic(topicId: number): Promise<Condition[]> {
        const { results } = await this.db.prepare(`
            SELECT c.*, 
                   (SELECT COUNT(*) FROM faq_items f WHERE f.condition_id = c.id AND f.status = 'published') as faq_count
            FROM topic_conditions c
            WHERE c.topic_id = ?
            ORDER BY c.display_order ASC
        `).bind(topicId).all();
        return (results as unknown as Condition[]) || [];
    }

    async getConditionBySlug(slug: string): Promise<Condition | null> {
        const condition = await this.db.prepare(
            "SELECT * FROM topic_conditions WHERE slug = ?"
        ).bind(slug).first();
        return condition as Condition | null;
    }

    async getFAQsByCondition(conditionId: number, status = 'published'): Promise<FAQItem[]> {
        let query = "SELECT * FROM faq_items WHERE condition_id = ?";
        const params: any[] = [conditionId];

        if (status !== 'all') {
            query += " AND status = ?";
            params.push(status);
        }

        query += " ORDER BY cluster ASC, created_at ASC";
        const { results } = await this.db.prepare(query).bind(...params).all();
        return results?.map(this.parseFAQ) || [];
    }

    async getFAQBySlug(slug: string): Promise<FAQItem | null> {
        const faq = await this.db.prepare(
            "SELECT * FROM faq_items WHERE slug = ?"
        ).bind(slug).first();
        return faq ? this.parseFAQ(faq) : null;
    }

    // --- Helpers ---
    private parseTopic(row: any): Topic {
        try {
            return { ...row, config: JSON.parse(row.config || '{}') };
        } catch { return row; }
    }

    private parseFAQ(row: any): FAQItem {
        try {
            return { ...row, tags: JSON.parse(row.tags || '[]') };
        } catch { return row; }
    }
}
