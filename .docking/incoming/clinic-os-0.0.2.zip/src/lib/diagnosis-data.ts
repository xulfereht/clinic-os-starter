export type ClinicId =
    | 'diet'
    | 'skin'
    | 'digestive'
    | 'pain'
    | 'women'
    | 'pediatric'
    | 'neuro'
    | 'wellness'
    | 'head';

export type ResultLevel = 'low' | 'medium' | 'high';

export interface DiagnosisOption {
    value?: string; // Optional for backward compatibility or future use
    label: string;
    score: number;
    redFlag?: boolean;
}

export interface DiagnosisQuestion {
    id: string;
    text: string;
    options: DiagnosisOption[];
}

export interface DiagnosisResult {
    level: ResultLevel;
    title: string;
    subtitle?: string;
    description: string;
    tags: string[];
    minScore: number;
    maxScore: number;
    ctaHeadline?: string;
    ctaBody?: string;
    ctaLink?: string;
}

export interface DiagnosisProgramVariant {
    id: string;
    name: string;
    questionOverrides?: {
        [questionId: string]: Partial<DiagnosisQuestion>;
    };
    resultOverrides?: {
        [level in ResultLevel]?: Partial<DiagnosisResult>;
    };
}

export interface ClinicDiagnosisConfig {
    clinicId: ClinicId;
    title: string;
    disclaimer: string;
    questions: DiagnosisQuestion[];
    results: DiagnosisResult[];
    programVariants?: DiagnosisProgramVariant[];
}

export const DIAGNOSIS_DATA: Record<string, ClinicDiagnosisConfig> = {
    diet: {
        clinicId: 'diet',
        title: "비대면 다이어트 미니 진단",
        disclaimer: "이 자가 체크는 간단한 참고 도구이며, 한의학적 진단이나 치료를 대신하지 않습니다.",
        questions: [
            {
                id: "q1",
                text: "최근 3개월 동안 체중 변화가 어느 정도 있었나요?",
                options: [
                    { label: "거의 변화 없음 (±1kg 이내)", score: 0 },
                    { label: "1~3kg 증가", score: 2 },
                    { label: "3~5kg 증가", score: 3 },
                    { label: "5kg 이상 증가", score: 5, redFlag: true }
                ]
            },
            {
                id: "q2",
                text: "가장 자주 반복되는 식습관 패턴을 골라주세요.",
                options: [
                    { label: "특별히 문제 되는 습관은 거의 없다", score: 0 },
                    { label: "군것질/단 음식이 잦다 (하루 2회 이상)", score: 2 },
                    { label: "야식/늦은 시간 식사가 잦다 (주 3회 이상)", score: 3 },
                    { label: "폭식/과식, 음주 후 과식이 잦다 (주 1회 이상)", score: 5 }
                ]
            },
            {
                id: "q3",
                text: "지금까지의 다이어트 경험을 가장 잘 설명하는 항목은?",
                options: [
                    { label: "다이어트 경험이 거의 없다", score: 0 },
                    { label: "단기 다이어트 후 어느 정도 유지했다", score: 2 },
                    { label: "여러 번 시도했지만 3개월 이내에 원래 체중으로 돌아왔다", score: 3 },
                    { label: "반복적인 요요, 이전보다 더 늘어난 경험이 있다", score: 5 }
                ]
            },
            {
                id: "q4",
                text: "평소 부종(붓기)과 순환 상태는 어떤가요?",
                options: [
                    { label: "거의 붓는 느낌이 없다", score: 0 },
                    { label: "오래 서있거나 앉아있을 때만 다리가 붓는다", score: 2 },
                    { label: "아침에 얼굴/손발 붓기가 자주 느껴진다", score: 3 },
                    { label: "붓기가 자주 반복되고, 오후에 더 심해지는 편이다", score: 5 }
                ]
            }
        ],
        results: [
            {
                level: "low",
                minScore: 0,
                maxScore: 5,
                title: "유지 관리형",
                subtitle: "현재 체중 유지가 우선입니다",
                description: "현재 체중과 생활습관이 비교적 안정적인 편입니다. 다만, 스트레스·수면 부족·간헐적인 폭식이 반복되면 체중이 서서히 올라갈 수 있으므로, 지금부터 작은 습관 교정으로 ‘방어선’을 만들어 두는 것이 중요합니다.",
                tags: ["체중유지", "예방관리", "가벼운코칭"],
                ctaHeadline: "더 건강한 유지를 원하신다면",
                ctaBody: "현재 상태를 점검하고 예방적 차원의 관리를 받아보세요."
            },
            {
                level: "medium",
                minScore: 6,
                maxScore: 12,
                title: "생활습관 교정형",
                subtitle: "대사 기능 회복이 우선입니다",
                description: "체중이 서서히 늘어나고 있거나, 다이어트 후 유지가 잘 안 되는 상태일 수 있습니다. 아직 급격한 체중 증가는 아니지만, 야식·군것질·수면 패턴 등의 습관이 계속되면 대사 기능이 쉽게 지치게 됩니다.",
                tags: ["생활습관", "대사균형", "초기관리"],
                ctaHeadline: "지금이 골든타임입니다",
                ctaBody: "생활습관 교정과 체질 개선으로 건강한 감량을 시작하세요."
            },
            {
                level: "high",
                minScore: 13,
                maxScore: 20,
                title: "급성 체중 증가형",
                subtitle: "집중 관리가 필요한 단계입니다",
                description: "최근 몇 달 사이 체중이 빠르게 늘면서, 단순한 식단 조절만으로는 조절이 어려운 단계일 가능성이 높습니다. 붓기·순환 문제와 함께 대사 기능 전반이 부담을 받고 있을 수 있어, 해독과 체액 조절, 식습관 교정이 동시에 필요합니다.",
                tags: ["급격체중증가", "붓기순환", "요요위험"],
                ctaHeadline: "1:1 맞춤 플랜이 필요합니다",
                ctaBody: "혼자 고민하지 마세요. 체질에 맞는 집중 치료 프로그램을 설계해 드립니다."
            }
        ]
    },
    skin: {
        clinicId: 'skin',
        title: "피부 체질 자가진단",
        disclaimer: "이 자가 체크는 간단한 참고 도구이며, 한의학적 진단이나 치료를 대신하지 않습니다.",
        questions: [
            {
                id: "category",
                text: "현재 가장 고민되는 피부 문제는 무엇인가요?",
                options: [
                    { label: "가려움·붉은 발진·진물 (습진/아토피)", score: 0, value: 'atopy' },
                    { label: "하얀 각질이 겹겹이 쌓이는 판상 홍반 (건선)", score: 0, value: 'psoriasis' },
                    { label: "사마귀·티눈 등 딱딱한 돌출 병변", score: 0, value: 'warts' },
                    { label: "여드름 자국·색소 침착·흉터", score: 0, value: 'acne' }
                ]
            },
            {
                id: "chronicity",
                text: "증상이 발생한 지 얼마나 되었나요?",
                options: [
                    { label: "2주 미만, 최근에 생겼다", score: 0 },
                    { label: "2주 ~ 3개월, 가끔 반복된다", score: 2 },
                    { label: "3개월 ~ 6개월, 잘 낫지 않고 지속된다", score: 3 },
                    { label: "6개월 이상, 거의 항상 증상이 있다", score: 5 }
                ]
            },
            {
                id: "impairment",
                text: "일상생활에 미치는 영향은 어느 정도인가요?",
                options: [
                    { label: "가끔 신경 쓰이지만 일상생활은 가능하다", score: 1 },
                    { label: "가려움이나 외관 때문에 스트레스를 받는다", score: 2 },
                    { label: "수면을 방해하거나, 대인관계가 꺼려질 정도다", score: 4 },
                    { label: "증상 때문에 학교/직장 생활이 힘들다", score: 5 }
                ]
            },
            {
                id: "red-flags",
                text: "다음 중 해당되는 위험 신호가 있나요?",
                options: [
                    { label: "없음", score: 0 },
                    { label: "갑작스럽게 전신으로 발진이 퍼졌다", score: 5, redFlag: true },
                    { label: "열이 나거나 통증이 동반된다", score: 5, redFlag: true },
                    { label: "진물, 출혈, 궤양 등 상처가 심하다", score: 5, redFlag: true }
                ]
            }
        ],
        results: [
            {
                level: "low",
                minScore: 0,
                maxScore: 4,
                title: "일시적 트러블형",
                subtitle: "생활 관리로도 호전이 가능한 단계입니다",
                description: "최근 단기간에 생긴 트러블로, 일정 기간이 지나면 자연히 가라앉을 가능성이 높은 상태입니다. 다만 반복되지 않도록, 수면·식습관·스트레스 관리를 점검해 보는 것이 좋습니다.",
                tags: ["일시적", "생활요인", "예방위주"],
                ctaHeadline: "재발 방지를 위한 팁",
                ctaBody: "생활 속 관리법을 점검하고 예방하세요."
            },
            {
                level: "medium",
                minScore: 5,
                maxScore: 11,
                title: "재발성 트러블형",
                subtitle: "피부 장벽 강화와 생활 관리가 필요합니다",
                description: "한 번 좋아졌다가도, 스트레스·수면 부족·계절 변화에 따라 다시 올라오는 패턴입니다. 아직 염증이 깊게 자리 잡은 것은 아니지만, 장기간 반복되면 만성화되기 쉬운 단계입니다.",
                tags: ["재발성", "장벽약화", "스트레스연관"],
                ctaHeadline: "만성화를 막아야 합니다",
                ctaBody: "피부 면역력을 높이는 체계적인 관리가 필요합니다."
            },
            {
                level: "high",
                minScore: 12,
                maxScore: 20,
                title: "만성 염증형",
                subtitle: "내부 면역·장부 기능 개선이 시급합니다",
                description: "피부 트러블이 6개월 이상 반복되거나, 전신 증상/통증 등을 동반하는 만성 단계입니다. 단순히 바르는 약이나 보습 제품만으로는 안정되기 어렵고, 소화·배변·수족냉증 등 내부 상태와 함께 보는 것이 필요합니다.",
                tags: ["만성염증", "면역균형", "체질관리"],
                ctaHeadline: "속부터 다스려야 합니다",
                ctaBody: "내부 원인을 찾아 치료하는 1:1 맞춤 처방을 받아보세요."
            }
        ],
        programVariants: [
            {
                id: 'atopy',
                name: '습진/아토피',
                resultOverrides: {
                    medium: { title: '재발성 습진/아토피', tags: ['만성습진', '가려움', '면역과민'] },
                    high: { title: '중증 아토피/습진', tags: ['진물/태선화', '스테로이드리바운드', '체질개선필수'] }
                }
            },
            {
                id: 'psoriasis',
                name: '건선',
                resultOverrides: {
                    medium: { title: '판상 건선 초기', tags: ['각질과다', '건조증', '면역불균형'] },
                    high: { title: '만성/전신 건선', tags: ['전신퍼짐', '관절염동반가능', '심부체온조절'] }
                }
            },
            {
                id: 'warts',
                name: '사마귀',
                resultOverrides: {
                    medium: { title: '다발성 사마귀', tags: ['바이러스성', '면역저하', '번짐주의'] },
                    high: { title: '난치성 사마귀', tags: ['냉동치료실패', '재발반복', '면역치료필요'] }
                }
            },
            {
                id: 'acne',
                name: '여드름/흉터',
                resultOverrides: {
                    medium: { title: '화농성 여드름', tags: ['염증반복', '흉터주의', '열독배출'] },
                    high: { title: '만성 여드름/흉터', tags: ['패인흉터', '색소침착', '재생치료'] }
                }
            }
        ]
    },
    digestive: {
        clinicId: 'digestive',
        title: '소화기질환 미니 진단',
        disclaimer: '이 자가 체크는 간단한 참고 도구이며, 실제 진단이나 치료를 대신하지 않습니다. 복통, 체중 변화, 출혈 등 증상이 심하거나 오래 지속되는 경우에는 반드시 의료진과 직접 상담해 주세요.',
        questions: [
            {
                id: 'duration',
                text: '현재 소화·복부 불편감은 얼마나 오래 지속되고 있나요?',
                options: [
                    { value: 'lt-2w', label: '2주 미만, 비교적 최근에 시작되었습니다.', score: 0 },
                    { value: '2w-1m', label: '2주 이상 1개월 미만 정도 계속되고 있습니다.', score: 2 },
                    { value: '1m-3m', label: '1개월 이상 3개월 미만 지속되고 있습니다.', score: 3 },
                    { value: 'gt-3m', label: '3개월 이상, 좋아졌다 나빠지기를 반복하거나 계속되고 있습니다.', score: 5 }
                ]
            },
            {
                id: 'main-pattern',
                text: '가장 신경 쓰이는 소화·복부 증상 양상은 무엇인가요?',
                options: [
                    { value: 'bloating', label: '식사 후 더부룩함·답답함이 주로 느껴집니다.', score: 2 },
                    { value: 'upper-burning', label: '속쓰림, 가슴 답답함, 신물이 올라오는 느낌(역류)이 자주 있습니다.', score: 3 },
                    { value: 'lower-gas-diarrhea', label: '아랫배 통증, 잦은 가스, 설사·묽은 변이 반복되는 편입니다.', score: 3 },
                    { value: 'pain-avoid-meal', label: '식사 전후와 관계없이 복부 통증이 심해 식사를 피하거나 줄이게 됩니다.', score: 5 }
                ]
            },
            {
                id: 'bowel-habit',
                text: '최근 배변 습관의 변화를 어떻게 느끼고 계신가요?',
                options: [
                    { value: 'no-change', label: '예전과 비교해 배변 횟수·모양에 큰 변화는 없습니다.', score: 0 },
                    { value: 'occasional-change', label: '가끔 변비(3일 이상 무변)나 묽은 변이 있지만, 자주 반복되지는 않습니다.', score: 2 },
                    { value: 'persistent-change', label: '1개월 이상 변비가 반복되거나, 하루 3회 이상 묽은 변·설사가 자주 있습니다.', score: 3 },
                    { value: 'blood-or-black', label: '변에서 피가 보이거나, 검게 변한 적이 있으며, 최근 들어 배변 패턴이 뚜렷하게 달라졌습니다.', score: 5, redFlag: true }
                ]
            },
            {
                id: 'systemic',
                text: '소화기 증상과 함께 동반되는 전신 상태를 골라주세요.',
                options: [
                    { value: 'only-fatigue', label: '가벼운 피로감 외에는 특별한 전신 증상은 느끼지 못합니다.', score: 0 },
                    { value: 'mild-appetite-change', label: '식욕이 줄거나 속이 메스껍고 더부룩한 날이 가끔 있어, 식사량이 조금 줄었습니다.', score: 2 },
                    { value: 'nausea-dizziness', label: '자주 메스꺼움·구역감이 있고, 어지럽거나 기운이 빠지는 느낌이 함께 있습니다.', score: 3 },
                    { value: 'weight-loss-or-night-pain', label: '최근 3개월 안에 특별한 다이어트 없이 3kg 이상 체중이 빠졌거나, 밤에 통증 때문에 자주 깨는 편입니다.', score: 5, redFlag: true }
                ]
            }
        ],
        results: [
            {
                level: 'low',
                title: '일시적 소화 불편형',
                subtitle: '생활 관리로 호전 가능성이 높은 단계입니다',
                description: '현재 소화·복부 증상이 비교적 단기간이거나, 배변·체중 변화가 크지 않은 상태로 보입니다. 스트레스·과식·야식·카페인/음주 등 생활습관과 수면 패턴을 조정하면, 자연스럽게 호전될 가능성이 높습니다.\n\n다만 같은 증상이 반복되거나, 기간이 1~3개월 이상 길어질 경우에는 단순한 위장 문제를 넘어 체질·장부 기능의 불균형으로 진행될 수 있어, 그 전에 한 번 정도는 전문적인 검진을 받아보시는 것이 좋습니다.',
                tags: ['일시적 소화불량', '생활습관 영향', '예방 관리'],
                minScore: 0,
                maxScore: 4,
                ctaHeadline: '지금 단계에서는, 과로·야식·카페인 등을 정리하는 것만으로도 큰 도움이 됩니다.',
                ctaBody: '생활 패턴을 점검하면서, 필요하다면 가벼운 위장 기능 회복 한약과 더불어 관리 방향을 함께 설계해 드립니다.'
            },
            {
                level: 'medium',
                title: '반복성 소화기 불균형형',
                subtitle: '위장·장 기능 회복과 생활 교정이 함께 필요합니다',
                description: '증상이 한두 달 이상 이어지거나, 좋아졌다 다시 나빠지는 패턴이 반복되고 있습니다. 이는 위장이나 장의 운동·기능이 지친 상태일 가능성이 높고, 스트레스·수면·식습관이 함께 영향을 주고 있을 수 있습니다.\n\n이 단계에서 적절한 치료와 생활 교정을 시작하면, 보다 가벼운 계획으로도 만성화되는 것을 막을 수 있습니다. 증상이 특정 음식·상황과 연관되어 있는지, 배변 패턴이 어떻게 바뀌는지 등을 함께 점검하는 것이 중요합니다.',
                tags: ['반복성 소화불량', '위장·장 기능 저하', '생활습관 교정'],
                minScore: 5,
                maxScore: 11,
                ctaHeadline: '현재 소화기 상태를 기준으로, 위장·장 기능을 함께 회복시키는 플랜이 필요합니다.',
                ctaBody: '증상의 기간과 배변 패턴, 동반 증상을 바탕으로 기능성 소화불량·과민성대장 여부를 체크하고, 체질에 맞는 한약과 식이·수면 관리 계획을 함께 제안해 드립니다.'
            },
            {
                level: 'high',
                title: '만성·고위험 소화기 관리 단계',
                subtitle: '장기간 지속되거나 경고 신호가 있는 상태입니다',
                description: '복부 불편감이 3개월 이상 이어지거나, 체중 감소·혈변/검은 변·야간 통증 등 경고 신호가 동반되는 단계입니다. 단순 위장약이나 일시적인 식이 조절만으로는 안정되기 어려우며, 한의학적 진찰과 더불어 필요한 경우에는 추가 검사가 권장됩니다.\n\n증상의 기간·양상·배변 변화·체중 변화는 모두 소화기 건강을 판단하는 중요한 단서입니다. 이 정보를 바탕으로 현재 상태를 정확히 파악한 뒤, 위장·간담·장부 기능을 종합적으로 조정하는 치료가 필요합니다.',
                tags: ['만성 소화기질환', '체중 변화', '경고 신호', '정밀 평가 필요'],
                minScore: 12,
                maxScore: 20,
                ctaHeadline: '현재는 증상 경과와 경고 신호를 함께 확인해야 하는 단계입니다.',
                ctaBody: '최근 체중·배변·통증 양상에 대해 자세히 여쭤본 뒤, 필요한 경우 검사를 권하고, 한의학적 치료와 생활 관리를 함께 설계해 드립니다. 자가 판단으로 오래 지켜보기보다는, 직접 진료를 통해 상태를 점검해 보시는 것을 권장합니다.'
            }
        ],
        programVariants: [
            {
                id: 'functional',
                name: '기능성 소화불량',
                resultOverrides: {
                    medium: {
                        title: '기능성 소화불량 의심 단계',
                        tags: ['기능성 소화불량', '만성 더부룩함', '식후 불편감']
                    },
                    high: {
                        title: '만성 기능성 소화불량',
                        tags: ['만성 소화불량', '식욕 저하', '위장 기능 저하']
                    }
                }
            },
            {
                id: 'ibs',
                name: '과민성 대장',
                resultOverrides: {
                    medium: {
                        title: '과민성 대장 증상 의심 단계',
                        tags: ['과민성 대장', '복부 가스', '묽은 변·변비 반복']
                    },
                    high: {
                        title: '만성 과민성 대장 패턴',
                        tags: ['만성 장 불균형', '복통·가스', '스트레스 연관']
                    }
                }
            },
            {
                id: 'reflux',
                name: '역류성 식도염',
                resultOverrides: {
                    medium: {
                        title: '역류성 식도염 의심 단계',
                        tags: ['역류', '속쓰림', '흉부 답답']
                    },
                    high: {
                        title: '만성 역류·속쓰림 패턴',
                        tags: ['만성 역류', '야간 속쓰림', '식도 자극']
                    }
                }
            }
        ]
    },
    pain: {
        clinicId: 'pain',
        title: '통증/근골격계 미니 진단',
        disclaimer: '이 자가 체크는 간단한 참고 도구이며, 실제 진단이나 치료를 대신하지 않습니다. 통증이 심하거나 외상 후 발생한 경우에는 반드시 의료진과 직접 상담해 주세요.',
        questions: [
            {
                id: 'duration',
                text: '통증이 시작된 지 얼마나 되었나요?',
                options: [
                    { value: 'acute', label: '2주 미만, 최근에 삐끗하거나 아프기 시작했습니다.', score: 0 },
                    { value: 'subacute', label: '1개월 ~ 3개월 정도 되었습니다.', score: 2 },
                    { value: 'chronic', label: '3개월 ~ 6개월 정도 지속되고 있습니다.', score: 3 },
                    { value: 'chronic-long', label: '6개월 이상 만성적으로 아픕니다.', score: 5, redFlag: true }
                ]
            },
            {
                id: 'intensity',
                text: '통증의 강도와 일상생활 영향은 어떤가요?',
                options: [
                    { value: 'mild', label: '뻐근한 정도이며 일상생활에는 지장이 없습니다.', score: 0 },
                    { value: 'moderate', label: '특정 동작을 할 때 통증이 있어 불편합니다.', score: 2 },
                    { value: 'severe', label: '통증 때문에 잠을 설치거나 일상생활이 힘듭니다.', score: 3 },
                    { value: 'very-severe', label: '가만히 있어도 아프고, 진통제가 잘 듣지 않습니다.', score: 5, redFlag: true }
                ]
            },
            {
                id: 'pattern',
                text: '통증이 언제 더 심해지나요?',
                options: [
                    { value: 'movement', label: '많이 움직이거나 무리한 날에만 아픕니다.', score: 0 },
                    { value: 'morning', label: '아침에 일어날 때 뻣뻣하고 아픕니다.', score: 2 },
                    { value: 'night', label: '밤에 자려고 누우면 통증이 심해집니다.', score: 3 },
                    { value: 'constant', label: '하루 종일 통증이 지속됩니다.', score: 5 }
                ]
            },
            {
                id: 'history',
                text: '과거 치료 경험이나 동반 질환이 있나요?',
                options: [
                    { value: 'none', label: '특별한 과거력이나 동반 질환은 없습니다.', score: 0 },
                    { value: 'recurrent', label: '이전에도 비슷한 통증으로 치료받은 적이 있습니다.', score: 2 },
                    { value: 'injury', label: '교통사고나 낙상 등 다친 이후로 시작되었습니다.', score: 3 },
                    { value: 'surgery', label: '수술을 권유받았거나, 수술 후에도 통증이 남았습니다.', score: 5 }
                ]
            }
        ],
        results: [
            {
                level: 'low',
                title: '단순 근육통/염좌',
                subtitle: '휴식과 초기 관리로 회복 가능합니다',
                description: '급성적인 근육 긴장이나 가벼운 염좌로 보입니다. 무리한 동작을 피하고 충분한 휴식을 취하면 자연스럽게 호전될 수 있습니다.\n\n다만 2주 이상 통증이 지속되거나 붓기가 심해진다면, 만성화를 막기 위해 간단한 침 치료나 물리치료를 받아보시는 것이 좋습니다.',
                tags: ['급성통증', '휴식필요', '초기관리'],
                minScore: 0,
                maxScore: 4,
                ctaHeadline: '통증이 오래가지 않도록 관리하세요.',
                ctaBody: '초기에 잘 관리하면 금방 좋아질 수 있습니다. 통증이 지속되면 내원해 주세요.'
            },
            {
                level: 'medium',
                title: '만성 통증 주의 단계',
                subtitle: '적극적인 치료와 재활이 필요합니다',
                description: '통증이 1개월 이상 지속되거나 반복되는 상태입니다. 단순한 근육통을 넘어 인대나 관절의 약화가 동반되었을 가능성이 높습니다.\n\n이 단계에서는 파스나 진통제만으로는 해결되지 않을 수 있으며, 약침, 추나요법 등을 통해 원인을 치료하고 기능을 회복시키는 것이 중요합니다.',
                tags: ['만성통증주의', '인대강화', '기능회복'],
                minScore: 5,
                maxScore: 11,
                ctaHeadline: '만성 통증으로 넘어가기 전 치료가 필요합니다.',
                ctaBody: '통증의 원인을 찾아 치료하고, 재발을 막는 강화 요법을 함께 진행해 드립니다.'
            },
            {
                level: 'high',
                title: '중증/만성 통증 단계',
                subtitle: '정밀 진단과 집중 치료가 시급합니다',
                description: '6개월 이상의 만성 통증이거나, 야간 통증/수면 장애를 동반하는 심한 상태입니다. 구조적인 문제(디스크, 협착 등)나 신경 손상 가능성도 고려해야 합니다.\n\n일반적인 치료로 호전되지 않는다면, 봉침/약침 등 강도 높은 치료와 함께 체질에 따른 한약 처방으로 염증을 제거하고 재생력을 높여야 합니다.',
                tags: ['중증통증', '디스크/협착', '집중치료'],
                minScore: 12,
                maxScore: 20,
                ctaHeadline: '더 이상 참지 마시고 전문가와 상의하세요.',
                ctaBody: '수술 전/후 관리, 난치성 통증까지 고려한 1:1 맞춤 심화 치료 프로그램을 설계해 드립니다.'
            }
        ]
    },
    women: {
        clinicId: 'women',
        title: '여성질환 미니 진단',
        disclaimer: '이 자가 체크는 간단한 참고 도구이며, 실제 진단이나 치료를 대신하지 않습니다. 부정출혈, 심한 복통 등 급성 증상이 있는 경우 반드시 산부인과 진료를 받아보세요.',
        questions: [
            {
                id: 'category',
                text: '현재 가장 고민되는 여성 건강 문제는 무엇인가요?',
                options: [
                    { label: '생리 불순·생리통·PMS', score: 0, value: 'period' },
                    { label: '갱년기 증상 (안면홍조, 열감, 감정기복)', score: 0, value: 'menopause' },
                    { label: '난임·임신 준비', score: 0, value: 'fertility' },
                    { label: '산후 조리·유산 후 회복', score: 0, value: 'postpartum' }
                ]
            },
            {
                id: 'chronicity',
                text: '증상이 지속된 기간은 어느 정도인가요?',
                options: [
                    { label: '6개월 미만', score: 0 },
                    { label: '6개월 ~ 1년', score: 2 },
                    { label: '1년 이상 지속됨', score: 3 },
                    { label: '수년 이상 반복됨', score: 5 }
                ]
            },
            {
                id: 'impairment',
                text: '일상생활이나 컨디션에 미치는 영향은?',
                options: [
                    { label: '약간 불편하지만 참을 만하다', score: 1 },
                    { label: '컨디션이 저하되고 피로감이 심하다', score: 2 },
                    { label: '진통제가 필요하거나, 감정 조절이 어렵다', score: 3 },
                    { label: '일상생활(직장/육아)이 힘들고 우울감이 심하다', score: 5 }
                ]
            },
            {
                id: 'red-flags',
                text: '다음 중 해당되는 위험 신호가 있나요?',
                options: [
                    { label: '없음', score: 0 },
                    { label: '생리량이 감당 안 될 정도로 많거나 덩어리가 심하다', score: 5, redFlag: true },
                    { label: '3개월 이상 무월경이거나 부정출혈이 잦다', score: 5, redFlag: true },
                    { label: '극심한 우울감, 자해 충동 등이 있다', score: 5, redFlag: true }
                ]
            }
        ],
        results: [
            {
                level: 'low',
                minScore: 0,
                maxScore: 4,
                title: '건강한 주기형',
                subtitle: '현재 상태를 잘 유지하는 것이 중요합니다',
                description: '생리 주기와 컨디션이 비교적 안정적입니다. 스트레스나 과로, 급격한 체중 변화만 주의한다면 건강한 상태를 유지할 수 있습니다.\n\n평소 아랫배를 따뜻하게 하고, 규칙적인 수면과 식습관을 가지는 것만으로도 충분한 관리가 됩니다.',
                tags: ['건강양호', '예방관리', '생활습관'],
                ctaHeadline: '지금의 건강함을 유지하세요.',
                ctaBody: '혹시 모를 변화에 대비해 정기적인 검진과 건강한 생활 습관을 이어가시길 바랍니다.'
            },
            {
                level: 'medium',
                minScore: 5,
                maxScore: 11,
                title: '호르몬 불균형 주의형',
                subtitle: '자궁/난소 기능의 회복이 필요합니다',
                description: '생리 불순이나 통증, PMS 등 호르몬 불균형의 신호가 보입니다. 스트레스, 수면 부족, 영양 불균형 등이 원인일 수 있으며, 방치하면 자궁 질환으로 이어질 수 있습니다.\n\n한의학적인 조경(생리 조절) 치료를 통해 호르몬 균형을 맞추고, 자궁 내 혈액 순환을 돕는 것이 좋습니다.',
                tags: ['생리불순', '생리통', '호르몬균형'],
                ctaHeadline: '불편한 증상, 참지 말고 개선하세요.',
                ctaBody: '체질에 맞는 한약과 침 치료로 호르몬 균형을 되찾고 편안한 주기를 만들어 드립니다.'
            },
            {
                level: 'high',
                minScore: 12,
                maxScore: 20,
                title: '자궁/난소 질환 의심형',
                subtitle: '적극적인 치료와 관리가 시급합니다',
                description: '무월경, 극심한 생리통, 심한 PMS 등 자궁/난소 기능이 많이 저하되었거나 기질적 질환(자궁근종, 내막증, 다낭성 등)이 의심되는 상태입니다.\n\n단순한 진통제나 호르몬제에 의존하기보다, 자궁의 환경을 집중적으로 개선하는 치료가 필요합니다. 난임이나 조기 폐경 예방을 위해서라도 전문가의 진단을 받아보세요.',
                tags: ['질환의심', '집중치료', '자궁면역'],
                ctaHeadline: '여성 건강의 적신호, 놓치지 마세요.',
                ctaBody: '자궁/난소의 기능을 강화하고 원인을 해결하는 1:1 맞춤 여성 클리닉을 제안합니다.'
            }
        ],
        programVariants: [
            {
                id: 'period',
                name: '생리질환',
                resultOverrides: {
                    medium: { title: '생리불순/통증 심화', tags: ['자궁냉증', '어혈제거', '순환개선'] },
                    high: { title: '자궁질환 의심/심한 PMS', tags: ['자궁근종/내막증', '호르몬불균형', '집중치료'] }
                }
            },
            {
                id: 'menopause',
                name: '갱년기',
                resultOverrides: {
                    medium: { title: '갱년기 증후군 초기', tags: ['상열감', '불면', '자율신경조절'] },
                    high: { title: '심한 갱년기 장애', tags: ['골다공증위험', '우울/불안', '호르몬보충'] }
                }
            },
            {
                id: 'fertility',
                name: '난임/임신준비',
                resultOverrides: {
                    medium: { title: '난소기능 저하 의심', tags: ['착상강화', '난자질개선', '배란유도'] },
                    high: { title: '반복 착상 실패/난임', tags: ['습관성유산', '시험관병행', '자궁환경개선'] }
                }
            },
            {
                id: 'postpartum',
                name: '산후/유산후',
                resultOverrides: {
                    medium: { title: '산후풍 초기', tags: ['관절통', '시림', '기혈보충'] },
                    high: { title: '만성 산후풍/유산후유증', tags: ['산후우울', '체형교정', '녹용보약'] }
                }
            }
        ]
    },
    head: {
        clinicId: 'head',
        title: '두면부(두통/어지럼) 미니 진단',
        disclaimer: '이 자가 체크는 간단한 참고 도구이며, 뇌혈관 질환 등 응급 상황을 배제하기 위해서는 반드시 의료진의 진단이 필요합니다.',
        questions: [
            {
                id: 'category',
                text: '현재 두면부에서 가장 신경 쓰이는 문제는 무엇인가요?',
                options: [
                    { label: '만성/반복성 두통', score: 0, value: 'headache' },
                    { label: '어지럼·빙빙 도는 느낌 (이명 포함)', score: 0, value: 'vertigo' },
                    { label: '안면마비·안면 비대칭', score: 0, value: 'palsy' },
                    { label: '얼굴 통증 (삼차신경통 계열)', score: 0, value: 'facepain' }
                ]
            },
            {
                id: 'chronicity',
                text: '이런 증상이 언제부터, 얼마나 자주 반복되고 있나요?',
                options: [
                    { label: '2주 미만, 최근에 생긴 편이다', score: 0 },
                    { label: '2주~3개월 사이, 가끔 반복된다', score: 2 },
                    { label: '3개월 이상, 한 달에 여러 번 반복된다', score: 3 },
                    { label: '6개월 이상, 거의 "달고 산다" 수준이다', score: 5 }
                ]
            },
            {
                id: 'impairment',
                text: '일상과 수면에 주는 영향은 어느 정도인가요?',
                options: [
                    { label: '큰 지장은 없다. 불편하지만 참고 지낸다', score: 1 },
                    { label: '피곤한 날은 일을 줄이거나 쉬어야 한다', score: 2 },
                    { label: '자주 일을 못 나가거나 포기하게 된다', score: 4 },
                    { label: '증상 때문에 생활 패턴 자체를 바꾸고 있다', score: 5 }
                ]
            },
            {
                id: 'red-flags',
                text: '다음 중 해당되는 것이 있다면 골라주세요.',
                options: [
                    { label: '없음', score: 0 },
                    { label: '눈앞이 캄캄해지거나 시야가 흐려진다', score: 2 },
                    { label: '메스꺼움·구토, 빛/소리 예민함이 심하다', score: 2 },
                    { label: '갑작스럽고 극심한 두통, 말이 어눌해짐, 마비감', score: 5, redFlag: true }
                ]
            }
        ],
        results: [
            {
                level: 'low',
                title: '경도 두면부 불편 단계',
                subtitle: '초기 관리로 충분히 좋아질 수 있습니다',
                description: '현재는 일시적 혹은 경도 수준의 두면부 불편으로 보입니다. 반복되는 만성두통·어지럼·안면마비·삼차신경통 수준까진 아니지만, 목·어깨 긴장, 피로, 수면 부족이 쌓이면 향후 그런 질환군으로 진행될 수 있습니다.',
                tags: ['초기증상', '스트레스관리', '순환개선'],
                minScore: 0,
                maxScore: 4,
                ctaHeadline: '더 심해지기 전에 관리하세요.',
                ctaBody: '가벼운 침 치료나 생활 습관 교정만으로도 충분한 효과를 볼 수 있습니다.'
            },
            {
                level: 'medium',
                title: '반복성 두면부 질환 의심 단계',
                subtitle: '순환과 신경 기능을 점검해야 할 때입니다',
                description: '3개월 이상 반복되는 두통·어지럼, 또는 안면마비·얼굴통과 유사한 증상이 일·수면·집안일에 영향을 주는 단계입니다. 정확한 진단명을 받았든 아니든, 지금은 두면부 전체 순환과 신경 기능을 한 번 정리해 줘야 할 타이밍입니다.',
                tags: ['만성두통/어지럼', '신경과민', '순환장애'],
                minScore: 5,
                maxScore: 11,
                ctaHeadline: '만성화의 고리를 끊어야 합니다.',
                ctaBody: '체질에 맞는 한약과 교정 치료로 머리와 얼굴의 순환을 돕고 신경을 안정시켜 드립니다.'
            },
            {
                level: 'high',
                title: '고위험/정밀 평가 권장 단계',
                subtitle: '적극적인 치료와 전문가의 진단이 필요합니다',
                description: '갑작스럽고 극심한 두통, 최근에 없던 신경학적 증상(한쪽 마비·말 어눌함 등)이 포함된 경우, 만성 편두통이나 단순 안면신경통으로 보기 어려운 고위험 신호일 수 있습니다. 이 경우에는 먼저 신경과·응급실 평가가 필요하며, 한의학적 치료는 이후 회복기·재발 방지에 보조적으로 사용하는 것이 더 안전합니다.',
                tags: ['고위험신호', '정밀검사필요', '집중치료'],
                minScore: 12,
                maxScore: 20,
                ctaHeadline: '혼자 판단하지 마시고 전문가와 상의하세요.',
                ctaBody: '증상의 원인을 정확히 파악한 후, 단계별 맞춤 치료 계획을 세워드립니다.'
            }
        ],
        programVariants: [
            {
                id: 'headache',
                name: '두통',
                resultOverrides: {
                    medium: { title: '만성 편두통/긴장성 두통', tags: ['진통제과다', '경추성두통', '혈류개선'] },
                    high: { title: '난치성 두통/군발두통', tags: ['일상불가', '신경차단술고려', '뇌기능회복'] }
                }
            },
            {
                id: 'vertigo',
                name: '어지럼증',
                resultOverrides: {
                    medium: { title: '메니에르/이석증 재발', tags: ['귀먹먹함', '재발방지', '전정기능강화'] },
                    high: { title: '중추성/만성 어지럼증', tags: ['뇌혈류장애', '균형감각저하', '소뇌기능'] }
                }
            },
            {
                id: 'palsy',
                name: '안면마비',
                resultOverrides: {
                    medium: { title: '구안와사 회복기', tags: ['안면비대칭', '후유증예방', '신경재생'] },
                    high: { title: '오래된 안면마비/후유증', tags: ['연합운동', '구축', '매선치료'] }
                }
            },
            {
                id: 'facepain',
                name: '안면통증',
                resultOverrides: {
                    medium: { title: '비정형 안면통', tags: ['치통과혼동', '스트레스성', '신경안정'] },
                    high: { title: '삼차신경통', tags: ['전기통증', '바람만스쳐도', '신경압박해소'] }
                }
            }
        ]
    },
    neuro: {
        clinicId: 'neuro',
        title: '신경정신(불면/우울/화병) 미니 진단',
        disclaimer: '이 자가 체크는 간단한 참고 도구이며, 정신건강의학과 진단을 대신하지 않습니다. 자해/타해 위험이 있는 경우 즉시 전문가의 도움을 받으세요.',
        questions: [
            {
                id: 'category',
                text: '현재 가장 힘든 마음의 문제는 무엇인가요?',
                options: [
                    { label: '잠이 안 오거나 자꾸 깬다 (불면)', score: 0, value: 'insomnia' },
                    { label: '우울하고 의욕이 없다 (우울)', score: 0, value: 'depression' },
                    { label: '갑자기 가슴이 뛰고 숨이 막힌다 (공황/불안)', score: 0, value: 'panic' },
                    { label: '화가 치밀고 억울하다 (화병)', score: 0, value: 'anger' }
                ]
            },
            {
                id: 'chronicity',
                text: '증상이 얼마나 지속되었나요?',
                options: [
                    { label: '2주 미만', score: 0 },
                    { label: '2주 ~ 3개월', score: 2 },
                    { label: '3개월 ~ 6개월', score: 3 },
                    { label: '6개월 이상', score: 5 }
                ]
            },
            {
                id: 'impairment',
                text: '일상생활(일/학업/관계)에 지장이 있나요?',
                options: [
                    { label: '약간 힘들지만 할 일은 한다', score: 1 },
                    { label: '능률이 떨어지고 실수가 잦다', score: 2 },
                    { label: '자주 결석/결근하거나 사람을 피한다', score: 4 },
                    { label: '아무것도 할 수 없는 상태다', score: 5 }
                ]
            },
            {
                id: 'red-flags',
                text: '다음 중 해당되는 위험 신호가 있나요?',
                options: [
                    { label: '없음', score: 0 },
                    { label: '술이나 약물에 의존하게 된다', score: 3 },
                    { label: '공황 발작으로 응급실에 간 적이 있다', score: 5, redFlag: true },
                    { label: '죽고 싶다는 생각이 들거나 자해 충동이 있다', score: 5, redFlag: true }
                ]
            }
        ],
        results: [
            {
                level: 'low',
                title: '초기 스트레스 반응',
                subtitle: '휴식과 안정이 필요한 시기입니다',
                description: '일시적인 스트레스나 환경 변화로 인한 반응일 수 있습니다. 충분한 휴식과 수면, 규칙적인 생활로 회복될 수 있지만, 증상이 2주 이상 지속된다면 상담이 필요할 수 있습니다.',
                tags: ['스트레스', '휴식필요', '초기관리'],
                minScore: 0,
                maxScore: 4,
                ctaHeadline: '마음의 짐을 덜어내세요.',
                ctaBody: '가벼운 상담과 침 치료로 긴장을 풀고 안정을 찾을 수 있습니다.'
            },
            {
                level: 'medium',
                title: '심리적 불안정 단계',
                subtitle: '전문적인 도움이 필요한 단계입니다',
                description: '불면, 우울, 불안 등의 증상이 일상생활에 영향을 주기 시작했습니다. 의지로만 이겨내려 하기보다, 전문가의 도움을 받아 뇌와 마음의 균형을 되찾는 것이 좋습니다.',
                tags: ['심리불안', '수면장애', '상담권장'],
                minScore: 5,
                maxScore: 11,
                ctaHeadline: '혼자 끙끙 앓지 마세요.',
                ctaBody: '체질에 맞는 한약과 심리 상담으로 마음의 힘을 길러드립니다.'
            },
            {
                level: 'high',
                title: '집중 치료 필요 단계',
                subtitle: '적극적인 치료와 보호가 시급합니다',
                description: '일상생활이 어렵거나, 극심한 고통을 겪고 있는 상태입니다. 공황 발작, 심한 우울감, 자해 충동 등은 뇌 신경 전달 물질의 불균형이 심화된 상태를 의미하며, 반드시 적극적인 치료가 필요합니다.',
                tags: ['집중치료', '뇌기능회복', '안전우선'],
                minScore: 12,
                maxScore: 20,
                ctaHeadline: '당신은 혼자가 아닙니다.',
                ctaBody: '가장 안전하고 효과적인 방법으로 일상으로의 복귀를 도와드립니다.'
            }
        ],
        programVariants: [
            {
                id: 'insomnia',
                name: '불면증',
                resultOverrides: {
                    medium: { title: '수면 유지 장애/입면 곤란', tags: ['수면질저하', '꿈이많음', '심장안정'] },
                    high: { title: '만성 불면증', tags: ['수면제의존', '낮밤바뀜', '뇌파안정'] }
                }
            },
            {
                id: 'depression',
                name: '우울증',
                resultOverrides: {
                    medium: { title: '경도 우울/무기력', tags: ['의욕저하', '식욕변화', '기분전환'] },
                    high: { title: '주요 우울 장애', tags: ['사회적고립', '인지기능저하', '적극적치료'] }
                }
            },
            {
                id: 'panic',
                name: '공황/불안',
                resultOverrides: {
                    medium: { title: '범불안장애/예기불안', tags: ['가슴두근거림', '초조함', '자율신경'] },
                    high: { title: '공황장애', tags: ['죽을것같은공포', '과호흡', '응급상황대처'] }
                }
            },
            {
                id: 'anger',
                name: '화병',
                resultOverrides: {
                    medium: { title: '화병 초기/울화', tags: ['가슴답답', '목이물감', '울체해소'] },
                    high: { title: '만성 화병', tags: ['열오름', '두통/불면', '심화배출'] }
                }
            }
        ]
    },
    pediatric: {
        clinicId: 'pediatric',
        title: '소아/수험생 미니 진단',
        disclaimer: '이 자가 체크는 간단한 참고 도구이며, 실제 진단이나 치료를 대신하지 않습니다. 아이의 발달이나 건강이 염려되는 경우 반드시 의료진과 상담해 주세요.',
        questions: [
            {
                id: 'category',
                text: '우리 아이, 어떤 점이 가장 걱정되시나요?',
                options: [
                    { label: '키 성장·체중 (성장부진/성조숙증)', score: 0, value: 'growth' },
                    { label: '잦은 감기·비염·중이염 (면역력)', score: 0, value: 'immunity' },
                    { label: '집중력 부족·학업 스트레스 (수험생)', score: 0, value: 'focus' },
                    { label: '틱 장애·ADHD·야뇨증', score: 0, value: 'tic' }
                ]
            },
            {
                id: 'chronicity',
                text: '증상이 얼마나 오래되었나요?',
                options: [
                    { label: '최근에 시작되었다', score: 0 },
                    { label: '몇 달 전부터 반복되고 있다', score: 2 },
                    { label: '1년 이상 지속되고 있다', score: 3 },
                    { label: '어릴 때부터 계속되거나 점점 심해진다', score: 5 }
                ]
            },
            {
                id: 'impairment',
                text: '아이의 생활에 미치는 영향은?',
                options: [
                    { label: '잘 놀고 잘 먹는 편이다', score: 1 },
                    { label: '컨디션이 자주 떨어지고 예민하다', score: 2 },
                    { label: '학교/유치원 생활에 지장이 있다', score: 4 },
                    { label: '또래 관계나 학업에 큰 어려움이 있다', score: 5 }
                ]
            },
            {
                id: 'red-flags',
                text: '다음 중 해당되는 위험 신호가 있나요?',
                options: [
                    { label: '없음', score: 0 },
                    { label: '또래보다 10cm 이상 작거나 사춘기가 너무 빠르다', score: 5, redFlag: true },
                    { label: '항생제를 달고 살거나 입원을 자주 한다', score: 5, redFlag: true },
                    { label: '눈을 심하게 깜빡이거나 소리를 낸다 (틱 증상)', score: 5, redFlag: true }
                ]
            }
        ],
        results: [
            {
                level: 'low',
                minScore: 0,
                maxScore: 4,
                title: '건강한 성장기',
                subtitle: '지금처럼 잘 관리해 주세요',
                description: '아이의 성장과 면역 상태가 비교적 양호합니다. 계절 변화나 학업 스트레스가 있을 때만 조금 더 신경 써주시면 건강한 상태를 유지할 수 있습니다.',
                tags: ['건강관리', '성장체크', '면역유지'],
                ctaHeadline: '건강한 습관을 유지하세요.',
                ctaBody: '정기적인 성장 점검과 면역 관리를 통해 아이의 잠재력을 키워주세요.'
            },
            {
                level: 'medium',
                minScore: 5,
                maxScore: 11,
                title: '성장/면역 주의 단계',
                subtitle: '부족한 부분을 채워줘야 할 때입니다',
                description: '잦은 잔병치레나 성장 부진, 집중력 저하 등의 신호가 보입니다. 아이의 에너지가 부족하거나 균형이 깨져 있을 수 있으니, 체질에 맞는 보강이 필요합니다.',
                tags: ['면역보강', '성장부진', '집중력강화'],
                ctaHeadline: '아이의 골든타임을 놓치지 마세요.',
                ctaBody: '체질에 맞는 녹용 보약이나 성장 치료로 아이의 부족한 기운을 채워드립니다.'
            },
            {
                level: 'high',
                minScore: 12,
                maxScore: 20,
                title: '집중 치료 필요 단계',
                subtitle: '전문적인 진단과 치료가 시급합니다',
                description: '성장 속도가 현저히 떨어지거나, 틱/ADHD 등 신경계 증상, 혹은 만성적인 면역 질환으로 아이가 힘들어하고 있습니다. 단순한 영양제나 휴식만으로는 해결하기 어려우며, 적극적인 한방 치료가 필요합니다.',
                tags: ['성장클리닉', '틱/ADHD', '집중치료'],
                ctaHeadline: '전문가와 함께 아이를 도와주세요.',
                ctaBody: '아이의 체질과 증상을 정밀하게 분석하여, 가장 적합한 1:1 맞춤 치료 계획을 세워드립니다.'
            }
        ],
        programVariants: [
            {
                id: 'growth',
                name: '성장',
                resultOverrides: {
                    medium: { title: '성장 부진/성조숙 의심', tags: ['성장판검사', '식욕부진', '수면관리'] },
                    high: { title: '성장 장애/성조숙증', tags: ['호르몬치료고려', '최종키손실', '집중성장치료'] }
                }
            },
            {
                id: 'immunity',
                name: '면역',
                resultOverrides: {
                    medium: { title: '잦은 감기/비염', tags: ['항생제반복', '단체생활증후군', '호흡기보강'] }
                }
            },
            {
                id: 'focus',
                name: '수험생',
                resultOverrides: {
                    medium: { title: '학업 스트레스/체력 저하', tags: ['총명탕', '체력보강', '두뇌피로'] },
                    high: { title: '수험생 번아웃', tags: ['불면/두통', '시험불안', '공진단'] }
                }
            },
            {
                id: 'tic',
                name: '틱/ADHD',
                resultOverrides: {
                    medium: { title: '일시적 틱/주의산만', tags: ['심리안정', '스트레스해소', '가정지도'] },
                    high: { title: '만성 틱장애/ADHD', tags: ['운동틱/음성틱', '학습장애', '뇌기능훈련'] }
                }
            }
        ]
    },
    wellness: {
        clinicId: 'wellness',
        title: '보약/웰니스 미니 진단',
        disclaimer: '이 자가 체크는 간단한 참고 도구이며, 실제 진단이나 치료를 대신하지 않습니다. 급격한 체중 감소나 심한 통증이 있는 경우 반드시 의료진과 상담해 주세요.',
        questions: [
            {
                id: 'category',
                text: '현재 내 몸에 가장 필요한 것은 무엇인가요?',
                options: [
                    { label: '만성 피로 회복 (보약)', score: 0, value: 'fatigue' },
                    { label: '수술/병후 기력 회복', score: 0, value: 'recovery' },
                    { label: '노화 방지·항산화 (공진단/경옥고)', score: 0, value: 'antiaging' },
                    { label: '해독·디톡스 (순환 개선)', score: 0, value: 'detox' }
                ]
            },
            {
                id: 'chronicity',
                text: '피로감이나 컨디션 저하가 얼마나 되었나요?',
                options: [
                    { label: '최근 며칠 무리했다', score: 0 },
                    { label: '한 달 정도 피곤함이 가시지 않는다', score: 2 },
                    { label: '3개월 이상 만성적으로 피로하다', score: 3 },
                    { label: '6개월 이상, 아침에 일어나기 너무 힘들다', score: 5 }
                ]
            },
            {
                id: 'impairment',
                text: '일상생활 활력도는 어느 정도인가요?',
                options: [
                    { label: '약간 지치지만 일상은 문제없다', score: 1 },
                    { label: '오후만 되면 급격히 방전된다', score: 2 },
                    { label: '주말 내내 쉬어도 회복이 안 된다', score: 4 },
                    { label: '기운이 없어 아무것도 하기 싫다', score: 5 }
                ]
            },
            {
                id: 'red-flags',
                text: '다음 중 해당되는 위험 신호가 있나요?',
                options: [
                    { label: '없음', score: 0 },
                    { label: '이유 없이 체중이 5kg 이상 빠졌다', score: 5, redFlag: true },
                    { label: '식은땀이 나고 가슴이 답답하다', score: 5, redFlag: true },
                    { label: '큰 수술이나 입원 치료 후 회복이 더디다', score: 5, redFlag: true }
                ]
            }
        ],
        results: [
            {
                level: 'low',
                minScore: 0,
                maxScore: 4,
                title: '활력 유지형',
                subtitle: '지금의 건강을 잘 지켜주세요',
                description: '현재 컨디션은 비교적 양호합니다. 과로나 스트레스가 쌓이지 않도록 주의하고, 계절이 바뀔 때나 특별히 힘든 일이 있을 때 미리미리 챙겨주시면 좋습니다.',
                tags: ['건강유지', '피로예방', '활력충전'],
                ctaHeadline: '더 활기찬 내일을 준비하세요.',
                ctaBody: '가벼운 공진단이나 경옥고 등으로 평소 면역력을 챙기시는 것을 추천합니다.'
            },
            {
                level: 'medium',
                minScore: 5,
                maxScore: 11,
                title: '에너지 고갈 주의형',
                subtitle: '충전이 필요한 시기입니다',
                description: '몸의 배터리가 방전되고 있다는 신호입니다. 자고 일어나도 개운하지 않고, 집중력이 떨어지며 소화도 잘 안 될 수 있습니다. 더 지치기 전에 에너지를 채워줘야 합니다.',
                tags: ['만성피로', '기력회복', '면역강화'],
                ctaHeadline: '내 몸에 휴식과 보양을 선물하세요.',
                ctaBody: '체질에 맞는 맞춤 보약으로 부족한 기혈을 보충하고 활력을 되찾아 드립니다.'
            },
            {
                level: 'high',
                minScore: 12,
                maxScore: 20,
                title: '기력 소진/번아웃 단계',
                subtitle: '적극적인 회복과 치료가 필요합니다',
                description: '단순한 피로를 넘어, 몸의 진액과 원기가 많이 고갈된 상태입니다. 수술 후나 큰 병을 앓은 뒤, 혹은 극심한 번아웃 상태일 수 있습니다. 이대로 방치하면 다른 질병으로 이어질 수 있습니다.',
                tags: ['번아웃', '수술후회복', '원기회복'],
                ctaHeadline: '전문가의 도움으로 다시 일어서세요.',
                ctaBody: '녹용, 공진단 등 고농축 보약과 침 치료를 병행하여, 몸의 기초 체력을 길러드립니다.'
            }
        ],
        programVariants: [

            {
                id: 'depression',
                name: '우울증',
                resultOverrides: {
                    medium: { title: '경도 우울/무기력', tags: ['의욕저하', '식욕변화', '기분전환'] },
                    high: { title: '주요 우울 장애', tags: ['사회적고립', '인지기능저하', '적극적치료'] }
                }
            },
            {
                id: 'panic',
                name: '공황/불안',
                resultOverrides: {
                    medium: { title: '범불안장애/예기불안', tags: ['가슴두근거림', '초조함', '자율신경'] },
                    high: { title: '공황장애', tags: ['죽을것같은공포', '과호흡', '응급상황대처'] }
                }
            },
            {
                id: 'anger',
                name: '화병',
                resultOverrides: {
                    medium: { title: '화병 초기/울화', tags: ['가슴답답', '목이물감', '울체해소'] },
                    high: { title: '만성 화병', tags: ['열오름', '두통/불면', '심화배출'] }
                }
            }
        ]
    }
};
