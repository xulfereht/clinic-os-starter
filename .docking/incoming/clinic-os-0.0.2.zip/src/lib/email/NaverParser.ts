
import * as cheerio from 'cheerio';

export interface ParsedEmailLead {
    name: string;
    phone: string;
    inquiry: string;
    product: string | null;
    reservationDate: string | null;
    reservationNumber: string | null;
    rawDate: string | null;
    status: 'NEW' | 'CONFIRMED' | 'CANCELLED' | 'CHANGED' | 'UNKNOWN';
}

export class NaverParser {
    static parseSubject(subject: string): ParsedEmailLead['status'] {
        if (subject.includes('취소')) return 'CANCELLED';
        if (subject.includes('확정')) return 'CONFIRMED';
        if (subject.includes('변경')) return 'CHANGED';
        if (subject.includes('접수')) return 'NEW';
        return 'UNKNOWN';
    }

    /**
     * Parses Naver Reservation Email HTML
     * @param htmlBody Raw HTML content of the email
     * @param subject Optional subject for status determination
     */
    static parse(htmlBody: string, subject: string = ''): ParsedEmailLead | null {
        const $ = cheerio.load(htmlBody);

        let name = '';
        let phone = '';
        let inquiry = '';
        let product = null;
        let reservationDate = null;
        let reservationNumber = null;

        // Try to find key fields by label
        $('th, td, strong, span').each((_, el) => {
            const text = $(el).text().trim();
            const value = $(el).next().text().trim() || $(el).parent().next().text().trim();

            if (text.includes('예약자명') || text.includes('신청자명')) {
                name = value;
            }
            if (text.includes('연락처')) {
                phone = value;
            }
            if (text.includes('요청사항') || text.includes('문의내용')) {
                inquiry = value.replace(/^문의내용|요청사항\s*/, '').trim();
            }
            if (text.includes('상품명') || text.includes('예약상품')) {
                product = value;
            }
            if (text.includes('이용일시') || text.includes('예약일시')) {
                reservationDate = value;
            }
            if (text.includes('예약번호')) {
                reservationNumber = value;
            }
        });

        if (!name && !phone) {
            const fullText = $.text();
            const phoneMatch = fullText.match(/010-\d{4}-\d{4}/);
            if (phoneMatch) phone = phoneMatch[0];

            const nameMatch = fullText.match(/예약자\s*:\s*([가-힣]{2,5})/);
            if (nameMatch) name = nameMatch[1];
        }

        if (!name && !phone) return null;

        return {
            name: name || 'Unknown',
            phone: phone || '',
            inquiry: inquiry || '내용 없음',
            product,
            reservationDate,
            reservationNumber,
            rawDate: new Date().toISOString(),
            status: NaverParser.parseSubject(subject)
        };
    }
}
