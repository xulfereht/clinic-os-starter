/**
 * Naver TalkTalk Integration Library
 * 
 * Handles sending and receiving messages with Naver TalkTalk Chatbot API
 * Reference: https://github.com/navertalk/chatbot-api
 */

export interface NaverTalkConfig {
    token: string;
    enabled?: boolean;
}

export interface NaverTalkUser {
    user: string;  // Naver TalkTalk user identifier
}

export interface NaverTalkTextContent {
    text: string;
    code?: string;
    inputType?: 'typing' | 'button' | 'sticker' | 'vphone' | 'product';
}

export interface NaverTalkImageContent {
    imageUrl: string;
}

export interface NaverTalkIncomingEvent {
    event: 'open' | 'send' | 'leave' | 'friend' | 'echo';
    user: string;
    textContent?: NaverTalkTextContent;
    imageContent?: NaverTalkImageContent;
    options?: {
        mobile?: boolean;
        product?: any;
    };
}

export interface NaverTalkSendResponse {
    success: boolean;
    resultCode: string;
    resultMessage?: string;
}

/**
 * Send a text message to a Naver TalkTalk user
 */
export async function sendNaverTalkMessage(
    config: NaverTalkConfig,
    user: string,
    text: string
): Promise<NaverTalkSendResponse> {
    const endpoint = 'https://gw.talk.naver.com/chatbot/v1/event';

    const payload = {
        event: 'send',
        user: user,
        textContent: {
            text: text
        }
    };

    try {
        const res = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json;charset=UTF-8',
                'Authorization': config.token.startsWith('Bearer ') ? config.token : `Bearer ${config.token}`
            },
            body: JSON.stringify(payload)
        });

        const data = await res.json();

        return {
            success: data.success === true || data.resultCode === '00',
            resultCode: data.resultCode || 'unknown',
            resultMessage: data.resultMessage
        };
    } catch (error: any) {
        console.error('[NaverTalk] Send error:', error);
        return {
            success: false,
            resultCode: 'error',
            resultMessage: error.message
        };
    }
}

/**
 * Send an image message to a Naver TalkTalk user
 */
export async function sendNaverTalkImage(
    config: NaverTalkConfig,
    user: string,
    imageUrl: string
): Promise<NaverTalkSendResponse> {
    const endpoint = 'https://gw.talk.naver.com/chatbot/v1/event';

    const payload = {
        event: 'send',
        user: user,
        imageContent: {
            imageUrl: imageUrl
        }
    };

    try {
        const res = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json;charset=UTF-8',
                'Authorization': config.token.startsWith('Bearer ') ? config.token : `Bearer ${config.token}`
            },
            body: JSON.stringify(payload)
        });

        const data = await res.json();

        return {
            success: data.success === true || data.resultCode === '00',
            resultCode: data.resultCode || 'unknown',
            resultMessage: data.resultMessage
        };
    } catch (error: any) {
        console.error('[NaverTalk] Send image error:', error);
        return {
            success: false,
            resultCode: 'error',
            resultMessage: error.message
        };
    }
}

/**
 * Get Naver TalkTalk configuration from database
 */
export async function getNaverTalkConfig(db: any): Promise<NaverTalkConfig | null> {
    try {
        const result = await db.prepare("SELECT integrations FROM clinics WHERE id = 1").first();

        if (result?.integrations) {
            const integrations = JSON.parse(result.integrations as string);
            if (integrations.naverTalk?.enabled && integrations.naverTalk?.token) {
                return {
                    token: integrations.naverTalk.token,
                    enabled: integrations.naverTalk.enabled
                };
            }
        }
        return null;
    } catch (error) {
        console.error('[NaverTalk] Failed to get config:', error);
        return null;
    }
}
