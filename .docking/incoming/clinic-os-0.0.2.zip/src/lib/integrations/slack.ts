/**
 * Slack Integration Utility
 * Sends formatted messages to Slack via webhook
 */

export interface SlackConfig {
    enabled: boolean;
    webhookUrl: string;
    channel?: string;
}

export interface InquiryNotification {
    name: string;
    phone: string;
    visitCategory?: string;
    patientType?: string;
    mainSymptom?: string;
    submittedAt: string;
}

/**
 * Send a notification to Slack when a new inquiry is received
 */
export async function sendSlackNotification(
    config: SlackConfig,
    inquiry: InquiryNotification
): Promise<{ success: boolean; error?: string }> {
    if (!config.enabled || !config.webhookUrl) {
        return { success: false, error: 'Slack integration is not enabled' };
    }

    try {
        const patientTypeLabel = inquiry.patientType === 'new' ? '초진' : '재진';
        const categoryEmoji = getCategoryEmoji(inquiry.visitCategory);

        const message = {
            blocks: [
                {
                    type: "header",
                    text: {
                        type: "plain_text",
                        text: `${categoryEmoji} 새로운 문의가 접수되었습니다`,
                        emoji: true
                    }
                },
                {
                    type: "section",
                    fields: [
                        {
                            type: "mrkdwn",
                            text: `*이름*\n${inquiry.name}`
                        },
                        {
                            type: "mrkdwn",
                            text: `*연락처*\n${inquiry.phone}`
                        },
                        {
                            type: "mrkdwn",
                            text: `*구분*\n${patientTypeLabel}`
                        },
                        {
                            type: "mrkdwn",
                            text: `*문의 유형*\n${inquiry.visitCategory || '일반'}`
                        }
                    ]
                },
                ...(inquiry.mainSymptom ? [{
                    type: "section",
                    text: {
                        type: "mrkdwn",
                        text: `*증상/메시지*\n${inquiry.mainSymptom.substring(0, 200)}${inquiry.mainSymptom.length > 200 ? '...' : ''}`
                    }
                }] : []),
                {
                    type: "context",
                    elements: [
                        {
                            type: "mrkdwn",
                            text: `접수 시간: ${inquiry.submittedAt}`
                        }
                    ]
                },
                {
                    type: "divider"
                }
            ]
        };

        const response = await fetch(config.webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(message)
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('[Slack] Failed to send notification:', errorText);
            return { success: false, error: `Slack API error: ${response.status}` };
        }

        console.log('[Slack] Notification sent successfully');
        return { success: true };

    } catch (error: any) {
        console.error('[Slack] Error sending notification:', error);
        return { success: false, error: error.message };
    }
}

/**
 * Send a test message to verify Slack webhook configuration
 */
export async function sendSlackTestMessage(webhookUrl: string): Promise<{ success: boolean; error?: string }> {
    try {
        const message = {
            blocks: [
                {
                    type: "section",
                    text: {
                        type: "mrkdwn",
                        text: "✅ *테스트 메시지* - Clinic-OS Slack 연동이 정상적으로 설정되었습니다!"
                    }
                },
                {
                    type: "context",
                    elements: [
                        {
                            type: "mrkdwn",
                            text: `테스트 시간: ${new Date().toLocaleString('ko-KR')}`
                        }
                    ]
                }
            ]
        };

        const response = await fetch(webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(message)
        });

        if (!response.ok) {
            const errorText = await response.text();
            return { success: false, error: `Webhook 오류: ${errorText}` };
        }

        return { success: true };

    } catch (error: any) {
        return { success: false, error: `연결 오류: ${error.message}` };
    }
}

function getCategoryEmoji(category?: string): string {
    switch (category) {
        case '다이어트': return '💊';
        case '일반진료': return '🏥';
        default: return '📩';
    }
}
