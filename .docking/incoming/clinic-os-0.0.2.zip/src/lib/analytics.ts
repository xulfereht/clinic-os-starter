import type { D1Database } from '@cloudflare/workers-types';

export interface DashboardStats {
  summary: {
    views: number;
    sessions: number;
    uniqueVisitors: number;  // Total unique visitors (by ip_hash) - newUsers + returningUsers should equal this
    leads: number;
    conversionRate: number;
    avgDurationSec: number;
    newUsers: number;
    returningUsers: number;
  };
  trends: {
    label: string;
    views: number;
    leads: number;
    sessions: number;   // Unique sessions by session_id
    visitors: number;   // Unique visitors by ip_hash
  }[];
  acquisition: {
    source: string;
    count: number;
  }[];
  topPages: {
    path: string;
    views: number;
  }[];
  programPerformance: {
    path: string;
    views: number;
  }[];
  funnel: {
    step: string;
    count: number;
    dropOff: number;
    rate: number;
  }[];
  deviceStats: {
    device_type: string;
    count: number;
  }[];
}

import { hashIP } from './analytics-utils';
import { getClinicSettings } from './clinic';

export class AnalyticsService {
  private static toKST(column: string): string {
    return `datetime(${column}, '+9 hours')`;
  }

  private static getDateFilter(range: 'today' | 'week' | 'month' | 'custom', startDate?: string): string {
    if (range === 'custom' && startDate) {
      return startDate;
    }

    const now = new Date();
    const kstNow = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Seoul' }));

    if (range === 'today') {
      return kstNow.toISOString().split('T')[0];
    } else if (range === 'week') {
      const weekAgo = new Date(kstNow.getTime() - 7 * 24 * 60 * 60 * 1000);
      return weekAgo.toISOString().split('T')[0];
    } else {
      const monthAgo = new Date(kstNow.getTime() - 30 * 24 * 60 * 60 * 1000);
      return monthAgo.toISOString().split('T')[0];
    }
  }

  static async getDashboardStats(
    db: D1Database,
    range: 'today' | 'week' | 'month' | 'custom',
    options?: { startDate?: string; endDate?: string }
  ): Promise<DashboardStats> {
    const dateFilter = this.getDateFilter(range, options?.startDate);
    const endDateFilter = options?.endDate || null;

    // Fetch blocked IPs from DB
    const settings = await getClinicSettings(db);
    const blockedIps = settings.analyticsConfig?.blockedIps || [];

    // Calculate hashes to exclude for internal IPs
    const excludedHashes = await Promise.all(blockedIps.map(ip => hashIP(ip)));
    const excludedHashString = excludedHashes.map(h => `'${h}'`).join(',');
    const hashFilter = excludedHashes.length > 0 ? `AND (ip_hash IS NULL OR ip_hash NOT IN (${excludedHashString}))` : '';
    const endDateClause = endDateFilter ? `AND date(${this.toKST('created_at')}) <= date('${endDateFilter}')` : '';

    // Filter for page_views table (has ip_hash column)
    const pageViewsFilter = `
            date(${this.toKST('created_at')}) >= date(?)
            ${endDateClause}
            AND path NOT LIKE '/admin%'
            ${hashFilter}
        `;

    // Filter for analytics_events table (does NOT have ip_hash column)
    const eventsFilter = `
            date(${this.toKST('created_at')}) >= date(?)
            ${endDateClause}
            AND path NOT LIKE '/admin%'
        `;

    // 1. Summary Metrics
    const trafficResult = await db.prepare(`
            SELECT 
                COUNT(*) as views,
                COUNT(DISTINCT session_id) as sessions,
                COUNT(DISTINCT ip_hash) as unique_visitors
            FROM page_views 
            WHERE ${pageViewsFilter}
        `).bind(dateFilter).first();

    const views = (trafficResult?.views as number) || 0;
    const sessions = (trafficResult?.sessions as number) || 0;
    const totalVisitorsInRange = (trafficResult?.unique_visitors as number) || 0;

    // New vs Returning Visitor Calculation (using ip_hash as visitor identifier)
    // New Visitor: ip_hash whose FIRST EVER page view (across ALL time) is within this date range
    // Returning Visitor: ip_hash whose first-ever visit was BEFORE this date range

    // Simple approach: 
    // 1. Get list of ip_hash that visited in current range (from totalVisitorsInRange query above)
    // 2. For each of those, check if their GLOBAL first visit date is >= dateFilter
    // 3. Count those as "new", the rest are "returning"

    // New visitors = visitors in range whose first-ever visit globally is in range
    const newVisitorsResult = await db.prepare(`
        SELECT COUNT(DISTINCT ip_hash) as count
        FROM page_views
        WHERE ip_hash IS NOT NULL
        AND ip_hash IN (
            -- ip_hash whose first-ever visit is in this range
            SELECT ip_hash 
            FROM page_views 
            WHERE ip_hash IS NOT NULL
            GROUP BY ip_hash
            HAVING date(MIN(${this.toKST('created_at')})) >= date(?)
        )
        AND ${pageViewsFilter}
    `).bind(dateFilter, dateFilter).first();

    const newUsers = (newVisitorsResult?.count as number) || 0;
    // Returning = visitors in range whose first visit was BEFORE the range
    const returningUsers = Math.max(0, totalVisitorsInRange - newUsers);

    // Leads
    const leadsResult = await db.prepare(`
            SELECT COUNT(*) as count 
            FROM analytics_events 
            WHERE event_type IN ('inquiry_submit', 'survey_complete')
            AND ${eventsFilter}
        `).bind(dateFilter).first();
    const leads = (leadsResult?.count as number) || 0;

    // Avg Duration (excluding outliers: > 30 min likely abandoned tabs)
    const MAX_REASONABLE_DURATION = 1800; // 30 minutes in seconds
    const durationResult = await db.prepare(`
            SELECT AVG(json_extract(event_data, '$.seconds')) as avg_seconds
            FROM analytics_events 
            WHERE event_type = 'page_exit'
            AND json_extract(event_data, '$.seconds') > 0
            AND json_extract(event_data, '$.seconds') <= ${MAX_REASONABLE_DURATION}
            AND ${eventsFilter}
        `).bind(dateFilter).first();
    const avgDurationSec = Math.round((durationResult?.avg_seconds as number) || 0);

    const conversionRate = sessions > 0 ? parseFloat(((leads / sessions) * 100).toFixed(1)) : 0;

    // 2. Trend Data (with sessions and visitors)
    let trendQuery = '';
    if (range === 'today') {
      trendQuery = `
                SELECT 
                    strftime('%H:00', ${this.toKST('created_at')}) as label, 
                    COUNT(*) as views,
                    COUNT(DISTINCT session_id) as sessions,
                    COUNT(DISTINCT ip_hash) as visitors
                FROM page_views
                WHERE date(${this.toKST('created_at')}) = date(?)
                AND path NOT LIKE '/admin%'
                GROUP BY label ORDER BY label
            `;
    } else {
      trendQuery = `
                SELECT 
                    strftime('%m-%d', ${this.toKST('created_at')}) as label, 
                    COUNT(*) as views,
                    COUNT(DISTINCT session_id) as sessions,
                    COUNT(DISTINCT ip_hash) as visitors
                FROM page_views
                WHERE ${pageViewsFilter}
                GROUP BY label ORDER BY MIN(created_at)
            `;
    }

    const trendResults = await db.prepare(trendQuery).bind(dateFilter).all();
    let trends = (trendResults.results as any[]).map(r => ({ ...r, leads: 0 }));

    // Lead Trends & Duration Trends
    let leadTrendQuery = '';
    let durationTrendQuery = '';

    if (range === 'today') {
      leadTrendQuery = `
                SELECT strftime('%H:00', ${this.toKST('created_at')}) as label, COUNT(*) as count
                FROM analytics_events
                WHERE event_type IN ('inquiry_submit', 'survey_complete')
                AND date(${this.toKST('created_at')}) = date(?)
                AND path NOT LIKE '/admin%'
                GROUP BY label
            `;
      durationTrendQuery = `
                SELECT strftime('%H:00', ${this.toKST('created_at')}) as label, AVG(json_extract(event_data, '$.seconds')) as avg_seconds
                FROM analytics_events
                WHERE event_type = 'page_exit'
                AND json_extract(event_data, '$.seconds') > 0
                AND json_extract(event_data, '$.seconds') <= 1800
                AND date(${this.toKST('created_at')}) = date(?)
                AND path NOT LIKE '/admin%'
                GROUP BY label
            `;
    } else {
      leadTrendQuery = `
                SELECT strftime('%m-%d', ${this.toKST('created_at')}) as label, COUNT(*) as count
                FROM analytics_events
                WHERE ${eventsFilter}
                AND event_type IN ('inquiry_submit', 'survey_complete')
                GROUP BY label
            `;
      durationTrendQuery = `
                SELECT strftime('%m-%d', ${this.toKST('created_at')}) as label, AVG(json_extract(event_data, '$.seconds')) as avg_seconds
                FROM analytics_events
                WHERE ${eventsFilter}
                AND event_type = 'page_exit'
                AND json_extract(event_data, '$.seconds') > 0
                AND json_extract(event_data, '$.seconds') <= 1800
                GROUP BY label
            `;
    }
    const leadTrends = await db.prepare(leadTrendQuery).bind(dateFilter).all();
    const leadMap = new Map((leadTrends.results as any[]).map(l => [l.label, l.count]));

    const durationTrends = await db.prepare(durationTrendQuery).bind(dateFilter).all();
    const durationMap = new Map((durationTrends.results as any[]).map(l => [l.label, Math.round(l.avg_seconds || 0)]));

    trends = trends.map(t => {
      const avgPV = t.sessions > 0 ? parseFloat((t.views / t.sessions).toFixed(1)) : 0;
      return {
        ...t,
        leads: leadMap.get(t.label) || 0,
        avgDuration: durationMap.get(t.label) || 0,
        avgPageviews: avgPV
      };
    });

    // 3. Detailed Referrers
    // Fetch raw referrers and process in simplified way (Domain level)
    const rawReferrers = await db.prepare(`
            SELECT referrer, COUNT(DISTINCT session_id) as count
            FROM page_views
            WHERE ${pageViewsFilter}
            AND referrer IS NOT NULL AND referrer != ''
            AND referrer NOT LIKE '%example.com%'
            GROUP BY referrer
            ORDER BY count DESC
            LIMIT 50
        `).bind(dateFilter).all();

    // Process in JS to aggregage domains/hostnames
    const refMap = new Map<string, number>();
    for (const row of rawReferrers.results as any[]) {
      try {
        const url = new URL(row.referrer);
        // Clean hostname: search.naver.com -> naver.com search?
        // User wants "Detailed", so let's keep hostname + path if search?
        // Actually, "search.naver.com" is better than just "Naver Search".
        // "m.search.naver.com" is distinct.
        let key = url.hostname;
        let keyword = url.searchParams.get('query') || url.searchParams.get('q');

        if (key.includes('google')) {
          key = 'Google Search';
        } else if (key.includes('naver')) {
          key = 'Naver Search';
        } else if (key.includes('daum')) {
          key = 'Daum Search';
        } else if (key.includes('instagram')) {
          key = 'Instagram';
        } else if (key.includes('facebook')) {
          key = 'Facebook';
        }

        if (keyword) {
          // key = `${key} ("${decodeURIComponent(keyword)}")`;
          // Careful with decoding errors
          try {
            key = `${key} : ${decodeURIComponent(keyword)}`;
          } catch (e) {
            key = `${key} : ${keyword}`;
          }
        } else if (!keyword && (key.includes('Search') || key.includes('naver') || key.includes('daum'))) {
          // If it's a search engine but no keyword, maybe show hostname to be specific
          if (url.hostname !== key) {
            // key = `${key} (${url.hostname})`;
          }
        }

        refMap.set(key, (refMap.get(key) || 0) + row.count);
      } catch {
        refMap.set('Unknown', (refMap.get('Unknown') || 0) + row.count);
      }
    }

    const acquisition = Array.from(refMap.entries())
      .map(([source, count]) => ({ source, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8); // Top 8 sources

    // 4. Content Performance
    const topPages = await db.prepare(`
            SELECT path, COUNT(*) as views 
            FROM page_views 
            WHERE ${pageViewsFilter}
            GROUP BY path ORDER BY views DESC LIMIT 8
        `).bind(dateFilter).all();

    const programPerformance = await db.prepare(`
            SELECT path, COUNT(*) as views 
            FROM page_views 
            WHERE ${pageViewsFilter} AND path LIKE '/programs/%'
            GROUP BY path ORDER BY views DESC LIMIT 5
        `).bind(dateFilter).all();

    // 5. Funnel
    const surveyStartRes = await db.prepare(`
          SELECT COUNT(*) as count FROM analytics_events 
          WHERE event_type = 'survey_start' AND ${eventsFilter}
        `).bind(dateFilter).first();
    const surveyStarts = (surveyStartRes?.count as number) || 0;

    const funnel = [
      { step: '방문 (Sessions)', count: sessions, dropOff: 0, rate: 100 },
      { step: '자가진단 시작', count: surveyStarts, dropOff: sessions - surveyStarts, rate: sessions > 0 ? Math.round((surveyStarts / sessions) * 100) : 0 },
      { step: '리드 전환', count: leads, dropOff: surveyStarts - leads, rate: surveyStarts > 0 ? Math.round((leads / surveyStarts) * 100) : 0 }
    ];

    // 6. Device Stats
    const deviceResult = await db.prepare(`
            SELECT device_type, COUNT(DISTINCT session_id) as count 
            FROM page_views 
            WHERE ${pageViewsFilter} AND device_type IS NOT NULL
            GROUP BY device_type ORDER BY count DESC
        `).bind(dateFilter).all();

    return {
      summary: {
        views, sessions,
        uniqueVisitors: totalVisitorsInRange,  // This equals newUsers + returningUsers
        leads, conversionRate, avgDurationSec,
        newUsers,        // Properly calculated from ip_hash first-seen date
        returningUsers   // Calculated as uniqueVisitors - newUsers
      },
      trends: trends as any[],
      acquisition,
      topPages: topPages.results as any[],
      programPerformance: programPerformance.results as any[],
      funnel,
      deviceStats: deviceResult.results as any[]
    };
  }

  static async getRealtimeStats(db: D1Database) {
    // Real-time window: Last 30 minutes
    // Note: 'now' in SQLite is UTC. transforming to KST for consistency if stored as KST?
    // Actually, created_at is stored as UTC usually? Let's check.
    // In `track.ts`, we use default timestamp? 
    // Wait, D1/SQLite default current_timestamp is UTC.
    // Our existing queries use `datetime(created_at, '+9 hours')` which implies created_at is UTC.
    // So for "last 30 minutes", we can just compare UTC to UTC.

    const timeWindow = `datetime('now', '-30 minutes')`;

    // Fetch blocked IPs to exclude them from Realtime too
    const settings = await getClinicSettings(db);
    const blockedIps = settings.analyticsConfig?.blockedIps || [];
    const excludedHashes = await Promise.all(blockedIps.map(ip => hashIP(ip)));
    const excludedHashString = excludedHashes.map(h => `'${h}'`).join(',');
    const hashFilter = excludedHashes.length > 0 ? `AND (ip_hash IS NULL OR ip_hash NOT IN (${excludedHashString}))` : '';

    const baseFilter = `created_at >= ${timeWindow} AND path NOT LIKE '/admin%' ${hashFilter}`;

    // 1. Total Active Users
    // We count distinct sessions or visitor_ids in the last 30 min
    const activeUsersRes = await db.prepare(`
        SELECT COUNT(DISTINCT session_id) as count
        FROM page_views
        WHERE ${baseFilter}
    `).first();
    const activeUsers = (activeUsersRes?.count as number) || 0;

    // 2. Top Active Pages
    const topPagesRes = await db.prepare(`
        SELECT path, COUNT(*) as views
        FROM page_views
        WHERE ${baseFilter}
        GROUP BY path
        ORDER BY views DESC
        LIMIT 5
    `).all();

    // 3. Active Countries (or Cities if available, but we only have country)
    const countriesRes = await db.prepare(`
        SELECT country, COUNT(DISTINCT session_id) as count
        FROM page_views
        WHERE ${baseFilter}
        GROUP BY country
        ORDER BY count DESC
        LIMIT 5
    `).all();

    // 4. Per minute trend (last 30 min) for the sparkline
    const trendRes = await db.prepare(`
        SELECT strftime('%H:%M', datetime(created_at, '+9 hours')) as minute, COUNT(*) as views
        FROM page_views
        WHERE ${baseFilter}
        GROUP BY minute
        ORDER BY minute ASC
    `).all();

    return {
      activeUsers,
      topPages: topPagesRes.results,
      activeCountries: countriesRes.results,
      trend: trendRes.results
    };
  }
}
