export interface IntakePayload {
  patient: {
    name: string;
    age: number | null;
    sex: "male" | "female" | "other" | null;
    contact: {
      phone: string;
      channel: "phone" | "kakao" | "sms" | "email";
    };
  };
  context: {
    visitType: "first" | "followup" | "consult-only";
    preferredTime: string | null;
  };
  chiefComplaints: {
    symptomId: string;
    label: string;
    severity: number | null; // 0-10
    duration: {
      value: number | null;
      unit: "days" | "weeks" | "months" | "years";
    };
    description: string;
  }[];
  lifestyle: {
    sleepHours: number | null;
    sleepQuality: "good" | "average" | "poor" | null;
    alcoholPerWeek: number | null;
    exercisePerWeek: number | null;
    stressLevel: number | null; // 0-10
  };
  goals: {
    primaryGoal: string;
    secondaryGoals: string[];
  };
  meta: {
    source: string;
    referrer: string;
  };
  consent: {
    privacy: boolean;
    marketing: boolean;
  };
}

export interface IntakeResponse {
  leadId?: string;
  intakeId: string;
  receivedAt: string;
  status: "ok" | "error";
  summaryForClinic: {
    headline: string;
    keyPoints: string[];
  };
  summaryForPatient: {
    title: string;
    body: string;
  };
  nextSteps: {
    recommendation: string;
    ctaLabel: string;
    ctaUrl: string;
  };
}
