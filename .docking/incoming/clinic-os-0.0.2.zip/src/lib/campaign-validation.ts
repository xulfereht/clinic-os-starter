
import { generateSegmentSql, type SegmentCriteria } from './segment-engine';
import { getSurveyLink } from './survey-registry';

export interface Patient {
    id: string;
    name: string;
    current_phone: string;
}

import { getClinicSettings } from './clinic';

export interface ClinicInfo {
    name: string;
    phone: string;
    url?: string;
}

export async function getCampaignData(db: any, campaignId: string) {
    // 1. Fetch Campaign
    const campaign = await db.prepare(`SELECT * FROM campaigns WHERE id = ?`).bind(campaignId).first();
    if (!campaign) throw new Error('Campaign not found');

    // 2. Fetch Template
    const template = await db.prepare("SELECT * FROM message_templates WHERE id = ?").bind(campaign.template_id).first();
    if (!template) throw new Error('Template not found');

    // 3. Fetch Segment & Patients
    if (!campaign.segment_id) throw new Error('No segment selected');

    const segment = await db.prepare('SELECT query_sql, criteria FROM segments WHERE id = ?').bind(campaign.segment_id).first();
    if (!segment) throw new Error('Segment not found');

    let whereClause = "";
    let queryParams: any[] = [];

    if (segment.criteria) {
        try {
            const criteria = JSON.parse(segment.criteria as string) as SegmentCriteria;
            const gen = generateSegmentSql(criteria);
            whereClause = gen.sql;
            queryParams = gen.params;
        } catch (e) {
            console.error("Failed to parse segment criteria", e);
            whereClause = segment.query_sql as string;
        }
    } else {
        whereClause = segment.query_sql as string;
    }

    let fullSql = "";
    if (whereClause.trim().toUpperCase().startsWith("SELECT")) {
        fullSql = whereClause;
    } else {
        fullSql = `SELECT id as patient_id FROM patients WHERE ${whereClause}`;
    }

    const segmentResult = await db.prepare(fullSql).bind(...queryParams).run();
    const patientIds = (segmentResult.results || []).map((r: any) => r.patient_id || r.id);

    if (patientIds.length === 0) return { campaign, template, patients: [] };

    // Fetch full patient details
    const placeholders = patientIds.map(() => '?').join(',');
    const patientsResult = await db.prepare(`
        SELECT id, name, current_phone FROM patients 
        WHERE id IN (${placeholders}) 
        AND current_phone IS NOT NULL 
        AND current_phone != ''
        AND deleted_at IS NULL
    `).bind(...patientIds).run();

    const rawPatients = patientsResult.results as any[];

    // De-duplicate
    const uniquePhones = new Set<string>();
    const patients: Patient[] = [];

    for (const p of rawPatients) {
        const normalizedPhone = p.current_phone.replace(/-/g, '');
        if (!uniquePhones.has(normalizedPhone)) {
            uniquePhones.add(normalizedPhone);
            patients.push(p);
        }
    }

    return { campaign, template, patients };
}
//...

export async function getClinicInfo(db: any): Promise<ClinicInfo> {
    const settings = await getClinicSettings(db);
    return {
        name: settings.name,
        phone: settings.contact.phone,
        url: settings.url
    };
}

export async function getPatientVariables(db: any, patient: Patient, clinicInfo: ClinicInfo) {
    const baseUrl = clinicInfo.url || 'https://www.example.com';
    const surveyUrl = getSurveyLink('diagnosis_weighted_v2', String(patient.id), baseUrl);

    // Fetch Next Reservation
    const nowSeconds = Math.floor(Date.now() / 1000);
    const reservation = await db.prepare(`
        SELECT reserved_at FROM reservations
        WHERE patient_id = ?
        AND status NOT IN ('cancelled', 'no_show', 'completed')
        AND (
            (typeof(reserved_at) = 'integer' AND reserved_at > ?)
            OR
            (typeof(reserved_at) = 'text' AND reserved_at > ?)
        )
        ORDER BY reserved_at ASC LIMIT 1
    `).bind(patient.id, nowSeconds, new Date().toISOString()).first() as { reserved_at: number | string } | null;

    let resDate = '';
    let resTime = '';
    let resDateTime = '';

    if (reservation && reservation.reserved_at) {
        let rDate: Date;
        if (typeof reservation.reserved_at === 'number') {
            rDate = new Date(reservation.reserved_at * 1000);
        } else {
            rDate = new Date(reservation.reserved_at);
        }

        const kstOffset = 9 * 60 * 60 * 1000;
        const kstDate = new Date(rDate.getTime() + kstOffset);

        const month = kstDate.getUTCMonth() + 1;
        const day = kstDate.getUTCDate();
        const hour = kstDate.getUTCHours();
        const minute = kstDate.getUTCMinutes();
        const year = kstDate.getUTCFullYear();

        const pad = (n: number) => n.toString().padStart(2, '0');

        resDate = `${year}-${pad(month)}-${pad(day)}`;
        resTime = `${pad(hour)}:${pad(minute)}`;
        resDateTime = `${month}월 ${day}일 ${pad(hour)}:${pad(minute)}`;
    }

    return {
        clinic_name: clinicInfo.name,
        clinic_phone: clinicInfo.phone,
        url: surveyUrl,
        name: patient.name,
        patient_name: patient.name,
        이름: patient.name,
        휴대폰: patient.current_phone,
        reservation_date: resDate,
        예약일: resDate,
        reservation_time: resTime,
        예약시간: resTime,
        reservation_datetime: resDateTime,
        예약일시: resDateTime,
        // Alias for tracking
        tracking_number: ''
    };
}

export function validateMessageContent(content: string, variables: Record<string, string>) {
    // Regex to find variables: #{var} or {var}
    const regex = /#\{([a-zA-Z0-9_가-힣]+)\}|\{([a-zA-Z0-9_가-힣]+)\}/g;
    const missing: string[] = [];

    // We want to find variables relevant to the content
    let match;
    while ((match = regex.exec(content)) !== null) {
        const varName = match[1] || match[2];
        const val = variables[varName];

        // If value is empty string, it is missing
        if (!val || val.trim() === '') {
            // Avoid duplicates
            if (!missing.includes(varName)) {
                missing.push(varName);
            }
        }
    }
    return missing;
}

export function substituteVariables(content: string, variables: Record<string, string>) {
    let result = content;
    // We iterate specific keys to ensure order and handling
    // Or we can just use regex replacement based on map

    // Order matters? No, just replace all known variables
    for (const [key, val] of Object.entries(variables)) {
        // Replace #{key} and {key}
        const regex = new RegExp(`(#\\{${key}\\}|\\{${key}\\})`, 'g');
        result = result.replace(regex, val);
    }

    // Clean up unknown variables? 
    // The current send.ts logic specifically cleans #{tracking_number}
    // and maybe others?
    // send.ts logic iterates specific known sets.

    return result;
}
