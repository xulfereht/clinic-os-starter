import type { AligoConfig, AligoResponse } from './aligo';
import { sendAlimTalk } from './aligo';

/**
 * Variables that can be substituted in AlimTalk templates
 */
export interface AlimTalkVariables {
    // Clinic
    clinic_name: string;
    clinic_phone: string;
    clinic_address?: string;
    bank_info?: string;

    // Patient
    patient_name: string;
    patient_phone: string;

    // Reservation
    reservation_date?: string;
    reservation_time?: string;
    reservation_datetime?: string;

    // Links
    survey_url?: string;
    upload_url?: string;
}

/**
 * Template data required for sending AlimTalk
 */
export interface AlimTalkTemplate {
    name: string;
    content: string;
    alimtalk_code: string;
    buttons: string | null;
}

/**
 * Validate if template has required variables and patient has necessary data
 */
export function validateRequiredVariables(
    templateContent: string,
    variables: AlimTalkVariables
): { valid: boolean; missingReason?: string } {
    // Check if template requires reservation variables
    const hasReservationVars = /#{reservation_date}|{reservation_date}|#{예약일}|#{reservation_time}|{reservation_time}|#{예약시간}|#{reservation_datetime}|{reservation_datetime}|#{예약일시}/.test(templateContent);

    if (hasReservationVars && !variables.reservation_datetime) {
        return {
            valid: false,
            missingReason: 'Template requires reservation data but patient has no reservations'
        };
    }

    return { valid: true };
}

/**
 * Prepare AlimTalk content with CRLF normalization and variable substitution
 */
export function prepareAlimTalkContent(
    template: AlimTalkTemplate,
    variables: AlimTalkVariables
): { content: string; subject: string } {
    let content = template.content || '';

    // CRITICAL: Normalize CRLF - Aligo templates use \r\n (CRLF)
    // Normalize first (\r\n and \r to \n), then convert to \r\n for Aligo
    content = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    content = content.replace(/\n/g, '\r\n');

    // Clinic Variables
    content = content.replace(/#{clinic_name}|{clinic_name}/g, variables.clinic_name);
    content = content.replace(/#{clinic_phone}|{clinic_phone}/g, variables.clinic_phone);
    if (variables.clinic_address) {
        content = content.replace(/#{clinic_address}|{clinic_address}/g, variables.clinic_address);
    }
    if (variables.bank_info) {
        content = content.replace(/#{bank_info}|{bank_info}/g, variables.bank_info);
    }
    // Clear old individual bank variables
    content = content.replace(/#{bank_name}|{bank_name}/g, '');
    content = content.replace(/#{bank_account}|{bank_account}/g, '');
    content = content.replace(/#{bank_holder}|{bank_holder}/g, '');

    // Links
    if (variables.survey_url) {
        content = content.replace(/#{url}|{url}|#{survey_link}|{survey_link}|#{survey_url}|{survey_url}/g, variables.survey_url);
    }
    if (variables.upload_url) {
        content = content.replace(/#{upload_link}|{upload_link}|#{upload_url}|{upload_url}/g, variables.upload_url);
    }

    // Reservation Variables
    content = content.replace(/#{reservation_date}|{reservation_date}|#{예약일}/g, variables.reservation_date || '');
    content = content.replace(/#{reservation_time}|{reservation_time}|#{예약시간}/g, variables.reservation_time || '');
    content = content.replace(/#{reservation_datetime}|{reservation_datetime}|#{예약일시}/g, variables.reservation_datetime || '');

    // Patient Variables
    content = content.replace(/#{이름}|{이름}|#{name}|{name}|#{patient_name}|{patient_name}/g, variables.patient_name || '고객님');
    content = content.replace(/#{휴대폰}|{휴대폰}/g, variables.patient_phone);
    content = content.replace(/#{tracking_number}|{tracking_number}/g, ''); // Clear unknown variables

    // Subject is template name
    const subject = template.name || '알림';

    return { content, subject };
}

/**
 * Prepare AlimTalk buttons with variable substitution
 */
export function prepareAlimTalkButtons(
    buttonsJson: string | null,
    variables: AlimTalkVariables
): string | undefined {
    if (!buttonsJson) return undefined;

    try {
        let buttons = JSON.parse(buttonsJson);
        let buttonString = JSON.stringify(buttons);

        // Clinic Variables
        buttonString = buttonString.replace(/#{clinic_name}|{clinic_name}/g, variables.clinic_name);
        buttonString = buttonString.replace(/#{clinic_phone}|{clinic_phone}/g, variables.clinic_phone);

        // Links
        if (variables.survey_url) {
            buttonString = buttonString.replace(/#{url}|{url}|#{survey_link}|{survey_link}|#{survey_url}|{survey_url}/g, variables.survey_url);
        }
        if (variables.upload_url) {
            buttonString = buttonString.replace(/#{upload_link}|{upload_link}|#{upload_url}|{upload_url}/g, variables.upload_url);
        }

        // Reservation Variables
        buttonString = buttonString.replace(/#{reservation_date}|{reservation_date}|#{예약일}/g, variables.reservation_date || '');
        buttonString = buttonString.replace(/#{reservation_time}|{reservation_time}|#{예약시간}/g, variables.reservation_time || '');
        buttonString = buttonString.replace(/#{reservation_datetime}|{reservation_datetime}|#{예약일시}/g, variables.reservation_datetime || '');

        // Patient Variables
        buttonString = buttonString.replace(/#{이름}|{이름}|#{name}|{name}|#{patient_name}|{patient_name}/g, variables.patient_name || '고객님');
        buttonString = buttonString.replace(/#{휴대폰}|{휴대폰}/g, variables.patient_phone);

        const substitutedButtons = JSON.parse(buttonString);

        // Filter buttons to only include fields needed by Aligo API
        const filteredButtons = substitutedButtons.map((btn: any) => {
            const baseButton = {
                name: btn.name,
                linkType: btn.linkType,
                linkTypeName: btn.linkTypeName
            };

            // Add URL fields only for button types that need them
            if (btn.linkType === 'WL') {
                return {
                    ...baseButton,
                    linkMo: btn.linkMo || '',
                    linkPc: btn.linkPc || ''
                };
            } else if (btn.linkType === 'AL') {
                return {
                    ...baseButton,
                    linkAnd: btn.linkAnd || '',
                    linkIos: btn.linkIos || ''
                };
            }

            // AC, DS, BK, MD: only name, linkType, linkTypeName
            return baseButton;
        });

        if (filteredButtons.length > 0) {
            return JSON.stringify({ button: filteredButtons });
        }

        return undefined;
    } catch (e) {
        console.error('Failed to parse/substitute buttons:', e);
        return undefined;
    }
}

/**
 * Check if content still has unsubstituted variables
 */
export function checkUnsubstitutedVariables(content: string): string[] | null {
    const remaining = content.match(/#{[^}]+}|{[^}]+}/g);
    return remaining && remaining.length > 0 ? remaining : null;
}

/**
 * Send AlimTalk message with prepared content and buttons
 * This is the main function that combines all preparation steps
 */
export async function sendAlimTalkMessage(
    config: AligoConfig,
    params: {
        receiver: string;
        template: AlimTalkTemplate;
        variables: AlimTalkVariables;
        failover: 'Y' | 'N';
    }
): Promise<AligoResponse> {
    // Prepare content
    const { content, subject } = prepareAlimTalkContent(params.template, params.variables);

    // Prepare buttons
    const buttonJson = prepareAlimTalkButtons(params.template.buttons, params.variables);

    // Send via Aligo API
    return await sendAlimTalk(config, {
        receiver: params.receiver,
        tpl_code: params.template.alimtalk_code,
        senderkey: config.senderKey || '',
        message_1: content,
        message: content,
        subject_1: subject,  // Use template name as subject
        button_1: buttonJson,
        failover: params.failover
    });
}
