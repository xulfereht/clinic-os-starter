import { clinicConfig } from "../config";

import { DEFAULT_THEME_CONFIG, type ThemeConfig, type SkinId } from "./design-system/schema";

export interface ClinicSettings {
    id?: number;
    name: string;
    englishName: string;
    description: string;
    url?: string;
    logoUrl?: string;
    faviconUrl?: string;
    businessLicenseNumber?: string;
    representativeName?: string;
    representativeNameEn?: string;
    contact: {
        phone: string;
        address: string;
        addressEn?: string;
        kakaoChannel: string;
        email: string;
        bookingUrl: string;
    };
    bankInfo?: string; // Integrated single bank info string
    hours: {
        weekdays: string;
        saturday: string;
        lunch: string;
        closed: string;
    };
    theme: ThemeConfig; // Now uses the new ThemeConfig
    aiConfig?: {
        geo: {
            city: string;
            district: string;
            neighborhood: string;
        }
    };
    features?: {
        remoteConsultation: boolean;
        multilingual?: boolean;
    };

    // AEO / SEO Extended Fields
    founder?: {
        name: string;
        role?: string;
        bio?: string; // education + career
        image?: string;
        socialProfiles?: string[];
    };
    coordinates?: {
        latitude: number;
        longitude: number;
    };
    socialProfiles?: string[]; // Clinic's social profiles

    analyticsConfig?: {
        blockedIps: string[];
    };
}

export function loadThemeConfigFromRow(row: any): ThemeConfig {
    // 1. Try to parse JSON config (Source of Truth)
    if (row.theme_config) {
        try {
            const parsed = typeof row.theme_config === 'string'
                ? JSON.parse(row.theme_config)
                : row.theme_config;
            return { ...DEFAULT_THEME_CONFIG, ...parsed };
        } catch (e) {
            console.error("Invalid theme_config JSON, falling back", e);
        }
    }

    // 2. Fallback: Map Legacy Columns to New Config
    // Legacy Colors: 'blue', 'green', 'teal', 'brown'
    // Legacy Styles: 'minimal', 'warm', 'professional'

    const legacyColor = row.theme_color || 'blue';
    const legacyStyle = row.theme_style || 'minimal';

    let skin: SkinId = 'clean'; // Default
    let brandHue: any = 'blue';

    // Map Color -> Hue
    if (['blue', 'green', 'teal', 'brown'].includes(legacyColor)) {
        brandHue = legacyColor;
    }

    // Map Style/Color -> Skin
    if (legacyStyle === 'warm' || legacyColor === 'brown') {
        skin = 'elegant'; // Brown/Warm -> Elegant
    } else {
        skin = 'clean';
    }

    return {
        ...DEFAULT_THEME_CONFIG,
        skin,
        brandHue,
        rounding: 'md',
    };
}

export async function getClinicSettings(db?: any): Promise<ClinicSettings> {
    // Default to config
    let settings: ClinicSettings = {
        name: clinicConfig.name,
        englishName: clinicConfig.englishName,
        description: clinicConfig.description,
        contact: clinicConfig.contact,
        hours: clinicConfig.hours,
        theme: DEFAULT_THEME_CONFIG,
        features: {
            remoteConsultation: false, // Default disabled
            multilingual: false // Default disabled
        }
    };

    if (!db) return settings;

    try {
        // 1. Try to fetch by ID 1 (API writes to this)
        let result = await db.prepare("SELECT * FROM clinics WHERE id = 1").first();

        // 2. If not found, or if theme_config is missing, try to find ANY row with theme_config populated
        if (!result || !result.theme_config) {
            const configResult = await db.prepare("SELECT * FROM clinics WHERE theme_config IS NOT NULL LIMIT 1").first();
            if (configResult) {
                result = configResult;
            }
        }

        // 3. Fallback to any row (Legacy)
        if (!result) {
            result = await db.prepare("SELECT * FROM clinics LIMIT 1").first();
        }

        if (result) {
            // Merge DB results
            if (result.id) settings.id = result.id;
            if (result.name) settings.name = result.name;
            if (result.logo_url) settings.logoUrl = result.logo_url;
            if (result.favicon_url) settings.faviconUrl = result.favicon_url;
            if (result.address) settings.contact.address = result.address;
            if (result.phone) settings.contact.phone = result.phone;
            if (result.business_license_number) settings.businessLicenseNumber = result.business_license_number;
            if (result.representative_name) settings.representativeName = result.representative_name;

            // Map Bank Info
            // Map Bank Info (Single Field)
            if (result.bank_info) {
                settings.bankInfo = result.bank_info;
            } else if (result.bank_name || result.bank_account_number) {
                // Fallback migration in memory if column empty but old cols exist
                settings.bankInfo = [result.bank_name, result.bank_account_number, result.bank_account_holder]
                    .filter(Boolean).join(' ');
            }

            // Load Theme Config (New Logic)
            settings.theme = loadThemeConfigFromRow(result);

            // Load AI Config
            if (result.ai_config) {
                try {
                    settings.aiConfig = typeof result.ai_config === 'string' ? JSON.parse(result.ai_config) : result.ai_config;
                } catch (e) {
                    console.error("Failed to parse ai_config JSON", e);
                }
            }

            // Load Analytics Config
            if (result.analytics_config) {
                try {
                    settings.analyticsConfig = typeof result.analytics_config === 'string' ? JSON.parse(result.analytics_config) : result.analytics_config;
                } catch (e) {
                    console.error("Failed to parse analytics_config JSON", e);
                }
            }

            // Parse Hours JSON
            if (result.hours) {
                try {
                    const dbHours = typeof result.hours === 'string' ? JSON.parse(result.hours) : result.hours;
                    settings.hours = {
                        weekdays: dbHours.weekday || settings.hours.weekdays,
                        saturday: dbHours.saturday || settings.hours.saturday,
                        lunch: dbHours.lunch || settings.hours.lunch,
                        closed: dbHours.closed || settings.hours.closed
                    };
                } catch (e) {
                    console.error("Failed to parse hours JSON", e);
                }
            }
        }

        // 4. Parallel Fetch for Extended Data
        try {
            const [
                siteSettingsResult,
                doctorResult,
                featureResult
            ] = await Promise.all([
                // Query 1: All Site Settings (SEO, Info, Social, i18n, Features) combined
                db.prepare('SELECT key, value, category FROM site_settings WHERE category IN ("seo", "info", "social", "i18n", "contact", "features", "feature")').all(),

                // Query 2: Doctor Info
                db.prepare(
                    settings.representativeName
                        ? `SELECT * FROM staff WHERE type='doctor' AND name LIKE ? LIMIT 1`
                        : `SELECT * FROM staff WHERE type='doctor' ORDER BY order_index ASC LIMIT 1`
                ).bind(settings.representativeName ? `%${settings.representativeName}%` : undefined).first(),

                // Legacy individual feature check (if needed, but covered by siteSettings above usually)
                // Keeping distinct if features are stored differently or for backward compat
                // But we can actually merge this into the site_settings map logic below
                Promise.resolve(null)
            ]);

            // Process Site Settings
            const settingRows = siteSettingsResult.results || [];
            const settingMap = new Map();

            settingRows.forEach((row: any) => {
                settingMap.set(row.key, row.value);

                // Specific Category Handling
                if (row.category === 'features' || row.category === 'feature') {
                    if (row.key === 'remote_consultation' || row.key === 'telemedicine_enabled') {
                        settings.features = {
                            ...settings.features,
                            remoteConsultation: row.value === 'true'
                        };
                    }
                    if (row.key === 'multilingual_enabled') {
                        settings.features = {
                            remoteConsultation: true,
                            ...settings.features,
                            multilingual: row.value === 'true'
                        };
                    }
                }
            });

            // Apply Global Settings
            if (settingMap.get('site_url')) settings.url = settingMap.get('site_url');
            if (settingMap.get('latitude') && settingMap.get('longitude')) {
                settings.coordinates = {
                    latitude: parseFloat(settingMap.get('latitude')),
                    longitude: parseFloat(settingMap.get('longitude'))
                };
            }

            // Apply Socials
            const socials: string[] = [];
            if (settingMap.get('instagram_url')) socials.push(settingMap.get('instagram_url'));
            if (settingMap.get('youtube_url')) socials.push(settingMap.get('youtube_url'));
            if (settingMap.get('blog_url')) socials.push(settingMap.get('blog_url'));
            if (socials.length > 0) settings.socialProfiles = socials;

            // Apply i18n
            if (settingMap.get('name_en')) settings.englishName = settingMap.get('name_en');
            if (settingMap.get('representative_name_en')) settings.representativeNameEn = settingMap.get('representative_name_en');
            if (settingMap.get('address_en')) settings.contact.addressEn = settingMap.get('address_en');


            // Process Doctor Info
            if (doctorResult) {
                settings.founder = {
                    name: doctorResult.name,
                    role: doctorResult.role || doctorResult.position || 'Representative Director',
                    bio: (doctorResult.education || (doctorResult.bio || '')) + '\n' + (doctorResult.career || ''),
                    image: doctorResult.image || doctorResult.image_url,
                    socialProfiles: settings.socialProfiles
                };
            }

        } catch (e) {
            console.error("Failed to fetch extended clinic settings", e);
        }

    } catch (e) {
        console.error("Failed to fetch clinic settings from DB", e);
    }

    return settings;
}
