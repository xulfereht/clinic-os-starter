/**
 * Demo Mode Utilities
 * 웨비나 시연용 개인정보 마스킹 유틸리티
 */

/**
 * Check if demo mode is enabled
 * - Environment variable: DEMO_MODE=true
 * - URL parameter: ?demo=1 (sets cookie for session persistence)
 * - Cookie: demo_mode=1
 */
export function isDemoMode(astroOrUrl?: any): boolean {
    // Check environment variable first
    if (typeof process !== 'undefined' && process.env?.DEMO_MODE === 'true') {
        return true;
    }

    // Check Astro context env
    if (astroOrUrl?.locals?.runtime?.env?.DEMO_MODE === 'true') {
        return true;
    }

    // Check URL parameter (this triggers demo mode)
    if (astroOrUrl?.url) {
        const url = astroOrUrl.url;
        if (url.searchParams?.get('demo') === '1') {
            return true;
        }
        // Check if demo=0 to disable
        if (url.searchParams?.get('demo') === '0') {
            return false;
        }
    }

    // Check cookies for persistent demo mode
    if (astroOrUrl?.cookies) {
        const demoCookie = astroOrUrl.cookies.get('demo_mode');
        if (demoCookie?.value === '1') {
            return true;
        }
    }

    // Check for browser context
    if (typeof window !== 'undefined') {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('demo') === '1') {
            return true;
        }
        // Check cookie in browser
        if (document.cookie.includes('demo_mode=1')) {
            return true;
        }
    }

    return false;
}

/**
 * Set demo mode cookie (call this from layout when demo=1 detected)
 */
export function setDemoModeCookie(astro: any, enabled: boolean): void {
    if (astro?.cookies) {
        if (enabled) {
            astro.cookies.set('demo_mode', '1', { path: '/', maxAge: 60 * 60 * 4 }); // 4 hours
        } else {
            astro.cookies.delete('demo_mode', { path: '/' });
        }
    }
}

/**
 * Mask a Korean name (keep first character)
 * 홍길동 → 홍**
 */
export function maskName(name: string | null | undefined): string {
    if (!name) return '';
    const trimmed = name.trim();
    if (trimmed.length <= 1) return trimmed;
    return trimmed[0] + '*'.repeat(trimmed.length - 1);
}

/**
 * Mask phone number (keep first 3 and last 4 digits)
 * 010-1234-5678 → 010-****-5678
 * 01012345678 → 010****5678
 */
export function maskPhone(phone: string | null | undefined): string {
    if (!phone) return '';

    // Remove all non-digits for processing
    const digits = phone.replace(/\D/g, '');

    if (digits.length < 7) return phone; // Too short to mask meaningfully

    // Check if original had hyphens
    const hasHyphens = phone.includes('-');

    if (hasHyphens) {
        // Format: 010-****-5678
        const first = digits.slice(0, 3);
        const last = digits.slice(-4);
        return `${first}-****-${last}`;
    } else {
        // Format: 010****5678
        const first = digits.slice(0, 3);
        const last = digits.slice(-4);
        return `${first}****${last}`;
    }
}

/**
 * Mask address (keep city/district, mask detail)
 * 서울시 강남구 역삼동 123-45 → 서울시 강남구 ****
 */
export function maskAddress(address: string | null | undefined): string {
    if (!address) return '';

    // Split by spaces
    const parts = address.trim().split(/\s+/);

    if (parts.length <= 2) {
        // Very short address, just mask last part
        return parts[0] + ' ****';
    }

    // Keep first 2 parts (usually city + district), mask rest
    return parts.slice(0, 2).join(' ') + ' ****';
}

/**
 * Mask email (keep first 2 chars and domain)
 * hong@email.com → ho***@email.com
 */
export function maskEmail(email: string | null | undefined): string {
    if (!email) return '';

    const atIndex = email.indexOf('@');
    if (atIndex <= 0) return email;

    const localPart = email.slice(0, atIndex);
    const domain = email.slice(atIndex);

    if (localPart.length <= 2) {
        return localPart + '***' + domain;
    }

    return localPart.slice(0, 2) + '***' + domain;
}

/**
 * Mask patient data object
 */
export function maskPatientData<T extends Record<string, any>>(patient: T, demoMode: boolean): T {
    if (!demoMode || !patient) return patient;

    return {
        ...patient,
        name: maskName(patient.name),
        current_phone: maskPhone(patient.current_phone),
        phone: maskPhone(patient.phone),
        address: maskAddress(patient.address),
        email: maskEmail(patient.email),
    };
}

/**
 * Mask lead data object
 */
export function maskLeadData<T extends Record<string, any>>(lead: T, demoMode: boolean): T {
    if (!demoMode || !lead) return lead;

    return {
        ...lead,
        name: maskName(lead.name),
        contact: maskPhone(lead.contact),
    };
}

/**
 * Mask array of patients
 */
export function maskPatients<T extends Record<string, any>>(patients: T[], demoMode: boolean): T[] {
    if (!demoMode) return patients;
    return patients.map(p => maskPatientData(p, demoMode));
}

/**
 * Mask array of leads
 */
export function maskLeads<T extends Record<string, any>>(leads: T[], demoMode: boolean): T[] {
    if (!demoMode) return leads;
    return leads.map(l => maskLeadData(l, demoMode));
}
