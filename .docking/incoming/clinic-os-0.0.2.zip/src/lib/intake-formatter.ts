
export const DURATION_MAP: Record<string, string> = {
    '1week': '1주일 이내',
    '1month': '1주일 ~ 1개월',
    '6months': '1개월 ~ 6개월',
    '1year': '6개월 ~ 1년',
    'chronic': '1년 이상'
};

export const HERBAL_CONSENT_MAP: Record<string, string> = {
    'yes': '한약 치료 상담 희망',
    'no': '침 치료만 희망'
};

export function formatDuration(value: string | undefined): string {
    if (!value) return '-';
    return DURATION_MAP[value] || value;
}

export function formatHerbalConsent(value: string | undefined): string {
    if (!value) return '';
    return HERBAL_CONSENT_MAP[value] || (value === 'yes' ? '희망함' : '희망 안 함');
}
