export interface ProgramSection {
    type: string;
    title: string;
    subtitle?: string;
    data?: any;
}

export interface ProgramPreset {
    id: string;
    name: string;
    description: string;
    sections: ProgramSection[];
}

export const PROGRAM_PRESETS: Record<string, ProgramPreset> = {
    product: {
        id: 'product',
        name: '제품형 프로그램 (다이어트/보약)',
        description: '특정 시술이나 처방을 중심으로 하는 프로그램에 적합합니다.',
        sections: [
            { type: 'hero', title: '프로그램명', subtitle: '핵심 가치 제안' },
            { type: 'problem', title: '이런 고민이 있으신가요?', subtitle: '환자의 페인 포인트' },
            { type: 'MiniDiagnosis', title: '간편 진단', subtitle: '내 상태 체크하기' },
            { type: 'solution', title: '맞춤형 솔루션', subtitle: '우리의 해결책' },
            { type: 'mechanism', title: '치료 원리', subtitle: '과학적/한의학적 근거' },
            { type: 'gallery', title: '치료 전후 / 제품 사진', subtitle: '' },
            { type: 'pricing', title: '비용 안내', subtitle: '합리적인 가격' },
            { type: 'faq', title: '자주 묻는 질문', subtitle: '궁금한 점을 해결해드립니다' },
            { type: 'RelatedPosts', title: '관련 건강 정보', subtitle: '전문가가 알려드리는 건강 지식' },
            { type: 'doctor-intro', title: '의료진 소개', subtitle: '담당 원장님' }
        ]
    },
    disease: {
        id: 'disease',
        name: '질환형 프로그램 (피부/통증)',
        description: '증상 완화와 치료 과정을 중심으로 하는 프로그램에 적합합니다.',
        sections: [
            { type: 'hero', title: '질환명 치료', subtitle: '원인 중심 치료' },
            { type: 'problem', title: '증상 체크리스트', subtitle: '내 증상을 확인해보세요' },
            { type: 'MiniDiagnosis', title: '간편 진단', subtitle: '내 상태 체크하기' },
            { type: 'mechanism', title: '발병 원인', subtitle: '왜 생기는 걸까요?' },
            { type: 'treatable', title: '치료 대상', subtitle: '이런 분들께 추천합니다' },
            { type: 'solution', title: '단계별 치료 과정', subtitle: '체계적인 치료 프로세스' },
            { type: 'gallery', title: '치료 사례', subtitle: '호전된 환자분들의 이야기' },
            { type: 'faq', title: '자주 묻는 질문', subtitle: '' },
            { type: 'RelatedPosts', title: '관련 건강 정보', subtitle: '전문가가 알려드리는 건강 지식' },
            { type: 'doctor-intro', title: '주치의 소개', subtitle: '당신의 건강 파트너' }
        ]
    }
};
