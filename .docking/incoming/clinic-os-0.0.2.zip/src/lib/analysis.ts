
import { symptomItems, type Organ, type Axis } from './survey-data';
import { patternData, type PatternDetail } from './pattern-data';

export interface SurveyAnalysis {
    scores: {
        qi: number;
        blood: number;
        yin: number;
        yang: number;
        total: number;
    };
    percentages: {
        qi: number;
        blood: number;
        yin: number;
        yang: number;
    };
    tendency: {
        duration: string;
        temp: string;
        nature: string;
    };
    organs: {
        name: string;
        key: string;
        score: number; // Weighted score (0-100)
        symptoms: string[]; // List of symptoms with severity > 0
        count: number; // Not used but kept for interface
        isPrimary?: boolean;
        isSecondary?: boolean;
        details?: {
            presence: number;
            severity: number;
            impact: number;
        };
    }[];
    safety: {
        history: string[];
        medication: string;
        side_effects: string;
    };
    diagnosis: {
        primary: string;
        secondary: string[];
        description: string;
        fullLabel?: string;
        axisLabel?: string;
        organPatternLabel?: string;
    };
    pattern?: PatternDetail;
}

export interface SleepAnalysisResult {
    scores: {
        sleep_onset: number; // 0-3
        sleep_maintenance: number; // 0-6
        sleep_duration_flag: number; // 0-4 (4=bad)
        sleep_satisfaction: number; // 0-10
        daytime_impairment: number; // 0-13
        mental_impact: number; // 0-3
        sleep_hygiene: number; // 0-9
    };
    flags: {
        sleep_duration_low: boolean;
        sleep_satisfaction_very_low: boolean;
        daytime_impairment_high: boolean;
        mental_impact_high: boolean;
        sleep_hygiene_poor: boolean;
        sleep_apnea_suspected: boolean;
        heavy_snoring: boolean;
        hypnotic_frequent: boolean;
    };
    raw: any;
}

// --- Helper Types ---

interface AxisScores {
    qi: number;
    blood: number;
    yin: number;
    yang: number;
}

interface OrganScores {
    heart: number;
    spleen: number;
    lung: number;
    liver: number;
    kidney: number;
}

interface MetaInfo {
    duration?: "acute" | "subacute" | "chronic";
    coldHeat?: "cold" | "hot" | "mixed" | "neutral";
    deficiencyExcess?: "deficiency" | "excess" | "mixed";
    mainSymptomOrgan?: Organ;
}

interface PatternResult {
    primaryOrgans: Organ[];
    secondaryOrgans: Organ[];
    axisLabel: string;
    organPatternLabel: string;
    fullLabel: string;
    explanation: string;
}

// --- Analysis Functions ---

function buildAxisLabel(axis: AxisScores): string {
    const arr: { key: Axis; label: string; score: number }[] = [
        { key: "qi", label: "기허 (Qi Deficiency)", score: axis.qi },
        { key: "blood", label: "혈허 (Blood Deficiency)", score: axis.blood },
        { key: "yin", label: "음허 (Yin Deficiency)", score: axis.yin },
        { key: "yang", label: "양허 (Yang Deficiency)", score: axis.yang },
    ];

    arr.sort((a, b) => b.score - a.score);
    const top = arr[0];
    const second = arr[1];

    if (top.score < 40) return "건강 양호 (Mild Mixed Pattern)";

    const close = Math.abs(top.score - second.score) <= 15;

    if (top.score >= 50 && second.score >= 50 && close) {
        const set = new Set<Axis>([top.key, second.key]);
        if (set.has("yin") && set.has("yang")) return "음양양허 (Yin–Yang Deficiency)";
        if (set.has("qi") && set.has("blood")) return "기혈양허 (Qi–Blood Deficiency)";
        if (set.has("qi") && set.has("yin")) return "기음양허 (Qi–Yin Deficiency)";
        if (set.has("qi") && set.has("yang")) return "기양양허 (Qi–Yang Deficiency)";
        if (set.has("blood") && set.has("yin")) return "혈음양허 (Blood–Yin Deficiency)";
        if (set.has("blood") && set.has("yang")) return "혈양양허 (Blood–Yang Deficiency)";
        return "복합 허증 (Mixed Deficiency)";
    }

    if (top.score >= 50) return top.label;

    return "복합 허증 (Mixed Deficiency)";
}

function analyzeOrgans(
    organScores: OrganScores,
    meta?: MetaInfo
): { primary: Organ[]; secondary: Organ[] } {
    const arr: { key: Organ; score: number }[] = [
        { key: "heart", score: organScores.heart },
        { key: "spleen", score: organScores.spleen },
        { key: "lung", score: organScores.lung },
        { key: "liver", score: organScores.liver },
        { key: "kidney", score: organScores.kidney },
    ];

    // Boost score if it matches main symptom (not implemented in UI yet)
    const boosted = arr.map((o) => ({
        ...o,
        score: o.score + (meta?.mainSymptomOrgan === o.key ? 10 : 0),
    }));

    boosted.sort((a, b) => b.score - a.score);
    const maxScore = boosted[0].score;

    const PRIMARY_THRESHOLD = 40; // Lowered slightly as weighted sums might be distributed
    const SECONDARY_MIN = 25;
    const MAX_DIFF_FOR_PRIMARY = 15;

    const primary: Organ[] = [];
    const secondary: Organ[] = [];

    for (const o of boosted) {
        if (o.score >= PRIMARY_THRESHOLD && maxScore - o.score <= MAX_DIFF_FOR_PRIMARY) {
            primary.push(o.key);
        }
    }

    if (primary.length === 0 && maxScore >= 30) {
        primary.push(boosted[0].key);
    }

    for (const o of boosted) {
        if (!primary.includes(o.key) && o.score >= SECONDARY_MIN) {
            secondary.push(o.key);
        }
    }

    return { primary, secondary };
}

function labelOrgans(primary: Organ[], secondary: Organ[]): string {
    const korMap: Record<Organ, string> = {
        heart: "심",
        spleen: "비위",
        lung: "폐",
        liver: "간",
        kidney: "신",
    };

    // 1. If too many primary organs (>2), it's a complex pattern.
    // Return empty string so the Axis Label becomes the main title (e.g., "기혈양허").
    if (primary.length > 2) return "";

    // 2. Map to Korean
    const primaryKor = primary.map((o) => korMap[o]).join("·");

    // 3. Construct Label
    // If we have distinct primary organs (1 or 2), use them.
    if (primaryKor) return `${primaryKor} 중심`;

    // If no primary but we have secondary, maybe show them? 
    // User wants "distinct" or nothing. So if no primary, just return empty.
    return "";
}

function analyzePattern(
    axis: AxisScores,
    organs: OrganScores,
    meta?: MetaInfo
): PatternResult {
    const axisLabel = buildAxisLabel(axis);
    const { primary, secondary } = analyzeOrgans(organs, meta);
    const organPatternLabel = labelOrgans(primary, secondary);

    const fullLabel =
        organPatternLabel === ""
            ? axisLabel
            : `${organPatternLabel} ${axisLabel}`;

    const explanation = [
        `축 패턴: ${axisLabel}`,
        primary.length ? `주 장부(Primary): ${primary.map(o => o.toUpperCase()).join(", ")}` : null,
        secondary.length ? `동반 장부(Secondary): ${secondary.map(o => o.toUpperCase()).join(", ")}` : null,
        meta?.coldHeat ? `한열: ${meta.coldHeat}` : null,
        meta?.deficiencyExcess ? `허실: ${meta.deficiencyExcess}` : null,
    ]
        .filter(Boolean)
        .join(" / ");

    return {
        primaryOrgans: primary,
        secondaryOrgans: secondary,
        axisLabel,
        organPatternLabel,
        fullLabel,
        explanation,
    };
}

function getMatchedPattern(axis: AxisScores, organs: OrganScores, meta: MetaInfo | undefined, highSeverityCounts?: Record<Organ, number>): PatternDetail | undefined {
    // 1. Determine Primary Axis
    const axes: { key: Axis; score: number }[] = [
        { key: 'qi', score: axis.qi },
        { key: 'blood', score: axis.blood },
        { key: 'yin', score: axis.yin },
        { key: 'yang', score: axis.yang },
    ];
    axes.sort((a, b) => b.score - a.score);
    const primaryAxis = axes[0].key;
    const secondaryAxis = axes[1]?.key;
    const axisScore1 = axes[0].score;
    const axisScore2 = axes[1]?.score;

    // 2. Determine Primary Organ
    const organList: { key: Organ; score: number; heavyCounts: number }[] = [
        { key: 'heart', score: organs.heart, heavyCounts: highSeverityCounts?.heart || 0 },
        { key: 'spleen', score: organs.spleen, heavyCounts: highSeverityCounts?.spleen || 0 },
        { key: 'lung', score: organs.lung, heavyCounts: highSeverityCounts?.lung || 0 },
        { key: 'liver', score: organs.liver, heavyCounts: highSeverityCounts?.liver || 0 },
        { key: 'kidney', score: organs.kidney, heavyCounts: highSeverityCounts?.kidney || 0 },
    ];

    // Priority Score = Score + (Heavy Symptom Count * 2) 
    organList.sort((a, b) => {
        const scoreA = a.score + (a.heavyCounts * 2);
        const scoreB = b.score + (b.heavyCounts * 2);
        return scoreB - scoreA;
    });

    const primaryOrganEntry = organList[0];
    const primaryOrganScore = primaryOrganEntry.score + (primaryOrganEntry.heavyCounts * 2);

    // 3. Logic Branching
    let key = '';

    // Threshold Check: If highest organ priority is still low (< 40), consider General/Mixed
    if (primaryOrganScore < 40) {

        // Mixed Check: Qi & Blood both high and close?
        const isQiBloodMixed =
            (primaryAxis === 'qi' && secondaryAxis === 'blood' || primaryAxis === 'blood' && secondaryAxis === 'qi') &&
            axisScore1 >= 50 && axisScore2 >= 50 &&
            Math.abs(axisScore1 - axisScore2) < 15;

        if (isQiBloodMixed) {
            key = 'mixed_qi_blood';
        } else {
            // Fallback to General Axis Pattern
            key = `general_${primaryAxis}`;
        }

    } else {
        // Standard Specific Organ Pattern
        key = `${primaryOrganEntry.key}_${primaryAxis}`;
    }

    // 4. Lookup (and fallback safety)
    return patternData[key] || patternData[`general_${primaryAxis}`];
}

// --- Main Exported Function ---

export function analyzeSurvey(data: any): SurveyAnalysis {
    // 1. Calculate Raw Scores from Weighted Symptoms
    const organRaw: Record<Organ, number> = {
        heart: 0, spleen: 0, lung: 0, liver: 0, kidney: 0,
    };
    const axisRaw: Record<Axis, number> = {
        qi: 0, blood: 0, yin: 0, yang: 0,
    };

    // Track symptoms for display
    const organSymptoms: Record<Organ, string[]> = {
        heart: [], spleen: [], lung: [], liver: [], kidney: []
    };
    const highSeverityCounts: Record<Organ, number> = {
        heart: 0, spleen: 0, lung: 0, liver: 0, kidney: 0
    };

    // Iterate through all defined symptoms
    for (const item of symptomItems) {
        const valStr = data[item.id];
        if (!valStr) continue;

        const severity = parseInt(valStr, 10); // 0-3
        if (severity === 0) continue;

        const sevNorm = severity / 3; // 0.0 ~ 1.0

        // Accumulate Organ Weights
        if (item.organWeights) {
            for (const [org, w] of Object.entries(item.organWeights)) {
                if (w) {
                    organRaw[org as Organ] += sevNorm * w;
                    // Add symptom text to the organ list if it's a significant contributor (>0.3 weight)
                    if (w >= 0.3) {
                        organSymptoms[org as Organ].push(`${item.label}(${severity})`);
                        if (severity === 3) {
                            highSeverityCounts[org as Organ]++;
                        }
                    }
                }
            }
        }

        // Accumulate Axis Weights
        if (item.axisWeights) {
            for (const [ax, w] of Object.entries(item.axisWeights)) {
                if (w) {
                    axisRaw[ax as Axis] += sevNorm * w;
                }
            }
        }
    }

    // 2. Normalize Scores (0-100)
    // We need a reference max to normalize against.
    // A simple approach is relative normalization: Max score = 100.
    // Or absolute normalization based on max possible score (which is hard to calculate dynamically).
    // Let's use Relative Normalization with a scaling factor to make it look realistic.
    // If the max raw score is small (e.g. 2.5), we scale it up.
    // Let's assume a "severe" patient might have raw score around 5-8 per organ.
    // Let's just normalize relative to the highest score found, but cap the scaling so low scores don't look huge.

    const normalize = (raw: Record<string, number>): Record<string, number> => {
        const max = Math.max(...Object.values(raw));
        if (max === 0) return Object.fromEntries(Object.keys(raw).map(k => [k, 0]));

        // Scaling strategy:
        // If max is high (>5), map max to 90-100.
        // If max is low (<2), map max to 40-50.
        // Let's just map Max -> 100 for relative comparison, but maybe dampen it?
        // User requested "Primary/Secondary" logic which relies on relative differences.
        // Let's just do simple Max -> 100 normalization for now.

        // Actually, to prevent "1 symptom = 100 score", let's use a fixed denominator if possible,
        // or a hybrid approach.
        // Let's use a "Soft Max" approach. 
        // Let's assume a theoretical max of ~10 for a very sick patient.
        const THEORETICAL_MAX = 8.0;

        return Object.fromEntries(
            Object.entries(raw).map(([k, v]) => [k, Math.min(100, Math.round((v / THEORETICAL_MAX) * 100))])
        );
    };

    const organScores = normalize(organRaw) as unknown as OrganScores;
    const axisScores = normalize(axisRaw) as unknown as AxisScores;

    // 3. Tendency & Meta
    const tendency = {
        duration: data.duration || '',
        temp: data.temp_tendency || '', // This might come from basic questions if we kept them
        nature: 'mixed'
    };

    // Adjust Yin/Yang based on temp tendency if available
    if (tendency.temp === 'heat') axisScores.yin = Math.min(100, axisScores.yin + 10); // Heat consumes Yin? Or Heat signs -> Yin Def?
    // Actually, in the previous logic: Heat -> Yin Def (often). Cold -> Yang Def.
    // Let's keep it simple.

    const meta: MetaInfo = {
        duration: tendency.duration.includes('6개월') ? 'chronic' : 'subacute',
        coldHeat: tendency.temp === 'heat' ? 'hot' : (tendency.temp === 'cold' ? 'cold' : 'neutral'),
        deficiencyExcess: 'deficiency'
    };

    // 4. Run Advanced Analysis
    const result = analyzePattern(axisScores, organScores, meta);

    // 5. Map Organs for UI
    const organMap: Record<string, { name: string, key: Organ }> = {
        'spleen': { name: '비위(소화기)', key: 'spleen' },
        'lung': { name: '폐(호흡기)', key: 'lung' },
        'heart': { name: '심(심리/수면)', key: 'heart' },
        'liver': { name: '간(근골격/피로)', key: 'liver' },
        'kidney': { name: '신(비뇨/생식)', key: 'kidney' }
    };

    const mappedOrgans = Object.entries(organMap).map(([key, info]) => {
        const score = organScores[key as Organ];
        return {
            name: info.name,
            key: info.key, // Add key
            score: score,
            symptoms: [...new Set(organSymptoms[key as Organ])], // Dedupe
            count: 0,
            isPrimary: result.primaryOrgans.includes(info.key),
            isSecondary: result.secondaryOrgans.includes(info.key),
            // We don't have detailed presence/severity/impact breakdown in this model easily, 
            // unless we calculate it separately. For now, omit details or provide dummy.
            details: undefined
        };
    }).filter(o => o.score > 0).sort((a, b) => b.score - a.score);

    // 6. Safety
    const safety = {
        history: data.history ? [data.history] : [],
        medication: data.medication || '없음',
        side_effects: data.side_effects || '없음'
    };

    // 5. Match Pattern
    const matchedPattern = getMatchedPattern(axisScores, organScores, meta, highSeverityCounts);

    return {
        scores: { ...axisScores, total: 0 },
        percentages: axisScores,
        tendency,
        organs: mappedOrgans,
        safety,
        diagnosis: {
            primary: result.fullLabel,
            secondary: [
                result.axisLabel !== result.fullLabel ? `기본 패턴: ${result.axisLabel}` : '',
            ].filter(Boolean),
            description: matchedPattern ?
                `<strong>${matchedPattern.displayName}</strong>에 해당합니다.<br>${matchedPattern.pathomechanism}` :
                result.explanation,
            fullLabel: result.fullLabel,
            axisLabel: result.axisLabel,
            organPatternLabel: result.organPatternLabel
        },
        pattern: matchedPattern
    };
}
export function analyzeSleepSurvey(data: any): SleepAnalysisResult {
    // Helper to get score from option value
    const getScore = (key: string, map: Record<string, number>): number => {
        const val = data[key];
        return map[val] ?? 0;
    };

    // 1. Calculate Scores
    const scores = {
        sleep_onset: getScore('sleep_onset', { 'lt_15': 0, '16_30': 1, '31_60': 2, 'gt_60': 3 }),
        sleep_maintenance: getScore('sleep_maintenance', { 'rare': 0, 'sometimes': 1, 'often': 2, 'always': 3 }) +
            getScore('wake_after_sleep', { 'rare': 0, 'sometimes': 1, 'often': 2, 'always': 3 }),
        sleep_duration_flag: getScore('sleep_duration', { 'gt_7': 0, '6_7': 1, '5_6': 2, 'lt_5': 3 }),
        sleep_satisfaction: parseInt(data.sleep_satisfaction || '5', 10),
        daytime_impairment: getScore('daytime_fatigue', { 'none': 0, 'mild': 1, 'moderate': 2, 'severe': 3 }) +
            getScore('daytime_concentration', { 'none': 0, 'mild': 1, 'moderate': 2, 'severe': 3 }) +
            getScore('daytime_mood', { 'none': 0, 'mild': 1, 'moderate': 2, 'severe': 3 }),
        mental_impact: getScore('sleep_anxiety', { 'none': 0, 'mild': 1, 'moderate': 2, 'severe': 3 }),
        sleep_hygiene: getScore('caffeine_intake', { 'rare': 0, 'morning': 1, 'afternoon': 2, 'evening': 3 }) +
            getScore('alcohol_intake', { 'rare': 0, 'sometimes': 1, 'often': 2, 'always': 3 }) +
            getScore('screen_time', { 'none': 0, 'brief': 1, 'long': 2, 'always': 3 })
    };

    // 2. Determine Flags
    const flags = {
        sleep_duration_low: scores.sleep_duration_flag >= 2,
        sleep_satisfaction_very_low: scores.sleep_satisfaction <= 3,
        daytime_impairment_high: scores.daytime_impairment >= 6,
        mental_impact_high: scores.mental_impact >= 2,
        sleep_hygiene_poor: scores.sleep_hygiene >= 4,
        sleep_apnea_suspected: data.snoring === 'apnea' || data.snoring === 'choking',
        heavy_snoring: data.snoring === 'loud' || data.snoring === 'apnea',
        hypnotic_frequent: data.medication === 'often' || data.medication === 'always'
    };

    return { scores, flags, raw: data };
}
