// Shared IP hashing utility
export async function hashIP(ip: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(ip + 'clinic-os-salt');
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.slice(0, 8).map(b => b.toString(16).padStart(2, '0')).join('');
}

export function isBot(userAgent: string): boolean {
    const ua = userAgent.toLowerCase();
    const botPatterns = [
        'bot', 'spider', 'crawl', 'slurp', 'bingbot', 'googlebot',
        'yandex', 'duckduckbot', 'baiduspider', 'facebookexternalhit',
        'twitterbot', 'linkedinbot', 'slackbot', 'discordbot',
        'whatsapp', 'telegram', 'pinterest', 'instagram', 'tiktok',
        'semrush', 'ahrefs', 'mj12bot', 'dotbot', 'petalbot',
        'bytespider', 'python-requests', 'axios', 'wget', 'curl'
    ];

    return botPatterns.some(pattern => ua.includes(pattern));
}
