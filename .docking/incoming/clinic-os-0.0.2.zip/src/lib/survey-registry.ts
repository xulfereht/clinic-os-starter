
export interface SurveyDefinition {
    id: string;
    label: string;
    description: string;
    pathTemplate: string; // Use [patient_id] as placeholder
    isPublic: boolean;
    tags: string[];
}

export const SURVEY_LIBRARY: SurveyDefinition[] = [
    {
        id: 'diagnosis_weighted_v2',
        label: '4축 체질·기능 진단',
        description: '기혈음양 4축 분석과 오장 육부의 기능적 불균형을 파악하는 종합 진단입니다.',
        pathTemplate: '/surveys/[patient_id]/diagnosis',
        isPublic: false,
        tags: ['기본', '종합']
    },
    {
        id: 'stress_test_v1',
        label: '스트레스/자율신경 검사',
        description: '교감/부교감 신경의 균형과 현재 스트레스 부하를 측정합니다. (준비 중)',
        pathTemplate: '/surveys/[patient_id]/stress', // Placeholder path
        isPublic: false,
        tags: ['정신', '신경']
    },
    {
        id: 'intake_v1',
        label: '초진 접수/문진표',
        description: '신규 환자 내원 시 작성하는 기본 인적사항 및 기초 문진표입니다.',
        pathTemplate: '/intake/new',
        isPublic: true,
        tags: ['기본', '접수']
    },
    {
        id: 'remote_diet_intake',
        label: '비대면 다이어트 접수 (통합)',
        description: '비대면 초진 접수와 다이어트 기초 비대면 문진이 통합된 폼입니다.',
        pathTemplate: '/surveys/[patient_id]/remote_intake',
        isPublic: false,
        tags: ['비대면', '통합접수']
    }
];

export const SURVEY_PANELS: Record<string, { label: string; description: string; tests: string[] }> = {
    'diet_initial': {
        label: '다이어트 초진 패널',
        description: '비대면 다이어트 프로그램 시작 시 필요한 기초 설문 모음입니다.',
        tests: ['intake_basic', 'diet_habit', 'ipaq_short', 'nrs_stress', 'nrs_body_image']
    },
    'sleep_initial': {
        label: '수면 초진 패널',
        description: '불면 및 수면 장애 프로그램 시작 시 수면 상태를 파악하기 위한 패널입니다.',
        tests: ['intake_basic', 'isi_k', 'psqi_k', 'sleep_snapshot']
    },
    'pain_initial': {
        label: '만성통증 초진 패널',
        description: '만성 통증 및 근골격계 질환 초진 시 통증 양상을 파악합니다.',
        tests: ['intake_basic', 'nrs_pain', 'pain_history', 'nrs_stress']
    },
    'skin_initial': {
        label: '피부질환 초진 패널',
        description: '아토피, 습진 등 피부 질환의 증상과 삶의 질 영향을 평가합니다.',
        tests: ['intake_basic', 'dlqi_k', 'nrs_itch', 'nrs_sleep_disturb']
    },
    'mental_initial': {
        label: '신경정신 초진 패널',
        description: '우울, 불안, 스트레스 등 정신 건강 상태를 종합적으로 평가합니다.',
        tests: ['intake_basic', 'phq_9', 'gad_7', 'k_pss_10', 'isi_k']
    }
};

export function getSurveyLink(surveyId: string, patientId: string, origin: string): string {
    // Check if it's a panel first
    if (SURVEY_PANELS[surveyId]) {
        return `${origin}/surveys/${patientId}/panel/${surveyId}`;
    }

    const survey = SURVEY_LIBRARY.find(s => s.id === surveyId);
    if (!survey) return '';
    return origin + survey.pathTemplate.replace('[patient_id]', patientId);
}

export function getPanelDefinition(panelId: string) {
    return SURVEY_PANELS[panelId];
}
