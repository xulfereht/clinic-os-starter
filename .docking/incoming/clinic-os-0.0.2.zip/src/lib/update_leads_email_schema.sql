
-- Migration: Add email integration fields to leads table
ALTER TABLE leads ADD COLUMN dedupe_key TEXT;
ALTER TABLE leads ADD COLUMN provider_msg_id TEXT;
ALTER TABLE leads ADD COLUMN source_data TEXT;

-- Index for deduplication lookups
CREATE INDEX IF NOT EXISTS idx_leads_dedupe_key ON leads(dedupe_key);
