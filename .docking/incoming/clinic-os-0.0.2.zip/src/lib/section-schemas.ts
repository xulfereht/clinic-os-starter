
export interface FieldSchema {
    key: string;
    label: string;
    type: 'text' | 'textarea' | 'image' | 'array' | 'doctor-selector' | 'checkbox' | 'select' | 'diagnosis-selector' | 'faq-topic-selector' | 'info';
    placeholder?: string;
    itemFields?: FieldSchema[]; // For array type
    options?: { label: string; value: string }[]; // For select type
}

export interface SectionSchema {
    label: string;
    fields: FieldSchema[];
}

export const SECTION_SCHEMAS: Record<string, SectionSchema> = {
    hero: {
        label: 'Hero (메인 상단)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' },
            {
                key: 'theme',
                label: '테마 선택',
                type: 'select',
                options: [
                    { label: '제품 (Product)', value: 'Product' },
                    { label: '질환 (Disease)', value: 'Disease' },
                    { label: '블루 (Blue)', value: 'blue' },
                    { label: '그린 (Green)', value: 'green' }
                ]
            },
            { key: 'backgroundImage', label: '배경 이미지 URL (선택사항)', type: 'image' },
            { key: 'image', label: '제품/메인 이미지 URL', type: 'image' },
            { key: 'ctaText', label: '메인 버튼 텍스트', type: 'text', placeholder: '진료 예약하기' },
            { key: 'ctaLink', label: '메인 버튼 링크', type: 'text', placeholder: '/intake' },
            { key: 'secondaryCtaText', label: '보조 버튼 텍스트', type: 'text', placeholder: '내 몸 상태 체크하기' },
            { key: 'secondaryCtaLink', label: '보조 버튼 링크', type: 'text', placeholder: '#diagnosis' },
            {
                key: 'badges',
                label: '뱃지 목록',
                type: 'array',
                itemFields: [
                    { key: 'text', label: '뱃지 텍스트', type: 'text' }
                ]
            }
        ]
    },
    problem: {
        label: '문제점 (Problem)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' },
            {
                key: 'cards',
                label: '문제점 카드',
                type: 'array',
                itemFields: [
                    { key: 'icon', label: '아이콘 (이모지)', type: 'text' },
                    { key: 'title', label: '제목', type: 'text' },
                    { key: 'description', label: '설명', type: 'textarea' }
                ]
            }
        ]
    },
    solution: {
        label: '솔루션 (Solution)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' },
            { key: 'tagline', label: '태그라인 (상단 소제목)', type: 'text' },
            {
                key: 'theme',
                label: '테마 선택',
                type: 'select',
                options: [
                    { label: '블루 (Blue)', value: 'blue' },
                    { label: '그린 (Green)', value: 'green' }
                ]
            },
            { key: 'image', label: '이미지 URL', type: 'image' },
            {
                key: 'features',
                label: '솔루션 특징',
                type: 'array',
                itemFields: [
                    { key: 'icon', label: '아이콘 (이모지)', type: 'text' },
                    { key: 'title', label: '특징 제목', type: 'text' },
                    { key: 'description', label: '내용', type: 'textarea' }
                ]
            }
        ]
    },
    mechanism: {
        label: '메커니즘 (Mechanism)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            {
                key: 'theme',
                label: '테마 선택',
                type: 'select',
                options: [
                    { label: '블루 (Blue)', value: 'blue' },
                    { label: '그린 (Green)', value: 'green' }
                ]
            },
            { key: 'image', label: '이미지 URL', type: 'image' },
            {
                key: 'steps',
                label: '메커니즘 단계',
                type: 'array',
                itemFields: [
                    { key: 'step', label: '단계 번호 (예: 01)', type: 'text' },
                    { key: 'title', label: '단계명', type: 'text' },
                    { key: 'description', label: '설명', type: 'textarea' }
                ]
            }
        ]
    },
    process: {
        label: '진료 절차 (Process)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            {
                key: 'theme',
                label: '테마 선택',
                type: 'select',
                options: [
                    { label: '블루 (Blue)', value: 'blue' },
                    { label: '그린 (Green)', value: 'green' }
                ]
            },
            { key: 'image', label: '이미지 URL', type: 'image' },
            {
                key: 'steps',
                label: '진료 단계',
                type: 'array',
                itemFields: [
                    { key: 'step', label: '단계 번호 (예: 01)', type: 'text' },
                    { key: 'title', label: '단계명', type: 'text' },
                    { key: 'description', label: '설명', type: 'textarea' }
                ]
            }
        ]
    },
    treatable: {
        label: '치료 가능 질환 (Treatable)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' },
            {
                key: 'conditions',
                label: '치료 가능 질환',
                type: 'array',
                itemFields: [
                    { key: 'name', label: '질환명', type: 'text' }
                ]
            }
        ]
    },
    TreatableConditions: {
        label: '진료 과목 (상세)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' },
            {
                key: 'conditions',
                label: '진료 과목 목록',
                type: 'array',
                itemFields: [
                    { key: 'name', label: '질환명', type: 'text' },
                    { key: 'description', label: '설명', type: 'textarea' },
                    { key: 'image', label: '이미지 URL', type: 'image' }
                ]
            }
        ]
    },
    pricing: {
        label: '가격 안내 (Pricing)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' },
            {
                key: 'theme',
                label: '테마 선택',
                type: 'select',
                options: [
                    { label: '블루 (Blue)', value: 'blue' },
                    { label: '그린 (Green)', value: 'green' }
                ]
            },
            {
                key: 'plans',
                label: '가격 플랜',
                type: 'array',
                itemFields: [
                    { key: 'name', label: '플랜명', type: 'text' },
                    { key: 'price', label: '가격 (숫자)', type: 'text' },
                    { key: 'originalPrice', label: '정가 (할인 전 가격)', type: 'text' },
                    { key: 'duration', label: '기간 (예: 1개월)', type: 'text' },
                    { key: 'features', label: '특징 (줄바꿈으로 구분)', type: 'textarea' },
                    { key: 'isBest', label: '추천 플랜 (Best)', type: 'checkbox' }
                ]
            }
        ]
    },
    faq: {
        label: 'FAQ',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            {
                key: 'theme',
                label: '테마 선택',
                type: 'select',
                options: [
                    { label: '블루 (Blue)', value: 'blue' },
                    { label: '그린 (Green)', value: 'green' }
                ]
            },
            { key: 'linkedTopicSlug', label: '연결할 FAQ 토픽', type: 'faq-topic-selector' },
            {
                key: 'items',
                label: 'FAQ 항목',
                type: 'array',
                itemFields: [
                    { key: 'q', label: '질문', type: 'text' },
                    { key: 'a', label: '답변', type: 'textarea' }
                ]
            }
        ]
    },
    'doctor-intro': {
        label: '의료진 소개',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' },
            { key: 'doctorSelector', label: '담당 의료진 선택', type: 'doctor-selector' }
        ]
    },
    DoctorIntro: {
        label: '의료진 소개',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' },
            { key: 'doctorSelector', label: '담당 의료진 선택', type: 'doctor-selector' }
        ]
    },
    youtube: {
        label: 'YouTube 동영상',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'youtubeUrl', label: 'YouTube 동영상 URL', type: 'text', placeholder: 'https://www.youtube.com/watch?v=...' },
            { key: 'description', label: '영상 설명', type: 'textarea' }
        ]
    },
    'related-diagnosis': {
        label: '관련 자가진단',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' },
            { key: 'diagnosisId', label: '연결할 자가진단 선택', type: 'diagnosis-selector' }
        ]
    },
    RelatedDiagnosis: {
        label: '관련 자가진단',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' },
            { key: 'diagnosisId', label: '연결할 자가진단 선택', type: 'diagnosis-selector' }
        ]
    },
    'related-reviews': {
        label: '관련 치료후기',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' }
        ]
    },
    'related-posts': {
        label: '관련 건강정보',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' }
        ]
    },
    RelatedReviews: {
        label: '관련 치료후기',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' }
        ]
    },
    RelatedPosts: {
        label: '관련 건강정보',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' }
        ]
    },
    gallery: {
        label: '갤러리',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'subtitle', label: '부제목/설명', type: 'textarea' },
            {
                key: 'images',
                label: '이미지 목록',
                type: 'array',
                itemFields: [
                    { key: 'url', label: '이미지 URL', type: 'image' },
                    { key: 'caption', label: '캡션', type: 'text' }
                ]
            }
        ]
    },
    MiniDiagnosis: {
        label: '간편 진단 (Mini Diagnosis)',
        fields: [
            { key: 'title', label: '섹션 제목 (관리용)', type: 'text' },
            { key: 'programId', label: '프로그램 ID (자동 설정됨)', type: 'text' }
        ]
    },
    FeatureHighlight: {
        label: '강조 박스 (Feature Highlight)',
        fields: [
            { key: 'title', label: '제목', type: 'text' },
            { key: 'description', label: '설명', type: 'textarea' },
            { key: 'image', label: '이미지 URL', type: 'image' },
            {
                key: 'align',
                label: '정렬',
                type: 'select',
                options: [
                    { label: '중앙 (Center)', value: 'center' },
                    { label: '왼쪽 (Left)', value: 'left' }
                ]
            },
            {
                key: 'background',
                label: '배경 스타일',
                type: 'select',
                options: [
                    { label: '부드러운 (Soft)', value: 'soft' },
                    { label: '흰색 (White)', value: 'white' }
                ]
            }
        ]
    },
    SolutionTypes: {
        label: '솔루션 유형 (Solution Types)',
        fields: [
            { key: 'title', label: '제목', type: 'text' },
            { key: 'subtitle', label: '부제목', type: 'textarea' },
            {
                key: 'types',
                label: '유형 목록',
                type: 'array',
                itemFields: [
                    { key: 'title', label: '유형 제목', type: 'text' },
                    { key: 'features', label: '특징 (줄바꿈으로 구분)', type: 'textarea' },
                    { key: 'pattern', label: '진단 패턴', type: 'text' },
                    { key: 'solutionTitle', label: '솔루션 제목', type: 'text' },
                    { key: 'solutionDescription', label: '솔루션 설명', type: 'textarea' }
                ]
            }
        ]
    },
    MainHero: {
        label: '메인 히어로 (슬라이드)',
        fields: [
            {
                key: 'images',
                label: '배경 이미지 목록 (슬라이드)',
                type: 'array',
                itemFields: [
                    { key: 'url', label: '이미지 URL', type: 'image' },
                    { key: 'alt', label: '대체 텍스트', type: 'text' }
                ]
            },
            { key: 'mainHeading', label: '메인 카피 (줄바꿈 가능)', type: 'textarea' },
            { key: 'subHeading', label: '서브 카피/뱃지', type: 'text' },
            { key: 'description', label: '설명 텍스트', type: 'textarea' },
            { key: 'ctaText', label: '메인 버튼 텍스트', type: 'text', placeholder: '진료 예약하기' },
            { key: 'ctaLink', label: '메인 버튼 링크', type: 'text', placeholder: '/intake' },
            {
                key: 'theme',
                label: '테마 선택',
                type: 'select',
                options: [
                    { label: 'Dark (흰색 텍스트)', value: 'dark' },
                    { label: 'Light (검은색 텍스트)', value: 'light' }
                ]
            }
        ]
    },
    ServiceTiles: {
        label: '서비스 타일 그리드 (Service Tiles)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text', placeholder: '진료 서비스' },
            { key: 'subtitle', label: '설명', type: 'textarea', placeholder: '원하시는 서비스를 선택해주세요.' },
            {
                key: 'items',
                label: '서비스 타일 목록',
                type: 'array',
                itemFields: [
                    { key: 'icon', label: '아이콘 (이모지)', type: 'text' },
                    { key: 'title', label: '타일 제목', type: 'text' },
                    { key: 'desc', label: '설명', type: 'textarea' },
                    { key: 'link', label: '링크 URL', type: 'text' },
                    {
                        key: 'bg',
                        label: '배경 스타일',
                        type: 'select',
                        options: [
                            { label: '부드러운 배경 (Soft)', value: 'soft' },
                            { label: '흰색 배경 (White)', value: 'white' }
                        ]
                    }
                ]
            }
        ]
    },
    Philosophy: {
        label: '진료 철학 & 원장 소개 (Philosophy)',
        fields: [
            { key: 'heading', label: '메인 헤딩', type: 'textarea' },
            { key: 'subHeading', label: '서브 헤딩/뱃지', type: 'text' },
            { key: 'description', label: '철학 설명 (줄바꿈으로 단락 구분)', type: 'textarea' },
            { key: 'doctorSelector', label: '대표원장 선택', type: 'doctor-selector' }
        ]
    },
    HomeInfo: {
        label: '홈 정보 & 공지사항 (Info)',
        fields: [
            { key: '_notice', label: '안내', type: 'info', placeholder: '진료 시간 및 병원 위치 정보는 [설정 > 병원 정보] 메뉴에서 수정할 수 있습니다.' },
            { key: 'showNotices', label: '공지사항 섹션 표시', type: 'checkbox' }
        ]
    },
    LocationMap: {
        label: '지도 & 주소 (Map)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text', placeholder: '오시는 길' },
            { key: 'mapSearchKeyword', label: '지도 검색 키워드 (상호명)', type: 'text', placeholder: '백록담한의원 송도' },
            { key: 'address', label: '주소 (도로명)', type: 'text', placeholder: '서울특별시 ...' },
            { key: 'mapUrl', label: '지도 링크 (네이버/카카오)', type: 'text' },
            { key: 'lat', label: '위도 (선택: 지도 API용)', type: 'text' },
            { key: 'lng', label: '경도 (선택: 지도 API용)', type: 'text' }
        ]
    },
    TransportInfo: {
        label: '교통편 안내 (Transport)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text', placeholder: '교통편 안내' },
            {
                key: 'items',
                label: '교통 수단 목록',
                type: 'array',
                itemFields: [
                    { key: 'type', label: '수단 (지하철/버스/자가용)', type: 'text' },
                    { key: 'icon', label: '아이콘 (이모지)', type: 'text' },
                    { key: 'description', label: '상세 안내 (줄바꿈 가능)', type: 'textarea' }
                ]
            }
        ]
    },
    BusinessHours: {
        label: '진료 시간 (Business Hours)',
        fields: [
            { key: 'title', label: '섹션 제목', type: 'text', placeholder: '진료 시간' },
            { key: 'weekdays', label: '평일 진료시간', type: 'text', placeholder: '09:30 - 20:30 (야간진료)' },
            { key: 'saturday', label: '토요일 진료시간', type: 'text', placeholder: '09:30 - 15:00' },
            { key: 'lunch', label: '점심시간', type: 'text', placeholder: '13:00 - 14:00' },
            { key: 'closed', label: '휴진일 안내', type: 'text', placeholder: '일요일/공휴일 휴진' },
            { key: 'notice', label: '추가 공지사항', type: 'textarea' },
            { key: 'ctaText', label: 'CTA 버튼 텍스트', type: 'text', placeholder: '진료 문의하기' },
            { key: 'ctaLink', label: 'CTA 버튼 링크', type: 'text', placeholder: '/intake' }
        ]
    },
    PageIntro: {
        label: '페이지 인트로 (Page Intro)',
        fields: [
            { key: 'title', label: '페이지 제목', type: 'text' },
            { key: 'description', label: '설명', type: 'textarea' }
        ]
    },
    StepGuide: {
        label: '단계별 가이드 (Step Guide)',
        fields: [
            { key: 'stepNumber', label: '스텝 번호 (예: Step 01)', type: 'text' },
            { key: 'title', label: '섹션 제목', type: 'text' },
            {
                key: 'steps',
                label: '단계 목록',
                type: 'array',
                itemFields: [
                    { key: 'title', label: '단계 제목', type: 'text' },
                    { key: 'description', label: '설명 (HTML 가능)', type: 'textarea' }
                ]
            }
        ]
    },
    AdaptationPeriod: {
        label: '적응기 안내표 (Adaptation Period)',
        fields: [
            { key: 'icon', label: '아이콘 (이모지)', type: 'text' },
            { key: 'title', label: '제목', type: 'text' },
            { key: 'description', label: '설명', type: 'textarea' },
            {
                key: 'schedule',
                label: '일정 항목',
                type: 'array',
                itemFields: [
                    { key: 'day', label: '일자', type: 'text' },
                    { key: 'instruction', label: '복용법', type: 'text' },
                    { key: 'highlight', label: '강조 표시', type: 'text' }
                ]
            }
        ]
    },
    SideEffectsGrid: {
        label: '부작용/반응 그리드 (Side Effects Grid)',
        fields: [
            { key: 'stepNumber', label: '스텝 번호', type: 'text' },
            { key: 'title', label: '섹션 제목', type: 'text' },
            { key: 'description', label: '설명', type: 'textarea' },
            {
                key: 'items',
                label: '항목 목록',
                type: 'array',
                itemFields: [
                    { key: 'title', label: '증상', type: 'text' },
                    { key: 'description', label: '대처법 (HTML 가능)', type: 'textarea' }
                ]
            }
        ]
    },
    RulesChecklist: {
        label: '주의사항 체크리스트 (Rules Checklist)',
        fields: [
            { key: 'title', label: '제목', type: 'text' },
            { key: 'subtitle', label: '부제목', type: 'text' },
            {
                key: 'rules',
                label: '규칙 목록',
                type: 'array',
                itemFields: [
                    { key: 'title', label: '규칙 제목', type: 'text' },
                    { key: 'description', label: '설명', type: 'textarea' }
                ]
            }
        ]
    },
    InquiryCTA: {
        label: '문의하기 CTA (Inquiry CTA)',
        fields: [
            { key: 'title', label: '제목', type: 'text' },
            { key: 'description', label: '설명', type: 'textarea' },
            { key: 'ctaText', label: '버튼 텍스트', type: 'text' },
            { key: 'ctaLink', label: '버튼 링크', type: 'text' }
        ]
    }
};
