/**
 * CRM 환자 코호트 분석 서비스
 * 
 * 스키마 변경 없이 patient_events 데이터를 런타임에 분류:
 * - 생애초진 (is_first_ever): 환자의 병원 첫 방문
 * - 에피소드초진 (is_episode_start): 휴면 후 재방문 시작 (재초진 포함)
 * - 재진: 에피소드 내 후속 방문
 */

import type { D1Database } from '@cloudflare/workers-types';

// ============================================================================
// Types
// ============================================================================

export interface PatientEvent {
    id: string;
    patient_id: string;
    type: string;
    event_date: number;  // Unix timestamp
    staff_id?: string;
    care_mode?: string;
    business_type?: string;
}

export interface ClassifiedVisit extends PatientEvent {
    is_first_ever: boolean;      // 생애초진 여부
    is_episode_start: boolean;   // 에피소드 시작 (생애초진 OR 재초진)
    episode_number: number;      // 에피소드 번호 (1, 2, 3...)
    visit_in_episode: number;    // 에피소드 내 방문 순서
    days_since_last?: number;    // 이전 방문 후 경과 일수
}

export interface CohortConfig {
    /** 휴면 판정 기준 (일) - 기본 90일 */
    dormantThresholdDays: number;
    /** 추적 기간 (주) - 기본 12주 */
    followUpWeeks: number;
    /** 데이터 성숙도 버퍼 (일) - 기본 14일 */
    cutoffBufferDays: number;
}

export interface CohortMetrics {
    /** 코호트 환자 수 */
    cohortSize: number;
    /** N주 리텐션 (재방문 1회 이상 비율) */
    retention: {
        week4: number;
        week8: number;
        week12: number;
    };
    /** 평균 재진 횟수 (초진 제외) */
    avgRevisits: number;
    /** 첫 재진까지 중앙값 (일) */
    medianFirstRevisitDays: number | null;
    /** 생애초진 vs 재초진 분리 */
    breakdown: {
        firstEverCount: number;
        reStartCount: number;  // 재초진
    };
}

// ============================================================================
// Default Configuration
// ============================================================================

export const DEFAULT_COHORT_CONFIG: CohortConfig = {
    dormantThresholdDays: 90,
    followUpWeeks: 12,
    cutoffBufferDays: 14,
};

// ============================================================================
// Visit Classification Logic
// ============================================================================

/**
 * 환자의 방문 기록을 분류합니다.
 * 
 * @param visits - 단일 환자의 visit 타입 이벤트 목록
 * @param config - 코호트 설정 (휴면 기준 등)
 * @returns 분류된 방문 목록
 */
export function classifyVisits(
    visits: PatientEvent[],
    config: CohortConfig = DEFAULT_COHORT_CONFIG
): ClassifiedVisit[] {
    if (visits.length === 0) return [];

    // 1. 날짜순 정렬 (오래된 것부터)
    const sorted = [...visits].sort((a, b) => a.event_date - b.event_date);

    let episodeNum = 1;
    let visitInEpisode = 1;
    let lastVisitDate: number | null = null;

    return sorted.map((v, i) => {
        const isFirstEver = i === 0;
        const daysSinceLast = lastVisitDate
            ? (v.event_date - lastVisitDate) / 86400
            : undefined;

        // 휴면 기준 초과 시 새 에피소드 시작
        const isEpisodeStart = isFirstEver ||
            (daysSinceLast !== undefined && daysSinceLast >= config.dormantThresholdDays);

        if (isEpisodeStart && !isFirstEver) {
            episodeNum++;
            visitInEpisode = 1;
        }

        const result: ClassifiedVisit = {
            ...v,
            is_first_ever: isFirstEver,
            is_episode_start: isEpisodeStart,
            episode_number: episodeNum,
            visit_in_episode: visitInEpisode,
            days_since_last: daysSinceLast,
        };

        lastVisitDate = v.event_date;
        visitInEpisode++;

        return result;
    });
}

// ============================================================================
// Cohort Building
// ============================================================================

/**
 * 코호트를 생성합니다.
 * 
 * @param db - D1 Database
 * @param intakeStart - 유입 시작일 (Unix timestamp)
 * @param intakeEnd - 유입 종료일 (Unix timestamp)
 * @param analysisType - 분석 유형 ('first_ever' | 'episode_start' | 'restart_only')
 * @param config - 코호트 설정
 */
export async function buildCohort(
    db: D1Database,
    intakeStart: number,
    intakeEnd: number,
    analysisType: 'first_ever' | 'episode_start' | 'restart_only' = 'episode_start',
    config: CohortConfig = DEFAULT_COHORT_CONFIG
): Promise<Map<string, ClassifiedVisit[]>> {
    // 1. 해당 기간 + 이전 기록이 있는 모든 환자의 visit 이벤트 조회
    const allVisits = await db.prepare(`
    SELECT 
      pe.id,
      pe.patient_id,
      pe.type,
      pe.event_date,
      pe.staff_id,
      pe.care_mode,
      pe.business_type
    FROM patient_events pe
    WHERE pe.type = 'visit'
      AND pe.deleted_at IS NULL
      AND pe.patient_id IN (
        SELECT DISTINCT patient_id 
        FROM patient_events 
        WHERE type = 'visit' 
          AND event_date >= ?
          AND event_date <= ?
          AND deleted_at IS NULL
      )
    ORDER BY pe.patient_id, pe.event_date ASC
  `).bind(intakeStart, intakeEnd).all();

    // 2. 환자별로 그룹화
    const patientVisitsMap = new Map<string, PatientEvent[]>();
    for (const row of allVisits.results as PatientEvent[]) {
        if (!patientVisitsMap.has(row.patient_id)) {
            patientVisitsMap.set(row.patient_id, []);
        }
        patientVisitsMap.get(row.patient_id)!.push(row);
    }

    // 3. 각 환자별 방문 분류
    const cohort = new Map<string, ClassifiedVisit[]>();

    for (const [patientId, visits] of patientVisitsMap) {
        const classified = classifyVisits(visits, config);

        // 코호트 기간 내 에피소드 시작이 있는 환자만 포함
        const hasMatchingStart = classified.some(v => {
            const inRange = v.event_date >= intakeStart && v.event_date <= intakeEnd;
            if (!inRange) return false;

            switch (analysisType) {
                case 'first_ever':
                    return v.is_first_ever;
                case 'restart_only':
                    return v.is_episode_start && !v.is_first_ever;
                case 'episode_start':
                default:
                    return v.is_episode_start;
            }
        });

        if (hasMatchingStart) {
            cohort.set(patientId, classified);
        }
    }

    return cohort;
}

// ============================================================================
// Metrics Calculation
// ============================================================================

/**
 * 코호트 지표를 계산합니다.
 */
export function calculateCohortMetrics(
    cohort: Map<string, ClassifiedVisit[]>,
    intakeStart: number,
    intakeEnd: number,
    config: CohortConfig = DEFAULT_COHORT_CONFIG
): CohortMetrics {
    const followUpSeconds = config.followUpWeeks * 7 * 86400;

    let firstEverCount = 0;
    let reStartCount = 0;
    let retention4 = 0;
    let retention8 = 0;
    let retention12 = 0;
    let totalRevisits = 0;
    const firstRevisitDays: number[] = [];

    for (const [, visits] of cohort) {
        // 코호트 기간 내 에피소드 시작 찾기
        const episodeStart = visits.find(v =>
            v.event_date >= intakeStart &&
            v.event_date <= intakeEnd &&
            v.is_episode_start
        );

        if (!episodeStart) continue;

        // 생애초진 vs 재초진 분류
        if (episodeStart.is_first_ever) {
            firstEverCount++;
        } else {
            reStartCount++;
        }

        // 에피소드 내 재방문 (추적 기간 내)
        const episodeVisits = visits.filter(v =>
            v.episode_number === episodeStart.episode_number &&
            v.event_date > episodeStart.event_date &&
            v.event_date <= episodeStart.event_date + followUpSeconds
        );

        // 재진 횟수
        totalRevisits += episodeVisits.length;

        // 첫 재진까지 일수
        if (episodeVisits.length > 0) {
            const firstRevisit = episodeVisits[0];
            const daysDiff = (firstRevisit.event_date - episodeStart.event_date) / 86400;
            firstRevisitDays.push(daysDiff);
        }

        // N주 리텐션
        const hasRevisitWithin = (weeks: number) =>
            episodeVisits.some(v =>
                v.event_date <= episodeStart.event_date + weeks * 7 * 86400
            );

        if (hasRevisitWithin(4)) retention4++;
        if (hasRevisitWithin(8)) retention8++;
        if (hasRevisitWithin(12)) retention12++;
    }

    const cohortSize = cohort.size;

    // 중앙값 계산
    const calcMedian = (arr: number[]): number | null => {
        if (arr.length === 0) return null;
        const sorted = [...arr].sort((a, b) => a - b);
        const mid = Math.floor(sorted.length / 2);
        return sorted.length % 2 !== 0
            ? sorted[mid]
            : (sorted[mid - 1] + sorted[mid]) / 2;
    };

    return {
        cohortSize,
        retention: {
            week4: cohortSize > 0 ? Math.round((retention4 / cohortSize) * 100) : 0,
            week8: cohortSize > 0 ? Math.round((retention8 / cohortSize) * 100) : 0,
            week12: cohortSize > 0 ? Math.round((retention12 / cohortSize) * 100) : 0,
        },
        avgRevisits: cohortSize > 0 ? Math.round((totalRevisits / cohortSize) * 10) / 10 : 0,
        medianFirstRevisitDays: calcMedian(firstRevisitDays),
        breakdown: {
            firstEverCount,
            reStartCount,
        },
    };
}

// ============================================================================
// Utility: Date Helpers
// ============================================================================

/**
 * 코호트 분석용 날짜 범위 계산
 * 
 * @param weeksAgo - 몇 주 전 기준
 * @param windowWeeks - 유입 창 (주)
 * @param cutoffDays - 데이터 성숙도 버퍼 (일)
 */
export function calculateCohortDateRange(
    weeksAgo: number = 4,
    windowWeeks: number = 4,
    cutoffDays: number = 14
): { intakeStart: number; intakeEnd: number; analysisDate: number } {
    const now = Math.floor(Date.now() / 1000);
    const cutoffTimestamp = now - cutoffDays * 86400;

    const intakeEnd = cutoffTimestamp - weeksAgo * 7 * 86400;
    const intakeStart = intakeEnd - windowWeeks * 7 * 86400;

    return {
        intakeStart,
        intakeEnd,
        analysisDate: cutoffTimestamp,
    };
}
