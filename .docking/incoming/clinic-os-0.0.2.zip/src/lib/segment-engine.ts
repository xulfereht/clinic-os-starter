export type Operator =
    | 'equals' | 'not_equals'
    | 'contains' | 'starts_with'
    | 'gt' | 'lt' | 'gte' | 'lte'
    | 'between' // for dates or numbers
    | 'is_true' | 'is_false' // for booleans
    | 'in' // for multiple selections (status, tags)
    | 'older_than_days' // e.g. "Drafted > 30 days ago" (date < now - 30)
    | 'within_days' // e.g. "Drafted < 30 days ago" (date >= now - 30)
    | 'relative_date' // e.g. +1 (Tomorrow), 0 (Today)
    ;

export type FieldType = 'string' | 'number' | 'date' | 'boolean' | 'array';

export interface Condition {
    field: string;
    operator: Operator;
    value: any; // string, number, or array for 'between'/'in'
}

export interface SegmentCriteria {
    operator: 'AND' | 'OR';
    conditions: Condition[];
}


// Allowed fields mapping to SQL Columns (Security: Whitelist)
const FIELD_MAP: Record<string, string> = {
    // Basic Info
    'name': 'name',
    'phone': 'current_phone',
    'gender': 'gender',
    'status': 'status',
    'address': 'address',
    'chart_number': 'chart_number',
    'first_source': 'first_source',
    'lifecycle_stage': 'lifecycle_stage',
    'tier': 'tier',
    'channel': 'channel',

    // Dates
    'created_at': 'created_at',
    'birth_date': 'birth_date',
    'last_visit_date': 'last_visit_date',
    'first_visit_date': 'first_visit_date',
    'reservation_date': 'reservation_date', // Virtual field, handled via subquery

    // Metrics
    'total_payment': 'total_payment',
    'average_transaction': 'average_transaction',
    'visit_count': 'visit_count',
    'last_payment_date': 'last_payment_date',
    'sms_consent': 'sms_consent',
    'email_consent': 'email_consent',

    // Arrays (JSON)
    'tags': 'segments', // This stores JSON array ["A", "B"]
    'legacy_medical_history': 'legacy_medical_history',

    // Calculated Fields (Subqueries)
    // Counts how many times this patient's chart_number appears as referrer_id in patients table
    'referral_count': '(SELECT COUNT(*) FROM patients p2 WHERE p2.referrer_id = id)',
    'payment_count': 'payment_count',
    'last_shipping_date': 'last_shipping_date'
};

// Generate Valid SQL WHERE Clause from Criteria
export function generateSegmentSql(criteria: SegmentCriteria): { sql: string, params: any[] } {
    if (!criteria || !criteria.conditions || criteria.conditions.length === 0) {
        // SAFETY: Instead of returning 1=1 (all patients), throw an error
        throw new Error('Segment criteria must have at least one condition. Empty criteria would select all patients.');
    }

    const clauses: string[] = [];
    const params: any[] = [];

    for (const fileCond of criteria.conditions) {
        const column = FIELD_MAP[fileCond.field];
        if (!column) continue; // Skip unknown columns for security

        let clause = "";
        const val = fileCond.value;

        switch (fileCond.operator) {
            case 'equals':
                clause = `${column} = ?`;
                params.push(val);
                break;
            case 'not_equals':
                clause = `${column} != ?`;
                params.push(val);
                break;
            case 'contains':
                clause = `${column} LIKE ?`;
                params.push(`%${val}%`);
                break;
            case 'starts_with':
                clause = `${column} LIKE ?`;
                params.push(`${val}%`);
                break;
            case 'gt':
                clause = `${column} > ?`;
                params.push(val);
                break;
            case 'gte':
                clause = `${column} >= ?`;
                params.push(val);
                break;
            case 'lt':
                clause = `${column} < ?`;
                params.push(val);
                break;
            case 'lte':
                clause = `${column} <= ?`;
                params.push(val);
                break;
            case 'between':
                // Check if value is array [start, end]
                if (Array.isArray(val) && val.length === 2) {
                    clause = `${column} BETWEEN ? AND ?`;
                    params.push(val[0], val[1]);
                }
                break;
            case 'in': // Useful for Status checkboxes
                if (Array.isArray(val) && val.length > 0) {
                    const placeholders = val.map(() => '?').join(',');
                    clause = `${column} IN (${placeholders})`;
                    params.push(...val);
                }
                break;
            case 'is_true':
                clause = `${column} = 1`;
                break;
            case 'is_false':
                clause = `${column} = 0`;
                break;
            case 'older_than_days':
                // Handle both timestamp columns (created_at) and date string columns (last_visit_date)
                // Timestamp columns: created_at, last_activity_at, updated_at, last_payment_date
                if (['created_at', 'last_activity_at', 'updated_at', 'last_payment_date'].includes(fileCond.field)) {
                    // Unix timestamp: compare with (now - N days in seconds)
                    clause = `${column} < (strftime('%s', 'now') - ? * 86400)`;
                    params.push(val);
                } else {
                    // Date string (YYYY-MM-DD): use date() function
                    clause = `${column} < date('now', '-' || ? || ' days')`;
                    params.push(val);
                }
                break;
            case 'within_days':
                // Handle both timestamp columns and date string columns
                if (['created_at', 'last_activity_at', 'updated_at', 'last_payment_date'].includes(fileCond.field)) {
                    // Unix timestamp: compare with (now - N days in seconds)
                    clause = `${column} >= (strftime('%s', 'now') - ? * 86400)`;
                    params.push(val);
                } else {
                    // Date string (YYYY-MM-DD): use date() function
                    clause = `${column} >= date('now', '-' || ? || ' days')`;
                    params.push(val);
                }
                break;
            case 'relative_date':
                // e.g. val = +1 (Tomorrow), 0 (Today), -1 (Yesterday)
                // We want to match the EXACT date.
                const offset = parseInt(val, 10);
                const sign = offset >= 0 ? '+' : ''; // SQL modifier needs + for positive? actually sqlite just takes '+1 days' or '-1 days'

                // For reservation_date (special subquery case handled below), we need to handle it differently.
                // But generally for date columns:
                if (fileCond.field === 'reservation_date') {
                    // This is a special virtual field, handled in the specific block below?
                    // Actually, let's allow it to fall through if we use a specific column name in FIELD_MAP?
                    // No, reservation_date needs a subquery.
                }

                if (['created_at', 'last_activity_at', 'updated_at', 'last_payment_date'].includes(fileCond.field)) {
                    // Timestamp range for that specific day
                    // This is tricky. simpler to use date(column, 'unixepoch', 'localtime')
                    clause = `date(${column}, 'unixepoch', 'localtime') = date('now', '${sign}${offset} days', 'localtime')`;
                } else {
                    // String YYYY-MM-DD
                    clause = `${column} = date('now', '${sign}${offset} days', 'localtime')`;
                }
                break;
        }

        // Special handling for 'tags' (JSON array) which uses LIKE
        if (fileCond.field === 'tags' && fileCond.operator === 'contains') {
            // Partial match within JSON array - searches for substring in any tag
            clause = `${column} LIKE ?`;
            params.pop();
            params.push(`%${val}%`);
        }

        // Special handling for 'reservation_date' which implies JOIN/EXISTS
        // Note: reservations table uses 'reserved_at' (Unix timestamp), not 'reservation_date'
        if (fileCond.field === 'reservation_date') {
            const offset = parseInt(val, 10);
            const sign = offset >= 0 ? '+' : '';

            if (fileCond.operator === 'relative_date') {
                clause = `EXISTS (
                    SELECT 1 FROM reservations r 
                    WHERE r.patient_id = patients.id 
                    AND r.deleted_at IS NULL
                    AND date(r.reserved_at, 'unixepoch', 'localtime') = date('now', '${sign}${offset} days', 'localtime')
                    AND r.status NOT IN ('cancelled', 'no_show', 'completed')
                )`;
                // No params needed for this hardcoded relative date logic
            } else if (fileCond.operator === 'gte') {
                clause = `EXISTS (
                    SELECT 1 FROM reservations r 
                    WHERE r.patient_id = patients.id 
                    AND r.deleted_at IS NULL
                    AND date(r.reserved_at, 'unixepoch', 'localtime') >= date(?)
                    AND r.status NOT IN ('cancelled', 'no_show', 'completed')
                )`;
                params.length = 0;
                params.push(val);
            }
        }


        // Special handling for Timestamps stored as Integers (created_at) vs Date Strings
        // If the column defines a timestamp but input is 'YYYY-MM-DD', we might need conversion.
        // For simplicity now, let's assume the frontend sends the correct format matching the DB column type.
        // OR we handle it here:
        if (fileCond.field === 'created_at' && (typeof val === 'string' && val.includes('-'))) {
            // Convert YYYY-MM-DD to Unix Timestamp if needed, but let's enforce Frontend to send timestamps or use Date functions
            // SQLite: strftime('%s', '2023-01-01')
        }

        if (clause) {
            clauses.push(clause);
        }
    }

    if (clauses.length === 0) return { sql: "1=1", params: [] };

    const glue = criteria.operator === 'OR' ? ' OR ' : ' AND ';
    const fullSql = `(${clauses.join(glue)})`;

    return { sql: fullSql, params };
}
