
export type Organ = "heart" | "spleen" | "lung" | "liver" | "kidney";
export type Axis = "qi" | "blood" | "yin" | "yang";

export type SymptomGroup =
    | "general"
    | "headMindSleep"
    | "chest"
    | "abdomen"
    | "musculo"
    | "uroGenital"
    | "safety";

export interface SymptomItem {
    id: string;
    group: SymptomGroup;
    label: string;      // Short label for admin/analysis
    question: string;   // Full question for patient
    organWeights: Partial<Record<Organ, number>>;
    axisWeights: Partial<Record<Axis, number>>;
}

export const symptomGroups: Record<SymptomGroup, string> = {
    general: "전신 / 피로 / 체온",
    headMindSleep: "머리 / 정신 / 수면",
    chest: "가슴 / 호흡",
    abdomen: "소화 / 복부",
    musculo: "근골격 / 통증",
    uroGenital: "소변 / 생식 / 기타",
    safety: "안전 점검 (과거력/복용약)"
};

export const symptomItems: SymptomItem[] = [
    // ... existing items ...

    // =====================
    // 1) 전신 / 피로
    // =====================
    {
        id: "fatigue_daytime",
        group: "general",
        label: "낮 시간대 피로감",
        question: "낮 동안 쉽게 피곤해지고, 쉬어도 개운하지 않은 날이 많나요?",
        organWeights: { spleen: 0.4, heart: 0.3, kidney: 0.3 },
        axisWeights: { qi: 0.6, blood: 0.2, yin: 0.2 },
    },
    {
        id: "weak_after_small_work",
        group: "general",
        label: "조금만 일해도 탈진",
        question: "가벼운 집안일이나 업무 후에도 금방 지치고 힘이 빠지나요?",
        organWeights: { spleen: 0.4, lung: 0.2, heart: 0.2, kidney: 0.2 },
        axisWeights: { qi: 0.7, blood: 0.1, yang: 0.2 },
    },
    {
        id: "spontaneous_sweat",
        group: "general",
        label: "가벼운 활동에도 땀",
        question: "조금만 움직여도 땀이 잘 나는 편인가요? (자한)",
        organWeights: { lung: 0.5, spleen: 0.3, heart: 0.2 },
        axisWeights: { qi: 0.7, yang: 0.3 },
    },
    {
        id: "cold_sensitivity",
        group: "general",
        label: "추위를 많이 탐",
        question: "다른 사람보다 유난히 추위를 많이 타거나 손발이 잘 시리나요?",
        organWeights: { kidney: 0.5, spleen: 0.3, heart: 0.2 },
        axisWeights: { yang: 0.6, qi: 0.2, yin: 0.2 },
    },
    {
        id: "heat_sensitivity_evening",
        group: "general",
        label: "오후/밤에 열감",
        question: "오후나 밤에 열이 오르거나 얼굴이 화끈거리는 느낌이 있나요?",
        organWeights: { liver: 0.4, heart: 0.3, kidney: 0.3 },
        axisWeights: { yin: 0.6, yang: 0.2, blood: 0.2 },
    },

    // ==========================
    // 2) 머리 · 정신 · 수면
    // ==========================
    {
        id: "light_sleep",
        group: "headMindSleep",
        label: "잠이 얕고 자주 깸",
        question: "잠이 얕고 꿈이 많거나, 자주 깨서 깊이 못 자는 편인가요?",
        organWeights: { heart: 0.6, liver: 0.3, kidney: 0.1 },
        axisWeights: { blood: 0.4, yin: 0.4, qi: 0.2 },
    },
    {
        id: "difficulty_falling_asleep",
        group: "headMindSleep",
        label: "잠들기 어렵다",
        question: "누워도 잠이 잘 들지 않고, 생각이 많아지면서 뒤척이나요?",
        organWeights: { heart: 0.6, liver: 0.3, spleen: 0.1 },
        axisWeights: { blood: 0.4, qi: 0.3, yin: 0.3 },
    },
    {
        id: "anxiety_irritability",
        group: "headMindSleep",
        label: "불안·예민함",
        question: "별일 아닌데도 불안하거나, 예민하고 짜증이 잘 나는 편인가요?",
        organWeights: { liver: 0.4, heart: 0.4, spleen: 0.2 },
        axisWeights: { blood: 0.4, qi: 0.3, yin: 0.3 },
    },
    {
        id: "poor_concentration",
        group: "headMindSleep",
        label: "집중력 저하",
        question: "집중이 잘 안 되거나, 머리가 멍하고 맑지 않은 느낌이 있나요?",
        organWeights: { heart: 0.4, spleen: 0.3, kidney: 0.3 },
        axisWeights: { qi: 0.4, blood: 0.4, yin: 0.2 },
    },
    {
        id: "dizziness",
        group: "headMindSleep",
        label: "어지럼",
        question: "특별한 이유 없이 어지럽거나, 일어날 때 핑 도는 느낌이 있나요?",
        organWeights: { liver: 0.4, heart: 0.3, kidney: 0.3 },
        axisWeights: { blood: 0.5, yin: 0.3, qi: 0.2 },
    },
    {
        id: "headache_tension",
        group: "headMindSleep",
        label: "두통·뻐근한 머리",
        question: "머리가 자주 아프거나, 머리 주변이 조이는 듯 뻐근한가요?",
        organWeights: { liver: 0.5, heart: 0.3, spleen: 0.2 },
        axisWeights: { blood: 0.5, qi: 0.3, yang: 0.2 },
    },

    // =======================
    // 3) 가슴(심장·호흡)
    // =======================
    {
        id: "palpitation",
        group: "chest",
        label: "두근거림",
        question: "가끔 이유 없이 심장이 두근거리거나 불규칙하게 뛰는 느낌이 있나요?",
        organWeights: { heart: 0.7, lung: 0.2, kidney: 0.1 },
        axisWeights: { qi: 0.4, blood: 0.3, yin: 0.3 },
    },
    {
        id: "chest_tightness",
        group: "chest",
        label: "가슴 답답함",
        question: "가슴이 답답하거나 꽉 막힌 느낌이 자주 드나요?",
        organWeights: { heart: 0.4, lung: 0.4, liver: 0.2 },
        axisWeights: { qi: 0.4, blood: 0.3, yin: 0.3 },
    },
    {
        id: "shortness_of_breath",
        group: "chest",
        label: "숨이 차고 깊게 못 쉼",
        question: "계단을 오르거나 조금만 움직여도 숨이 차고, 깊게 숨쉬기 어렵나요?",
        organWeights: { lung: 0.6, heart: 0.3, kidney: 0.1 },
        axisWeights: { qi: 0.6, yang: 0.2, yin: 0.2 },
    },
    {
        id: "chronic_cough_phlegm",
        group: "chest",
        label: "기침·가래가 오래감",
        question: "기침이나 가래가 생기면 쉽게 낫지 않고 오래 가는 편인가요?",
        organWeights: { lung: 0.8, heart: 0.2 },
        axisWeights: { qi: 0.5, yin: 0.3, yang: 0.2 },
    },
    {
        id: "frequent_colds",
        group: "chest",
        label: "자주 감기",
        question: "감기, 목감기, 기침감기에 자주 걸리는 편인가요?",
        organWeights: { lung: 0.7, spleen: 0.3 },
        axisWeights: { qi: 0.6, yang: 0.2, yin: 0.2 },
    },

    // =====================
    // 4) 복부(소화)
    // =====================
    {
        id: "poor_appetite",
        group: "abdomen",
        label: "입맛 없음",
        question: "배가 고프다는 느낌이 잘 안 들거나, 먹고 싶지 않은 날이 많나요?",
        organWeights: { spleen: 0.7, liver: 0.3 },
        axisWeights: { qi: 0.6, blood: 0.2, yang: 0.2 },
    },
    {
        id: "bloating_after_meal",
        group: "abdomen",
        label: "식후 더부룩함",
        question: "식사 후 배가 자주 더부룩하거나 소화가 더디다고 느끼나요?",
        organWeights: { spleen: 0.7, liver: 0.3 },
        axisWeights: { qi: 0.6, yang: 0.2, blood: 0.2 },
    },
    {
        id: "abdominal_pain_discomfort",
        group: "abdomen",
        label: "복부 불편·통증",
        question: "명확한 원인 없이 속이 더부룩하거나 아프고 불편한 느낌이 있나요?",
        organWeights: { spleen: 0.6, liver: 0.4 },
        axisWeights: { qi: 0.5, blood: 0.3, yang: 0.2 },
    },
    {
        id: "loose_stool",
        group: "abdomen",
        label: "묽은 변·설사",
        question: "묽은 변이나 설사가 잦거나, 대변이 잘 덜 나오는 느낌이 있나요?",
        organWeights: { spleen: 0.8, kidney: 0.2 },
        axisWeights: { qi: 0.4, yang: 0.4, yin: 0.2 },
    },
    {
        id: "tendency_constipation",
        group: "abdomen",
        label: "변비 경향",
        question: "대변이 딱딱하고 시원하게 보지 못하는 날이 많나요?",
        organWeights: { spleen: 0.4, liver: 0.3, kidney: 0.3 },
        axisWeights: { yin: 0.4, blood: 0.3, qi: 0.3 },
    },
    {
        id: "abdominal_coldness",
        group: "abdomen",
        label: "배가 찬 느낌",
        question: "배가 자주 차갑게 느껴지거나, 찬 음식에 민감한 편인가요?",
        organWeights: { spleen: 0.6, kidney: 0.4 },
        axisWeights: { yang: 0.6, qi: 0.2, yin: 0.2 },
    },

    // =========================
    // 5) 근골격 · 허리/무릎
    // =========================
    {
        id: "low_back_pain_weakness",
        group: "musculo",
        label: "허리 시큰·무력감",
        question: "허리가 자주 시큰거리거나 힘이 빠지는 느낌이 있나요?",
        organWeights: { kidney: 0.7, liver: 0.3 },
        axisWeights: { yin: 0.4, yang: 0.4, qi: 0.2 },
    },
    {
        id: "knee_pain_weakness",
        group: "musculo",
        label: "무릎 시큰·불안정",
        question: "무릎이 시큰거리거나, 오래 걷고 나면 힘이 빠지는 느낌이 있나요?",
        organWeights: { kidney: 0.6, liver: 0.4 },
        axisWeights: { yin: 0.4, blood: 0.3, qi: 0.3 },
    },
    {
        id: "muscle_stiffness_cramps",
        group: "musculo",
        label: "근육 뻐근·쥐",
        question: "근육이 잘 뭉치거나, 쥐가 자주 나는 편인가요?",
        organWeights: { liver: 0.6, spleen: 0.2, kidney: 0.2 },
        axisWeights: { blood: 0.5, yin: 0.3, qi: 0.2 },
    },
    {
        id: "general_body_ache",
        group: "musculo",
        label: "온몸이 쑤시고 무거움",
        question: "특별한 병이 없는데도 온몸이 쑤시고 무거운 느낌이 자주 있나요?",
        organWeights: { spleen: 0.4, liver: 0.3, kidney: 0.3 },
        axisWeights: { qi: 0.4, blood: 0.4, yang: 0.2 },
    },

    // ==========================
    // 6) 소변/생식/기타
    // ==========================
    {
        id: "nocturia",
        group: "uroGenital",
        label: "야간뇨",
        question: "밤에 소변 때문에 2회 이상 깨는 날이 자주 있나요?",
        organWeights: { kidney: 0.8, spleen: 0.2 },
        axisWeights: { yin: 0.5, qi: 0.3, yang: 0.2 },
    },
    {
        id: "frequent_urination_day",
        group: "uroGenital",
        label: "주간 빈뇨",
        question: "낮에도 소변이 자주 마렵고, 참기 힘든 편인가요?",
        organWeights: { kidney: 0.6, spleen: 0.2, heart: 0.2 },
        axisWeights: { qi: 0.4, yin: 0.3, yang: 0.3 },
    },
    {
        id: "sexual_function_down",
        group: "uroGenital",
        label: "성욕·성기능 저하",
        question: "예전에 비해 성욕이나 성기능이 눈에 띄게 줄었다고 느끼나요?",
        organWeights: { kidney: 0.8, liver: 0.2 },
        axisWeights: { yin: 0.5, yang: 0.3, qi: 0.2 },
    },
    {
        id: "menstrual_disorder_pain",
        group: "uroGenital",
        label: "생리불순·생리통 (해당 시)",
        question: "여성인 경우, 생리 주기가 고르지 않거나 생리통이 심한 편인가요?",
        organWeights: { liver: 0.6, kidney: 0.3, spleen: 0.1 },
        axisWeights: { blood: 0.5, yin: 0.3, qi: 0.2 },
    },

    // ==========================
    // 7) 안전 점검 (주관식)
    // ==========================
    {
        id: "history",
        group: "safety",
        label: "과거력",
        question: "과거에 진단받거나 치료받은 질병이 있나요? (수술 이력 포함)",
        organWeights: {},
        axisWeights: {},
    },
    {
        id: "medication",
        group: "safety",
        label: "복용약",
        question: "현재 복용 중인 양약이나 건강기능식품이 있나요?",
        organWeights: {},
        axisWeights: {},
    },
    {
        id: "side_effects",
        group: "safety",
        label: "부작용 경험",
        question: "과거 한약 복용 시 부작용이나 불편했던 경험이 있나요?",
        organWeights: {},
        axisWeights: {},
    },
];
