
import type { SurveyAnalysis } from './analysis';
import type { Organ } from './survey-data';
import type { PatternDetail } from './pattern-data';


export interface ReportContent {
    header: {
        oneLineDiagnosis: string;
        oneLineDiagnosisEng: string;
    };
    summary: {
        axis: {
            qi: { score: number; comment: string };
            blood: { score: number; comment: string };
            yin: { score: number; comment: string };
            yang: { score: number; comment: string };
        };
        organFocus: {
            primary: string;
            secondary: string;
            qiFocus: string;
            bloodFocus: string;
        };
    };
    tendency: {
        duration: string;
        temp: string;
    };
    organs: {
        name: string;
        score: number;
        symptoms: string[];
        isPrimary?: boolean;
        isSecondary?: boolean;
    }[];
    diagnosis: {
        primary: string;
        description: string;
        secondary: string[];
    };
    interpretation: {
        summarySentence: string;
        details: string[];
    };
    management: {
        clinicalFocus: {
            title: string;
            content: string;
        }[];
        lifestyle: string[];
    };
    pattern?: PatternDetail;
}

export interface SleepReportContent {
    header: {
        diagnosis: string;
        diagnosisEng: string;
    };
    summary: {
        scores: {
            onset: { score: number; max: number; label: string; color: string };
            maintenance: { score: number; max: number; label: string; color: string };
            satisfaction: { score: number; max: number; label: string; color: string };
            daytime: { score: number; max: number; label: string; color: string };
        };
        flags: string[];
    };
    interpretation: {
        summary: string;
        details: string[];
    };
    management: {
        focus: string[];
        lifestyle: string[];
    };
}

const KOR_MAP: Record<string, string> = {
    heart: "심(Heart)",
    spleen: "비위(Spleen)",
    lung: "폐(Lung)",
    liver: "간(Liver)",
    kidney: "신(Kidney)",
    qi: "기(Qi)",
    blood: "혈(Blood)",
    yin: "음(Yin)",
    yang: "양(Yang)"
};

const ENG_MAP: Record<string, string> = {
    heart: "Heart",
    spleen: "Spleen",
    lung: "Lung",
    liver: "Liver",
    kidney: "Kidney",
    qi: "Qi",
    blood: "Blood",
    yin: "Yin",
    yang: "Yang"
};

// --- Text Block Library ---

const AXIS_TEXT = {
    qi: {
        high: "기(氣)를 쓰는 힘이 많이 소모된 상태로 보입니다.",
        mid: "기(氣)가 다소 부족한 경향이 있습니다.",
        low: "기(氣)는 비교적 유지되고 있는 것으로 보입니다."
    },
    blood: {
        high: "혈(血)이 부족하여 영양 공급이 원활하지 않을 수 있습니다.",
        mid: "혈(血)이 다소 부족한 경향이 있습니다.",
        low: "혈(血) 상태는 양호한 편입니다."
    },
    yin: {
        high: "음(陰, 체액/냉각수)이 부족해져 몸이 건조하거나 허열이 뜨기 쉽습니다.",
        mid: "음(陰)이 다소 부족한 경향이 있습니다.",
        low: "음(陰) 상태는 양호한 편입니다."
    },
    yang: {
        high: "양(陽, 체온/에너지)이 부족해져 몸이 차거나 대사가 느려진 상태일 수 있습니다.",
        mid: "양(陽)이 다소 부족한 경향이 있습니다.",
        low: "양(陽) 상태는 양호한 편입니다."
    }
};

const ORGAN_PRIMARY_TEXT: Record<Organ, string> = {
    spleen: "비위(소화기)가 약해지면 음식을 에너지로 바꾸는 효율이 떨어져, 먹고도 힘이 나지 않거나 식후 더부룩함, 설사·묽은 변 등이 나타나기 쉽습니다.",
    lung: "폐 기능이 약해지면 호흡기 감염에 취약해지고, 조금만 움직여도 숨이 차거나, 기침·가래가 오래 가는 양상으로 나타날 수 있습니다.",
    heart: "심장 기능이 약해지면 혈액 순환이 더뎌지고, 작은 일에도 두근거리고 불안하거나 잠을 깊이 못 자는 증상이 나타나기 쉽습니다.",
    liver: "간의 기운이 막히거나 부족하면 근육이 뻣뻣해지고 쥐가 잘 나며, 눈이 피로하고 감정적으로 예민해지기 쉽습니다.",
    kidney: "신장 기능이 약해진 패턴에서는 허리와 무릎이 시큰거리고, 소변이 잦거나 시원치 않으며, 깊은 피로감이 나타나기 쉽습니다."
};

function determineSeverityLevel(scores: { qi: number; blood: number; yin: number; yang: number }): {
    level: '경도' | '중등도' | '중등도 이상';
    description: string;
} {
    const maxScore = Math.max(scores.qi, scores.blood, scores.yin, scores.yang);

    if (maxScore >= 81) {
        return {
            level: '중등도 이상',
            description: '현재 증상이 비교적 뚜렷한 단계로, 적극적인 관리가 필요합니다.'
        };
    } else if (maxScore >= 66) {
        return {
            level: '중등도',
            description: '증상이 악화되기 전에 조절하면 회복이 더 빠른 단계입니다.'
        };
    } else {
        return {
            level: '경도',
            description: '아직 초기 단계로, 생활 관리와 함께 조기 개입하면 빠른 개선이 가능합니다.'
        };
    }
}

const LIFESTYLE_GUIDE = {
    qi: "과로와 야근을 줄이고, 최소한 취침 시간은 일정하게 맞추세요.",
    blood: "철분과 단백질 섭취에 신경 쓰고, 무리한 다이어트는 피하세요.",
    yin: "맵고 자극적인 음식을 피하고, 늦은 밤 스마트폰 사용 등 과열 활동을 줄이세요.",
    yang: "찬 음식과 에어컨 바람을 피하고, 가벼운 근육 운동으로 체온을 높이세요."
};

export function generateReportContent(analysis: SurveyAnalysis): ReportContent {
    const { scores, diagnosis, organs } = analysis;

    // 1. Header Info
    const primaryOrgans = organs.filter(o => o.isPrimary);
    const secondaryOrgans = organs.filter(o => o.isSecondary);

    const primaryKor = primaryOrgans.map(o => KOR_MAP[o.key as string] || o.name).join('·') || "복합";
    const primaryEng = primaryOrgans.map(o => ENG_MAP[o.key as string] || "").join('-');

    // Parse axis label from diagnosis if possible, or reconstruct
    const axisLabelKor = diagnosis.axisLabel || "복합 허증";
    // Simple English mapping for axis label (can be improved)
    const axisLabelEng = axisLabelKor.replace("기허", "Qi Deficiency").replace("혈허", "Blood Deficiency").replace("음허", "Yin Deficiency").replace("양허", "Yang Deficiency").replace("기혈양허", "Qi-Blood Deficiency").replace("음양양허", "Yin-Yang Deficiency");

    // 2. Summary - Axis Comments
    const getAxisComment = (key: 'qi' | 'blood' | 'yin' | 'yang', score: number) => {
        if (score >= 70) return AXIS_TEXT[key].high;
        if (score >= 50) return AXIS_TEXT[key].mid;
        return AXIS_TEXT[key].low;
    };

    // 3. Summary - Organ Focus
    // Find where Qi/Blood are focused (highest score organ among primary/secondary)
    // Only show focus if the axis score is significant (>= 50)
    const topOrgan = organs[0]; // Already sorted by score

    let qiFocus = "양호함";
    if (scores.qi >= 50) {
        qiFocus = topOrgan ? `${topOrgan.name}에 가장 많이 집중` : "전신";
    }

    let bloodFocus = "양호함";
    if (scores.blood >= 50) {
        // If top organ is same as qi focus, try second one, otherwise use top
        const bloodOrgan = organs.length > 1 ? organs[1] : topOrgan;
        bloodFocus = bloodOrgan ? `${bloodOrgan.name}와 연관성 높음` : "전신";
    }

    // 4. Interpretation
    const severity = determineSeverityLevel(scores);

    const summarySentence = `"${primaryKor} 기능이 약해지면서 ${axisLabelKor}가 중심이 된 상태"입니다.`;
    const severitySentence = `전체적으로 볼 때, 현재 ${axisLabelKor} 정도는 **${severity.level}** 수준입니다. (${severity.description})`;

    const details = [
        // Data source clarification
        "이 결과는 초진 설문과 증상 체크를 바탕으로, 4축(기·혈·음·양)과 장부(심·비·폐·간·신) 간의 패턴을 분석한 결과입니다.",
        // Axis explanation
        scores.qi >= 50 ? "기(氣)가 부족하여 몸의 에너지 레벨이 떨어져 있을 가능성이 높습니다." : "",
        scores.blood >= 50 ? "혈(血)이 부족하여 영양 공급과 순환이 원활하지 않을 수 있습니다." : "",
        // Organ explanation (Primary)
        ...primaryOrgans.map(o => ORGAN_PRIMARY_TEXT[o.key as Organ]),
        // Secondary
        secondaryOrgans.length > 0 ? `또한 ${secondaryOrgans.map(o => o.name).join(', ')} 쪽에도 부담이 동반되고 있어 관리가 필요할 수 있습니다.` : ""
    ].filter(Boolean);

    // 5. Management
    const clinicalFocus = [];

    if (primaryOrgans.length > 0) {
        clinicalFocus.push({
            title: `${primaryKor} 기능 회복`,
            content: `약해진 ${primaryKor}의 기능을 끌어올려 핵심 에너지를 회복합니다.`
        });
    }

    if (secondaryOrgans.length > 0) {
        clinicalFocus.push({
            title: `동반 부위(${secondaryOrgans.map(o => o.name).join('·')}) 부담 조절`,
            content: `주 장부의 영향으로 함께 약해진 부위를 보강하여 균형을 맞춥니다.`
        });
    }

    // Axis Care
    const axisCare = [];
    if (scores.qi >= 50) axisCare.push("기운을 북돋아주는 치료");
    if (scores.blood >= 50) axisCare.push("혈을 보충하는 치료");
    if (scores.yin >= 50) axisCare.push("진액을 보충하는 치료");
    if (scores.yang >= 50) axisCare.push("몸을 따뜻하게 하는 치료");

    if (axisCare.length > 0) {
        clinicalFocus.push({
            title: `${axisLabelKor} 개선`,
            content: `${axisCare.join(', ')}를 병행하여 전신 컨디션을 개선합니다.`
        });
    }

    // Lifestyle
    const lifestyle = [];
    if (scores.qi >= 50) lifestyle.push(LIFESTYLE_GUIDE.qi);
    if (scores.blood >= 50) lifestyle.push(LIFESTYLE_GUIDE.blood);
    if (scores.yin >= 50) lifestyle.push(LIFESTYLE_GUIDE.yin);
    if (scores.yang >= 50) lifestyle.push(LIFESTYLE_GUIDE.yang);
    if (lifestyle.length === 0) lifestyle.push("규칙적인 식사와 수면, 적절한 운동으로 현재의 건강한 상태를 유지하세요.");

    return {
        header: {
            oneLineDiagnosis: `주 패턴: ${primaryKor} 중심 ${axisLabelKor}형`,
            oneLineDiagnosisEng: `(${primaryEng}-centered ${axisLabelEng})`
        },
        summary: {
            axis: {
                qi: { score: scores.qi, comment: getAxisComment('qi', scores.qi) },
                blood: { score: scores.blood, comment: getAxisComment('blood', scores.blood) },
                yin: { score: scores.yin, comment: getAxisComment('yin', scores.yin) },
                yang: { score: scores.yang, comment: getAxisComment('yang', scores.yang) }
            },
            organFocus: {
                primary: primaryKor,
                secondary: secondaryOrgans.map(o => o.name).join('·') || "없음",
                qiFocus: qiFocus,
                bloodFocus: bloodFocus
            }
        },
        tendency: {
            duration: analysis.tendency.duration || '미입력',
            temp: analysis.tendency.temp || '미입력'
        },
        organs: organs.map(o => ({
            name: o.name,
            score: o.score,
            symptoms: o.symptoms,
            isPrimary: o.isPrimary,
            isSecondary: o.isSecondary
        })),
        diagnosis: {
            primary: diagnosis.primary,
            description: diagnosis.description,
            secondary: diagnosis.secondary
        },
        interpretation: {
            summarySentence: summarySentence + " " + severitySentence,
            details
        },
        management: {
            clinicalFocus,
            lifestyle
        },
        pattern: analysis.pattern ? {
            ...analysis.pattern,
            pathomechanism: (() => {
                // Mix static pathomechanism with dynamic symptoms
                const core = analysis.pattern!.pathomechanism;
                const symptoms = analysis.organs[0]?.symptoms || []; // Get symptoms from top organ

                if (symptoms.length === 0) return core;

                // Cleanup symptoms: "두통(3)" -> "두통"
                const cleanSymptoms = symptoms
                    .map((s: string) => s.replace(/\(\d+\)$/, '').trim())
                    .slice(0, 3); // Top 3

                if (cleanSymptoms.length === 0) return core;

                return `${core} 특히 고객님의 경우, 이러한 불균형이 **[${cleanSymptoms.join(', ')}]** 등의 증상으로 나타나고 있습니다.`;
            })()
        } : undefined
    };
}

export function generateSleepReportContent(analysis: any): SleepReportContent {
    const { scores, flags } = analysis;

    // 1. Diagnosis Logic
    let diagnosis = "수면 패턴 양호";
    let diagnosisEng = "Good Sleep Pattern";

    if (scores.sleep_onset >= 2 && scores.sleep_maintenance >= 4) {
        diagnosis = "복합성 불면 (입면+유지장애)";
        diagnosisEng = "Mixed Insomnia (Onset + Maintenance)";
    } else if (scores.sleep_onset >= 2) {
        diagnosis = "입면장애형 불면";
        diagnosisEng = "Sleep Onset Insomnia";
    } else if (scores.sleep_maintenance >= 4) {
        diagnosis = "수면유지장애형 불면";
        diagnosisEng = "Sleep Maintenance Insomnia";
    } else if (flags.sleep_duration_low) {
        diagnosis = "수면부족 증후군";
        diagnosisEng = "Insufficient Sleep Syndrome";
    } else if (flags.sleep_satisfaction_very_low) {
        diagnosis = "주관적 수면 불만족";
        diagnosisEng = "Subjective Poor Sleep Quality";
    }

    // 2. Score Interpretation Helpers
    const getLevel = (score: number, thresholds: number[]) => {
        if (score >= thresholds[1]) return { label: '심각', color: 'bg-red-500' };
        if (score >= thresholds[0]) return { label: '주의', color: 'bg-yellow-500' };
        return { label: '양호', color: 'bg-green-500' };
    };

    // 3. Interpretation Text
    const details = [];
    if (scores.sleep_onset >= 2) details.push("잠들기까지 30분 이상 소요되어 입면에 어려움이 있습니다.");
    if (scores.sleep_maintenance >= 4) details.push("자주 깨거나 다시 잠들기 힘들어 수면의 연속성이 떨어집니다.");
    if (flags.sleep_duration_low) details.push("총 수면 시간이 6시간 미만으로 절대적인 수면량이 부족합니다.");
    if (flags.daytime_impairment_high) details.push("수면 문제로 인해 낮 시간의 피로와 기능 저하가 뚜렷합니다.");
    if (flags.sleep_apnea_suspected) details.push("수면 무호흡 가능성이 있어 정밀 검사가 필요할 수 있습니다.");
    if (flags.sleep_hygiene_poor) details.push("카페인, 음주, 스마트폰 등 수면을 방해하는 생활 습관이 관찰됩니다.");

    // 4. Management Guide
    const focus = [];
    if (scores.sleep_onset >= 2) focus.push("입면 시간 단축을 위한 이완 요법 및 자율신경 조절");
    if (scores.sleep_maintenance >= 4) focus.push("수면 깊이를 개선하고 야간 각성을 줄이는 치료");
    if (flags.mental_impact_high) focus.push("수면으로 인한 불안/우울감을 완화하는 심리 안정 치료");
    if (flags.daytime_impairment_high) focus.push("주간 활력을 높이고 피로를 개선하는 보강 치료");

    const lifestyle = [];
    if (scores.sleep_hygiene >= 1) {
        if (analysis.raw.screen_time !== 'none') lifestyle.push("취침 1시간 전부터는 스마트폰/TV 사용을 자제하세요.");
        if (analysis.raw.caffeine_intake !== 'rare') lifestyle.push("오후 2시 이후에는 카페인 섭취를 피하세요.");
        if (analysis.raw.alcohol_intake !== 'rare') lifestyle.push("술은 수면의 질을 떨어뜨리므로 절주가 필요합니다.");
    }
    lifestyle.push("매일 같은 시간에 일어나 생체 리듬을 일정하게 유지하세요.");
    lifestyle.push("낮 시간에 30분 이상 햇볕을 쬐며 산책하세요.");

    return {
        header: { diagnosis, diagnosisEng },
        summary: {
            scores: {
                onset: {
                    score: scores.sleep_onset, max: 3,
                    ...getLevel(scores.sleep_onset, [1, 2])
                },
                maintenance: {
                    score: scores.sleep_maintenance, max: 6,
                    ...getLevel(scores.sleep_maintenance, [2, 4])
                },
                satisfaction: {
                    score: scores.sleep_satisfaction, max: 10,
                    label: scores.sleep_satisfaction <= 3 ? '불만족' : (scores.sleep_satisfaction >= 7 ? '만족' : '보통'),
                    color: scores.sleep_satisfaction <= 3 ? 'bg-red-500' : (scores.sleep_satisfaction >= 7 ? 'bg-green-500' : 'bg-yellow-500')
                },
                daytime: {
                    score: scores.daytime_impairment, max: 13,
                    ...getLevel(scores.daytime_impairment, [4, 8])
                }
            },
            flags: Object.entries(flags).filter(([_, v]) => v).map(([k, _]) => {
                const map: Record<string, string> = {
                    sleep_duration_low: "수면부족",
                    sleep_satisfaction_very_low: "만족도저하",
                    daytime_impairment_high: "주간기능저하",
                    mental_impact_high: "정서영향",
                    sleep_hygiene_poor: "수면위생불량",
                    sleep_apnea_suspected: "무호흡의심",
                    heavy_snoring: "심한코골이",
                    hypnotic_frequent: "수면제의존"
                };
                return map[k];
            }).filter(Boolean)
        },
        interpretation: {
            summary: `현재 수면 패턴은 **${diagnosis}** 양상을 보이고 있습니다.`,
            details
        },
        management: {
            focus,
            lifestyle
        }
    };
}
