import type { D1Database } from "@cloudflare/workers-types";

export interface KnowledgeCard {
    id: string;
    topic: string;
    card_type: string; // Renamed from category
    category: string; // New column (Subject)
    role: string; // Kept for reference but less critical
    tags: string[];
    level: 'L1' | 'L2' | 'L3';
    content: {
        one_liner: string;
        expand_patient: string;
        expand_staff: string;
        safe_alternatives: string[];
        avoid_phrases: string[];
    };
    status: 'draft' | 'review' | 'approved' | 'archived' | 'needs_revision';
    revision_note?: string; // Note from revision request
    created_at: number;
    updated_at: number;
    created_by?: string;
}

export interface KnowledgeCategory {
    id: string;
    name: string;
    description?: string;
    is_enabled: boolean;
    display_order: number;
    created_at: number;
    updated_at: number;
}

export interface KnowledgeInteraction {
    id: number;
    staff_id: string;
    card_id: string;
    type: 'view' | 'save' | 'helpful' | 'not_helpful';
    created_at: number;
}

export async function getKnowledgeCards(db: D1Database, options: {
    status?: string;
    topic?: string;
    category?: string;
    role?: string;
    limit?: number;
    offset?: number;
    search?: string;
} = {}) {
    let query = "SELECT * FROM knowledge_cards WHERE 1=1";
    const params: any[] = [];

    if (options.search) {
        query += " AND (topic LIKE ? OR content LIKE ? OR tags LIKE ?)";
        const term = `%${options.search}%`;
        params.push(term, term, term);
    }

    if (options.status) {
        query += " AND status = ?";
        params.push(options.status);
    }
    if (options.topic) {
        query += " AND topic = ?";
        params.push(options.topic);
    }
    if (options.category) {
        query += " AND category = ?";
        params.push(options.category);
    }
    // Role filter is now optional/secondary
    if (options.role && options.role !== 'All') {
        query += " AND (role = ? OR role = 'All')";
        params.push(options.role);
    }

    query += " ORDER BY created_at DESC";

    if (options.limit) {
        query += " LIMIT ?";
        params.push(options.limit);
    }
    if (options.offset) {
        query += " OFFSET ?";
        params.push(options.offset);
    }

    const { results } = await db.prepare(query).bind(...params).all();

    return results.map(row => ({
        ...row,
        tags: row.tags ? JSON.parse(row.tags as string) : [],
        content: JSON.parse(row.content as string)
    })) as KnowledgeCard[];
}

export async function getRandomKnowledgeCard(db: D1Database, role?: string): Promise<KnowledgeCard | null> {
    // 1. Get enabled categories
    const { results: categories } = await db.prepare("SELECT name FROM knowledge_categories WHERE is_enabled = 1").all();
    const enabledCategories = categories.map(c => c.name);

    if (enabledCategories.length === 0) return null;

    // 2. Query random card from enabled categories
    // We still respect role if provided, but now category enablement is the primary filter
    let query = `
        SELECT * FROM knowledge_cards 
        WHERE status = 'approved' 
        AND category IN (${enabledCategories.map(() => '?').join(',')})
    `;
    const params: any[] = [...enabledCategories];

    // Role filter (Optional, mostly for legacy or specific UI contexts)
    // If user is master/admin, we show everything (already handled by caller passing null or specific logic, but let's be safe)
    if (role && role !== 'master' && role !== 'admin' && role !== 'super_admin') {
        query += " AND (role = ? OR role = 'All')";
        params.push(role);
    }

    query += " ORDER BY RANDOM() LIMIT 1";

    const card = await db.prepare(query).bind(...params).first();

    if (!card) return null;

    return {
        ...card,
        tags: card.tags ? JSON.parse(card.tags as string) : [],
        content: JSON.parse(card.content as string)
    } as KnowledgeCard;
}

export async function createKnowledgeCard(db: D1Database, card: Omit<KnowledgeCard, 'created_at' | 'updated_at'>) {
    const now = Math.floor(Date.now() / 1000);
    const result = await db.prepare(`
        INSERT INTO knowledge_cards (id, topic, card_type, category, role, tags, level, content, status, created_at, updated_at, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
        card.id,
        card.topic,
        card.card_type,
        card.category,
        card.role,
        JSON.stringify(card.tags),
        card.level,
        JSON.stringify(card.content),
        card.status,
        now,
        now,
        card.created_by
    ).run();

    return result;
}

export async function updateKnowledgeCard(db: D1Database, id: string, updates: Partial<KnowledgeCard>) {
    const now = Math.floor(Date.now() / 1000);

    // Build dynamic update query
    const fields: string[] = [];
    const values: any[] = [];

    if (updates.topic) { fields.push("topic = ?"); values.push(updates.topic); }
    if (updates.card_type) { fields.push("card_type = ?"); values.push(updates.card_type); }
    if (updates.category) { fields.push("category = ?"); values.push(updates.category); }
    if (updates.role) { fields.push("role = ?"); values.push(updates.role); }
    if (updates.tags) { fields.push("tags = ?"); values.push(JSON.stringify(updates.tags)); }
    if (updates.level) { fields.push("level = ?"); values.push(updates.level); }
    if (updates.content) { fields.push("content = ?"); values.push(JSON.stringify(updates.content)); }
    if (updates.status) { fields.push("status = ?"); values.push(updates.status); }

    fields.push("updated_at = ?");
    values.push(now);

    values.push(id); // For WHERE clause

    const query = `UPDATE knowledge_cards SET ${fields.join(", ")} WHERE id = ?`;

    return await db.prepare(query).bind(...values).run();
}

export async function recordInteraction(db: D1Database, interaction: Omit<KnowledgeInteraction, 'id' | 'created_at'>) {
    const now = Math.floor(Date.now() / 1000);
    await db.prepare(`
        INSERT INTO knowledge_interactions (staff_id, card_id, type, created_at)
        VALUES (?, ?, ?, ?)
    `).bind(
        interaction.staff_id,
        interaction.card_id,
        interaction.type,
        now
    ).run();
}

export async function getSavedCards(db: D1Database, staffId: string) {
    const { results } = await db.prepare(`
        SELECT c.* 
        FROM knowledge_cards c
        JOIN knowledge_interactions i ON c.id = i.card_id
        WHERE i.staff_id = ? AND i.type = 'save'
        ORDER BY i.created_at DESC
    `).bind(staffId).all();

    return results.map(row => ({
        ...row,
        tags: row.tags ? JSON.parse(row.tags as string) : [],
        content: JSON.parse(row.content as string)
    })) as KnowledgeCard[];
}

// --- Category Management ---

export async function getKnowledgeCategories(db: D1Database) {
    const { results } = await db.prepare("SELECT * FROM knowledge_categories ORDER BY display_order ASC").all();
    return results as KnowledgeCategory[];
}

export async function toggleCategory(db: D1Database, id: string, isEnabled: boolean) {
    const now = Math.floor(Date.now() / 1000);
    return await db.prepare("UPDATE knowledge_categories SET is_enabled = ?, updated_at = ? WHERE id = ?")
        .bind(isEnabled ? 1 : 0, now, id)
        .run();
}

export async function createCategory(db: D1Database, name: string) {
    const now = Math.floor(Date.now() / 1000);
    const id = `cat-${Date.now()}`; // Simple ID generation
    // Get max order
    const maxOrder = await db.prepare("SELECT MAX(display_order) as max_order FROM knowledge_categories").first('max_order') as number || 0;

    return await db.prepare("INSERT INTO knowledge_categories (id, name, is_enabled, display_order, created_at, updated_at) VALUES (?, ?, 1, ?, ?, ?)")
        .bind(id, name, maxOrder + 1, now, now)
        .run();
}

// --- Statistics ---

export interface KnowledgeStats {
    total: number;
    byCategory: { category: string; count: number }[];
    byType: { card_type: string; count: number }[];
    byStatus: { status: string; count: number }[];
}

export async function getKnowledgeStats(db: D1Database): Promise<KnowledgeStats> {
    // Total count
    const totalResult = await db.prepare("SELECT COUNT(*) as count FROM knowledge_cards").first();
    const total = (totalResult?.count as number) || 0;

    // By category
    const { results: catResults } = await db.prepare(`
        SELECT category, COUNT(*) as count 
        FROM knowledge_cards 
        GROUP BY category 
        ORDER BY count DESC
    `).all();

    // By type
    const { results: typeResults } = await db.prepare(`
        SELECT card_type, COUNT(*) as count 
        FROM knowledge_cards 
        GROUP BY card_type 
        ORDER BY count DESC
    `).all();

    // By status
    const { results: statusResults } = await db.prepare(`
        SELECT status, COUNT(*) as count 
        FROM knowledge_cards 
        GROUP BY status 
        ORDER BY count DESC
    `).all();

    return {
        total,
        byCategory: catResults as { category: string; count: number }[],
        byType: typeResults as { card_type: string; count: number }[],
        byStatus: statusResults as { status: string; count: number }[]
    };
}

// --- Pagination with Total Count ---

export async function getKnowledgeCardsWithCount(db: D1Database, options: {
    status?: string;
    category?: string;
    search?: string;
    limit?: number;
    offset?: number;
} = {}): Promise<{ cards: KnowledgeCard[]; total: number }> {
    let whereClause = "WHERE 1=1";
    const params: any[] = [];

    if (options.search) {
        whereClause += " AND (topic LIKE ? OR content LIKE ? OR tags LIKE ?)";
        const term = `%${options.search}%`;
        params.push(term, term, term);
    }
    if (options.status) {
        whereClause += " AND status = ?";
        params.push(options.status);
    }
    if (options.category) {
        whereClause += " AND category = ?";
        params.push(options.category);
    }

    // Get total count
    const countQuery = `SELECT COUNT(*) as count FROM knowledge_cards ${whereClause}`;
    const countResult = await db.prepare(countQuery).bind(...params).first();
    const total = (countResult?.count as number) || 0;

    // Get paginated results
    let query = `SELECT * FROM knowledge_cards ${whereClause} ORDER BY created_at DESC`;
    const paginatedParams = [...params];

    if (options.limit) {
        query += " LIMIT ?";
        paginatedParams.push(options.limit);
    }
    if (options.offset) {
        query += " OFFSET ?";
        paginatedParams.push(options.offset);
    }

    const { results } = await db.prepare(query).bind(...paginatedParams).all();

    const cards = results.map(row => ({
        ...row,
        tags: row.tags ? JSON.parse(row.tags as string) : [],
        content: JSON.parse(row.content as string)
    })) as KnowledgeCard[];

    return { cards, total };
}
