
export async function findPatientByPhone(db: any, phone: string): Promise<{ id: string, type: 'returning' } | null> {
    if (!phone) return null;

    // Normalize: remove all non-digits
    const normalized = phone.replace(/[^0-9]/g, '');
    if (!normalized) return null;

    try {
        // Try strict match on normalized version
        // We assume 'current_phone' in DB might be formatted or not, 
        // so we compare normalized versions.
        const patient = await db.prepare(`
            SELECT id FROM patients 
            WHERE REPLACE(REPLACE(current_phone, '-', ''), ' ', '') = ?
        `).bind(normalized).first();

        if (patient) {
            return { id: patient.id, type: 'returning' };
        }
    } catch (e) {
        console.warn("[PatientLookup] Error looking up patient:", e);
    }
    return null;
}
