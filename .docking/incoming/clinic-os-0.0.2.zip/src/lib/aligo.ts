export interface AligoConfig {
    key: string;
    userid: string;
    sender: string;
    senderKey?: string; // For AlimTalk
    username?: string; // Legacy support? No, user_id is the key.
    baseUrl?: string;
    testmode_yn?: 'Y' | 'N';
    enabled?: boolean;
}

export interface SendMessageOptions {
    receiver: string; // Phone number (010-1234-5678)
    msg: string;      // Message content
    title?: string;   // For LMS (Long Message)
    destination?: string; // "01012345678|Name" format for variable subs
    msg_type?: 'SMS' | 'LMS' | 'MMS'; // Explicit type
}

export interface AligoResponse {
    result_code: string; // 1: Success, other: Error
    message: string;
    msg_id?: string;
    success_cnt?: number;
    error_cnt?: number;
    msg_type?: string;
}

export interface SendAlimTalkOptions {
    receiver: string;
    tpl_code: string;
    senderkey: string;
    subject_1: string; // Fallback Title
    message_1: string; // Fallback Message
    emtitle_1?: string; // AlimTalk Title (Emphasis)
    message?: string; // Only needed if template has variables, usually constructed before this function
    failover?: 'Y' | 'N';
    button_1?: string; // JSON String of buttons
}

export async function sendAlimTalk(
    config: AligoConfig,
    options: SendAlimTalkOptions
): Promise<AligoResponse> {
    // SIMULATION MODE
    if (config.key === 'TEST' || config.testmode_yn === 'Y') {
        console.log('[ALIMTALK SIMULATION]', {
            to: options.receiver,
            tpl_code: options.tpl_code,
            config: config
        });

        if (config.key === 'TEST') {
            return {
                result_code: '1',
                message: 'success',
                msg_id: 'SIMULATED_AT_' + Date.now(),
                success_cnt: 1,
                error_cnt: 0,
                msg_type: 'ALIMTALK'
            };
        }
    }

    // Use configured Base URL (Proxy) if available, otherwise direct
    // Ensure the proxy handles /akv10/ paths correctly if using proxy
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/+$/, '') + '/' : 'https://kakaoapi.aligo.in/';
    const endpoint = `${baseUrl}akv10/alimtalk/send/`; // AlimTalk Endpoint

    const formData = new FormData();
    formData.append('apikey', config.key); // AlimTalk uses 'apikey', SMS uses 'key'
    formData.append('userid', config.userid);
    formData.append('senderkey', options.senderkey);
    formData.append('tpl_code', options.tpl_code);
    formData.append('sender', config.sender);

    const cleanReceiver = options.receiver.replace(/-/g, '');
    formData.append('receiver_1', cleanReceiver);

    formData.append('failover', options.failover || 'Y');
    formData.append('subject_1', options.subject_1); // Required: AlimTalk Title
    formData.append('fsubject_1', options.subject_1); // Explicit fallback fields if supported
    formData.append('fmessage_1', options.message_1);

    formData.append('message_1', options.message || options.message_1); // The actual AlimTalk content (with variables replaced) or fallback message

    if (options.emtitle_1) {
        formData.append('emtitle_1', options.emtitle_1);
    }

    if (options.button_1) {
        formData.append('button_1', options.button_1);
    }

    if (config.testmode_yn) {
        formData.append('testmode_yn', config.testmode_yn);
    }

    // Debug logging
    console.log('[ALIMTALK SEND REQUEST]', {
        endpoint,
        tpl_code: options.tpl_code,
        receiver: cleanReceiver,
        senderkey: options.senderkey?.substring(0, 10) + '...',
        message_length: (options.message || options.message_1)?.length,
        button_1: options.button_1,
        failover: options.failover
    });

    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 60000); // 60s timeout

        const response = await fetch(endpoint, {
            method: 'POST',
            body: formData,
            signal: controller.signal
        });
        clearTimeout(timeoutId);
        const text = await response.text();

        console.log('[ALIMTALK SEND RESPONSE]', text);

        try {
            return JSON.parse(text) as AligoResponse;
        } catch (e) {
            return { result_code: '-1', message: 'Parsing Error: ' + text };
        }
    } catch (error) {
        console.error('[ALIMTALK SEND ERROR]', error);
        return {
            result_code: '-1',
            message: error instanceof Error ? error.message : 'Unknown error'
        };
    }
}

export async function sendAligoMessage(
    config: AligoConfig,
    options: SendMessageOptions
): Promise<AligoResponse> {
    // SIMULATION MODE
    if (config.key === 'TEST' || config.testmode_yn === 'Y') {
        console.log('[SMS SIMULATION]', {
            to: options.receiver,
            msg: options.msg,
            config: config
        });

        // If explicitly using "TEST" key, return success without calling API
        if (config.key === 'TEST') {
            return {
                result_code: '1',
                message: 'success',
                msg_id: 'SIMULATED_' + Date.now(),
                success_cnt: 1,
                error_cnt: 0,
                msg_type: 'SMS'
            };
        }
    }

    // Use configured base URL or default to official API
    // Ensure it ends with a slash
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/+$/, '') + '/' : 'https://apis.aligo.in/';
    const endpoint = `${baseUrl}send/`;

    const formData = new FormData();
    formData.append('key', config.key);
    formData.append('user_id', config.userid); // Spec says 'user_id'
    formData.append('sender', config.sender);

    // Clean phone number (remove dashes)
    const cleanReceiver = options.receiver.replace(/-/g, '');
    formData.append('receiver', cleanReceiver);

    formData.append('msg', options.msg);

    if (options.msg_type) {
        formData.append('msg_type', options.msg_type);
    }

    if (options.title) {
        formData.append('title', options.title);
    }
    if (options.destination) {
        formData.append('destination', options.destination);
    }

    if (config.testmode_yn) {
        formData.append('testmode_yn', config.testmode_yn);
    }

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            body: formData,
        });

        // Check if response is JSON
        const contentType = response.headers.get('content-type') || '';
        const text = await response.text();

        console.log('Aligo response status:', response.status, 'contentType:', contentType);
        console.log('Aligo response text:', text.substring(0, 300));

        // Handle empty response
        if (!text || text.trim() === '') {
            // If HTTP was OK, assume success (some proxies may not return body)
            if (response.ok) {
                return {
                    result_code: '1',
                    message: 'success (no response body)',
                    msg_type: 'SMS'
                };
            }
            return {
                result_code: '-1',
                message: `빈 응답 (HTTP ${response.status})`
            };
        }

        if (!contentType.includes('application/json') && text.startsWith('<')) {
            console.error('Aligo API returned HTML instead of JSON:', text.substring(0, 200));
            return {
                result_code: '-1',
                message: `프록시 서버 오류: HTML 응답이 반환되었습니다. 프록시 URL을 확인하세요. (${endpoint})`
            };
        }

        try {
            const data = JSON.parse(text) as AligoResponse;
            return data;
        } catch (parseError) {
            console.error('Failed to parse Aligo response:', text.substring(0, 200));
            // If HTTP was OK despite parse error, assume success
            if (response.ok) {
                return {
                    result_code: '1',
                    message: 'success (parse error but HTTP OK)',
                    msg_type: 'SMS'
                };
            }
            // Custom check for Cloudflare 1016 Error
            if (text.includes('error code: 1016')) {
                return {
                    result_code: '-1',
                    message: `Cloudflare DNS Error (1016): Cannot reach Aligo API. Hostname resolution failed.`
                };
            }

            return {
                result_code: '-1',
                message: `응답 파싱 오류: ${text.substring(0, 100)}`
            };
        }
    } catch (error) {
        console.error('Aligo SMS Send Error:', error);
        return {
            result_code: '-1',
            message: error instanceof Error ? error.message : 'Unknown error during fetch'
        };
    }
}

// Template List Interface
export interface AligoTemplate {
    templtCode: string; // Template Code
    templtName: string; // Template Name
    templtContent: string; // Template Content
    templtButtons?: string; // JSON string of buttons
    templtStatus?: string; // Legacy/Incorrect field?
    status?: string; // 'R': Registered?
    inspStatus: string; // 'APR': Approved, 'REQ': Requested, 'REJ': Rejected
    cdate: string; // Created Date
}

export interface AligoTemplateListResponse {
    code: number; // 0: success, other: error
    message: string;
    list: AligoTemplate[];
    result_code?: string; // Optional: Keep for backward compatibility or simulation
}

export async function getAligoTemplates(config: AligoConfig): Promise<AligoTemplateListResponse> {
    // SIMULATION MODE
    if (config.key === 'TEST' || config.testmode_yn === 'Y') {
        const dummyList: AligoTemplate[] = [
            { templtCode: 'TEST_001', templtName: '테스트 템플릿 1', templtContent: '테스트 메시지입니다.', inspStatus: 'APR', status: 'R', cdate: '2024-01-01' },
            { templtCode: 'TEST_002', templtName: '테스트 템플릿 2', templtContent: '예약 확정 메시지 #{이름}', inspStatus: 'APR', status: 'R', cdate: '2024-01-02' }
        ];
        return { code: 0, result_code: '1', message: 'success', list: dummyList };
    }

    // Revert to using configured Base URL (Proxy) because Aligo restricts IP access even for template list.
    // Ensure the proxy handles /akv10/ paths correctly.
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/+$/, '') + '/' : 'https://kakaoapi.aligo.in/';
    const endpoint = `${baseUrl}akv10/template/list/`;

    // Use URLSearchParams for application/x-www-form-urlencoded
    const params = new URLSearchParams();
    params.append('apikey', config.key);
    params.append('userid', config.userid);
    params.append('senderkey', config.senderKey || '');

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            body: params, // Fetch automatically sets Content-Type to application/x-www-form-urlencoded
        });

        const text = await response.text();

        // Log for debugging
        if (!text.trim().startsWith('{')) {
            console.error('Aligo Template Sync Error (Non-JSON):', text.substring(0, 500));
            // Show start of HTML to user to identify error type (404, 403, etc)
            const preview = text.substring(0, 200).replace(/\n/g, ' ').replace(/\s+/g, ' ');
            return {
                code: -1,
                result_code: '-1',
                message: `API 응답 오류 (HTML): ${preview} (URL: ${endpoint})`,
                list: []
            };
        }

        const result = JSON.parse(text) as AligoTemplateListResponse;

        // Aligo API returns code 0 for success
        if (result.code !== 0) {
            return {
                code: result.code,
                result_code: String(result.code),
                message: result.message || '알리고 API 오류',
                list: []
            };
        }

        return result;
    } catch (error) {
        return {
            code: -1,
            result_code: '-1',
            message: error instanceof Error ? error.message : 'Unknown error',
            list: []
        };
    }
}

// Helper to get config from DB or Env
export async function getAligoConfig(env: any, db: any) {
    let config: AligoConfig = {
        key: env?.ALIGO_API_KEY,
        userid: env?.ALIGO_USER_ID,
        sender: env?.ALIGO_SENDER,
        senderKey: env?.ALIGO_SENDER_KEY,
        baseUrl: env?.ALIGO_BASE_URL,
        testmode_yn: (env?.ALIGO_TESTMODE || 'N') as 'Y' | 'N'  // Default to N (real mode)
    };

    // Try DB override
    try {
        if (db) {
            const result = await db.prepare("SELECT integrations FROM clinics WHERE id = 1").first();
            if (result?.integrations) {
                const integrations = JSON.parse(result.integrations);
                if (integrations.aligo && integrations.aligo.enabled) {
                    config.key = integrations.aligo.apiKey || config.key;
                    config.userid = integrations.aligo.userId || config.userid;
                    config.sender = integrations.aligo.sender || config.sender;
                    config.senderKey = integrations.aligo.senderKey || config.senderKey;
                    config.baseUrl = integrations.aligo.baseUrl || config.baseUrl;
                    config.testmode_yn = integrations.aligo.testmode_yn || 'N';  // Default to real mode
                    config.enabled = true;
                } else if (integrations.aligo && integrations.aligo.enabled === false) {
                    config.enabled = false;
                }
            }
        }
    } catch (e) {
        console.error('Failed to load Aligo config from DB, using Env', e);
    }

    if (!config.key || !config.userid || !config.sender) {
        return null;
    }

    // Default enabled to true if we have keys (Env vars case) and wasn't explicitly disabled by DB
    if (config.enabled === undefined) {
        config.enabled = true;
    }

    return config;
}

// AlimTalk History Interface
export interface AlimTalkHistoryParams {
    page: number;
    limit: number;
    start_date?: string; // YYYYMMDD
    end_date?: string;   // YYYYMMDD
}

export async function getAlimTalkHistory(config: AligoConfig, params: AlimTalkHistoryParams) {
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/+$/, '') + '/' : 'https://kakaoapi.aligo.in/';
    const endpoint = `${baseUrl}akv10/history/list/`;

    const formData = new FormData();
    formData.append('apikey', config.key);
    formData.append('userid', config.userid);
    formData.append('senderkey', config.senderKey || '');
    formData.append('page', String(params.page));
    formData.append('limit', String(params.limit));

    if (params.start_date) formData.append('start_date', params.start_date);
    if (params.end_date) formData.append('end_date', params.end_date);

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            body: formData,
        });
        return await response.json();
    } catch (error) {
        return { code: -1, message: error instanceof Error ? error.message : 'Unknown Error' };
    }
}

export async function getAlimTalkDetail(config: AligoConfig, mid: string) {
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/+$/, '') + '/' : 'https://kakaoapi.aligo.in/';
    const endpoint = `${baseUrl}akv10/history/detail/`;

    const formData = new FormData();
    formData.append('apikey', config.key);
    formData.append('userid', config.userid);
    formData.append('mid', mid);

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            body: formData,
        });
        return await response.json();
    } catch (error) {
        return { code: -1, message: error instanceof Error ? error.message : 'Unknown Error' };
    }
}

// Template Management Interfaces
export interface AligoTemplateParams {
    tpl_name: string;
    tpl_content: string;
    tpl_code?: string; // Required for modify
    tpl_button?: string; // JSON string
    tpl_type?: string; // BA, EX, AD, MI
    tpl_emtype?: string; // NONE, TEXT, IMAGE
    image?: File; // Not supported in this simplified implementation yet
}

export interface AligoTemplateResponse {
    code: number;
    message: string;
    data?: {
        senderKey: string;
        templtContent: string;
        templtName: string;
        templtCode: string;
        status: string;
        inspStatus: string;
        buttons?: any[];
    };
}

// 1. Add Template
export async function addAlimTalkTemplate(config: AligoConfig, params: AligoTemplateParams): Promise<AligoTemplateResponse> {
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/+$/, '') + '/' : 'https://kakaoapi.aligo.in/';
    const endpoint = `${baseUrl}akv10/template/add/`;

    const formData = new FormData();
    formData.append('apikey', config.key);
    formData.append('userid', config.userid);
    formData.append('senderkey', config.senderKey || '');
    formData.append('tpl_name', params.tpl_name);
    formData.append('tpl_content', params.tpl_content);

    if (params.tpl_button) formData.append('tpl_button', params.tpl_button);

    // Default to BA/NONE to avoid errors if not specified
    // formData.append('tpl_type', params.tpl_type || 'BA');
    // formData.append('tpl_emtype', params.tpl_emtype || 'NONE');

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            body: formData,
        });
        return await response.json();
    } catch (error) {
        return { code: -1, message: error instanceof Error ? error.message : 'Unknown Error' };
    }
}

// 2. Modify Template
export async function modifyAlimTalkTemplate(config: AligoConfig, params: AligoTemplateParams): Promise<AligoTemplateResponse> {
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/+$/, '') + '/' : 'https://kakaoapi.aligo.in/';
    const endpoint = `${baseUrl}akv10/template/modify/`;

    const formData = new FormData();
    formData.append('apikey', config.key);
    formData.append('userid', config.userid);
    formData.append('senderkey', config.senderKey || '');
    formData.append('tpl_code', params.tpl_code || '');
    formData.append('tpl_name', params.tpl_name);
    formData.append('tpl_content', params.tpl_content);

    if (params.tpl_button) formData.append('tpl_button', params.tpl_button);

    try {
        const response = await fetch(endpoint, { method: 'POST', body: formData });
        return await response.json();
    } catch (error) {
        return { code: -1, message: error instanceof Error ? error.message : 'Unknown Error' };
    }
}

// 3. Delete Template
export async function deleteAlimTalkTemplate(config: AligoConfig, tpl_code: string) {
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/+$/, '') + '/' : 'https://kakaoapi.aligo.in/';
    const endpoint = `${baseUrl}akv10/template/del/`;

    const formData = new FormData();
    formData.append('apikey', config.key);
    formData.append('userid', config.userid);
    formData.append('senderkey', config.senderKey || '');
    formData.append('tpl_code', tpl_code);

    try {
        const response = await fetch(endpoint, { method: 'POST', body: formData });
        return await response.json();
    } catch (error) {
        return { code: -1, message: error instanceof Error ? error.message : 'Unknown Error' };
    }
}

// 4. Request Inspection
export async function requestAlimTalkTemplate(config: AligoConfig, tpl_code: string) {
    const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/+$/, '') + '/' : 'https://kakaoapi.aligo.in/';
    const endpoint = `${baseUrl}akv10/template/request/`;

    const formData = new FormData();
    formData.append('apikey', config.key);
    formData.append('userid', config.userid);
    formData.append('senderkey', config.senderKey || '');
    formData.append('tpl_code', tpl_code);

    try {
        const response = await fetch(endpoint, { method: 'POST', body: formData });
        return await response.json();
    } catch (error) {
        return { code: -1, message: error instanceof Error ? error.message : 'Unknown Error' };
    }
}

// Helper: Convert Variables
export function convertVariablesToAligoFormat(content: string): string {
    // Replace {variable} with #{variable}
    // Careful not to replace existing #{variable} (which would become ##{variable})
    // Regex: Match `{` that is NOT preceded by `#`
    return content.replace(/(?<!#)\{([^}]+)\}/g, '#{$1}');
}
