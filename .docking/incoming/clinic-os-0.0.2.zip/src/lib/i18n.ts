/**
 * i18n (Internationalization) Library
 * 다국어 시스템 핵심 유틸리티
 */

// =====================================================
// 타입 및 상수 정의
// =====================================================

export const SUPPORTED_LOCALES = ['ko', 'en', 'ja', 'zh-hans', 'vi'] as const;
export type Locale = typeof SUPPORTED_LOCALES[number];
export const DEFAULT_LOCALE: Locale = 'ko';

/**
 * Convert literal \n strings and actual newlines to HTML <br/> tags
 * Handles: \\n (literal), \n (actual newline), multiple consecutive newlines
 */
export function processNewlines(text: string | undefined | null): string {
    if (!text) return '';
    return text
        .replace(/\\n/g, '<br/>')  // literal backslash-n
        .replace(/\n/g, '<br/>');  // actual newline character
}

export const LOCALE_NAMES: Record<Locale, string> = {
    'ko': '한국어',
    'en': 'English',
    'ja': '日本語',
    'zh-hans': '简体中文',
    'vi': 'Tiếng Việt'
};

export const LOCALE_FLAGS: Record<Locale, string> = {
    'ko': '🇰🇷',
    'en': '🇺🇸',
    'ja': '🇯🇵',
    'zh-hans': '🇨🇳',
    'vi': '🇻🇳'
};

// hreflang에 사용되는 ISO 코드
export const HREFLANG_CODES: Record<Locale, string> = {
    'ko': 'ko',
    'en': 'en',
    'ja': 'ja',
    'zh-hans': 'zh-Hans',
    'vi': 'vi'
};

// 번역 상태
export type TranslationStatus = 'pending' | 'draft' | 'in_progress' | 'review' | 'published';

export const TRANSLATION_STATUS_LABELS: Record<TranslationStatus, Record<Locale, string>> = {
    'pending': { ko: '대기', en: 'Pending', ja: '保留中', 'zh-hans': '待处理', vi: 'Chờ xử lý' },
    'draft': { ko: '초안', en: 'Draft', ja: '下書き', 'zh-hans': '草稿', vi: 'Bản nháp' },
    'in_progress': { ko: '진행중', en: 'In Progress', ja: '進行中', 'zh-hans': '进行中', vi: 'Đang xử lý' },
    'review': { ko: '검토중', en: 'Review', ja: 'レビュー中', 'zh-hans': '审核中', vi: 'Đang duyệt' },
    'published': { ko: '게시됨', en: 'Published', ja: '公開済み', 'zh-hans': '已发布', vi: 'Đã xuất bản' }
};

// =====================================================
// 동적 언어 관리 (DB 기반)
// =====================================================

export interface SupportedLocale {
    code: string;
    name: string;
    native_name: string;
    flag: string;
    is_active: boolean;
    sort_order: number;
}

/**
 * Get all supported locales from database (including inactive)
 * Falls back to static SUPPORTED_LOCALES if DB unavailable
 */
export async function getSupportedLocales(db: any): Promise<SupportedLocale[]> {
    if (!db) {
        return SUPPORTED_LOCALES.map(code => ({
            code,
            name: LOCALE_NAMES[code],
            native_name: LOCALE_NAMES[code],
            flag: LOCALE_FLAGS[code],
            is_active: true,
            sort_order: SUPPORTED_LOCALES.indexOf(code)
        }));
    }

    try {
        const { results } = await db.prepare(
            "SELECT * FROM supported_locales ORDER BY sort_order ASC"
        ).all();
        return (results || []).map((r: any) => ({
            ...r,
            is_active: r.is_active === 1
        }));
    } catch (e) {
        console.error('Failed to fetch supported_locales:', e);
        return SUPPORTED_LOCALES.map(code => ({
            code,
            name: LOCALE_NAMES[code],
            native_name: LOCALE_NAMES[code],
            flag: LOCALE_FLAGS[code],
            is_active: true,
            sort_order: SUPPORTED_LOCALES.indexOf(code)
        }));
    }
}

/**
 * Get only active locales (for public-facing pages)
 */
export async function getActiveLocales(db: any): Promise<SupportedLocale[]> {
    const all = await getSupportedLocales(db);
    return all.filter(l => l.is_active);
}

/**
 * Get only non-default locales for translation UI
 */
export async function getTargetLocales(db: any, includeInactive = true): Promise<SupportedLocale[]> {
    const all = includeInactive
        ? await getSupportedLocales(db)
        : await getActiveLocales(db);
    return all.filter(l => l.code !== DEFAULT_LOCALE);
}

// UI Translations for components (Navbar, Footer, etc.)
// Note: Not all locales need entries - getUIText() falls back to Korean
export const UI_TRANSLATIONS: Record<string, Partial<Record<Locale, string>>> = {
    // Navbar - Main Menu
    'nav.aboutClinic': { ko: '병원 소개', en: 'About Us', ja: 'クリニック紹介', 'zh-hans': '诊所介绍', vi: 'Giới Thiệu' },
    'nav.doctors': { ko: '의료진 소개', en: 'Our Doctors', ja: '医師紹介', 'zh-hans': '医生团队', vi: 'Bác Sĩ' },
    'nav.location': { ko: '오시는 길', en: 'Location', ja: 'アクセス', 'zh-hans': '位置', vi: 'Đường Đi' },
    'nav.notices': { ko: '병원 공지', en: 'Notices', ja: 'お知らせ', 'zh-hans': '公告', vi: 'Thông Báo' },
    'nav.programs': { ko: '진료 과목', en: 'Treatments', ja: '診療科目', 'zh-hans': '诊疗项目', vi: 'Chương Trình' },
    'nav.viewAll': { ko: '전체 보기', en: 'View All', ja: 'すべて見る', 'zh-hans': '查看全部', vi: 'Xem Tất Cả' },
    'nav.telemedicine': { ko: '비대면 진료', en: 'Telemedicine', ja: 'オンライン診療', 'zh-hans': '远程医疗', vi: 'Khám Từ Xa' },
    'nav.selfDiagnosis': { ko: '자가진단', en: 'Self-Diagnosis', ja: '自己診断', 'zh-hans': '自我诊断', vi: 'Tự Chẩn Đoán' },
    'nav.community': { ko: '커뮤니티', en: 'Community', ja: 'コミュニティ', 'zh-hans': '社区', vi: 'Cộng Đồng' },
    'nav.reviews': { ko: '치료후기', en: 'Reviews', ja: '治療後記', 'zh-hans': '治疗评价', vi: 'Đánh Giá' },
    'nav.blog': { ko: '건강칼럼', en: 'Health Blog', ja: '健康コラム', 'zh-hans': '健康专栏', vi: 'Blog Sức Khỏe' },
    'nav.guides': { ko: '건강가이드', en: 'Health Guides', ja: '健康ガイド', 'zh-hans': '健康指南', vi: 'Hướng Dẫn' },
    'nav.booking': { ko: '진료 예약', en: 'Book Appointment', ja: '予約する', 'zh-hans': '预约诊疗', vi: 'Đặt Lịch' },
    'nav.healthGuide': { ko: '건강가이드', en: 'Health Guides', ja: '健康ガイド', 'zh-hans': '健康指南', vi: 'Hướng Dẫn' },
    'nav.viewAllPrograms': { ko: '프로그램 전체 보기', en: 'View All Programs', ja: 'すべてのプログラムを見る', 'zh-hans': '查看所有项目', vi: 'Xem Tất Cả' },
    'nav.telemedicineGuide': { ko: '비대면 진료 안내', en: 'Telemedicine Info', ja: 'オンライン診療案内', 'zh-hans': '远程医疗指南', vi: 'Thông Tin Khám Từ Xa' },
    'nav.bookAppointment': { ko: '진료 예약하기', en: 'Book Appointment', ja: '今すぐ予約', 'zh-hans': '立即预约', vi: 'Đặt Lịch Ngay' },

    // Hero Section
    'hero.telemedicineCta': { ko: '전국 어디서나 비대면 진료', en: 'Telemedicine Nationwide', ja: '全国どこでもオンライン診療', 'zh-hans': '全国远程诊疗', vi: 'Khám Từ Xa Toàn Quốc' },

    // Footer
    'footer.hours': { ko: '진료 시간', en: 'Office Hours', ja: '診療時間', 'zh-hans': '营业时间', vi: 'Giờ Làm Việc' },
    'footer.weekdays': { ko: '평일', en: 'Weekdays', ja: '平日', 'zh-hans': '工作日', vi: 'Ngày Thường' },
    'footer.saturday': { ko: '토요일', en: 'Saturday', ja: '土曜日', 'zh-hans': '周六', vi: 'Thứ Bảy' },
    'footer.lunch': { ko: '점심시간', en: 'Lunch', ja: '昼休み', 'zh-hans': '午休', vi: 'Nghỉ Trưa' },
    'footer.quickLinks': { ko: '바로가기', en: 'Quick Links', ja: 'クイックリンク', 'zh-hans': '快捷链接', vi: 'Liên Kết Nhanh' },
    'footer.terms': { ko: '이용약관', en: 'Terms of Service', ja: '利用規約', 'zh-hans': '服务条款', vi: 'Điều Khoản' },
    'footer.privacy': { ko: '개인정보처리방침', en: 'Privacy Policy', ja: 'プライバシーポリシー', 'zh-hans': '隐私政策', vi: 'Chính Sách Bảo Mật' },
    'footer.businessName': { ko: '상호', en: 'Business Name', ja: '商号', 'zh-hans': '商号', vi: 'Tên Doanh Nghiệp' },
    'footer.representative': { ko: '대표', en: 'Representative', ja: '代表', 'zh-hans': '代表', vi: 'Đại Diện' },
    'footer.phone': { ko: '전화', en: 'Phone', ja: '電話', 'zh-hans': '电话', vi: 'Điện Thoại' },
    'footer.address': { ko: '주소', en: 'Address', ja: '住所', 'zh-hans': '地址', vi: 'Địa Chỉ' },
    'footer.businessLicense': { ko: '사업자등록번호', en: 'Business License', ja: '事業者登録番号', 'zh-hans': '营业执照号', vi: 'Số ĐKKD' },
    'footer.refundPolicy': { ko: '환불/취소 안내', en: 'Refund Policy', ja: '返金/キャンセルポリシー', 'zh-hans': '退款/取消政策', vi: 'Chính Sách Hoàn Tiền' },

    // Mobile Menu
    'menu.title': { ko: '메뉴', en: 'Menu', ja: 'メニュー', 'zh-hans': '菜单', vi: 'Menu' },
    'menu.allPrograms': { ko: '프로그램 전체 보기', en: 'View All Programs', ja: 'すべてのプログラムを見る', 'zh-hans': '查看所有项目', vi: 'Xem Tất Cả' },
    'menu.telemedicineInfo': { ko: '비대면 진료 안내', en: 'Telemedicine Info', ja: 'オンライン診療案内', 'zh-hans': '远程医疗指南', vi: 'Thông Tin Khám Từ Xa' },
    'menu.selfDiagnosis': { ko: '내 증상 자가진단', en: 'Self-Diagnose Symptoms', ja: '症状セルフチェック', 'zh-hans': '自我症状诊断', vi: 'Tự Chẩn Đoán' },

    // Common
    'common.bookNow': { ko: '진료 예약하기', en: 'Book Now', ja: '今すぐ予約', 'zh-hans': '立即预约', vi: 'Đặt Lịch Ngay' },
    'common.apply': { ko: '신청하기', en: 'Apply Now', ja: '申し込む', 'zh-hans': '立即申请', vi: 'Đăng Ký' },
    'common.consult': { ko: '상담 신청하기', en: 'Request Consultation', ja: '相談を申し込む', 'zh-hans': '咨询预约', vi: 'Tư Vấn' },
    'common.checkNow': { ko: '확인하세요', en: 'Check Now', ja: '今すぐ確認', 'zh-hans': '立即查看', vi: 'Xem Ngay' },
    'common.viewMore': { ko: '더보기', en: 'View More', ja: 'もっと見る', 'zh-hans': '查看更多', vi: 'Xem Thêm' },
    'common.loginToView': { ko: '로그인하고 온전히 보기', en: 'Login to view full content', ja: 'ログインして全て見る', 'zh-hans': '登录查看全部', vi: 'Đăng nhập để xem' },
    'common.viewMoreQuestions': { ko: '더 많은 질문 보기', en: 'View More Questions', ja: 'もっと質問を見る', 'zh-hans': '查看更多问题', vi: 'Xem Thêm Câu Hỏi' },
    'common.closed': { ko: '휴진', en: 'Closed', ja: '休診', 'zh-hans': '休诊', vi: 'Đóng Cửa' },
    'common.weekendClosed': { ko: '주말/공휴일 휴진', en: 'Closed on weekends/holidays', ja: '週末・祈日休診', 'zh-hans': '周末/节假日休诊', vi: 'Nghỉ Cuối Tuần/Lễ' },
    'common.column': { ko: '칼럼', en: 'Column', ja: 'コラム', 'zh-hans': '专栏', vi: 'Chuyên Mục' },
    'common.blog': { ko: '블로그', en: 'Blog', ja: 'ブログ', 'zh-hans': '博客', vi: 'Blog' },

    // Telemedicine Card
    'telemedicine.processTitle': { ko: '비대면 진료 프로세스', en: 'Telemedicine Process', ja: 'オンライン診療プロセス', 'zh-hans': '远程诊疗流程', vi: 'Quy Trình Khám Từ Xa' },
    'telemedicine.processDesc': { ko: '내원하지 않아도 진료와 처방이 가능합니다.<br/>간편하게 상담받아보세요.', en: 'Get consultations and prescriptions without visiting.<br/>Try our easy consultation service.', ja: '来院なしで診察・処方が可能です。<br/>お気軽にご相談ください。', 'zh-hans': '无需到院即可诊疗和开处方。<br/>欢迎轻松咨询。', vi: 'Nhận tư vấn và đơn thuốc mà không cần đến.<br/>Thử dịch vụ tư vấn tiện lợi.' },
    'telemedicine.learnMore': { ko: '비대면 진료 자세히 보기', en: 'Learn More About Telemedicine', ja: 'オンライン診療の詳細', 'zh-hans': '了解更多远程诊疗', vi: 'Tìm Hiểu Thêm Về Khám Từ Xa' },

    // Contact Card
    'contact.inquiryTitle': { ko: '진료 문의', en: 'Contact Us', ja: '診療お問い合わせ', 'zh-hans': '诊疗咨询' },
    'contact.inquiryDesc': { ko: '궁금한 점이 있으신가요?<br/>친절하게 안내해 드리겠습니다.', en: 'Have questions?<br/>We\'re here to help.', ja: 'ご不明な点はございますか？<br/>丁寧にご案内いたします。', 'zh-hans': '有疑问吗？<br/>我们竭诚为您服务。' },
    'contact.callUs': { ko: '전화 상담하기', en: 'Call Us', ja: '電話で相談', 'zh-hans': '电话咨询' },

    // Pricing
    'pricing.disclaimer': { ko: '* 개인의 처방에 따라 복용량과 가격은 달라질 수 있습니다.', en: '* Dosage and pricing may vary based on individual prescription.', ja: '* 処方により用量と価格は異なる場合があります。', 'zh-hans': '* 剂量和价格可能因个人处方而异。' },

    // Doctors
    'doctor.medicalTeam': { ko: '담당 의료진', en: 'Medical Team', ja: '担当医師', 'zh-hans': '医疗团队', vi: 'Đội Ngũ Y Tế' },
    'doctor.chiefDirector': { ko: '대표원장', en: 'Chief Director', ja: '院長', 'zh-hans': '院长', vi: 'Bác Sĩ Trưởng' },
    'doctor.viewProfile': { ko: '의료진 소개 더보기', en: 'View Doctor Profile', ja: '医師紹介を見る', 'zh-hans': '查看医生简介', vi: 'Xem Hồ Sơ' },
    'doctor.koreanMedicine': { ko: '한의사', en: 'Doctor of Korean Medicine', ja: '韓医師', 'zh-hans': '韩医师', vi: 'Bác Sĩ Đông Y' },
    'doctor.introduction': { ko: '의료진 소개', en: 'Doctor Introduction', ja: '医師紹介', 'zh-hans': '医生介绍', vi: 'Giới Thiệu Bác Sĩ' },
    'doctor.education': { ko: '학력', en: 'Education', ja: '学歴', 'zh-hans': '学历', vi: 'Học Vấn' },
    'doctor.career': { ko: '경력', en: 'Career', ja: '経歴', 'zh-hans': '经历', vi: 'Kinh Nghiệm' },
    'doctor.bio': { ko: '소개글', en: 'Biography', ja: '自己紹介', 'zh-hans': '简介', vi: 'Tiểu Sử' },
    'doctor.assignedPrograms': { ko: '담당 클리닉', en: 'Assigned Programs', ja: '担当クリニック', 'zh-hans': '负责项目', vi: 'Chương Trình Phụ Trách' },
    'doctor.recentPosts': { ko: '최근 작성한 칼럼', en: 'Recent Posts', ja: '最近の投稿', 'zh-hans': '最近发布的文章', vi: 'Bài Viết Gần Đây' },
    // MiniDiagnosis
    'diagnosis.title': { ko: '비대면 다이어트 미니 진단', en: 'Diet Self-Check Quiz', ja: 'ダイエット簡易診断', 'zh-hans': '减肥自查问卷' },
    'diagnosis.question1': { ko: '최근 3개월 동안 체중 변화가 어느 정도 있었나요?', en: 'How much has your weight changed in the last 3 months?', ja: '過去3ヶ月で体重はどのくらい変化しましたか？', 'zh-hans': '过去3个月您的体重变化了多少？' },
    'diagnosis.noChange': { ko: '거의 변화 없음 (±1kg 이내)', en: 'Almost no change (within ±1kg)', ja: 'ほとんど変化なし（±1kg以内）', 'zh-hans': '几乎没有变化（±1公斤以内）' },
    'diagnosis.gain1to3': { ko: '1~3kg 증가', en: 'Gained 1-3kg', ja: '1〜3kg増加', 'zh-hans': '增加1-3公斤' },
    'diagnosis.gain3to5': { ko: '3~5kg 증가', en: 'Gained 3-5kg', ja: '3〜5kg増加', 'zh-hans': '增加3-5公斤' },
    'diagnosis.gain5plus': { ko: '5kg 이상 증가', en: 'Gained more than 5kg', ja: '5kg以上増加', 'zh-hans': '增加5公斤以上' },

    // Reviews
    'reviews.loginPrompt': { ko: '로그인하고 후기를 온전히 확인하세요', en: 'Login to view full reviews', ja: 'ログインしてレビューを確認', 'zh-hans': '登录查看完整评价' },

    // Intake Form
    'intake.title': { ko: '진료 예약/문의', en: 'Book Appointment', ja: '診療予約', 'zh-hans': '预约/咨询', vi: 'Đặt Lịch Hẹn' },
    'intake.step1.title': { ko: '어떤 진료를<br/>원하시나요?', en: 'What type of<br/>consultation?', ja: 'ご希望の<br/>診療は？', 'zh-hans': '您需要什么<br/>类型的诊疗？', vi: 'Bạn cần loại<br/>tư vấn nào?' },
    'intake.diet': { ko: '비대면 다이어트', en: 'Telemedicine Diet', ja: 'オンラインダイエット', 'zh-hans': '远程减肥', vi: 'Giảm Cân Từ Xa' },
    'intake.dietDesc': { ko: '집에서 편하게 처방받는 감비정', en: 'Prescription diet herbal medicine from home', ja: '自宅でお手軽に処方を受けられます', 'zh-hans': '在家轻松获取处方', vi: 'Thuốc thảo dược giảm cân tại nhà' },
    'intake.general': { ko: '고질적 만성질환 / 통증', en: 'Chronic Conditions / Pain', ja: '慢性疾患・痛み', 'zh-hans': '慢性疾病/疼痛', vi: 'Bệnh Mãn Tính / Đau' },
    'intake.generalDesc': { ko: '소화기, 피부, 통증 등 집중 치료', en: 'Digestive, skin, pain treatment', ja: '消化器・皮膚・痛みなどの集中治療', 'zh-hans': '消化、皮肤、疼痛等综合治疗', vi: 'Điều trị tiêu hóa, da, đau' },
    'intake.step15.title': { ko: '진료 방식을<br/>선택해주세요.', en: 'Select consultation<br/>method', ja: '診療方法を<br/>選択してください', 'zh-hans': '请选择<br/>诊疗方式', vi: 'Chọn phương thức<br/>tư vấn' },
    'intake.inPerson': { ko: '내원 진료', en: 'In-person Visit', ja: '来院診療', 'zh-hans': '到院就诊', vi: 'Đến Phòng Khám' },
    'intake.inPersonDesc': { ko: '한의원에 직접 방문하여 진료', en: 'Visit the clinic in person', ja: 'クリニックでの診療', 'zh-hans': '亲自到诊所就诊', vi: 'Đến phòng khám trực tiếp' },
    'intake.telemedicine': { ko: '비대면 진료', en: 'Telemedicine', ja: 'オンライン診療', 'zh-hans': '远程诊疗', vi: 'Khám Từ Xa' },
    'intake.telemedicineDesc': { ko: '전화/화상 상담 후 약 배송', en: 'Phone/video call, medicine delivery', ja: '電話・ビデオ相談後、薬配送', 'zh-hans': '电话/视频问诊后送药', vi: 'Gọi điện/video, giao thuốc' },
    'intake.step2.title': { ko: '방문하신 적이<br/>있으신가요?', en: 'Have you visited<br/>before?', ja: 'ご来院<br/>経験は？', 'zh-hans': '您以前<br/>来过吗？' },
    'intake.newPatient': { ko: '처음입니다 (초진)', en: 'First visit (New patient)', ja: '初めてです（初診）', 'zh-hans': '第一次（初诊）' },
    'intake.newPatientDesc': { ko: '우리 한의원이 처음이신가요?', en: 'Is this your first visit to our clinic?', ja: '初めてのご来院ですか？', 'zh-hans': '第一次来我们诊所？' },
    'intake.returning': { ko: '재진입니다', en: 'Returning patient', ja: '再診です', 'zh-hans': '复诊' },
    'intake.returningDesc': { ko: '이전에 진료받은 적이 있습니다', en: 'I have visited before', ja: '以前診療を受けたことがあります', 'zh-hans': '我以前来过' },
    'intake.step3.title': { ko: '성함이<br/>어떻게 되시나요?', en: 'What is<br/>your name?', ja: 'お名前を<br/>教えてください', 'zh-hans': '请问<br/>您的姓名？' },
    'intake.namePlaceholder': { ko: '홍길동', en: 'John Doe', ja: '山田太郎', 'zh-hans': '张三' },
    'intake.step4.title': { ko: '연락처를<br/>입력해 주세요.', en: 'Enter your<br/>phone number', ja: '連絡先を<br/>入力してください', 'zh-hans': '请输入<br/>您的联系电话' },
    'intake.phonePlaceholder': { ko: '010-0000-0000', en: '+82-10-1234-5678', ja: '010-0000-0000', 'zh-hans': '+82-10-1234-5678' },
    'intake.step5.title': { ko: '궁금하신 점이나<br/>증상을 남겨주세요.', en: 'Describe your<br/>symptoms or questions', ja: 'ご質問や<br/>症状をお書きください', 'zh-hans': '请描述您的<br/>症状或问题' },
    'intake.step5.subtitle': { ko: '간단히 적어주셔도 됩니다.', en: 'A brief description is fine.', ja: '簡単にお書きください。', 'zh-hans': '简单描述即可。' },
    'intake.messagePlaceholder': { ko: '예: 다이어트 약 처방 받고 싶어요.', en: 'e.g., I would like to get diet prescription.', ja: '例：ダイエット薬の処方を希望します。', 'zh-hans': '例：我想要减肥药处方。' },
    'intake.privacyConsent': { ko: '[필수] 개인정보 수집 및 이용에 동의합니다.', en: '[Required] I agree to the collection and use of personal information.', ja: '【必須】個人情報の収集・利用に同意します。', 'zh-hans': '[必填] 我同意个人信息的收集和使用。' },
    'intake.prev': { ko: '이전', en: 'Back', ja: '戻る', 'zh-hans': '返回' },
    'intake.next': { ko: '다음', en: 'Next', ja: '次へ', 'zh-hans': '下一步' },
    'intake.submit': { ko: '문의하기', en: 'Submit', ja: '送信', 'zh-hans': '提交' },
    'intake.processing': { ko: '처리중...', en: 'Processing...', ja: '処理中...', 'zh-hans': '处理中...' },
    'intake.error': { ko: '접수 중 오류가 발생했습니다.', en: 'An error occurred while submitting.', ja: '送信中にエラーが発生しました。', 'zh-hans': '提交时发生错误。' },
    'intake.serverError': { ko: '서버 통신 오류가 발생했습니다.', en: 'Server communication error.', ja: 'サーバーエラーが発生しました。', 'zh-hans': '服务器通信错误。' },

    // Telemedicine Page
    'telemed.title': { ko: '비대면 진료 신청', en: 'Telemedicine Request', ja: 'オンライン診療申し込み', 'zh-hans': '远程诊疗申请' },
    'telemed.hero.tag': { ko: '비대면 진료 서비스', en: 'Telemedicine Service', ja: 'オンライン診療サービス', 'zh-hans': '远程诊疗服务' },
    'telemed.hero.title': { ko: '고질적인 만성질환,<br/><span class="text-accent">거리와 시간의 제약 없이</span> 치료합니다.', en: 'Chronic Diseases,<br/><span class="text-accent">Treat without distance or time limits.</span>', ja: '慢性疾患、<br/><span class="text-accent">距離と時間の制約なく</span>治療します。', 'zh-hans': '慢性及疑难杂症，<br/><span class="text-accent">打破距离与时间的限制</span>进行治疗。' },
    'telemed.hero.desc': { ko: '비대면 진료는 단순한 약 처방이 아닙니다.<br/>심도 있는 문진과 상담을 통해 발병 원인을 파악하고,<br/>체계적인 치료 계획을 수립합니다.', en: 'Our telemedicine is not just about prescribing medicine.<br/>We identify the root cause through in-depth consultation<br/>and establish a systematic treatment plan.', ja: 'オンライン診療は単なる薬の処方ではありません。<br/>詳細な問診と相談を通じて原因を把握し、<br/>体系的な治療計画を立てます。', 'zh-hans': '我们的远程诊疗不仅仅是开药。<br/>通过深入的问诊和咨询查明病因，<br/>并制定系统的治疗计划。' },
    'telemed.principles.title': { ko: '🏥 내원 진료가 원칙이지만', en: '🏥 In-person visit is standard', ja: '🏥 来院診療が原則ですが', 'zh-hans': '🏥 虽然原则上建议到院就诊' },
    'telemed.principles.desc': { ko: '직접 보고 듣고 진맥하는 것이 가장 정확합니다.<br/>가능하시다면 내원을 권장드립니다.', en: 'Direct examination is most accurate.<br/>We recommend visiting if possible.', ja: '直接診察するのが最も正確です。<br/>可能であれば来院をお勧めします。', 'zh-hans': '当面诊察最为准确。<br/>如果可能，建议您亲自到院。' },
    'telemed.cases.title': { ko: '📱 이런 경우 비대면으로', en: '📱 In these cases, try remote', ja: '📱 このような場合はオンラインで', 'zh-hans': '📱 以下情况可选择远程' },
    'telemed.cases.1': { ko: '거리가 멀어 내원이 힘드신 분', en: 'Too far to visit', ja: '遠方で来院が難しい方', 'zh-hans': '距离太远无法到院' },
    'telemed.cases.2': { ko: '거동이 불편하거나 시간이 부족하신 분', en: 'Mobility issues or busy schedule', ja: '移動が困難または忙しい方', 'zh-hans': '行动不便或时间紧迫' },
    'telemed.cases.3': { ko: '지속적인 관리가 필요한 만성질환', en: 'Chronic conditions needing care', ja: '継続的な管理が必要な慢性疾患', 'zh-hans': '需要持续管理的慢性病' },
    'telemed.target.title': { ko: '비대면으로도 충분히 치료 가능합니다', en: 'Effective Treatment Remotely', ja: 'オンラインでも十分治療可能です', 'zh-hans': '远程也能通过充分治疗' },
    'telemed.target.sub': { ko: '증상이 명확하고, 꾸준한 관리가 중요한 질환들입니다.', en: 'Conditions with clear symptoms needing steady care.', ja: '症状が明確で、着実な管理が重要な疾患です。', 'zh-hans': '针对症状明确且需要持续管理的疾病。' },
    'telemed.process.title': { ko: '신청부터 처방까지,<br/><span class="text-accent">체계적인 프로세스</span>', en: 'From Request to Prescription,<br/><span class="text-accent">Systematic Process</span>', ja: '申し込みから処方まで、<br/><span class="text-accent">体系的なプロセス</span>', 'zh-hans': '从申请到处方，<br/><span class="text-accent">系统的流程</span>' },
    'telemed.process.desc': { ko: '단순히 증상만 듣고 처방하지 않습니다.<br/>사전 문진표와 심층 상담을 통해<br/>환자분의 상태를 면밀히 파악합니다.', en: 'We analyze your condition deeply<br/>through preliminary questionnaires<br/>and in-depth consultations.', ja: '詳細な問診と深い相談を通じて<br/>患者の状態を綿密に把握します。', 'zh-hans': '我们通过预诊问卷和深入咨询，<br/>仔细了解患者的状况。' },
    'telemed.btn.apply': { ko: '비대면 진료 신청하기', en: 'Request Telemedicine', ja: 'オンライン診療を申し込む', 'zh-hans': '申请远程诊疗' },
    'telemed.btn.note': { ko: "* 신청서 작성 시 '비대면 진료'를 선택해주세요.", en: "* Please select 'Telemedicine' in the form.", ja: "* フォームで「オンライン診療」を選択してください。", 'zh-hans': "* 请在表格中选择“远程诊疗”。" },
    'telemed.step.1': { ko: '진료 신청', en: 'Request', ja: '申し込み', 'zh-hans': '申请' },
    'telemed.step.2': { ko: '사전 문진', en: 'Questionnaire', ja: '事前問診', 'zh-hans': '问卷填寫' },

    // Intake Form (Steps continued)
    'intake.step6.title': { ko: '현금영수증 발급 번호', en: 'Cash Receipt Number', ja: '現金領収書発行番号', 'zh-hans': '现金收据号码' },
    'intake.step6.subtitle': { ko: '미발급 시 공란으로 두시면 됩니다.', en: 'Leave blank if not needed.', ja: '不要な場合は空欄にしてください。', 'zh-hans': '如不需要请留空。' },
    'intake.step7.title': { ko: '어떻게 알고<br/>문의하셨나요?', en: 'How did you<br/>hear about us?', ja: '当院をどこで<br/>知りましたか？', 'zh-hans': '您是如何<br/>知道我们的？' },
    'intake.step8.title': { ko: '비대면 진료 동의 및 안내', en: 'Telemedicine Consent', ja: 'オンライン診療同意・案内', 'zh-hans': '远程诊疗同意书' },

    'intake.shippingAddressPlaceholder': { ko: '전체 주소를 입력해 주세요', en: 'Enter full address', ja: '住所を入力してください', 'zh-hans': '请输入完整地址' },
    'intake.shippingRequestPlaceholder': { ko: '배송 요청사항 (선택)', en: 'Delivery request (Optional)', ja: '配送リクエスト（任意）', 'zh-hans': '配送要求（选填）' },
    'intake.cashReceiptPlaceholder': { ko: '휴대폰번호 또는 사업자번호', en: 'Phone number or Business number', ja: '携帯電話番号または事業者番号', 'zh-hans': '手机号码或营业执照号码' },

    'intake.referral.friend': { ko: '지인/가족 소개', en: 'Friend/Family', ja: '知人/家族の紹介', 'zh-hans': '朋友/家人介绍' },
    'intake.referral.naver': { ko: '네이버 검색', en: 'Naver Search', ja: 'Naver検索', 'zh-hans': 'Naver搜索' },
    'intake.referral.blog': { ko: '블로그/카페 글', en: 'Blog/Cafe', ja: 'ブログ/カフェ', 'zh-hans': '博客/论坛' },
    'intake.referral.instagram': { ko: '인스타그램/페이스북', en: 'Instagram/Facebook', ja: 'Instagram/Facebook', 'zh-hans': 'Instagram/Facebook' },
    'intake.referral.youtube': { ko: '유튜브', en: 'YouTube', ja: 'YouTube', 'zh-hans': 'YouTube' },
    'intake.referral.etc': { ko: '기타', en: 'Other', ja: 'その他', 'zh-hans': '其他' },

    'telemed.step.3': { ko: '비대면 상담', en: 'Consultation', ja: 'オンライン相談', 'zh-hans': '远程咨询' },
    'telemed.step.4': { ko: '처방 및 배송', en: 'Prescription', ja: '処方・配送', 'zh-hans': '处方配送' },
    'telemed.step.5': { ko: '사후 관리', en: 'Follow-up', ja: 'アフターケア', 'zh-hans': '后续管理' },
    'telemed.faq.title': { ko: '자주 묻는 질문', en: 'FAQ', ja: 'よくある質問', 'zh-hans': '常见问题' },
    'telemed.refundNotice': {
        ko: '처방 및 조제가 시작된 이후에는 변심으로 인한 취소가 어려울 수 있습니다. 환불 규정에 대한 자세한 내용은 환불 정책 페이지를 확인해 주세요.',
        en: 'Once prescription and preparation have begun, cancellations due to change of mind may be difficult. Please check the refund policy page for more details.',
        ja: '処方および調剤が開始された後は、個人の都合によるキャンセルが難しい場合があります。返金規定の詳細については、返金ポリシーページをご確認ください。',
        'zh-hans': '处方和配药开始后，可能难以因个人意愿取消。有关退款规定的更多详细信息，请查看退款政策页面。',
        vi: 'Sau khi bắt đầu kê đơn và pha chế, việc hủy bỏ do thay đổi ý định có thể gặp khó khăn. Vui lòng kiểm tra trang chính sách hoàn tiền để biết thêm chi tiết.'
    },
    'telemed.refundCta': { ko: '환불 규정 자세히 보기', en: 'View Refund Policy', ja: '返金規定を詳しく見る', 'zh-hans': '查看有关退款规定', vi: 'Xem Chính Sách Hoàn Tiền' },

    // Location Page
    'location.transport': { ko: '교통편 안내', en: 'Transport', ja: 'アクセス方法', 'zh-hans': '交通指南', vi: 'Phương Tiện' },
    'location.parking': { ko: '주차 안내', en: 'Parking', ja: '駐車場', 'zh-hans': '停车指南', vi: 'Đỗ Xe' },
    'location.subway': { ko: '지하철', en: 'Subway', ja: '地下鉄', 'zh-hans': '地铁', vi: 'Tàu Điện Ngầm' },
    'location.bus': { ko: '버스', en: 'Bus', ja: 'バス', 'zh-hans': '公交车', vi: 'Xe Buýt' },
    'location.car': { ko: '자가용', en: 'Car', ja: 'お車', 'zh-hans': '自驾', vi: 'Ô Tô' },
    'location.address': { ko: '주소', en: 'Address', ja: '住所', 'zh-hans': '地址', vi: 'Địa Chỉ' },
    'location.searchKeyword': { ko: '지도 검색어', en: 'Search Keyword', ja: '検索キーワード', 'zh-hans': '地图搜索词', vi: 'Từ Khóa' },
    'location.desc': { ko: '편안한 진료를 위해 오시는 길을 안내해 드립니다', en: 'We guide you to the clinic for comfortable treatment.', ja: '快適な診療のためにアクセスをご案内します', 'zh-hans': '为了您的舒适诊疗，为您指引来院路线', vi: 'Hướng dẫn đường đến phòng khám' },

    // Map Component
    'map.viewOnNaver': { ko: '네이버 지도에서 보기', en: 'View on Naver Map', ja: 'Naverマップで見る', 'zh-hans': '在Naver地图上查看' },
    'map.openMap': { ko: '지도 열기', en: 'Open Map', ja: '地図を開く', 'zh-hans': '打开地图' },
    'map.address': { ko: '주소', en: 'Address', ja: '住所', 'zh-hans': '地址' },
    'map.copyAddress': { ko: '주소 복사', en: 'Copy Address', ja: '住所をコピー', 'zh-hans': '复制地址' },
    'map.copied': { ko: '✓ 복사됨', en: '✓ Copied', ja: '✓ コピー完了', 'zh-hans': '✓ 已复制' },
    'map.tmap': { ko: 'TMap 길찾기', en: 'TMap Navigation', ja: 'TMap ナビ', 'zh-hans': 'TMap 导航' },
    'map.searchKeywordLabel': { ko: '네이버 지도 검색어', en: 'Naver Map Keyword', ja: 'Naverマップ検索語', 'zh-hans': 'Naver地图搜索词' },

    // Business Hours Section
    'hours.title': { ko: '진료 시간', en: 'Opening Hours', ja: '診療時間', 'zh-hans': '诊疗时间', vi: 'Giờ Làm Việc' },
    'hours.weekdaysLabel': { ko: '평일 (월~금)', en: 'Weekdays (Mon-Fri)', ja: '平日 (月~金)', 'zh-hans': '平日 (周一~周五)', vi: 'Ngày Thường (T2-T6)' },
    'hours.saturdayLabel': { ko: '토요일', en: 'Saturday', ja: '土曜日', 'zh-hans': '周六', vi: 'Thứ Bảy' },
    'hours.lunchLabel': { ko: '점심시간', en: 'Lunch Break', ja: '昼休み', 'zh-hans': '午休', vi: 'Nghỉ Trưa' },
    'hours.closedLabel': { ko: '휴진 안내', en: 'Closed', ja: '休診案内', 'zh-hans': '休诊指南', vi: 'Đóng Cửa' },
    'hours.receptionNotice': { ko: '접수는 마감 1시간 전까지 가능합니다.', en: 'Reception closes 1 hour before closing time.', ja: '受付は終了1時間前まで可能です。', 'zh-hans': '请在结束前1小时完成挂号。', vi: 'Tiếp nhận kết thúc 1 giờ trước.' },

    // Transport Info Section
    'transport.title': { ko: '교통편 안내', en: 'Transport', ja: 'アクセス', 'zh-hans': '交通指南' },
    'transport.subwayDesc': { ko: '가까운 역에서 도보 이동', en: 'Walk from nearest station', ja: '最寄駅から徒歩', 'zh-hans': '从最近的车站步行' },
    'transport.busDesc': { ko: '정류장 하차 후 도보', en: 'Walk from bus stop', ja: 'バス停から徒歩', 'zh-hans': '下车后步行' },
    'transport.carDesc': { ko: '건물 내 주차장 이용', en: 'Use building parking lot', ja: 'ビル内の駐車場を利用', 'zh-hans': '使用大楼内停车场' },

    'common.notice': { ko: '공지', en: 'Notice', ja: 'お知らせ', 'zh-hans': '公告', vi: 'Thông Báo' },
    'common.notices': { ko: '공지사항', en: 'Notices', ja: 'お知らせ', 'zh-hans': '公告', vi: 'Thông Báo' },
    'common.more': { ko: '더보기 +', en: 'More +', ja: 'もっと見る +', 'zh-hans': '更多 +', vi: 'Xem Thêm +' },
    'common.noNotices': { ko: '등록된 공지사항이 없습니다.', en: 'No notices found.', ja: 'お知らせはありません。', 'zh-hans': '暂无公告。', vi: 'Không có thông báo.' },
    'common.viewMap': { ko: '지도 보기', en: 'View Map', ja: '地図を見る', 'zh-hans': '查看地图', vi: 'Xem Bản Đồ' },
    'contact.title': { ko: '예약 및 문의', en: 'Reservation & Inquiry', ja: '予約・お問い合わせ', 'zh-hans': '预约咨询', vi: 'Đặt Lịch & Liên Hệ' },
};

// Helper to get UI translation (synchronous, hardcoded only - for backward compatibility)
export function getUIText(key: string, locale: Locale): string {
    return UI_TRANSLATIONS[key]?.[locale] || UI_TRANSLATIONS[key]?.ko || key;
}

/**
 * DB-first UI translation lookup (async version)
 * 1. First checks DB for translation
 * 2. Falls back to hardcoded UI_TRANSLATIONS
 * 3. Falls back to Korean value
 * 4. Falls back to key itself
 */
export async function getUITextAsync(
    db: any,
    key: string,
    locale: Locale
): Promise<string> {
    // Korean uses hardcoded values directly (source language)
    if (locale === 'ko') {
        return UI_TRANSLATIONS[key]?.ko || key;
    }

    // Try DB first for non-Korean locales
    if (db) {
        try {
            const result = await db
                .prepare('SELECT value FROM ui_translations WHERE key = ? AND locale = ?')
                .bind(key, locale)
                .first();
            if (result?.value) {
                return result.value;
            }
        } catch (e) {
            // DB error, fall through to hardcoded
        }
    }

    // Fallback to hardcoded values
    return UI_TRANSLATIONS[key]?.[locale] || UI_TRANSLATIONS[key]?.ko || key;
}

/**
 * Batch load UI translations for a locale (for performance)
 * Returns a lookup function that can be used synchronously
 */
export async function loadUITranslations(
    db: any,
    locale: Locale
): Promise<(key: string) => string> {
    const dbTranslations: Record<string, string> = {};

    if (db && locale !== 'ko') {
        try {
            const result = await db
                .prepare('SELECT key, value FROM ui_translations WHERE locale = ?')
                .bind(locale)
                .all();

            for (const row of (result.results || [])) {
                dbTranslations[row.key] = row.value;
            }
        } catch (e) {
            // Fall through to hardcoded
        }
    }

    // Return a lookup function
    return (key: string): string => {
        // DB value takes priority
        if (dbTranslations[key]) {
            return dbTranslations[key];
        }
        // Fallback to hardcoded
        return UI_TRANSLATIONS[key]?.[locale] || UI_TRANSLATIONS[key]?.ko || key;
    };
}

// =====================================================
// Multi-language System Configuration
// =====================================================

/**
 * Check if multi-language (i18n) feature is enabled globally
 * When OFF: Only Korean is supported
 * When ON: Translation tabs appear in admin editors
 */
export async function isI18nEnabled(db: any): Promise<boolean> {
    if (!db) return false;

    try {
        const result = await db.prepare(
            "SELECT value FROM site_settings WHERE key = 'i18n_enabled'"
        ).first();

        return result?.value === 'true' || result?.value === '1';
    } catch (e) {
        console.error('Failed to check i18n status:', e);
        return false;
    }
}

/**
 * Get list of available locales for translation (excludes 'ko' which is the default)
 */
export function getTranslatableLocales(): Locale[] {
    return SUPPORTED_LOCALES.filter(l => l !== 'ko') as Locale[];
}

// Multilingual settings from DB (clinic name, address, slogan, etc.)
export interface I18nSettings {
    clinicName: string;
    address: string;
    slogan: string;
    currencyFormat: 'KRW' | 'WON';
    mapSearchKeyword?: string;
}

export async function getI18nSettings(db: any, locale: Locale): Promise<I18nSettings> {
    const defaults: I18nSettings = {
        clinicName: '샘플한의원',
        address: '서울특별시 강남구 테헤란로 123',
        slogan: '건강한 삶을 위한 한방 치료',
        currencyFormat: 'WON'
    };

    if (!db || locale === 'ko') return defaults;

    try {
        const localeSuffix = locale === 'zh-hans' ? 'zh' : locale;

        // Keys to look for:
        // name_en, name_ja, name_zh
        // address_en, address_ja, address_zh
        // map_search_keyword (shared, technically not localized per se but good to have here or assume shared)
        // slogan usually not editable yet, keep defaults

        const nameKey = `name_${localeSuffix}`;
        const addressKey = `address_${localeSuffix}`;

        const results = await db.prepare(`
            SELECT key, value FROM site_settings 
            WHERE key IN (?, ?, ?, 'currency_format', 'map_search_keyword')
        `).bind(nameKey, addressKey, `slogan_${localeSuffix}`).all();

        const settingsMap = new Map<string, string>((results.results || []).map((r: any) => [r.key, r.value]));

        return {
            clinicName: settingsMap.get(nameKey) || defaults.clinicName,
            address: settingsMap.get(addressKey) || defaults.address,
            slogan: settingsMap.get(`slogan_${localeSuffix}`) || defaults.slogan,
            currencyFormat: 'KRW',
            mapSearchKeyword: settingsMap.get('map_search_keyword')
        };
    } catch (e) {
        console.error('Failed to fetch i18n settings:', e);
        return defaults;
    }
}

/**
 * Format price for display based on locale
 * - Korean: 15만원, 37.9만원
 * - International: KRW 150,000, KRW 379,000
 */
export function formatPrice(price: number | string, locale: Locale): string {
    const numPrice = typeof price === 'string' ? parseInt(price.replace(/\D/g, ''), 10) : price;

    if (isNaN(numPrice)) return String(price);

    if (locale === 'ko') {
        // Korean format: use 만원
        if (numPrice >= 10000) {
            const man = numPrice / 10000;
            return man % 1 === 0 ? `${man}만원` : `${man.toFixed(1)}만원`;
        }
        return `${numPrice.toLocaleString()}원`;
    } else {
        // International format: KRW with comma separator
        return `KRW ${numPrice.toLocaleString()}`;
    }
}

// =====================================================
// 유틸리티 함수
// =====================================================

/**
 * 유효한 로케일인지 확인
 */
export function isValidLocale(locale: string): locale is Locale {
    return SUPPORTED_LOCALES.includes(locale as Locale);
}

/**
 * URL에서 로케일 추출
 * /en/programs/diet → 'en'
 * /programs/diet → 'ko' (기본값)
 */
export function extractLocaleFromPath(pathname: string): Locale {
    const segments = pathname.split('/').filter(Boolean);
    const firstSegment = segments[0];

    if (firstSegment && isValidLocale(firstSegment)) {
        return firstSegment;
    }
    return DEFAULT_LOCALE;
}

/**
 * 로케일을 제외한 경로 반환
 * /en/programs/diet → /programs/diet
 */
export function removeLocaleFromPath(pathname: string): string {
    const segments = pathname.split('/').filter(Boolean);
    const firstSegment = segments[0];

    if (firstSegment && isValidLocale(firstSegment)) {
        return '/' + segments.slice(1).join('/');
    }
    return pathname;
}

/**
 * 경로에 로케일 추가 (표준 유틸리티)
 * /programs/diet, 'en' → /en/programs/diet
 * /programs/diet, 'ko' → /programs/diet (기본 언어는 prefix 없음)
 */
export function getLocalizedPath(path: string, locale: Locale): string {
    const cleanPath = removeLocaleFromPath(path);
    const normalizedPath = cleanPath.startsWith('/') ? cleanPath : `/${cleanPath}`;

    if (locale === DEFAULT_LOCALE) {
        return normalizedPath || '/';
    }

    return `/${locale}${normalizedPath === '/' ? '' : normalizedPath}`;
}

/**
 * Accept-Language 헤더에서 선호 로케일 추출
 */
export function getPreferredLocale(acceptLanguage: string | null): Locale {
    if (!acceptLanguage) return DEFAULT_LOCALE;

    const languages = acceptLanguage
        .split(',')
        .map(lang => {
            const [code, quality = '1'] = lang.trim().split(';q=');
            return { code: code.toLowerCase(), quality: parseFloat(quality) };
        })
        .sort((a, b) => b.quality - a.quality);

    for (const { code } of languages) {
        if (code === 'ko' || code.startsWith('ko-')) return 'ko';
        if (code === 'en' || code.startsWith('en-')) return 'en';
        if (code === 'ja' || code.startsWith('ja-')) return 'ja';
        if (code === 'zh' || code.startsWith('zh-')) return 'zh-hans';
        if (code === 'vi' || code.startsWith('vi-')) return 'vi';
    }

    return DEFAULT_LOCALE;
}

// =====================================================
// 데이터베이스 함수
// =====================================================

/**
 * UI 번역 가져오기 (캐시 가능)
 */
export async function getUITranslations(db: any, locale: Locale): Promise<Record<string, string>> {
    if (locale === DEFAULT_LOCALE) {
        return {}; // 한국어는 하드코딩된 기본값 사용
    }

    const result = await db
        .prepare('SELECT key, value FROM ui_translations WHERE locale = ?')
        .bind(locale)
        .all();

    const translations: Record<string, string> = {};
    for (const row of result.results || []) {
        translations[row.key] = row.value;
    }

    return translations;
}

/**
 * 특정 UI 키 번역 가져오기
 */
export async function getUITranslation(db: any, key: string, locale: Locale, fallback: string): Promise<string> {
    if (locale === DEFAULT_LOCALE) return fallback;

    const result = await db
        .prepare('SELECT value FROM ui_translations WHERE key = ? AND locale = ?')
        .bind(key, locale)
        .first();

    return result?.value || fallback;
}

/**
 * 페이지 번역 가져오기
 */
export async function getPageTranslation(db: any, pageType: string, pageId: string, locale: Locale) {
    if (locale === DEFAULT_LOCALE) return null; // 한국어는 원본 사용

    return await db
        .prepare(`
            SELECT * FROM page_translations 
            WHERE page_type = ? AND page_id = ? AND locale = ? AND status = 'published'
        `)
        .bind(pageType, pageId, locale)
        .first();
}

/**
 * FAQ 번역 가져오기
 */
export async function getFAQTranslation(db: any, faqId: number, locale: Locale) {
    if (locale === DEFAULT_LOCALE) return null;

    return await db
        .prepare(`
            SELECT * FROM faq_translations 
            WHERE faq_id = ? AND locale = ? AND status = 'published'
        `)
        .bind(faqId, locale)
        .first();
}

/**
 * 프로그램 번역 가져오기
 */
export async function getProgramTranslation(db: any, programId: string, locale: Locale) {
    if (locale === DEFAULT_LOCALE) return null;

    return await db
        .prepare(`
            SELECT * FROM program_translations 
            WHERE program_id = ? AND locale = ? AND status = 'published'
        `)
        .bind(programId, locale)
        .first();
}

// =====================================================
// 번역 상태 통계 (관리자 대시보드용)
// =====================================================

export interface TranslationStats {
    locale: Locale;
    total: number;
    pending: number;
    draft: number;
    inProgress: number;
    review: number;
    published: number;
    progressPercent: number;
}

export interface TranslationOverview {
    pages: TranslationStats[];
    faqs: TranslationStats[];
    programs: TranslationStats[];
    ui: TranslationStats[];
}

/**
 * 전체 번역 통계 가져오기
 */
export async function getTranslationStats(db: any): Promise<TranslationOverview> {
    const locales: Locale[] = ['en', 'ja', 'zh-hans', 'vi'];

    // 페이지 통계
    const pageStats = await Promise.all(locales.map(async (locale) => {
        const total = await db.prepare("SELECT COUNT(*) as count FROM pages WHERE is_published = 1").first();
        const stats = await db.prepare(`
            SELECT status, COUNT(*) as count 
            FROM page_translations 
            WHERE locale = ? 
            GROUP BY status
        `).bind(locale).all();

        return aggregateStats(locale, total?.count || 0, stats.results || []);
    }));

    // FAQ 통계
    const faqStats = await Promise.all(locales.map(async (locale) => {
        const total = await db.prepare("SELECT COUNT(*) as count FROM faq_items WHERE status = 'published'").first();
        const stats = await db.prepare(`
            SELECT status, COUNT(*) as count 
            FROM faq_translations 
            WHERE locale = ? 
            GROUP BY status
        `).bind(locale).all();

        return aggregateStats(locale, total?.count || 0, stats.results || []);
    }));

    // 프로그램 통계
    const programStats = await Promise.all(locales.map(async (locale) => {
        const total = await db.prepare("SELECT COUNT(*) as count FROM programs").first();
        const stats = await db.prepare(`
            SELECT status, COUNT(*) as count 
            FROM program_translations 
            WHERE locale = ? 
            GROUP BY status
        `).bind(locale).all();

        return aggregateStats(locale, total?.count || 0, stats.results || []);
    }));

    // UI 통계
    const uiStats = await Promise.all(locales.map(async (locale) => {
        const total = await db.prepare("SELECT COUNT(DISTINCT key) as count FROM ui_translations WHERE locale = 'en'").first();
        const translated = await db.prepare("SELECT COUNT(*) as count FROM ui_translations WHERE locale = ?").bind(locale).first();

        return {
            locale,
            total: total?.count || 0,
            pending: 0,
            draft: 0,
            inProgress: 0,
            review: 0,
            published: translated?.count || 0,
            progressPercent: total?.count ? Math.round((translated?.count || 0) / total.count * 100) : 0
        } as TranslationStats;
    }));

    return {
        pages: pageStats,
        faqs: faqStats,
        programs: programStats,
        ui: uiStats
    };
}

function aggregateStats(locale: Locale, total: number, results: any[]): TranslationStats {
    const statusCounts: Record<string, number> = {};
    for (const row of results) {
        statusCounts[row.status] = row.count;
    }

    const published = statusCounts['published'] || 0;

    return {
        locale,
        total,
        pending: total - Object.values(statusCounts).reduce((a, b) => a + b, 0),
        draft: statusCounts['draft'] || 0,
        inProgress: statusCounts['in_progress'] || 0,
        review: statusCounts['review'] || 0,
        published,
        progressPercent: total ? Math.round(published / total * 100) : 0
    };
}

/**
 * 미번역 항목 목록 가져오기
 */
export async function getUntranslatedItems(db: any, entityType: 'page' | 'faq' | 'program', locale: Locale, limit = 20) {
    switch (entityType) {
        case 'page':
            return await db.prepare(`
                SELECT p.slug, p.title, p.updated_at
                FROM pages p
                LEFT JOIN page_translations pt ON p.slug = pt.page_id AND pt.locale = ?
                WHERE p.is_published = 1 AND pt.id IS NULL
                ORDER BY p.updated_at DESC
                LIMIT ?
            `).bind(locale, limit).all();

        case 'faq':
            return await db.prepare(`
                SELECT f.id, f.question, f.topic_id, t.title as topic_title
                FROM faq_items f
                LEFT JOIN faq_translations ft ON f.id = ft.faq_id AND ft.locale = ?
                LEFT JOIN topics t ON f.topic_id = t.id
                WHERE f.status = 'published' AND ft.id IS NULL
                ORDER BY f.view_count DESC
                LIMIT ?
            `).bind(locale, limit).all();

        case 'program':
            return await db.prepare(`
                SELECT p.id, p.title, p.updated_at
                FROM programs p
                LEFT JOIN program_translations pt ON p.id = pt.program_id AND pt.locale = ?
                WHERE pt.id IS NULL
                LIMIT ?
            `).bind(locale, limit).all();

        default:
            return { results: [] };
    }
}
