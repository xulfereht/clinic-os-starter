
interface PatientEvent {
    patient_id: string;
    type: 'reservation' | 'visit' | 'payment' | 'cancel' | 'inquiry';
    data?: any;
}

export class PatientStatusService {
    private db: any;

    constructor(db: any) {
        this.db = db;
    }

    async handleEvent(event: PatientEvent) {
        // 1. Log the event (optional, if not already handled by caller)
        // Assuming caller handles adding row to reservations/payments/events tables.

        // 2. Re-evaluate Patient Status
        await this.updatePatientStatus(event.patient_id);

        // 3. Update Labels (optional)
        await this.updatePatientLabels(event.patient_id);
    }

    async updatePatientStatus(patientId: string) {
        // Fetch All Intearction Dates (Visits + Payments)
        // We want to count distinctive DAYS where an interaction happened.
        // Visit: `event_date` in patient_events (type='visit') -> Unix Epoch
        // Payment: `paid_at` in payments (amount > 0) -> Unix Epoch (or ISO string? Let's assume Unix based on schema usage elsewhere, but we should cast carefully).
        // Actually radiator.ts used: `paid_at >= ?` with unix timestamps. So `paid_at` is likely unix instructions.

        const query = `
            WITH interactions AS (
                SELECT event_date as interact_at FROM patient_events WHERE patient_id = ? AND type = 'visit'
                UNION ALL
                SELECT paid_at as interact_at FROM payments WHERE patient_id = ? AND amount > 0 AND status = 'completed'
            )
            SELECT 
                COUNT(DISTINCT date(interact_at, 'unixepoch', 'localtime')) as distinct_days,
                MAX(interact_at) as last_interact_at
            FROM interactions
            WHERE interact_at IS NOT NULL
        `;

        // Note: sqlite `date(..., 'unixepoch', 'localtime')` converts to local string YYYY-MM-DD.
        // This effectively groups both events on the same day as 1 "visit/interaction".

        const { results } = await this.db.prepare(query).bind(patientId, patientId).run();
        const stats = results[0];
        const distinctDays = stats.distinct_days as number || 0;
        const lastInteractAt = stats.last_interact_at as number;

        let newStatus = 'inquiry'; // Default fallback

        if (distinctDays === 1) {
            newStatus = 'first_visit';
        } else if (distinctDays >= 2) {
            newStatus = 'active'; // Returning patient
        }

        // Update patient table
        // We also update 'visit_count' to reflect this "interaction count" or should we keep strict visit count?
        // User asked for "Check label status". If we update status, it shows correctly.
        // If we update `visit_count` with `distinctDays`, it might be confusing if they expect physical visits.
        // BUT, for the logic "2회 이상 -> 재진", effectively this count IS the status driver.
        // Let's update `visit_count` to match `distinctDays` so the UI (which might rely on it) helps debug?
        // Or better: Keep `visit_count` as PHYSICAL visits, but drive Status by `distinctDays`.
        // However, `patient-status.ts` previously updated `visit_count`. 
        // Let's stick to updating `visit_count` with `distinctDays` to align with "2회" concept.

        let updateSql = `UPDATE patients SET status = ?, visit_count = ?, updated_at = unixepoch()`;
        const params: any[] = [newStatus, distinctDays];

        if (lastInteractAt) {
            updateSql += `, last_visit_date = ?`;
            // Convert to KST YYYY-MM-DD
            const kstOffset = 9 * 60 * 60 * 1000;
            const dateObj = new Date(lastInteractAt * 1000 + kstOffset);
            const dateStr = dateObj.toISOString().split('T')[0];
            params.push(dateStr);
        }

        updateSql += ` WHERE id = ?`;
        params.push(patientId);

        await this.db.prepare(updateSql).bind(...params).run();
    }

    async updatePatientLabels(patientId: string) {
        // Advanced Labeling based on aggregated data
        // e.g. "VIP" if total payment > 1,000,000

        const paymentQuery = `SELECT SUM(amount) as total FROM payments WHERE patient_id = ? AND status = 'completed'`;
        const { results: payRes } = await this.db.prepare(paymentQuery).bind(patientId).run();
        const totalPay = payRes[0].total as number || 0;

        const labels = [];
        if (totalPay >= 3000000) labels.push('VIP');
        else if (totalPay >= 1000000) labels.push('HighValue');

        // Insert/Update labels
        // For simplicity, we can delete old system-generated labels and re-insert, 
        // or use UPSERT if we track source.

        for (const label of labels) {
            await this.db.prepare(`
         INSERT INTO patient_labels (patient_id, category, value, created_by)
         VALUES (?, 'system', ?, 'system')
         ON CONFLICT(patient_id, category, value) DO NOTHING
       `).bind(patientId, label).run();
        }
    }
}
