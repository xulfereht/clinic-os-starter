export interface PermissionSet {
    [resource: string]: string[]; // e.g., "knowledge": ["view", "edit"]
}

export const RESOURCES = {
    // Customer Mgmt
    LEADS: 'leads',
    INTAKE: 'intake',
    PATIENTS: 'patients',
    MEMBERS: 'members',
    MESSAGES: 'messages',
    // MESSAGES_ARCHIVED handled by MESSAGES
    RESERVATIONS: 'reservations',
    PAYMENTS: 'payments',
    SHIPPING: 'shipping',

    // Hospital Ops
    SCHEDULE: 'schedule',
    PRODUCTS: 'products',
    PROMOTIONS: 'promotions',
    INVENTORY: 'inventory',
    TASKS: 'tasks',
    MANUALS: 'manuals',
    DOCUMENTS: 'documents',
    EXPENSES: 'expenses',

    // Marketing & Message
    SEGMENTS: 'segments',
    CAMPAIGNS: 'campaigns',
    EVENTS: 'events',
    MARKETING_HISTORY: 'marketing_history',

    // Data Analysis
    ANALYTICS: 'analytics',
    CRM: 'crm', // Patient DB Analysis
    WEB_ANALYTICS: 'web_analytics',
    AEO: 'aeo',
    LAB: 'lab',

    // Contents
    PROGRAMS: 'programs',
    POSTS: 'posts',
    MEDIA: 'media',
    REVIEWS: 'reviews',
    NOTICES: 'notices',
    SURVEYS: 'surveys',
    TOPICS: 'topics',
    PAGES: 'pages',

    // Global (Multi-language)
    TRANSLATIONS: 'translations',
    UI_TRANSLATIONS: 'ui_translations',
    LANGUAGES: 'languages',
    AI_CONTEXT: 'ai_context',

    // System
    SETTINGS: 'settings',
    STAFF: 'staff',
    DESIGN: 'design',
    WIDGET: 'widget',
    SEO: 'seo',
    INTEGRATIONS: 'integrations',
    AI_SETTINGS: 'ai_settings',
    DATA_HUB: 'data_hub',
    TRASH: 'trash',
} as const;

export const RESOURCE_METADATA = {
    // Customer Mgmt
    [RESOURCES.LEADS]: { label: '문의/리드', description: '고객 문의 및 잠재고객 관리' },
    [RESOURCES.INTAKE]: { label: '접수 현황', description: '초진 접수 내역 확인' },
    [RESOURCES.PATIENTS]: { label: '환자 관리', description: '등록 환자 정보 및 차트' },
    [RESOURCES.MEMBERS]: { label: '웹회원 관리', description: '홈페이지 가입 회원 승인' },
    [RESOURCES.MESSAGES]: { label: '메신저', description: '실시간 채팅 및 상담' },
    [RESOURCES.RESERVATIONS]: { label: '예약 관리', description: '예약 조회 및 등록' },
    [RESOURCES.PAYMENTS]: { label: '결제 관리', description: '결제 내역 조회 및 환불' },
    [RESOURCES.SHIPPING]: { label: '배송/해피콜', description: '배송 및 해피콜 관리' },

    // Hospital Ops
    [RESOURCES.SCHEDULE]: { label: '근무/휴일', description: '운영시간 및 휴무일 설정' },
    [RESOURCES.PRODUCTS]: { label: '상품/가격', description: '상품 및 가격 설정' },
    [RESOURCES.PROMOTIONS]: { label: '프로모션', description: '할인 및 이벤트 관리' },
    [RESOURCES.INVENTORY]: { label: '재고 관리', description: '약재 및 물품 재고' },
    [RESOURCES.TASKS]: { label: '업무 체크', description: '일일 업무 체크리스트' },
    [RESOURCES.MANUALS]: { label: '업무 매뉴얼', description: '업무 가이드 및 매뉴얼' },
    [RESOURCES.DOCUMENTS]: { label: '문서함', description: '병원 문서 보관' },
    [RESOURCES.EXPENSES]: { label: '지출 관리', description: '병원 지출 및 입금 요청' },

    // Marketing
    [RESOURCES.SEGMENTS]: { label: '세그먼트 빌더', description: '환자 타겟 그룹 생성' },
    [RESOURCES.CAMPAIGNS]: { label: '문자 캠페인', description: '단체 문자 발송 및 관리' },
    [RESOURCES.EVENTS]: { label: '이벤트 폼 빌더', description: '이벤트 페이지/신청서 제작' },
    [RESOURCES.MARKETING_HISTORY]: { label: '발송 내역', description: '문자 발송 기록 확인' },

    // Analytics
    [RESOURCES.ANALYTICS]: { label: '매출/전환 분석', description: '유입~결제 전환 퍼널 분석' },
    [RESOURCES.CRM]: { label: '환자 DB 분석', description: '신규/재방문 및 유지율 분석' },
    [RESOURCES.WEB_ANALYTICS]: { label: '웹사이트 분석', description: '방문자 트래픽 및 유입 분석' },
    [RESOURCES.AEO]: { label: 'AEO 최적화', description: 'AI 검색 노출 모니터링' },
    [RESOURCES.LAB]: { label: '실험실 (Beta)', description: '상세 데이터 심층 분석' },

    // Contents
    [RESOURCES.PROGRAMS]: { label: '프로그램', description: '진료 프로그램 관리' },
    [RESOURCES.POSTS]: { label: '블로그/칼럼', description: '블로그 글 작성' },
    [RESOURCES.MEDIA]: { label: '미디어 라이브러리', description: '이미지 파일 관리' },
    [RESOURCES.REVIEWS]: { label: '치료 후기', description: '환자 후기 관리' },
    [RESOURCES.NOTICES]: { label: '공지사항', description: '공지사항 작성' },
    [RESOURCES.SURVEYS]: { label: '설문/검사', description: '검사/자가진단 관리' },
    [RESOURCES.TOPICS]: { label: 'AEO 토픽', description: '지식 클러스터(Pillar) 관리' },
    [RESOURCES.PAGES]: { label: '페이지 관리', description: '일반 페이지 제작' },

    // Global
    [RESOURCES.TRANSLATIONS]: { label: '번역 대시보드', description: '전체 번역 현황 및 매트릭스' },
    [RESOURCES.UI_TRANSLATIONS]: { label: 'UI 번역', description: '네비게이션, 버튼 등 UI 텍스트' },
    [RESOURCES.LANGUAGES]: { label: '언어 설정', description: '지원 언어 추가/활성화' },
    [RESOURCES.AI_CONTEXT]: { label: 'AI 컨텍스트', description: 'AI 크롤러용 다국어 정보' },

    // System
    [RESOURCES.SETTINGS]: { label: '기본 설정', description: '병원 기본 정보' },
    [RESOURCES.STAFF]: { label: '직원 관리', description: '직원 계정 및 권한 설정' },
    [RESOURCES.DESIGN]: { label: '디자인', description: '테마 및 디자인 설정' },
    [RESOURCES.WIDGET]: { label: '채팅 위젯', description: '고객 상담 위젯' },
    [RESOURCES.SEO]: { label: 'SEO', description: '검색엔진 최적화' },
    [RESOURCES.INTEGRATIONS]: { label: 'API 연동', description: '외부 서비스 연동' },
    [RESOURCES.AI_SETTINGS]: { label: 'AI 에이전트', description: 'AI 기능 설정' },
    [RESOURCES.DATA_HUB]: { label: '데이터 관리', description: '데이터 가져오기/내보내기' },
    [RESOURCES.TRASH]: { label: '휴지통', description: '삭제된 항목' },
};

export const RESOURCE_GROUPS = {
    '고객 관리': [
        RESOURCES.LEADS, RESOURCES.INTAKE, RESOURCES.PATIENTS, RESOURCES.MEMBERS,
        RESOURCES.MESSAGES, RESOURCES.RESERVATIONS, RESOURCES.PAYMENTS, RESOURCES.SHIPPING
    ],
    '병원 운영': [
        RESOURCES.SCHEDULE, RESOURCES.PRODUCTS, RESOURCES.PROMOTIONS, RESOURCES.INVENTORY,
        RESOURCES.TASKS, RESOURCES.MANUALS, RESOURCES.DOCUMENTS, RESOURCES.EXPENSES
    ],
    '마케팅 & 메시지': [
        RESOURCES.SEGMENTS, RESOURCES.CAMPAIGNS, RESOURCES.EVENTS, RESOURCES.MARKETING_HISTORY
    ],
    '데이터 분석': [
        RESOURCES.ANALYTICS, RESOURCES.CRM, RESOURCES.WEB_ANALYTICS, RESOURCES.AEO, RESOURCES.LAB
    ],
    '콘텐츠 관리': [
        RESOURCES.PROGRAMS, RESOURCES.POSTS, RESOURCES.MEDIA, RESOURCES.REVIEWS,
        RESOURCES.NOTICES, RESOURCES.SURVEYS, RESOURCES.TOPICS, RESOURCES.PAGES
    ],
    '다국어 관리': [
        RESOURCES.TRANSLATIONS, RESOURCES.UI_TRANSLATIONS, RESOURCES.LANGUAGES, RESOURCES.AI_CONTEXT
    ],
    '시스템 설정': [
        RESOURCES.SETTINGS, RESOURCES.STAFF, RESOURCES.DESIGN, RESOURCES.WIDGET,
        RESOURCES.SEO, RESOURCES.INTEGRATIONS, RESOURCES.AI_SETTINGS, RESOURCES.DATA_HUB,
        RESOURCES.TRASH
    ]
};

export const ACTIONS = {
    VIEW: 'view',
    EDIT: 'edit', // Create/Update
    DELETE: 'delete',
    EXPORT: 'export'
} as const;

export interface UserWithPermissions {
    role: string;
    permissions: PermissionSet;
}

export const PERMISSION_PRESETS = {
    'DIRECTOR': {
        label: '원장 (Director)',
        description: '진료 및 병원 운영 전반에 대한 권한 (관리자 Role 적용)',
        targetRole: 'admin',
        permissions: Object.values(RESOURCES).reduce((acc, res) => {
            // System Settings: View Only
            // Cast as string[] to allow checking any resource string
            if ((RESOURCE_GROUPS['시스템 설정'] as readonly string[]).includes(res)) {
                acc[res] = ['view'];
            } else {
                acc[res] = ['view', 'edit'];
            }
            return acc;
        }, {} as PermissionSet)
    },
    'VICE_DIRECTOR': {
        label: '부원장 (Vice Director)',
        description: '시스템 설정을 제외한 전 영역 권한 (일반 직원 Role 적용)',
        targetRole: 'staff',
        permissions: Object.values(RESOURCES).reduce((acc, res) => {
            // Exclude System Settings
            if (!(RESOURCE_GROUPS['시스템 설정'] as readonly string[]).includes(res)) {
                acc[res] = ['view', 'edit'];
            }
            return acc;
        }, {} as PermissionSet)
    },
    'MANAGER': {
        label: '실장 (Manager)',
        description: '병원 전체 권한 (관리자 Role 적용)',
        targetRole: 'admin',
        permissions: Object.values(RESOURCES).reduce((acc, res) => ({ ...acc, [res]: ['view', 'edit'] }), {} as PermissionSet)
    },
    'STAFF': {
        label: '일반 직원 (Staff)',
        description: '고객 관리 및 병원 운영 권한 (일반 직원 Role 적용)',
        targetRole: 'staff',
        permissions: [
            ...RESOURCE_GROUPS['고객 관리'],
            ...RESOURCE_GROUPS['병원 운영']
        ].reduce((acc, res) => ({ ...acc, [res]: ['view', 'edit'] }), {} as PermissionSet)
    },
    'MARKETING': {
        label: '마케팅 (Marketing)',
        description: '콘텐츠, 디자인, 캠페인 관리 (에디터 Role 적용)',
        targetRole: 'editor',
        permissions: (() => {
            const perms: PermissionSet = {};
            // Edit Access - Explicitly type array to allow any string
            const editGroups: string[] = [
                ...RESOURCE_GROUPS['마케팅 & 메시지'],
                ...RESOURCE_GROUPS['콘텐츠 관리']
            ];
            editGroups.push(RESOURCES.DESIGN); // Allow Design Edit

            editGroups.forEach(res => {
                perms[res] = ['view', 'edit'];
            });

            // View Access
            const viewGroups = [
                ...RESOURCE_GROUPS['데이터 분석']
            ];
            viewGroups.forEach(res => {
                if (!perms[res]) perms[res] = ['view'];
            });

            // Except AEO might need Edit?
            if (perms[RESOURCES.AEO]) perms[RESOURCES.AEO] = ['view', 'edit'];

            return perms;
        })()
    },
    'ADMIN': {
        label: '시스템 관리자 (Admin)',
        description: '모든 기능에 대한 완전한 접근 권한 (최고 관리자 Role 적용)',
        targetRole: 'super_admin',
        permissions: Object.values(RESOURCES).reduce((acc, res) => ({ ...acc, [res]: ['view', 'edit'] }), {} as PermissionSet)
    }
};

/**
 * Check if a user has a specific permission.
 * Super Admins and Masters always have full access.
 */
export function hasPermission(user: UserWithPermissions | undefined, resource: string, action: string = 'view'): boolean {
    if (!user) return false;

    // 1. Super Admin / Master Override
    if (user.role === 'super_admin' || user.role === 'master' || user.role === '최고관리자') {
        return true;
    }

    // 2. Check Granular Permissions
    const resourcePerms = user.permissions[resource];
    if (!resourcePerms) return false;

    return resourcePerms.includes(action) || resourcePerms.includes('all');
}

/**
 * Get default permissions based on legacy role (migration helper)
 */
export function getDefaultPermissions(role: string): PermissionSet {
    // Basic mapping for legacy roles
    if (role === 'admin' || role === '관리자') return PERMISSION_PRESETS.ADMIN.permissions;
    if (role === 'editor') return PERMISSION_PRESETS.MARKETING.permissions;
    return {};
}
