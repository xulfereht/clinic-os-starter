import { GoogleTranslationService } from './google';

export class TranslationOrchestrator {
    private db: any;
    private googleService: GoogleTranslationService | null = null;
    private isInitialized = false;

    constructor(db: any) {
        this.db = db;
    }

    async init() {
        if (this.isInitialized) return;

        // Fetch Google Translate API Key from DB
        try {
            const config = await this.db.prepare(
                "SELECT api_key, is_active FROM ai_configs WHERE provider = 'google_translate'"
            ).first();

            if (config && config.is_active && config.api_key) {
                this.googleService = new GoogleTranslationService(config.api_key);
            } else {
                console.warn('Google Translation is not configured or inactive.');
            }
        } catch (e) {
            console.error('Failed to load translation config:', e);
        }

        this.isInitialized = true;
    }

    /**
     * Translates a message and saves it to the database.
     */
    async translateAndSave(
        messageId: string,
        content: string,
        targetLang: string,
        sourceLang?: string
    ): Promise<string | null> {
        await this.init();
        if (!this.googleService) return null;

        try {
            // Skip if target matches source (if known)
            if (sourceLang && sourceLang === targetLang) return null;

            const result = await this.googleService.translate(content, targetLang, sourceLang);

            // Delete any existing translation for this message (for re-translation with new language)
            await this.db.prepare(`DELETE FROM message_translations WHERE message_id = ?`).bind(messageId).run();

            // Save to DB
            await this.db.prepare(`
                INSERT INTO message_translations (message_id, locale, translated_text, engine, created_at, confidence)
                VALUES (?, ?, ?, 'google', unixepoch(), ?)
            `).bind(messageId, targetLang, result.translatedText, 1.0).run();

            return result.translatedText;
        } catch (e) {
            console.error('Translation Orchestration Failed:', e);
            return null;
        }
    }

    async detectLanguage(content: string): Promise<string> {
        await this.init();
        if (!this.googleService) return 'und';

        return await this.googleService.detectLanguage(content);
    }
}
