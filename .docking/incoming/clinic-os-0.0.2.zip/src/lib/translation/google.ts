
export interface TranslationResult {
    translatedText: string;
    detectedSourceLanguage?: string;
}

export class GoogleTranslationService {
    private apiKey: string;
    private baseUrl = 'https://translation.googleapis.com/language/translate/v2';

    constructor(apiKey: string) {
        this.apiKey = apiKey;
    }

    /**
     * Translates text to the target language.
     * @param text The text to translate
     * @param targetLang The target language code (e.g., 'en', 'ko')
     * @param sourceLang Optional source language code
     */
    async translate(text: string, targetLang: string, sourceLang?: string): Promise<TranslationResult> {
        try {
            const url = new URL(this.baseUrl);
            url.searchParams.append('key', this.apiKey);
            url.searchParams.append('q', text);
            url.searchParams.append('target', targetLang);
            if (sourceLang) {
                url.searchParams.append('source', sourceLang);
            }
            url.searchParams.append('format', 'text');

            const response = await fetch(url.toString(), {
                method: 'POST'
            });

            if (!response.ok) {
                const errorData = await response.json() as any;
                throw new Error(`Google Translate API Error: ${errorData.error?.message || response.statusText}`);
            }

            const data = await response.json() as any;

            if (data.data?.translations?.length > 0) {
                const result = data.data.translations[0];
                return {
                    translatedText: result.translatedText,
                    detectedSourceLanguage: result.detectedSourceLanguage
                };
            }

            throw new Error('No translation returned');

        } catch (error) {
            console.error('Google Translation Failed:', error);
            throw error;
        }
    }

    /**
     * Detects the language of the given text.
     * @param text The text to analyze
     */
    async detectLanguage(text: string): Promise<string> {
        try {
            const url = new URL(`${this.baseUrl}/detect`);
            url.searchParams.append('key', this.apiKey);
            url.searchParams.append('q', text);

            const response = await fetch(url.toString(), {
                method: 'POST'
            });

            if (!response.ok) {
                throw new Error(`Google Detect API Error: ${response.statusText}`);
            }

            const data = await response.json() as any;

            if (data.data?.detections?.length > 0 && data.data.detections[0].length > 0) {
                return data.data.detections[0][0].language;
            }

            return 'und'; // Undetermined

        } catch (error) {
            console.error('Language Detection Failed:', error);
            return 'und';
        }
    }
}
