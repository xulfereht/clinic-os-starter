export const STYLES = {
    minimal: {
        id: 'minimal',
        name: 'Minimal',
        description: 'Clean, sharp, and modern. Best for Dermatology, Plastic Surgery.',
        css: {
            '--radius-sm': '0.25rem',
            '--radius-md': '0.5rem',
            '--radius-lg': '0.75rem',
            '--font-heading': '"Pretendard", "Noto Sans KR", sans-serif',
            '--font-body': '"Pretendard", "Noto Sans KR", sans-serif',
            '--shadow-card': '0 1px 2px 0 rgb(0 0 0 / 0.05)',
        }
    },
    soft: {
        id: 'soft',
        name: 'Soft',
        description: 'Rounded, gentle, and friendly. Best for Pediatrics, Oriental Medicine.',
        css: {
            '--radius-sm': '0.75rem',
            '--radius-md': '1.25rem',
            '--radius-lg': '1.75rem',
            '--font-heading': '"Pretendard", "Noto Sans KR", sans-serif',
            '--font-body': '"Pretendard", "Noto Sans KR", sans-serif',
            '--shadow-card': '0 10px 30px -5px rgba(0, 0, 0, 0.08)',
        }
    },
    classic: {
        id: 'classic',
        name: 'Classic',
        description: 'Trustworthy and traditional. Best for Internal Medicine, Orthopedics.',
        css: {
            '--radius-sm': '0.375rem',
            '--radius-md': '0.5rem',
            '--radius-lg': '0.75rem',
            '--font-heading': '"Merriweather", "Noto Serif KR", serif',
            '--font-body': '"Pretendard", "Noto Sans KR", sans-serif',
            '--shadow-card': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        }
    }
};

export const COLORS = {
    blue: {
        id: 'blue',
        name: 'Professional Blue',
        colors: {
            primary: '#0052CC', // Deep Professional Blue
            secondary: '#003BB3', // Darker shade
            background: '#F0F4FF', // Soft Blue Tint
            text: '#0F172A', // Slate-900 for high contrast
        }
    },
    green: {
        id: 'green',
        name: 'Modern Teal',
        colors: {
            primary: '#0D9488', // Teal-600
            secondary: '#0F766E', // Teal-700
            background: '#F0FDFA', // Teal-50
            text: '#0F172A', // Slate-900
        }
    },
    warm: {
        id: 'warm',
        name: 'Wellness Amber',
        colors: {
            primary: '#D97706', // Amber-600
            secondary: '#B45309', // Amber-700
            background: '#FFFBEB', // Amber-50
            text: '#0F172A', // Slate-900
        }
    },
    grayscale: {
        id: 'grayscale',
        name: 'Modern Gray',
        colors: {
            primary: '#4B5563', // Gray-600
            secondary: '#1F2937', // Gray-800
            background: '#F9FAFB', // Gray-50
            text: '#111827', // Gray-900
        }
    }
};
