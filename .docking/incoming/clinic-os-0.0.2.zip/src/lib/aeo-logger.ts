export interface AEOEvent {
    path: string;
    userAgent: string;
    ip?: string;
    referer?: string;
    status: number;
}

export const KNOWN_BOTS = [
    { name: 'GPTBot', pattern: /GPTBot/i },
    { name: 'OAI-SearchBot', pattern: /OAI-SearchBot/i },
    { name: 'ClaudeBot', pattern: /ClaudeBot/i },
    { name: 'Google-Extended', pattern: /Google-Extended/i },
    { name: 'GoogleOther', pattern: /GoogleOther/i },
    { name: 'PerplexityBot', pattern: /PerplexityBot/i },
    { name: 'CCBot', pattern: /CCBot/i },
    { name: 'FacebookBot', pattern: /FacebookBot/i },
    { name: 'Twitterbot', pattern: /Twitterbot/i },
    { name: 'Applebot', pattern: /Applebot/i },
    { name: 'NaverBot', pattern: /Yeti|NaverBot/i }
];

export function detectAIBot(userAgent: string): string | null {
    if (!userAgent) return null;
    for (const bot of KNOWN_BOTS) {
        if (bot.pattern.test(userAgent)) {
            return bot.name;
        }
    }
    return null;
}

export async function logAEOEvent(db: any, event: AEOEvent) {
    if (!db) return;

    const botName = detectAIBot(event.userAgent);

    // Only log if it's a known bot OR if it's hitting specific AI endpoints
    const isAIEndpoint = event.path.includes('llms.txt') || event.path.includes('ai.json');

    if (!botName && !isAIEndpoint) return; // Skip normal traffic to save space

    try {
        await db.prepare(`
            INSERT INTO aeo_logs (bot_type, user_agent, path, ip_address, referer, status_code)
            VALUES (?, ?, ?, ?, ?, ?)
        `).bind(
            botName || 'Unknown-AI-Scan',
            event.userAgent,
            event.path,
            event.ip || null,
            event.referer || null,
            event.status
        ).run();
    } catch (e) {
        // Fail silently to not impact request
        console.error("Failed to log AEO event", e);
    }
}
