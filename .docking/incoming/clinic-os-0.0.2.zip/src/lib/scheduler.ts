export interface ScheduleConfig {
    freq: 'MINUTELY' | 'HOURLY' | 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'CUSTOM';
    every_n_minutes?: number; // for MINUTELY
    minute?: number; // for HOURLY
    time?: string; // for DAILY, WEEKLY, MONTHLY (HH:MM)
    days_of_week?: number[]; // for WEEKLY (0=Sun, 1=Mon...)
    day_of_month?: number; // for MONTHLY (1-31)
    cron_expression?: string; // for CUSTOM
}

// Helper to get KST Date object (UTC+9)
function toKST(date: Date): Date {
    return new Date(date.getTime() + (9 * 60 * 60 * 1000));
}

// Helper to convert KST Date back to UTC Timestamp (seconds)
function fromKST(kstDate: Date): number {
    return Math.floor((kstDate.getTime() - (9 * 60 * 60 * 1000)) / 1000);
}

export function calculateNextRun(config: ScheduleConfig, fromUnix: number): number {
    // 1. Convert 'fromUnix' (UTC) to KST Virtual Date
    // logic: If real UTC is 00:00, KST is 09:00. 
    // We create a Date object that *looks* like 09:00 in UTC methods (getUTCHours not used, just getHours locally if env is UTC? 
    // Cloudflare Workers environment is usually UTC. 
    // new Date() prints in UTC.
    // simpler: operate on milliseconds.

    // Allow for "virtual" KST object where .getHours() returns KST hour.
    // If env is UTC, we add 9 hours.
    const nowUTC = new Date(fromUnix * 1000);
    const nowKST = toKST(nowUTC);

    // We will perform logic on 'targetKST', then convert back.
    const targetKST = new Date(nowKST);

    switch (config.freq) {
        case 'MINUTELY': {
            const minutes = config.every_n_minutes || 15;
            targetKST.setMinutes(targetKST.getMinutes() + minutes);
            targetKST.setSeconds(0);
            targetKST.setMilliseconds(0);
            return fromKST(targetKST);
        }

        case 'HOURLY': {
            const minute = config.minute || 0;
            targetKST.setMinutes(minute);
            targetKST.setSeconds(0);
            targetKST.setMilliseconds(0);

            // If passed in current hour (KST context), move next hour
            if (targetKST.getTime() <= nowKST.getTime()) {
                targetKST.setHours(targetKST.getHours() + 1);
            }
            return fromKST(targetKST);
        }

        case 'DAILY': {
            if (!config.time) return fromUnix + 86400;
            const [h, m] = config.time.split(':').map(Number);
            // h is KST hour (e.g. 01 for 01:34 AM KST)
            targetKST.setHours(h, m, 0, 0);

            // If passed today (KST context), move next day
            if (targetKST.getTime() <= nowKST.getTime()) {
                targetKST.setDate(targetKST.getDate() + 1);
            }
            return fromKST(targetKST);
        }

        case 'WEEKLY': {
            if (!config.time || !config.days_of_week || config.days_of_week.length === 0) return fromUnix + 86400;
            const [h, m] = config.time.split(':').map(Number);
            targetKST.setHours(h, m, 0, 0);

            for (let i = 0; i < 8; i++) {
                const currentDay = targetKST.getDay(); // 0-6 (in KST context)
                if (config.days_of_week.includes(currentDay)) {
                    // Found match. Is it future?
                    if (targetKST.getTime() > nowKST.getTime()) {
                        return fromKST(targetKST);
                    }
                }
                targetKST.setDate(targetKST.getDate() + 1);
                targetKST.setHours(h, m, 0, 0);
            }
            return fromUnix + 86400;
        }

        case 'MONTHLY': {
            if (!config.time || !config.day_of_month) return fromUnix + 86400;
            const [h, m] = config.time.split(':').map(Number);
            targetKST.setDate(config.day_of_month);
            targetKST.setHours(h, m, 0, 0);

            // If passed, move next month
            if (targetKST.getTime() <= nowKST.getTime()) {
                targetKST.setMonth(targetKST.getMonth() + 1);
            }
            return fromKST(targetKST);
        }

        case 'CUSTOM': {
            return fromUnix + 3600;
        }

        default:
            return fromUnix + 86400;
    }
}
