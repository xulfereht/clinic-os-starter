
export async function generateSignature(key: string, secret: string): Promise<string> {
    const enc = new TextEncoder();
    const algorithm = { name: 'HMAC', hash: 'SHA-256' };
    const keyData = await crypto.subtle.importKey('raw', enc.encode(secret), algorithm, false, ['sign']);
    const signature = await crypto.subtle.sign(algorithm.name, keyData, enc.encode(key));

    // Convert to hex string
    return Array.from(new Uint8Array(signature))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}

export async function verifySignature(key: string, signature: string, secret: string): Promise<boolean> {
    if (!signature || !secret || !key) return false;
    const expected = await generateSignature(key, secret);
    return expected === signature;
}

export async function generateSignedUrl(baseUrl: string, secret: string, expiresInMinutes: number = 1440): Promise<string> {
    const url = new URL(baseUrl);
    const expires = Math.floor(Date.now() / 1000) + (expiresInMinutes * 60);
    url.searchParams.set('expires', expires.toString());

    // Sign: pathname + expires
    const signaturePayload = url.pathname + expires;
    const signature = await generateSignature(signaturePayload, secret);

    url.searchParams.set('signature', signature);
    return url.toString();
}

export async function verifySignedUrl(requestUrl: string, secret: string): Promise<boolean> {
    try {
        const url = new URL(requestUrl);
        const expires = url.searchParams.get('expires');
        const signature = url.searchParams.get('signature');

        if (!expires || !signature) return false;

        const now = Math.floor(Date.now() / 1000);
        if (now > parseInt(expires)) return false;

        const signaturePayload = url.pathname + expires;
        return await verifySignature(signaturePayload, signature, secret);
    } catch (e) {
        return false;
    }
}
