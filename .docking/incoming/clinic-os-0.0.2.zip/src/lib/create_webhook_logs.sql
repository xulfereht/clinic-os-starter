
CREATE TABLE webhook_logs (
    id TEXT PRIMARY KEY,
    received_at INTEGER NOT NULL,
    source TEXT NOT NULL,
    payload_preview TEXT,
    status TEXT NOT NULL,
    message TEXT,
    lead_id TEXT,
    created_at INTEGER DEFAULT (unixepoch())
);

CREATE INDEX idx_webhook_logs_received_at ON webhook_logs(received_at DESC);
