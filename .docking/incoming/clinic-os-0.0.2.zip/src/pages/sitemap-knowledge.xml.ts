import type { APIContext } from 'astro';

interface SitemapUrl {
    loc: string;
    lastmod?: string;
    changefreq?: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
    priority?: number;
}

function formatDate(dateStr?: number | string): string {
    if (!dateStr) return new Date().toISOString();
    return new Date(dateStr).toISOString();
}

export const prerender = false;

export async function GET(context: APIContext) {
    const db = context.locals.runtime?.env?.DB;
    // @ts-ignore
    const { getClinicSettings } = await import('../lib/clinic');
    const settings = await getClinicSettings(db);
    const siteUrl = settings.url || (context.site?.toString() ?? 'https://sample-clinic.com');
    const site = siteUrl.endsWith('/') ? siteUrl.slice(0, -1) : siteUrl;

    let urls: SitemapUrl[] = [];

    if (db) {
        try {
            // AEO Topics (Hub Pages)
            const topics = await db.prepare("SELECT slug FROM topics").all();
            if (topics.results) {
                // Hub Main
                urls.push({ loc: `${site}/topics`, changefreq: 'daily' as const, priority: 0.9 });

                // Topic Details
                urls.push(...topics.results.map((t: any) => ({
                    loc: `${site}/topics/${t.slug}`,
                    changefreq: 'weekly' as const,
                    priority: 0.85
                })));
            }

            // AEO Conditions
            // Note: topic_conditions table only has created_at, no updated_at
            const conditions = await db.prepare(`
                SELECT c.slug, c.created_at, t.slug as topic_slug
                FROM topic_conditions c
                JOIN topics t ON c.topic_id = t.id
            `).all();

            if (conditions.results) {
                urls.push(...conditions.results.map((c: any) => ({
                    loc: `${site}/topics/${c.topic_slug}/${c.slug}`,
                    lastmod: formatDate(c.created_at),
                    changefreq: 'weekly' as const,
                    priority: 0.8
                })));
            }

            // AEO FAQs
            // Structure: /topics/{topic_slug}/{condition_slug}/{faq_slug}
            const faqs = await db.prepare(`
                SELECT f.id, f.slug, f.updated_at, f.created_at, 
                       tc.slug as condition_slug, t.slug as topic_slug 
                FROM faq_items f 
                JOIN topic_conditions tc ON f.condition_id = tc.id 
                JOIN topics t ON tc.topic_id = t.id 
                WHERE f.status = 'published'
            `).all();

            if (faqs.results) {
                urls.push(...faqs.results.map((f: any) => ({
                    loc: `${site}/topics/${f.topic_slug}/${f.condition_slug}/${f.slug || f.id}`,
                    lastmod: formatDate(f.updated_at || f.created_at),
                    changefreq: 'weekly' as const,
                    priority: 0.7
                })));
            }

        } catch (e) {
            console.error('Error fetching DB content for sitemap-knowledge:', e);
        }
    }

    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${urls.map(u => `
    <url>
      <loc>${u.loc}</loc>
      ${u.lastmod ? `<lastmod>${u.lastmod}</lastmod>` : ''}
      ${u.changefreq ? `<changefreq>${u.changefreq}</changefreq>` : ''}
      ${u.priority ? `<priority>${u.priority}</priority>` : ''}
    </url>
  `).join('')}
</urlset>`;

    return new Response(sitemap, {
        headers: {
            'Content-Type': 'application/xml',
        },
    });
}
