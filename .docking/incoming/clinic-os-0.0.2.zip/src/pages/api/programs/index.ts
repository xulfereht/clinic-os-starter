import type { APIRoute } from 'astro';

export const prerender = false;

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const { results } = await db.prepare("SELECT * FROM programs WHERE deleted_at IS NULL ORDER BY title ASC").run();
        return new Response(JSON.stringify(results), {
            status: 200,
            headers: {
                "Content-Type": "application/json"
            }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const {
            title = "새 프로그램",
            description = "",
            category = "special",
            doctor_ids = [],
            sections = []
        } = body;

        // Generate ID from title or random if empty
        // Simple slugification: remove special chars, replace spaces with hyphens
        let id = title.toLowerCase()
            .replace(/[^\w\s-]/g, '') // Remove non-word chars (except spaces and hyphens)
            .replace(/\s+/g, '-')     // Replace spaces with hyphens
            .replace(/--+/g, '-');    // Replace multiple hyphens with single

        // If id is empty (e.g. Korean title only) or too short, use random string
        if (!id || id.length < 2) {
            id = 'program-' + Math.random().toString(36).substring(2, 8);
        }

        // Check if ID exists and append suffix if needed
        let finalId = id;
        let counter = 1;
        while (true) {
            const existing = await db.prepare("SELECT id FROM programs WHERE id = ?").bind(finalId).first();
            if (!existing) break;
            finalId = `${id}-${counter++}`;
        }

        const now = Math.floor(Date.now() / 1000);

        await db.prepare(`
            INSERT INTO programs (
                id, title, description, category, doctor_ids, sections, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `).bind(
            finalId,
            title,
            description,
            category,
            JSON.stringify(doctor_ids),
            JSON.stringify(sections),
            now
        ).run();

        return new Response(JSON.stringify({
            success: true,
            id: finalId,
            message: "Program created successfully"
        }), {
            status: 201,
            headers: { "Content-Type": "application/json" }
        });

    } catch (e: any) {
        console.error("Failed to create program:", e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
