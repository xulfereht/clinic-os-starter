import type { APIRoute } from 'astro';

export const prerender = false;

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { title, description, pricing, features, sections, doctor_ids, linkedTopicSlug } = body;

        if (sections) {
            await db.prepare(
                `UPDATE programs SET sections = ?, updated_at = strftime('%s', 'now') WHERE id = ?`
            ).bind(JSON.stringify(sections), id).run();
        }

        if (body.translations !== undefined) {
            await db.prepare(
                `UPDATE programs SET translations = ?, updated_at = strftime('%s', 'now') WHERE id = ?`
            ).bind(JSON.stringify(body.translations), id).run();
        }

        // Handle doctor_ids update
        if (doctor_ids !== undefined) {
            // Update doctor_ids as JSON array
            await db.prepare(
                `UPDATE programs SET doctor_ids = ?, updated_at = strftime('%s', 'now') WHERE id = ?`
            ).bind(JSON.stringify(doctor_ids), id).run();

            // Optional: Update legacy doctor_id with the first selected doctor (if any) for backward compatibility
            const primaryDoctorId = doctor_ids.length > 0 ? doctor_ids[0] : null;
            await db.prepare(
                `UPDATE programs SET doctor_id = ? WHERE id = ?`
            ).bind(primaryDoctorId, id).run();
        }

        // Handle FAQ Topic linking
        if (linkedTopicSlug !== undefined) {
            // First, unlink any topic currently linked to this program
            await db.prepare(
                `UPDATE topics SET related_program_id = NULL WHERE related_program_id = ?`
            ).bind(id).run();

            // Then, if a new topic is selected, link it
            if (linkedTopicSlug) {
                await db.prepare(
                    `UPDATE topics SET related_program_id = ? WHERE slug = ?`
                ).bind(id, linkedTopicSlug).run();
            }
        }

        // Handle basic info updates
        if (title !== undefined || description !== undefined || features !== undefined || body.order_index !== undefined || body.treatable_conditions !== undefined || body.conditions !== undefined) {
            const updates = [];
            const values = [];

            if (title !== undefined) {
                updates.push("title = ?");
                values.push(title);
            }
            if (description !== undefined) {
                updates.push("description = ?");
                values.push(description);
            }
            // If features is passed (legacy or new usage), update it
            if (features !== undefined) {
                updates.push("features = ?");
                values.push(JSON.stringify(features));
            }

            // Handle treatable_conditions (passed as array of strings)
            // The request body might send it as 'conditions' or 'treatable_conditions'
            const conditions = body.treatable_conditions || body.conditions;
            if (conditions !== undefined) {
                updates.push("treatable_conditions = ?");
                values.push(JSON.stringify(conditions));
            }

            const order_index = body.order_index;
            if (order_index !== undefined) {
                updates.push("order_index = ?");
                values.push(order_index);
            }

            if (updates.length > 0) {
                updates.push("updated_at = strftime('%s', 'now')");
                values.push(id); // For WHERE clause

                await db.prepare(
                    `UPDATE programs SET ${updates.join(", ")} WHERE id = ?`
                ).bind(...values).run();
            }
        }

        return new Response(JSON.stringify({ status: "ok" }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        await db.prepare("UPDATE programs SET deleted_at = unixepoch() WHERE id = ?").bind(id).run();
        return new Response(JSON.stringify({ status: "ok" }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
