import type { APIRoute } from 'astro';

export const prerender = false;

export const PUT: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { items } = body; // Expecting [{ id: '...', order_index: 0 }, ...]

        if (!Array.isArray(items)) {
            return new Response(JSON.stringify({ error: "Invalid data format" }), { status: 400 });
        }

        // Use a transaction or batch update
        const stmt = db.prepare("UPDATE programs SET order_index = ? WHERE id = ?");
        const batch = items.map((item: any) => stmt.bind(item.order_index, item.id));

        await db.batch(batch);

        return new Response(JSON.stringify({ status: "ok" }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
