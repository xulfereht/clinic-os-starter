import type { APIRoute } from 'astro';

export const prerender = false;

export const PUT: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();

        // Prepare batch update
        const stmt = db.prepare("INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, strftime('%s', 'now'))");
        const batch = [];

        for (const [key, value] of Object.entries(body)) {
            batch.push(stmt.bind(key, value));
        }

        await db.batch(batch);

        return new Response(JSON.stringify({ status: "ok", message: "Settings updated" }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
