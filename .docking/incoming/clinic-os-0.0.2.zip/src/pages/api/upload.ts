import type { APIRoute } from 'astro';

async function generateSignature(key: string, secret: string): Promise<string> {
    const enc = new TextEncoder();
    const algorithm = { name: 'HMAC', hash: 'SHA-256' };
    const keyData = await crypto.subtle.importKey('raw', enc.encode(secret), algorithm, false, ['sign']);
    const signature = await crypto.subtle.sign(algorithm.name, keyData, enc.encode(key));

    // Convert to hex string
    return Array.from(new Uint8Array(signature))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const formData = await request.formData();
        const file = formData.get('file') as File;

        console.log('[Upload Debug] File:', file ? { name: file.name, size: file.size, type: file.type } : 'null');
        console.log('[Upload Debug] Context:', formData.get('context'));

        if (!file) {
            console.error('[Upload Debug] Error: No file provided');
            return new Response(JSON.stringify({ error: 'No file provided' }), { status: 400 });
        }

        // Validate file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
            console.error('[Upload Debug] Error: File too large', file.size);
            const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
            return new Response(JSON.stringify({ error: `파일 크기가 너무 큽니다. (최대 5MB, 현재 ${sizeMB}MB)` }), { status: 400 });
        }

        // Get upload context and optional parameters
        const context = (formData.get('context') as string) || 'messenger';
        const patientId = formData.get('patientId') as string;
        const customPath = formData.get('path') as string;

        let filename: string;
        const uuid = crypto.randomUUID().split('-')[0];
        const originalName = file.name || 'file';
        const ext = originalName.split('.').pop() || 'bin';

        if (customPath) {
            // Legacy: Custom path for assets (programs, etc.)
            // Security check: only allow specific prefixes
            if (!customPath.startsWith('/images/programs/') &&
                !customPath.startsWith('/assets/') ||
                customPath.includes('..')) {
                return new Response(JSON.stringify({
                    error: 'Invalid target path. Must be in /images/programs/ or /assets/'
                }), { status: 400 });
            }
            filename = customPath.startsWith('/') ? customPath.slice(1) : customPath;
        } else {
            // Context-based routing
            const now = new Date();
            const yearMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

            switch (context) {
                case 'patient':
                    // Patient files: patients/{patientId}/{type}/{uuid}.{ext}
                    if (!patientId) {
                        return new Response(JSON.stringify({
                            error: 'patientId is required for patient context'
                        }), { status: 400 });
                    }
                    const fileType = file.type.startsWith('image/') ? 'images' : 'documents';
                    filename = `patients/${patientId}/${fileType}/${uuid}.${ext}`;
                    break;

                case 'asset':
                    // Site assets: assets/{yearMonth}/{uuid}.{ext}
                    filename = `assets/${yearMonth}/${uuid}.${ext}`;
                    break;

                case 'messenger':
                default:
                    // Messenger files (ephemeral): ephemeral/{yearMonth}/{uuid}.{ext}
                    filename = `ephemeral/${yearMonth}/${uuid}.${ext}`;
                    break;
            }
        }

        // Get Cloudflare R2 Binding
        // @ts-ignore
        const bucket = locals.runtime?.env?.BUCKET;

        if (!bucket) {
            console.error('[Upload] CRITICAL: R2 BUCKET binding not found on locals.runtime.env');
            console.error('[Upload] Available Env Keys:', Object.keys(locals.runtime?.env || {}));
            return new Response(JSON.stringify({
                error: 'Server Storage Configuration Error',
                details: 'R2 Bucket binding is missing. Please configure "BUCKET" in Cloudflare Pages Dashboard.'
            }), { status: 500 });
        }

        // Convert file to buffer (Required for R2 put)
        const arrayBuffer = await file.arrayBuffer();

        // R2 Upload (Native Binding)
        // R2 Upload (Native Binding)
        let contentType = file.type;
        // Ensure charset=utf-8 for text files to prevent encoding issues
        if (contentType.startsWith('text/') && !contentType.includes('charset')) {
            contentType += '; charset=utf-8';
        }

        await bucket.put(filename, arrayBuffer, {
            httpMetadata: {
                contentType: contentType,
            },
        });

        // Generate Proxy URL (Secure Access)
        // Instead of a public R2 URL, we point to our own API which checks auth.
        // We sign the URL so external users (e.g. patients) can access it without login.

        let url = `/api/files/${filename}`;

        // Use ADMIN_PASSWORD as secret (simple and effective for this scale)
        // @ts-ignore
        const secret = locals.runtime?.env?.ADMIN_PASSWORD || 'clinic-admin';

        const signature = await generateSignature(filename, secret);

        url += `?sig=${signature}`;

        return new Response(JSON.stringify({
            status: 'ok',
            url,
            filename,
            originalName, // Use the variable which has content
            size: file.size,
            type: file.type
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Upload error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
