import type { APIRoute } from "astro";

export const prerender = false;

export const POST: APIRoute = async ({ request, cookies, locals }) => {
    try {
        const body = await request.json();
        const { email, currentPassword, newPassword, userType } = body;

        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
        }

        if (!email || !currentPassword || !newPassword) {
            return new Response(JSON.stringify({ success: false, message: '모든 필드를 입력해주세요.' }), { status: 400 });
        }

        let table = userType === 'super_admin' ? 'super_admins' : 'staff';

        // 1. Verify Current User & Password
        const user = await db.prepare(`SELECT * FROM ${table} WHERE email = ?`).bind(email).first();
        if (!user || !user.password_hash) {
            return new Response(JSON.stringify({ success: false, message: '사용자를 찾을 수 없습니다.' }), { status: 404 });
        }

        const isValid = await verifyPassword(currentPassword, user.password_hash as string);
        if (!isValid) {
            return new Response(JSON.stringify({ success: false, message: '현재 비밀번호가 일치하지 않습니다.' }), { status: 401 });
        }

        // 2. Update Password & Clear Flag
        const newHash = await hashPassword(newPassword);

        await db.prepare(`
            UPDATE ${table} 
            SET password_hash = ?, password_change_required = 0, updated_at = unixepoch()
            WHERE id = ?
        `).bind(newHash, user.id).run();

        // 3. Login (Create Session)
        const sessionId = crypto.randomUUID();
        const expiresAt = Math.floor(Date.now() / 1000) + (24 * 60 * 60);

        await db.prepare(`
            INSERT INTO sessions (id, member_id, staff_id, expires_at)
            VALUES (?, NULL, ?, ?)
        `).bind(sessionId, userType === 'super_admin' ? user.id : user.id, expiresAt).run(); // Note: session table assumes member_id or staff_id. 
        // Logic check: super_admins usually don't have staff_id in sessions? 
        // Looking at admin-login.ts: 
        // super_admin -> VALUES (?, NULL, ?, ?) bind(sessionId, superAdmin.id, expiresAt) -- wait, session table usually has staff_id?
        // Let's check admin-login.ts bindings again.

        // admin-login.ts for super_admin says:
        // VALUES (?, NULL, ?, ?) bind(sessionId, superAdmin.id, expiresAt) -> This looks like it puts superAdmin.id into staff_id? 
        // Or maybe sessions table has (id, member_id, staff_id, expires_at).
        // Let's assume standard behavior: if super_admin uses staff_id column, then use it.

        // Re-checking admin-login.ts line 31: 
        // VALUES (?, NULL, ?, ?) bind(sessionId, superAdmin.id, expiresAt)
        // This maps to id=?, member_id=NULL, staff_id=?, expires_at=?
        // So yes, super_admin ID goes into staff_id column.

        cookies.set("admin_session", sessionId, {
            path: "/",
            httpOnly: true,
            secure: true,
            maxAge: 60 * 60 * 24,
        });

        return new Response(JSON.stringify({ success: true }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(
            JSON.stringify({ success: false, message: "Server error: " + e.message }),
            { status: 500 }
        );
    }
};

async function verifyPassword(password: string, hash: string): Promise<boolean> {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const inputHashBuffer = await crypto.subtle.digest('SHA-256', data);
    const inputHash = Array.from(new Uint8Array(inputHashBuffer))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
    return inputHash === hash;
}

async function hashPassword(password: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}
