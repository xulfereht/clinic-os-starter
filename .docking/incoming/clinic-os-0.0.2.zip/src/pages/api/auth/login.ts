import type { APIRoute } from "astro";

export const prerender = false;

export const POST: APIRoute = async ({ request, cookies, locals }) => {
    try {
        const body = await request.json();
        const { email, password } = body; // Expect email for members

        // 1. Admin Login Check Removed (Moved to /api/auth/admin-login)


        // 2. Member Login Check
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (db && email) {
            // 2.1 Check Staff (Admin) Login Removed (Moved to /api/auth/admin-login)


            // 2.2 Check Member Login
            const member = await db.prepare("SELECT * FROM web_members WHERE email = ?").bind(email).first();

            if (member) {
                const isValid = await verifyPassword(password, member.password_hash as string);
                if (isValid) {
                    // Check Approval Status
                    if (member.status === 'pending') {
                        return new Response(
                            JSON.stringify({ success: false, message: "가입 승인 대기 중입니다. 관리자 승인 후 이용 가능합니다." }),
                            { status: 401 }
                        );
                    }

                    // Create Session
                    const sessionId = crypto.randomUUID();
                    const expiresAt = Math.floor(Date.now() / 1000) + (30 * 24 * 60 * 60); // 30 days

                    await db.prepare(`
                        INSERT INTO sessions (id, member_id, expires_at)
                        VALUES (?, ?, ?)
                    `).bind(sessionId, member.id, expiresAt).run();

                    cookies.set('session', sessionId, {
                        path: '/',
                        httpOnly: true,
                        secure: true,
                        sameSite: 'lax',
                        maxAge: 30 * 24 * 60 * 60
                    });

                    return new Response(JSON.stringify({ success: true }), { status: 200 });
                }
            }
        }

        return new Response(
            JSON.stringify({ success: false, message: "이메일 또는 비밀번호가 올바르지 않습니다." }),
            { status: 401 }
        );

    } catch (e: any) {
        console.error(e);
        return new Response(
            JSON.stringify({ success: false, message: "Server error: " + e.message }),
            { status: 500 }
        );
    }
};

async function verifyPassword(password: string, hash: string): Promise<boolean> {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const inputHashBuffer = await crypto.subtle.digest('SHA-256', data);
    const inputHash = Array.from(new Uint8Array(inputHashBuffer))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
    return inputHash === hash;
}
