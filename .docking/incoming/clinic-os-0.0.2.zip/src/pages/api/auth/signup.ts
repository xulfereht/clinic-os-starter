import type { APIRoute } from 'astro';

export const prerender = false;

// Signup
export const POST: APIRoute = async ({ request, locals, cookies }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const formData = await request.formData();
        const email = formData.get('email') as string;
        const password = formData.get('password') as string;
        const name = formData.get('name') as string || null;
        const marketingConsent = formData.get('marketing_consent') === 'on';
        const returnTo = formData.get('returnTo') as string || '/';

        // Check if email exists
        const existing = await db.prepare('SELECT id FROM web_members WHERE email = ?').bind(email).first();
        if (existing) {
            return Response.redirect(`/signup?error=${encodeURIComponent('이미 사용 중인 이메일입니다')}&returnTo=${returnTo}`, 302);
        }

        // Hash password (simple for now - in production use bcrypt)
        const passwordHash = await hashPassword(password);

        // Check approval mode setting
        const setting = await db.prepare("SELECT value FROM settings WHERE key = 'member_approval_mode'").first();
        const approvalMode = setting ? setting.value : 'manual';
        const status = approvalMode === 'auto' ? 'approved' : 'pending';

        // Create member
        const memberId = crypto.randomUUID();
        await db.prepare(`
            INSERT INTO web_members (id, email, password_hash, name, marketing_consent, source, status)
            VALUES (?, ?, ?, ?, ?, 'web_signup', ?)
        `).bind(memberId, email, passwordHash, name, marketingConsent ? 1 : 0, status).run();

        if (status === 'approved') {
            // Auto-login: Create session
            const sessionId = crypto.randomUUID();
            // Expires in 7 days
            await db.prepare(`
                INSERT INTO sessions (id, member_id, expires_at)
                VALUES (?, ?, strftime('%s', 'now') + 604800)
            `).bind(sessionId, memberId).run();

            cookies.set('session', sessionId, {
                path: '/',
                httpOnly: true,
                secure: import.meta.env.PROD,
                sameSite: 'lax',
                maxAge: 604800
            });

            return Response.redirect(returnTo, 302);
        } else {
            // Redirect to login with pending message
            return Response.redirect('/login?message=signup_pending', 302);
        }
    } catch (e: any) {
        return Response.redirect(`/signup?error=${encodeURIComponent('가입 중 오류가 발생했습니다')}`, 302);
    }
};

// Simple password hashing (use bcrypt in production)
async function hashPassword(password: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}
