import type { APIRoute } from 'astro';

export const prerender = false;

const logout = async ({ cookies, request }: { cookies: any, request: Request }) => {
    try {
        // robust cookie clearing
        // 1. Delete using Astro's delete method
        cookies.delete('session', { path: '/' });
        cookies.delete('admin_session', { path: '/' });

        // 2. Explicitly overwrite with expired cookies (failsafe)
        cookies.set('admin_session', '', {
            path: '/',
            expires: new Date(0),
            maxAge: 0,
            httpOnly: true,
            secure: true
        });

        cookies.set('session', '', {
            path: '/',
            expires: new Date(0),
            maxAge: 0,
            httpOnly: true,
            secure: true
        });

        // Determine redirect target
        const url = new URL(request.url);
        const isAdminLogout = url.pathname.includes('admin') || request.headers.get('referer')?.includes('/admin');
        const redirectUrl = isAdminLogout ? '/admin/login' : '/';

        return new Response(null, {
            status: 302,
            headers: {
                'Location': redirectUrl,
                'Clear-Site-Data': '"cookies", "storage"' // Modern browsers support this
            }
        });
    } catch (e) {
        console.error("Logout Error:", e);
        return new Response(null, {
            status: 302,
            headers: { 'Location': '/' }
        });
    }
};

export const POST: APIRoute = logout;
export const GET: APIRoute = logout;
