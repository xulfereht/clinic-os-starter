import type { APIRoute } from "astro";

export const prerender = false;

export const POST: APIRoute = async ({ request, cookies, locals }) => {
    try {
        const body = await request.json();
        const { email, password } = body;

        // Get DB for authentication
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
        }

        if (!email) {
            return new Response(JSON.stringify({ error: '이메일을 입력해주세요.' }), { status: 400 });
        }

        // 1. Super Admin Login Check (dedicated table)
        const superAdmin = await db.prepare("SELECT * FROM super_admins WHERE email = ?").bind(email).first();
        if (superAdmin && superAdmin.password_hash) {
            const isValid = await verifyPassword(password, superAdmin.password_hash as string);
            if (isValid) {
                // Check if password change is required
                if (superAdmin.password_change_required === 1) {
                    return new Response(JSON.stringify({
                        success: false,
                        requirePasswordChange: true,
                        userId: superAdmin.id,
                        userType: 'super_admin'
                    }), { status: 200 }); // Not an error, but requires action
                }

                const sessionId = crypto.randomUUID();
                const expiresAt = Math.floor(Date.now() / 1000) + (24 * 60 * 60);

                await db.prepare(`
                    INSERT INTO sessions (id, member_id, staff_id, expires_at)
                    VALUES (?, NULL, ?, ?)
                `).bind(sessionId, superAdmin.id, expiresAt).run();

                cookies.set("admin_session", sessionId, {
                    path: "/",
                    httpOnly: true,
                    secure: true,
                    maxAge: 60 * 60 * 24,
                });

                return new Response(JSON.stringify({ success: true, isAdmin: true, role: 'super_admin' }), { status: 200 });
            }
        }

        // 2. Staff Login Check
        const staff = await db.prepare("SELECT * FROM staff WHERE email = ?").bind(email).first();
        if (staff && staff.password_hash) {
            const isValid = await verifyPassword(password, staff.password_hash as string);
            if (isValid) {
                // Check if password change is required
                if (staff.password_change_required === 1) {
                    return new Response(JSON.stringify({
                        success: false,
                        requirePasswordChange: true,
                        userId: staff.id,
                        userType: 'staff'
                    }), { status: 200 });
                }

                const sessionId = crypto.randomUUID();
                const expiresAt = Math.floor(Date.now() / 1000) + (24 * 60 * 60);

                await db.prepare(`
                    INSERT INTO sessions (id, member_id, staff_id, expires_at)
                    VALUES (?, NULL, ?, ?)
                `).bind(sessionId, staff.id, expiresAt).run();

                cookies.set("admin_session", sessionId, {
                    path: "/",
                    httpOnly: true,
                    secure: true,
                    maxAge: 60 * 60 * 24,
                });

                return new Response(JSON.stringify({ success: true, isAdmin: true, role: staff.role }), { status: 200 });
            }
        }

        return new Response(
            JSON.stringify({ success: false, message: "이메일 또는 비밀번호가 올바르지 않습니다." }),
            { status: 401 }
        );

    } catch (e: any) {
        console.error(e);
        return new Response(
            JSON.stringify({ success: false, message: "Server error: " + e.message }),
            { status: 500 }
        );
    }
};

async function verifyPassword(password: string, hash: string): Promise<boolean> {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const inputHashBuffer = await crypto.subtle.digest('SHA-256', data);
    const inputHash = Array.from(new Uint8Array(inputHashBuffer))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
    return inputHash === hash;
}
