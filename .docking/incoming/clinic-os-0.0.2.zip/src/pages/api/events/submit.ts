
import type { APIRoute } from 'astro';

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const data = await request.json();
        const { name, phone, product, slug } = data;

        // Product can be string or array of strings
        if (!name || !phone || !product || (Array.isArray(product) && product.length === 0)) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
        }

        const campaignSlug = slug || '2025-year-end'; // Default fallback

        // Normalize inputs
        const normalizedPhone = phone.replace(/[^0-9]/g, '');

        // 1. Check for Existing Patient
        let patientId = null;
        let patientType = 'new'; // Standardized: 'new' vs 'returning'

        try {
            const existingPatient = await db.prepare(`
                SELECT id, name FROM patients 
                WHERE REPLACE(REPLACE(current_phone, '-', ''), ' ', '') = ?
            `).bind(normalizedPhone).first();

            if (existingPatient) {
                patientId = existingPatient.id;
                patientType = 'returning'; // Standardized
                console.log(`[EventSubmit] Linked to existing patient: ${existingPatient.name} (${existingPatient.id})`);
            }
        } catch (e) {
            console.warn("Patient lookup failed", e);
        }

        const intakeData = {
            // Ensure product is always an array for consistency in JSON
            products: Array.isArray(product) ? product : [product],
            campaign: campaignSlug,
            applied_at: new Date().toISOString()
        };

        const leadId = crypto.randomUUID();

        await db.prepare(`
            INSERT INTO leads (id, name, contact, type, channel, status, intake_data, patient_id, patient_type, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, unixepoch())
        `).bind(
            leadId,
            name,
            phone, // Keep original format for display
            'event', // [CHANGED] Distinct type for Event
            `campaign_${campaignSlug.replace(/-/g, '_')}`,
            'new',
            JSON.stringify(intakeData),
            patientId,
            patientType
        ).run();


        // --- SHARED: Log Marketing Consent to Unified consent_log Table ---
        const marketingConsent = data.marketing_consent === 'yes' || data.marketing_consent === true;

        try {
            const consentChannels = marketingConsent ? JSON.stringify(["kakao", "sms", "email"]) : null;
            const consentIP = request.headers.get('cf-connecting-ip') || request.headers.get('x-forwarded-for') || 'unknown';
            const consentUA = request.headers.get('user-agent') || 'unknown';

            // 1. Privacy Consent
            const privacyConsent = data.privacy_consent === true;
            await db.prepare(`
                INSERT INTO consent_log (id, patient_id, consent_type, consent, consent_version, consent_text_snapshot, source, ip_address, user_agent, created_at)
                VALUES (?, ?, 'privacy', ?, 'v1.0', ?, 'event-form', ?, ?, unixepoch())
            `).bind(
                crypto.randomUUID(),
                patientId,
                privacyConsent ? 1 : 0,
                '[개인정보 수집·이용 동의]\n목적: 이벤트 참여 및 상담\n항목: 성명, 연락처\n보유기간: 이용 목적 달성 시까지',
                consentIP,
                consentUA
            ).run();

            // 2. Marketing Consent
            await db.prepare(`
                INSERT INTO consent_log (id, patient_id, consent_type, consent, channels, consent_version, consent_text_snapshot, source, ip_address, user_agent, created_at)
                VALUES (?, ?, 'marketing', ?, ?, 'v1.0', ?, 'event-form', ?, ?, unixepoch())
            `).bind(
                crypto.randomUUID(),
                patientId, // might be null if new lead
                marketingConsent ? 1 : 0,
                consentChannels,
                '[마케팅 정보 수신 동의]\n수집 항목: 성명, 연락처, 이메일, 이용 기록\n이용 목적: 혜택, 이벤트, 프로모션 정보 제공\n발송 수단: 문자, 카카오톡, 이메일\n보유 기간: 동의 철회 시까지',
                consentIP,
                consentUA
            ).run();
            console.log(`[Event API] Marketing Consent Logged: ${marketingConsent}`);
        } catch (logError) {
            console.error('[Event API] Failed to log marketing consent:', logError);
        }

        return new Response(JSON.stringify({
            success: true,
            id: leadId,
            linked_patient: !!patientId
        }), { status: 200 });

    } catch (e) {
        console.error("Event Submission Error:", e);
        return new Response(JSON.stringify({ error: 'Internal Server Error', details: e instanceof Error ? e.message : String(e) }), { status: 500 });
    }
};
