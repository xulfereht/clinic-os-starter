import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT m.*, s.name as author_name 
       FROM manual_pages m 
       LEFT JOIN staff s ON m.updated_by = s.id 
       ORDER BY m.category, m.title`
        ).run();

        return new Response(JSON.stringify(results), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const data = await request.json();
        const { title, content, category, updated_by } = data;
        const id = crypto.randomUUID();

        await locals.runtime.env.DB.prepare(
            `INSERT INTO manual_pages (id, title, content, category, updated_by) 
       VALUES (?, ?, ?, ?, ?)`
        ).bind(id, title, content, category, updated_by).run();

        return new Response(JSON.stringify({ id, message: 'Manual created' }), { status: 201 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
