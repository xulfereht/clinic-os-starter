import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT m.*, s.name as author_name 
       FROM manual_pages m 
       LEFT JOIN staff s ON m.updated_by = s.id 
       WHERE m.id = ?`
        ).bind(id).run();

        if (!results.length) {
            return new Response(JSON.stringify({ error: 'Manual not found' }), { status: 404 });
        }

        return new Response(JSON.stringify(results[0]), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    try {
        const data = await request.json();
        const { title, content, category, updated_by } = data;

        await locals.runtime.env.DB.prepare(
            `UPDATE manual_pages 
       SET title = ?, content = ?, category = ?, updated_by = ?, updated_at = unixepoch() 
       WHERE id = ?`
        ).bind(title, content, category, updated_by, id).run();

        return new Response(JSON.stringify({ message: 'Manual updated' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    try {
        await locals.runtime.env.DB.prepare(
            `DELETE FROM manual_pages WHERE id = ?`
        ).bind(id).run();

        return new Response(JSON.stringify({ message: 'Manual deleted' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
