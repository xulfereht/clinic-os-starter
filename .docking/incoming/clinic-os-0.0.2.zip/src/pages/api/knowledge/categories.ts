import type { APIRoute } from "astro";
import { createCategory, toggleCategory } from "../../../lib/knowledge";

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });

    try {
        const body = await request.json();
        const { name } = body;

        if (!name) return new Response(JSON.stringify({ error: "Name is required" }), { status: 400 });

        await createCategory(db, name);
        return new Response(JSON.stringify({ success: true }), { status: 201 });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: "Internal Server Error" }), { status: 500 });
    }
};

export const PUT: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });

    try {
        const body = await request.json();
        const { id, is_enabled } = body;

        if (!id || is_enabled === undefined) return new Response(JSON.stringify({ error: "ID and is_enabled are required" }), { status: 400 });

        await toggleCategory(db, id, is_enabled);
        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: "Internal Server Error" }), { status: 500 });
    }
};
