import type { APIRoute } from "astro";
import { recordInteraction } from "../../../lib/knowledge";

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { staff_id, card_id, type } = body;

        if (!staff_id || !card_id || !type) {
            return new Response(JSON.stringify({ error: "Missing required fields" }), { status: 400 });
        }

        await recordInteraction(db, { staff_id, card_id, type });

        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { "Content-Type": "application/json" }
        });
    } catch (e) {
        console.error("Failed to record interaction:", e);
        return new Response(JSON.stringify({ error: "Internal Server Error" }), { status: 500 });
    }
};
