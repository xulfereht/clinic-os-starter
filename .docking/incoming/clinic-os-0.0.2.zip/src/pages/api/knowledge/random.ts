import type { APIRoute } from "astro";
import { getRandomKnowledgeCard } from "../../../lib/knowledge";

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    // Optional: Filter by role if authenticated staff info is available
    // For now, we'll just take a query param or default to 'All'
    const role = url.searchParams.get("role") || undefined;

    try {
        const card = await getRandomKnowledgeCard(db, role);
        return new Response(JSON.stringify({ card }), {
            status: 200,
            headers: { "Content-Type": "application/json" }
        });
    } catch (e) {
        console.error("Failed to fetch random knowledge card:", e);
        return new Response(JSON.stringify({ error: "Internal Server Error" }), { status: 500 });
    }
};
