import type { APIRoute } from "astro";

export const POST: APIRoute = async ({ request, locals, params }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    const { id } = params;
    if (!id) {
        return new Response(JSON.stringify({ error: "Missing ID" }), { status: 400 });
    }

    try {
        const body = await request.json();
        const note = body.note || '';
        const now = Math.floor(Date.now() / 1000);

        // Update status to needs_revision and set the revision note
        await db.prepare(`
            UPDATE knowledge_cards 
            SET status = 'needs_revision', 
                revision_note = ?, 
                updated_at = ? 
            WHERE id = ?
        `).bind(note, now, id).run();

        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { "Content-Type": "application/json" }
        });
    } catch (e) {
        console.error("Failed to request revision:", e);
        return new Response(JSON.stringify({ error: "Internal Server Error" }), { status: 500 });
    }
};
