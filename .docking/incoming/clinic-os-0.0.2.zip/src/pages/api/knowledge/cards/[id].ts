import type { APIRoute } from "astro";

export const PUT: APIRoute = async ({ request, locals, params }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    const { id } = params;
    if (!id) {
        return new Response(JSON.stringify({ error: "Missing ID" }), { status: 400 });
    }

    try {
        const body = await request.json();
        const now = Math.floor(Date.now() / 1000);

        // Dynamic update query construction
        const updates: string[] = [];
        const values: any[] = [];

        const allowedFields = ['topic', 'category', 'card_type', 'role', 'tags', 'level', 'content', 'status', 'revision_note'];

        for (const field of allowedFields) {
            if (body[field] !== undefined) {
                updates.push(`${field} = ?`);
                if (field === 'tags' || field === 'content') {
                    values.push(JSON.stringify(body[field]));
                } else {
                    values.push(body[field]);
                }
            }
        }

        updates.push("updated_at = ?");
        values.push(now);

        // Where clause
        values.push(id);

        if (updates.length === 0) {
            return new Response(JSON.stringify({ success: true }), { status: 200 });
        }

        const query = `UPDATE knowledge_cards SET ${updates.join(", ")} WHERE id = ?`;
        await db.prepare(query).bind(...values).run();

        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { "Content-Type": "application/json" }
        });
    } catch (e) {
        console.error("Failed to update knowledge card:", e);
        return new Response(JSON.stringify({ error: "Internal Server Error" }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ locals, params }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    const { id } = params;
    if (!id) {
        return new Response(JSON.stringify({ error: "Missing ID" }), { status: 400 });
    }

    try {
        await db.prepare("DELETE FROM knowledge_cards WHERE id = ?").bind(id).run();
        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { "Content-Type": "application/json" }
        });
    } catch (e) {
        console.error("Failed to delete knowledge card:", e);
        return new Response(JSON.stringify({ error: "Internal Server Error" }), { status: 500 });
    }
};
