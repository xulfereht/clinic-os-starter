import type { APIRoute } from "astro";
import { getKnowledgeCards, createKnowledgeCard } from "../../../lib/knowledge";

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    const status = url.searchParams.get("status") || undefined;
    const topic = url.searchParams.get("topic") || undefined;
    const role = url.searchParams.get("role") || undefined;
    const search = url.searchParams.get("search") || undefined;
    const category = url.searchParams.get("category") || undefined;
    const limit = parseInt(url.searchParams.get("limit") || "50");
    const offset = parseInt(url.searchParams.get("offset") || "0");

    try {
        const cards = await getKnowledgeCards(db, { status, topic, role, search, category, limit, offset });
        return new Response(JSON.stringify({ cards }), {
            status: 200,
            headers: { "Content-Type": "application/json" }
        });
    } catch (e) {
        console.error("Failed to fetch knowledge cards:", e);
        return new Response(JSON.stringify({ error: "Internal Server Error" }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        // Basic validation
        if (!body.topic || !body.content || !body.content.one_liner) {
            return new Response(JSON.stringify({ error: "Missing required fields" }), { status: 400 });
        }

        const id = crypto.randomUUID();
        const card = {
            id,
            ...body,
            status: body.status || 'draft',
            created_by: locals.user?.id
        };

        await createKnowledgeCard(db, card);

        return new Response(JSON.stringify({ success: true, id }), {
            status: 201,
            headers: { "Content-Type": "application/json" }
        });
    } catch (e) {
        console.error("Failed to create knowledge card:", e);
        return new Response(JSON.stringify({ error: "Internal Server Error" }), { status: 500 });
    }
};
