import type { APIRoute } from 'astro';
import { getKnowledgeCardsWithCount } from '../../../lib/knowledge';

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    const url = new URL(request.url);
    const search = url.searchParams.get('search') || '';
    const category = url.searchParams.get('category') || '';
    const status = url.searchParams.get('status') || '';
    const limit = parseInt(url.searchParams.get('limit') || '30');
    const offset = parseInt(url.searchParams.get('offset') || '0');

    try {
        const { cards, total } = await getKnowledgeCardsWithCount(db, {
            search: search || undefined,
            category: category || undefined,
            status: status || undefined,
            limit,
            offset
        });

        return new Response(JSON.stringify({
            cards,
            total,
            hasMore: offset + cards.length < total,
            offset: offset + cards.length
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Error fetching cards:', error);
        return new Response(JSON.stringify({ error: 'Failed to fetch cards' }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};
