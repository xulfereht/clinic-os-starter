
import type { APIRoute } from 'astro';

async function generateSignature(key: string, secret: string): Promise<string> {
    const enc = new TextEncoder();
    const algorithm = { name: 'HMAC', hash: 'SHA-256' };
    const keyData = await crypto.subtle.importKey('raw', enc.encode(secret), algorithm, false, ['sign']);
    const signature = await crypto.subtle.sign(algorithm.name, keyData, enc.encode(key));

    // Convert to hex string
    return Array.from(new Uint8Array(signature))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}

async function verifySignature(key: string, signature: string, secret: string): Promise<boolean> {
    if (!signature || !secret || !key) return false;
    const expected = await generateSignature(key, secret);
    return expected === signature;
}

export const GET: APIRoute = async ({ params, request, locals }) => {
    const { key } = params;
    if (!key) {
        return new Response('File not found', { status: 404 });
    }

    // 1. Authentication Check
    // Allow if Admin OR if Valid Signature
    let isAuthorized = false;

    if (locals.user) {
        isAuthorized = true;
    } else {
        // Check Signature
        const url = new URL(request.url);
        const sig = url.searchParams.get('sig');

        if (sig && key) {
            // @ts-ignore
            const secret = locals.runtime?.env?.ADMIN_PASSWORD || 'clinic-admin';
            const isValid = await verifySignature(key as string, sig, secret);
            if (isValid) isAuthorized = true;
        }
    }

    if (!isAuthorized) {
        return new Response('Unauthorized', { status: 401 });
    }

    // 2. Get R2 Bucket
    // @ts-ignore
    const bucket = locals.runtime?.env?.BUCKET;
    if (!bucket) {
        console.error('R2 BUCKET binding not found');
        return new Response('Server Configuration Error', { status: 500 });
    }

    try {
        console.log('1. Fetching key:', key);
        const object = await bucket.get(key);
        console.log('2. Got object:', !!object);

        if (!object) {
            return new Response('File not found', { status: 404 });
        }

        // Simple response handling to avoid serialization issues
        const headers = new Headers();
        headers.set('Content-Type', object.httpMetadata?.contentType || 'application/octet-stream');
        headers.set('ETag', object.httpEtag);
        headers.set('Cache-Control', 'public, max-age=31536000');

        // Read body as ArrayBuffer (safer for local dev than stream)
        const body = await object.arrayBuffer();

        return new Response(body, { headers });

    } catch (e: any) {
        console.error('File retrieval error:', e.message);
        console.error('Requested Key:', key);
        console.error('Bucket Binding Exists:', !!bucket);
        return new Response(`Error fetching file: ${e.message}`, { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    const { key } = params;
    if (!key) {
        return new Response(JSON.stringify({ error: 'File not found' }), { status: 404 });
    }

    // Only authenticated admin users can delete
    if (!locals.user) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    // @ts-ignore
    const bucket = locals.runtime?.env?.BUCKET;
    if (!bucket) {
        return new Response(JSON.stringify({ error: 'Server Configuration Error' }), { status: 500 });
    }

    try {
        console.log('Deleting key:', key);
        await bucket.delete(key);
        console.log('Deleted successfully');
        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        console.error('File deletion error:', e.message);
        return new Response(JSON.stringify({ error: 'Error deleting file: ' + e.message }), { status: 500 });
    }
};
