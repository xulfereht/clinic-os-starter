import type { APIRoute } from 'astro';
import { NaverParser } from '../../../lib/email/NaverParser';
import PostalMime from 'postal-mime';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response('Database not available', { status: 500 });
    }

    // Logging Helper
    const logAttempt = async (status: string, message: string, leadId: string | null = null, preview: string = '') => {
        try {
            const logId = crypto.randomUUID();
            await db.prepare(`
                INSERT INTO webhook_logs (id, received_at, source, payload_preview, status, message, lead_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            `).bind(
                logId,
                Math.floor(Date.now() / 1000),
                'naver_email',
                preview.substring(0, 200),
                status,
                message,
                leadId
            ).run();
        } catch (e) {
            console.error('[Webhook Log Error]', e);
        }
    };

    try {
        const body = await request.json();
        const { from, to, subject, html, text, messageId } = body;

        // Basic validation
        if (!html && !text) {
            await logAttempt('error', 'No content in payload');
            return new Response('No content', { status: 400 });
        }

        const previewText = `Subject: ${subject} | From: ${from}`;

        // 1. Parse Email (Handle Raw MIME if needed)
        let htmlContent = html;
        let textContent = text;

        // Check if text looks like raw email (Cloudflare sometimes sends raw in text)
        if (!html && text && (text.includes('Received:') || text.includes('MIME-Version:'))) {
            try {
                const parser = new PostalMime();
                const email = await parser.parse(text);
                if (email.html) htmlContent = email.html;
                if (email.text) textContent = email.text;
                console.log('[Email Webhook] Parsed raw MIME content');
            } catch (e) {
                console.warn('[Email Webhook] Failed to parse raw MIME:', e);
            }
        }

        let leadData = null;
        if (htmlContent) {
            leadData = NaverParser.parse(htmlContent, subject || '');
        } else {
            leadData = NaverParser.parse(textContent || '', subject || '');
        }

        if (!leadData) {
            console.warn('[Email Webhook] Parsing failed. Creating fallback lead.');
            leadData = {
                name: '파싱실패',
                phone: '',
                inquiry: `[원본 내용] ${(text || '').substring(0, 500)}...`,
                product: '파싱실패',
                reservationDate: null,
                reservationNumber: null,
                rawDate: new Date().toISOString(),
                status: 'UNKNOWN'
            };
        }

        // 2. Filter Logic
        if (leadData.status === 'CONFIRMED') {
            await logAttempt('ignored', 'Confirmed Status', null, previewText);
            return new Response('Ignored confirmed reservation', { status: 200 });
        }

        // 3. Generate Dedupe Key
        const dedupeKey = messageId || `hash_${leadData.phone}_${leadData.rawDate}`;

        // 4. Check Duplicates
        const existing = await db.prepare("SELECT id FROM leads WHERE dedupe_key = ?").bind(dedupeKey).first();
        if (existing) {
            await logAttempt('duplicate', `Duplicate of Lead ${existing.id} (Key: ${dedupeKey})`, existing.id as string, previewText);
            return new Response('Duplicate lead', { status: 200 });
        }

        // 5. Create Lead
        const leadId = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        // Determine Patient Type
        let patientType = 'new_lead';
        let patientId = null;
        try {
            const { findPatientByPhone } = await import('../../../lib/patients/lookup');
            const match = await findPatientByPhone(db, leadData.phone);
            if (match) {
                patientType = 'returning';
                patientId = match.id;
            }
        } catch (e) { /* ignore */ }

        let summaryPrefix = '[네이버예약]';
        let leadStatus = 'new';

        if (leadData.status === 'CANCELLED') {
            summaryPrefix = '[예약취소]';
            leadStatus = 'new';
        } else if (leadData.status === 'CHANGED') {
            summaryPrefix = '[예약변경]';
            leadStatus = 'new';
        }

        const summary = `${summaryPrefix} ${leadData.product || '상품미지정'} - ${leadData.inquiry}`;

        const intakeData = JSON.stringify({
            notes: leadData.inquiry,
            reservation_date: leadData.reservationDate,
            reservation_number: leadData.reservationNumber,
            product: leadData.product,
            source: 'naver_email',
            email_status: leadData.status
        });

        await db.prepare(`
            INSERT INTO leads (
                id, type, status, channel, 
                name, contact, intake_data, 
                created_at, updated_at, 
                dedupe_key, provider_msg_id, summary,
                patient_type, patient_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            leadId,
            'consultation',
            leadStatus,
            'naver_reservation',
            leadData.name,
            leadData.phone,
            intakeData,
            now,
            now,
            dedupeKey,
            messageId,
            summary,
            patientType,
            patientId
        ).run();

        await logAttempt('success', 'Lead Created', leadId, previewText);
        return new Response(JSON.stringify({ success: true, leadId }), { status: 200 });

    } catch (e: any) {
        console.error('[Email Webhook] Error:', e);
        // Can't reliably log if DB is down, but try
        await logAttempt('error', `Exception: ${e.message}`).catch(() => { });
        return new Response(`Error: ${e.message}`, { status: 500 });
    }
};
