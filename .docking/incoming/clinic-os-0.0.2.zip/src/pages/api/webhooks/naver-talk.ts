export const prerender = false;

export async function POST({ request, locals }: { request: Request; locals: any }) {
    try {
        console.log('[Naver Talk Webhook] Received request');

        const data = await request.json();
        console.log('[Naver Talk Webhook] Payload:', JSON.stringify(data, null, 2));

        const db = locals.runtime.env.DB;
        const now = Math.floor(Date.now() / 1000);

        // Extract data from Naver payload
        // Spec: { username: string, icon_url: string, text: string }
        const { username, text } = data;

        if (!username) {
            return new Response(JSON.stringify({ error: 'Missing username' }), { status: 400 });
        }

        const leadId = crypto.randomUUID();

        // Create Lead
        // Note: Naver Talk payload doesn't provide phone number by default.
        // We'll store the text message in intake_data for reference.

        const leadData = {
            id: leadId,
            name: username,
            contact: 'Naver Talk (No Phone)', // Placeholder
            type: 'general',
            status: 'new',
            channel: 'naver_talk',
            patient_type: 'new',
            intake_data: JSON.stringify({
                visit_category: 'Naver Talk Inquiry',
                main_symptom: text,
                source_message: text
            }),
            created_at: now,
            updated_at: now
        };

        await db.prepare(`
            INSERT INTO leads (
                id, name, contact, type, status, channel, patient_type, intake_data, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            leadData.id,
            leadData.name,
            leadData.contact,
            leadData.type,
            leadData.status,
            leadData.channel,
            leadData.patient_type,
            leadData.intake_data,
            leadData.created_at,
            leadData.updated_at
        ).run();

        console.log(`[Naver Talk Webhook] Created lead: ${leadId} for user: ${username}`);

        return new Response(JSON.stringify({ success: true }), { status: 200 });

    } catch (e: any) {
        console.error('[Naver Talk Webhook] Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
