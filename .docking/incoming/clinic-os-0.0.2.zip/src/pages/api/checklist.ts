import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
  try {
    const payload = await request.json();

    // Insert into D1
    // @ts-ignore
    if (locals.runtime?.env?.DB) {
      // @ts-ignore
      const db = locals.runtime.env.DB;
      const id = `chk - ${Date.now()} `;
      await db.prepare(
        "INSERT INTO checklists (id, checklist_id, score, result_title, payload) VALUES (?, ?, ?, ?, ?)"
      ).bind(
        id,
        payload.checklistId,
        payload.score,
        payload.resultTitle,
        JSON.stringify(payload)
      ).run();
    }

    return new Response(JSON.stringify({ status: "ok" }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ status: "error" }), {
      status: 400,
      headers: { "Content-Type": "application/json" }
    });
  }
};
