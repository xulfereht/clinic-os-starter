import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { surveyId, patientId, responses, submittedAt } = body;

        if (!surveyId || !patientId || !responses) {
            return new Response(JSON.stringify({ error: "Missing required fields" }), { status: 400 });
        }

        const id = crypto.randomUUID();
        const now = submittedAt || Math.floor(Date.now() / 1000);

        await db.prepare(`
            INSERT INTO survey_responses (id, patient_id, survey_type, response_data, created_at)
            VALUES (?, ?, ?, ?, ?)
        `).bind(
            id, patientId, surveyId, JSON.stringify(responses), now
        ).run();

        return new Response(JSON.stringify({ success: true, id }), {
            status: 201,
            headers: { "Content-Type": "application/json" }
        });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
