import type { APIRoute } from 'astro';

export const prerender = false;

export const GET: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const survey = await db.prepare("SELECT * FROM surveys WHERE id = ?").bind(id).first();

        if (!survey) {
            return new Response(JSON.stringify({ error: "Survey not found" }), { status: 404 });
        }

        survey.tags = JSON.parse(survey.tags || '[]');

        return new Response(JSON.stringify(survey), {
            status: 200,
            headers: { "Content-Type": "application/json" }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const PUT: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { label, description, path_template, is_public, tags, relatedProgram } = body;

        const now = Math.floor(Date.now() / 1000);

        // Fetch current definition to merge
        const current = await db.prepare("SELECT definition FROM surveys WHERE id = ?").bind(id).first();
        let definition = {};
        if (current && current.definition) {
            try { definition = JSON.parse(current.definition); } catch (e) { }
        }

        // Update relatedProgram in definition
        if (relatedProgram !== undefined) {
            // @ts-ignore
            definition.relatedProgram = relatedProgram;
        }

        await db.prepare(`
            UPDATE surveys 
            SET label = ?, description = ?, path_template = ?, is_public = ?, tags = ?, definition = ?, updated_at = ?
            WHERE id = ?
        `).bind(
            label, description, path_template, is_public ? 1 : 0, JSON.stringify(tags), JSON.stringify(definition), now, id
        ).run();

        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { "Content-Type": "application/json" }
        });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        await db.prepare("UPDATE surveys SET deleted_at = unixepoch() WHERE id = ?").bind(id).run();

        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { "Content-Type": "application/json" }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
