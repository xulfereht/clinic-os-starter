import type { APIRoute } from 'astro';

export const prerender = false;

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const { results } = await db.prepare("SELECT * FROM surveys WHERE deleted_at IS NULL ORDER BY created_at DESC").run();

        // Parse tags JSON
        const surveys = results.map((s: any) => ({
            ...s,
            tags: JSON.parse(s.tags || '[]')
        }));

        return new Response(JSON.stringify(surveys), {
            status: 200,
            headers: { "Content-Type": "application/json" }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { id, label, description, path_template, is_public = false, tags = [], definition = null } = body;

        if (!id || !label || !path_template) {
            return new Response(JSON.stringify({ error: "Missing required fields" }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);

        await db.prepare(`
            INSERT INTO surveys (id, label, description, path_template, is_public, tags, definition, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            id, label, description, path_template, is_public ? 1 : 0, JSON.stringify(tags), definition, now, now
        ).run();

        return new Response(JSON.stringify({ success: true, id }), {
            status: 201,
            headers: { "Content-Type": "application/json" }
        });

    } catch (e: any) {
        if (e.message.includes('UNIQUE constraint failed')) {
            return new Response(JSON.stringify({ error: "ID already exists" }), { status: 409 });
        }
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
