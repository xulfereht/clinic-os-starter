import type { APIRoute } from 'astro';
import { createShortLink } from '../../lib/shortener';

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const body = await request.json();
        const { url, expiresIn } = body;

        if (!url) {
            return new Response(JSON.stringify({ error: 'Missing parameters' }), { status: 400 });
        }

        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
        }

        const { code } = await createShortLink(db, url, expiresIn);

        const origin = new URL(request.url).origin;
        const shortUrl = `${origin}/s/${code}`;

        return new Response(JSON.stringify({ code, shortUrl }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e) {
        console.error('Error shortening link:', e);
        return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
    }
};
