import type { APIRoute } from 'astro';

export const GET: APIRoute = async () => {
    const faqs = [
        {
            q: "주차 가능한가요?",
            a: "네, 건물 지하 주차장에 2시간 무료 주차 가능합니다."
        },
        {
            q: "초진 시 소요 시간은 얼마나 되나요?",
            a: "검사와 상담을 포함하여 약 1시간 정도 소요됩니다."
        },
        {
            q: "야간 진료 하나요?",
            a: "네, 평일은 오후 8시까지 야간 진료를 운영합니다."
        },
        {
            q: "비대면 진료 가능한가요?",
            a: "재진 환자에 한해, 의료진 판단 하에 제한적으로 가능합니다."
        }
    ];

    return new Response(JSON.stringify(faqs), {
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    });
};
