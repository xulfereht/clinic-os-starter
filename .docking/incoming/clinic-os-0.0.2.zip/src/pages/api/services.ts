import type { APIRoute } from 'astro';

export const GET: APIRoute = async () => {
    const services = [
        {
            id: "sulbae",
            name: "술배·복부비만 클리닉",
            description: "태음인 체질 기반의 복부비만 및 간 기능 개선 프로그램",
            target: "배만 나온 체형, 음주가 잦은 직장인",
            duration: "8~12주",
            tags: ["diet", "detox", "liver"]
        },
        {
            id: "fatigue",
            name: "만성피로·수면 클리닉",
            description: "수면의 질 개선과 부신 기능 회복을 통한 피로 관리",
            target: "자고 일어나도 개운하지 않은 분",
            duration: "4~8주",
            tags: ["sleep", "energy"]
        },
        {
            id: "pain",
            name: "통증·교정 클리닉",
            description: "추나요법을 이용한 거북목, 허리 통증 교정",
            target: "장시간 앉아있는 사무직",
            tags: ["pain", "chuna"]
        }
    ];

    return new Response(JSON.stringify(services), {
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    });
};
