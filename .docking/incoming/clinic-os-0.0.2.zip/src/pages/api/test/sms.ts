import type { APIRoute } from 'astro';
import { sendAligoMessage, getAligoConfig } from '../../../lib/aligo';

export const POST: APIRoute = async ({ request, locals }) => {
    // Check for admin authentication (optional but recommended even for test)
    // For now, let's keep it open or check for a special header if needed, 
    // but relying on Admin Layout protections might be enough if this is only reachable from admin side.
    // However, as an API route, it's public. Let's add basic check if user is logged in.
    const user = locals.user;
    if (!user) {
        return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });
    }

    try {
        const formData = await request.formData();
        const receiver = formData.get('receiver')?.toString();
        const msg = formData.get('msg')?.toString() || 'Test Message from BRD Clinic';
        const title = formData.get('title')?.toString();

        if (!receiver) {
            return new Response(JSON.stringify({ error: 'Receiver is required' }), { status: 400 });
        }

        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        // @ts-ignore
        const env = locals.runtime?.env;

        const config = await getAligoConfig(env, db);
        if (!config) {
            return new Response(JSON.stringify({ error: "SMS Configuration Missing" }), { status: 500 });
        }

        const result = await sendAligoMessage(config, {
            receiver,
            msg,
            title
        });

        return new Response(JSON.stringify(result), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error) {
        return new Response(JSON.stringify({
            error: 'Internal Server Error',
            details: error instanceof Error ? error.message : String(error)
        }), { status: 500 });
    }
};
