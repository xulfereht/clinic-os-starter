import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response('Database not found', { status: 500 });
    }

    try {
        const url = new URL(request.url);
        const targetId = url.searchParams.get('id');

        let query = 'SELECT * FROM programs';
        const params = [];

        if (targetId) {
            query += ' WHERE id = ?';
            params.push(targetId);
        }

        const programs = await db.prepare(query).bind(...params).all();
        const results = [];

        for (const program of programs.results) {
            let sections = [];
            try {
                sections = JSON.parse(program.sections as string);
            } catch (e) {
                console.error(`Failed to parse sections for program ${program.id}`, e);
                continue;
            }

            // Check if MiniDiagnosis already exists
            const hasMiniDiagnosis = sections.some((s: any) => s.type === 'MiniDiagnosis');

            if (!hasMiniDiagnosis) {
                const heroIndex = sections.findIndex((s: any) => s.type === 'Hero' || s.type === 'hero');
                const newSection = {
                    type: 'MiniDiagnosis',
                    title: '간편 진단',
                    subtitle: '내 상태 체크하기',
                    data: { programId: program.id }
                };

                if (heroIndex !== -1) {
                    sections.splice(heroIndex + 1, 0, newSection);
                } else {
                    sections.unshift(newSection);
                }

                await db.prepare('UPDATE programs SET sections = ? WHERE id = ?')
                    .bind(JSON.stringify(sections), program.id)
                    .run();

                results.push({ id: program.id, status: 'updated' });
            } else {
                results.push({ id: program.id, status: 'skipped' });
            }
        }

        return new Response(JSON.stringify({ success: true, results }, null, 2), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500 });
    }
};
