import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT * FROM task_templates ORDER BY created_at DESC`
        ).run();

        return new Response(JSON.stringify(results), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const data = await request.json();
        const { title, description, content, subtasks, frequency } = data;
        const id = crypto.randomUUID();

        await locals.runtime.env.DB.prepare(
            `INSERT INTO task_templates (id, title, description, content, subtasks, frequency) 
             VALUES (?, ?, ?, ?, ?, ?)`
        ).bind(id, title, description, content, subtasks || '[]', frequency || 'once').run();

        return new Response(JSON.stringify({ id, message: 'Template created' }), { status: 201 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
