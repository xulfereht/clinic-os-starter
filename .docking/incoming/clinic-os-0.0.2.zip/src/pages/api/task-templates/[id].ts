import type { APIRoute } from 'astro';

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    try {
        const data = await request.json();
        const { title, description, content, subtasks, frequency } = data;

        await locals.runtime.env.DB.prepare(
            `UPDATE task_templates 
             SET title = ?, description = ?, content = ?, subtasks = ?, frequency = ? 
             WHERE id = ?`
        ).bind(title, description, content, subtasks, frequency, id).run();

        return new Response(JSON.stringify({ message: 'Template updated' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    try {
        await locals.runtime.env.DB.prepare(
            `DELETE FROM task_templates WHERE id = ?`
        ).bind(id).run();

        return new Response(JSON.stringify({ message: 'Template deleted' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
