import type { APIRoute } from 'astro';

export const prerender = false;

export const GET: APIRoute = async ({ params, locals, request, url }) => {
    // @ts-ignore
    const db = locals?.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const { id } = params;

        const template = await db.prepare(`
            SELECT * FROM self_diagnosis_templates 
            WHERE id = ? AND status = 'active'
        `).bind(id).first();

        if (!template) {
            return new Response(JSON.stringify({ error: `Template not found for id: ${id}` }), { status: 404 });
        }

        // Parse JSON fields and provide defaults
        const questions = JSON.parse((template.questions as string) || '[]');
        const result_templates = JSON.parse((template.result_templates_json as string) || '{}');
        const cta_config = JSON.parse((template.cta_config as string) || '{}');

        let result: any = {
            ...template,
            questions,
            result_templates: Object.keys(result_templates).length > 0 ? result_templates : {
                general: {
                    title: "진단 분석 결과",
                    description: "회원님의 답변을 바탕으로 분석한 결과입니다. 더 자세한 상담이 필요하시면 아래 버튼을 눌러주세요.",
                    characteristics: ["현재 증상에 대한 다각도 분석이 필요합니다.", "생활 습관 교정이 도움이 될 수 있습니다."],
                    recommendations: ["백록담한의원 전문가와 상담하기", "충분한 휴식과 수분 섭취"]
                }
            },
            cta_config: Object.keys(cta_config).length > 0 ? cta_config : {
                primary: { text: "맞춤 상담 신청하기" }
            }
        };

        // Handle Localization
        const locale = url.searchParams.get('locale');

        if (locale && locale !== 'ko') {
            const translation = await db.prepare(`
                SELECT * FROM self_diagnosis_template_translations 
                WHERE template_id = ? AND locale = ?
            `).bind(id, locale).first();

            if (translation) {
                if (translation.title) result.name = translation.title; // map title to name
                if (translation.questions) {
                    try {
                        result.questions = JSON.parse(translation.questions as string);
                    } catch (e) { }
                }
                if (translation.results) {
                    try {
                        result.result_templates = JSON.parse(translation.results as string);
                    } catch (e) { }
                }
            }
        }

        return new Response(JSON.stringify(result), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error("API Error:", error);
        return new Response(JSON.stringify({
            error: "Internal Server Error",
            details: error instanceof Error ? error.message : String(error)
        }), { status: 500 });
    }
};
