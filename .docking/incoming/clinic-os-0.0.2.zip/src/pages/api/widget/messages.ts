import type { APIRoute } from 'astro';
import { TranslationOrchestrator } from '../../../lib/translation/orchestrator';

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const url = new URL(request.url);
    const channelId = url.searchParams.get('channelId');

    if (!channelId) {
        return new Response(JSON.stringify({ error: 'Channel ID required' }), { status: 400 });
    }

    try {
        // Get the channel and lead info to determine who is the customer
        const channel = await db.prepare("SELECT lead_id, status FROM channels WHERE id = ?").bind(channelId).first();
        const leadId = channel?.lead_id;

        // Default values
        let officialName = 'Customer Support';
        let officialAvatar = ''; // Keep officialAvatar initialization

        // Load officialName from settings if available
        try {
            const setting = await db.prepare("SELECT value FROM site_settings WHERE category = 'widget' AND key = 'official_name'").first();
            if (setting) {
                officialName = setting.value as string;
            }
        } catch (e) {
            console.error("Failed to load official name", e);
        }

        // Fetch official profile settings (for avatar and potentially overriding name)
        const settingsRow = await db.prepare("SELECT value FROM settings WHERE key = 'widget_settings'").first();
        if (settingsRow?.value) {
            try {
                const settings = JSON.parse(settingsRow.value as string);
                // officialName = settings.officialName || officialName; // The new logic for officialName takes precedence
                officialAvatar = settings.officialAvatar || '';
            } catch (e) { }
        }

        // 0. Get lead language preference
        let userLocale = 'en'; // Default fallback
        if (leadId) {
            const l = await db.prepare("SELECT language FROM leads WHERE id = ?").bind(leadId).first() as any;
            if (l && l.language) userLocale = l.language;
        }

        // Fetch messages for this channel
        // Join ONLY the translation for the user's locale
        const { results } = await db.prepare(`
            SELECT 
                m.id, m.channel_id, m.sender_id, m.content, m.created_at, m.file_url, m.file_type,
                mt.translated_text as translation,
                mt.locale as translation_locale
            FROM admin_messages m 
            LEFT JOIN message_translations mt ON m.id = mt.message_id
            WHERE m.channel_id = ? AND m.deleted_at IS NULL
            ORDER BY m.created_at ASC
        `).bind(channelId).all();

        // Transform messages
        // 1. Identify staff senders
        const staffIds = [...new Set(results
            .filter((m: any) => m.sender_id !== leadId && m.sender_id !== 'system')
            .map((m: any) => m.sender_id)
        )];

        // 2. Fetch staff info
        let staffMap = new Map();
        if (staffIds.length > 0) {
            // SQLite 'IN' clause construction
            const placeholders = staffIds.map(() => '?').join(',');
            const { results: staffRows } = await db.prepare(
                `SELECT id, name, name_en, name_hanja, role, position FROM staff WHERE id IN (${placeholders})`
            ).bind(...staffIds).all();

            if (staffRows) {
                staffRows.forEach((s: any) => {
                    staffMap.set(s.id, {
                        name: s.name,
                        name_en: s.name_en,
                        name_hanja: s.name_hanja,
                        role: s.role,
                        position: s.position
                    });
                });
            }
        }

        const messages = results.map((m: any) => {
            const isCustomer = m.sender_id === leadId;
            const isSystem = m.sender_id === 'system';

            // Determine name
            let senderName = null;
            let senderNameEn = null;
            let senderNameHanja = null;
            let senderAvatar = null;
            let senderRole = null;

            if (isSystem) {
                senderName = '시스템';
            } else if (!isCustomer) {
                // Check if it's a known staff member
                const staff = staffMap.get(m.sender_id);
                if (staff) {
                    senderName = staff.name;
                    senderNameEn = staff.name_en;
                    senderNameHanja = staff.name_hanja;
                    senderRole = staff.position || staff.role || 'Staff'; // Priority to position (e.g. Director)
                    senderAvatar = null; // Could add staff avatar later
                } else {
                    // Fallback to official settings if not found in staff table (e.g. super admin or deleted)
                    senderName = officialName;
                    senderAvatar = officialAvatar;
                }
            }

            return {
                id: m.id,
                channel_id: m.channel_id,
                sender_id: m.sender_id,
                content: m.content,
                created_at: m.created_at,
                file_url: m.file_url,
                file_type: m.file_type,
                sender_name: senderName,
                sender_name_en: senderNameEn,
                sender_name_hanja: senderNameHanja,
                sender_role: senderRole,
                is_staff: !isCustomer && !isSystem,
                is_system: isSystem,
                translation: m.translation || null,
                translation_locale: m.translation_locale || null
            };
        });

        // Update last_seen for the lead
        if (leadId) {
            await db.prepare('UPDATE leads SET last_seen = unixepoch() WHERE id = ?').bind(leadId).run();
        }

        return new Response(JSON.stringify({
            success: true,
            messages,
            isClosed: channel?.status === 'closed',
            officialName,
            officialAvatar
        }), {
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0'
            }
        });
    } catch (e: any) {
        console.error('[Widget Messages GET] Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    try {
        const { channelId, content, senderId, leadId } = await request.json();

        if (!channelId || !content) {
            return new Response(JSON.stringify({ error: 'Missing fields' }), { status: 400 });
        }

        const finalSenderId = senderId || leadId;

        const msgId = crypto.randomUUID();

        // Insert Message
        await db.prepare(`
            INSERT INTO admin_messages (id, channel_id, sender_id, content, created_at)
            VALUES (?, ?, ?, ?, unixepoch())
        `).bind(msgId, channelId, finalSenderId, content).run();

        // Update Channel Last Message AND reactivate if closed
        // Update Channel Last Message AND reactivate if closed
        await db.prepare(`
            UPDATE channels 
            SET last_message_at = unixepoch(), 
                last_message = ?,
                status = 'active'
            WHERE id = ?
        `).bind(content, channelId).run();

        // ------------------------------------------------------------
        // 🌐 LANGUAGE DETECTION (Incoming from Widget)
        // We only DETECT and UPDATE lead's language preference here.
        // Translation is done ON-DEMAND when Admin enables Translation Mode.
        // ------------------------------------------------------------
        try {
            const orchestrator = new TranslationOrchestrator(db);

            // 1. Detect Language
            const detectedLang = await orchestrator.detectLanguage(content);
            console.log(`[Widget] Incoming message detected as: ${detectedLang}`);

            if (detectedLang !== 'und' && detectedLang !== 'ko') {
                // 2. Update Lead Language if it's foreign (not Korean)
                // This ensures subsequent admin replies can be translated to this language when toggle is ON.
                let targetLeadId = leadId;
                let isTranslationEnabled = false;

                // Fetch lead_id and translation_enabled from channel
                const channelData = await db.prepare("SELECT lead_id, translation_enabled FROM channels WHERE id = ?").bind(channelId).first();

                if (channelData) {
                    if (!targetLeadId) targetLeadId = channelData.lead_id;
                    isTranslationEnabled = !!channelData.translation_enabled;
                }

                if (targetLeadId) {
                    try {
                        await db.prepare("UPDATE leads SET language = ? WHERE id = ?").bind(detectedLang, targetLeadId).run();
                        console.log(`[Widget] Updated lead ${targetLeadId} language to: ${detectedLang}`);
                    } catch (leadUpdateErr) {
                        console.error('[Widget] Failed to update lead language:', leadUpdateErr);
                    }
                }

                // 3. Auto-Translate if Translation Mode is ON for this channel
                if (isTranslationEnabled) {
                    console.log(`[Widget] Translation Mode ON -> Auto-translating incoming message to Korean`);
                    await orchestrator.translateAndSave(msgId, content, 'ko', detectedLang);
                }
            }
        } catch (translationErr) {
            console.error('[Widget] Language detection failed:', translationErr);
        }

        return new Response(JSON.stringify({ success: true, id: msgId }));

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

