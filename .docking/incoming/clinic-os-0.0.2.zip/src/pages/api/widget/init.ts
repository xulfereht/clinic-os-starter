import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { name, contact, deviceInfo, leadId: magicLeadId } = body;

        let leadId = null;
        let lead = null; // Declare lead variable in outer scope

        // 1. Magic Link / Restore Flow
        if (magicLeadId) {
            // @ts-ignore
            lead = await db.prepare('SELECT * FROM leads WHERE id = ?').bind(magicLeadId).first();
            if (!lead) return new Response(JSON.stringify({ error: 'Invalid lead ID' }), { status: 404 });
            leadId = lead.id;
        }

        // 2. Normal Flow (Name/Contact) - Only if no valid leadId yet
        if (!leadId) {
            if (!contact) {
                return new Response(JSON.stringify({ error: 'Contact is required' }), { status: 400 });
            }

            // Get IP from request headers (set by Cloudflare)
            const ipAddress = request.headers.get('cf-connecting-ip') ||
                request.headers.get('x-forwarded-for')?.split(',')[0] ||
                'unknown';

            // Normalize phone number (remove hyphens, spaces, dots)
            const normalizedContact = contact.replace(/[-\s.]/g, '');
            const formattedContact = contact.includes('@') ? contact :
                (normalizedContact.length === 11 ?
                    `${normalizedContact.slice(0, 3)}-${normalizedContact.slice(3, 7)}-${normalizedContact.slice(7)}` :
                    normalizedContact);

            // Check for existing lead with either format
            // @ts-ignore
            lead = await db.prepare(
                "SELECT * FROM leads WHERE REPLACE(REPLACE(contact, '-', ''), ' ', '') = ? OR contact = ?"
            ).bind(normalizedContact, contact).first();
            leadId = lead?.id;

            // Create Lead if not exists
            if (!lead) {
                leadId = crypto.randomUUID();

                // [CHANGED] Flexible Identity Lookup
                // Check if contact looks like an email
                const isEmail = contact.includes('@');
                let existingPatient = null;

                if (isEmail) {
                    existingPatient = await db.prepare(
                        "SELECT id FROM patients WHERE current_email = ? OR current_email = ?"
                    ).bind(contact, contact.trim()).first();
                } else {
                    // Fallback to phone lookup - check both normalized and formatted versions
                    existingPatient = await db.prepare(
                        "SELECT id FROM patients WHERE REPLACE(REPLACE(current_phone, '-', ''), ' ', '') = ?"
                    ).bind(normalizedContact).first();
                }

                const patientType = existingPatient ? 'returning' : 'new';
                const patientId = existingPatient ? existingPatient.id : null;

                await db.prepare(`
                    INSERT INTO leads (id, name, contact, status, channel, patient_type, patient_id, user_agent, ip_address, device_type, referrer, type, created_at) 
                    VALUES (?, ?, ?, 'new', 'web_widget', ?, ?, ?, ?, ?, ?, 'chat', unixepoch())
                `).bind(
                    leadId,
                    name || '익명 고객',
                    contact,
                    patientType,
                    patientId,
                    deviceInfo?.userAgent || null,
                    ipAddress,
                    deviceInfo?.deviceType || null,
                    deviceInfo?.referrer || null
                ).run();
                // Note: I need to ensure identity_type column exists or just omit it if I don't want to migrate schemas yet.
                // The user said "No major DB changes". I should check if I really need to insert 'identity_type'.
                // Checking previous schema files, 'identity_type' is NOT in 'leads' table.
                // So I will REMOVE 'identity_type' from the INSERT query to be safe, unless I add the migration.
                // Re-writing the query without 'identity_type' to be safe for now, as 'contact' stores the value anyway.

                // Fetch the newly created lead to ensure we have the object
                // @ts-ignore
                lead = { id: leadId, name: name || '익명 고객', contact };
            } else {
                // Update device info if existing lead re-connects
                if (deviceInfo) {
                    await db.prepare(`
                        UPDATE leads SET 
                            user_agent = COALESCE(?, user_agent),
                            ip_address = COALESCE(?, ip_address),
                            device_type = COALESCE(?, device_type),
                            name = COALESCE(?, name)
                        WHERE id = ?
                    `).bind(
                        deviceInfo.userAgent || null,
                        ipAddress || null,
                        deviceInfo.deviceType || null,
                        name || null,
                        leadId
                    ).run();
                }
            }
        }

        let channelId;

        // 4. Find or Create Channel for this Lead
        // Prioritize active channels. If multiple, pick latest.
        // @ts-ignore
        const channel = await db.prepare("SELECT * FROM channels WHERE lead_id = ? AND status != 'closed' ORDER BY created_at DESC").bind(leadId).first();

        if (channel) {
            channelId = channel.id;
        } else {
            // Create new channel
            channelId = crypto.randomUUID();
            await db.prepare(`
                INSERT INTO channels (id, type, name, lead_id, source, status, created_at, last_message_at) 
                VALUES (?, 'customer_support', ?, ?, 'web_widget', 'active', unixepoch(), unixepoch())
            `).bind(channelId, (lead?.name || name || '고객상담'), leadId).run();

            // Link channel back to lead
            await db.prepare("UPDATE leads SET channel_id = ? WHERE id = ?").bind(channelId, leadId).run();
        }

        return new Response(JSON.stringify({
            success: true,
            channelId,
            leadId,
            customerName: lead?.name || name || '고객'
        }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: 'Failed to init chat', details: e.message }), { status: 500 });
    }
}
