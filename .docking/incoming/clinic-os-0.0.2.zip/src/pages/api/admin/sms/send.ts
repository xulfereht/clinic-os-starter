import type { APIRoute } from 'astro';
import { sendAligoMessage, getAligoConfig } from '../../../../lib/aligo';

export const POST: APIRoute = async ({ request, locals, env }) => {
    try {
        const body = await request.json();
        const { receiver, message, type = 'notification', ref_id, lead_id, patient_id } = body;

        const config = await getAligoConfig(env, locals.db);
        if (!config || !config.enabled) {
            return new Response(JSON.stringify({ success: false, error: 'Aligo SMS is not configured or enabled' }), { status: 400 });
        }

        // 1. Send SMS
        const result = await sendAligoMessage(config, {
            receiver,
            msg: message,
            msg_type: 'SMS', // Default to SMS, Aligo auto-upgrades to LMS if needed
            title: type === 'chat_reply' ? '상담 답변' : undefined
        });

        const success = result.result_code === '1';

        // 2. Log to Database
        try {
            await locals.db.prepare(`
                INSERT INTO message_logs (
                    phone, content, status, error_message, 
                    type, lead_id, patient_id, sent_at, created_at, admin_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, strftime('%s', 'now'), ?)
            `).bind(
                receiver,
                message,
                success ? 'sent' : 'failed',
                success ? null : result.message,
                type,
                lead_id || null,
                patient_id || null,
                success ? Math.floor(Date.now() / 1000) : null,
                locals.user?.id || 'system'
            ).run();
        } catch (logError) {
            console.error('Failed to log SMS:', logError);
        }

        if (success) {
            return new Response(JSON.stringify({ success: true, msg_id: result.msg_id }), { status: 200 });
        } else {
            return new Response(JSON.stringify({ success: false, error: result.message }), { status: 400 });
        }

    } catch (error) {
        console.error('SMS Send Error:', error);
        return new Response(JSON.stringify({ success: false, error: 'Internal Server Error' }), { status: 500 });
    }
};
