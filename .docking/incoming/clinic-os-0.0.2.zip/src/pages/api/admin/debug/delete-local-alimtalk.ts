
import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response('No DB', { status: 500 });
    }

    try {
        const { meta } = await db.prepare(
            "UPDATE message_templates SET alimtalk_code = NULL, buttons = NULL WHERE alimtalk_code IS NOT NULL AND alimtalk_code != ''"
        ).run();

        return new Response(JSON.stringify({
            success: true,
            updated_count: meta.changes,
            message: 'Local AlimTalk templates cleared (set to NULL).'
        }, null, 2), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
