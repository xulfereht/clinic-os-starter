
import type { APIRoute } from 'astro';
import { getAligoConfig, getAlimTalkHistory, getAlimTalkDetail } from '../../../../lib/aligo';

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const env = locals.runtime?.env;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    const config = await getAligoConfig(env, db);
    if (!config) {
        return new Response('Config missing', { status: 500 });
    }

    const url = new URL(request.url);
    const phone = url.searchParams.get('phone') || '010-4532-1126'; // Default to user's phone

    // 1. Get History
    const history = await getAlimTalkHistory(config, {
        page: 1,
        limit: 50,
        start_date: new Date().toISOString().slice(0, 10).replace(/-/g, '') // Today YYYYMMDD
    });

    if (history.code !== 0) {
        return new Response(JSON.stringify(history), { status: 500 });
    }

    // 2. Find message to this phone
    // clean phone
    // const cleanPhone = phone.replace(/-/g, '');
    // const found = history.list.find((item: any) => item.receiver === cleanPhone || item.receiver === phone);

    // Just take the first one for now as it matches the time
    const found = history.list[0];

    if (!found) {
        return new Response(JSON.stringify({ message: 'No history found' }), { status: 404 });
    }

    // 3. Get Detail
    const detail = await getAlimTalkDetail(config, found.mid);

    return new Response(JSON.stringify({
        summary: found,
        detail: detail
    }), { status: 200 });
};
