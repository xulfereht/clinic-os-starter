
import type { APIRoute } from 'astro';
import { getAligoConfig, getAligoTemplates, deleteAlimTalkTemplate, type AligoTemplate } from '../../../../lib/aligo';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const env = locals.runtime?.env;

    if (!db) return new Response('No DB', { status: 500 });

    // 1. Get Config
    const config = await getAligoConfig(env, db);
    if (!config || !config.enabled) {
        return new Response('Aligo not configured', { status: 400 });
    }

    // 2. Fetch All Templates from Aligo
    const response = await getAligoTemplates(config);
    if (response.code !== 0) {
        return new Response(JSON.stringify(response), { status: 500 });
    }

    const allTemplates = response.list;
    const grouped: Record<string, AligoTemplate[]> = {};

    // 3. Group by Name
    for (const t of allTemplates) {
        if (!grouped[t.templtName]) {
            grouped[t.templtName] = [];
        }
        grouped[t.templtName].push(t);
    }

    const duplicates = [];
    const deleted = [];
    const errors = [];

    // 4. Process Duplicates
    for (const name in grouped) {
        const group = grouped[name];
        if (group.length > 1) {
            // Found duplicate
            // Sort priority: APR (Approved) > REQ > REG > REJ
            // If same status, take latest cdate

            const sorted = group.sort((a, b) => {
                const statusScore = (s: string) => {
                    if (s === 'APR') return 4;
                    if (s === 'REQ') return 3;
                    if (s === 'REG') return 2;
                    return 1; // REJ or others
                };

                const scoreA = statusScore(a.inspStatus);
                const scoreB = statusScore(b.inspStatus);

                if (scoreA !== scoreB) return scoreB - scoreA; // Descending score

                // If score same, sort by date descending (latest first)
                return b.cdate.localeCompare(a.cdate);
            });

            const winner = sorted[0];
            const losers = sorted.slice(1);

            duplicates.push({
                name: name,
                winner: winner.templtCode,
                losers: losers.map(l => l.templtCode)
            });

            // Delete losers
            for (const loser of losers) {
                // Determine if we can delete. 
                // Aligo might not allow deleting 'REQ' or 'APR' easily?
                // Try deleting.
                const delRes = await deleteAlimTalkTemplate(config, loser.templtCode);
                if (delRes.code === 0) {
                    deleted.push({ name: name, code: loser.templtCode });
                } else {
                    errors.push({ name: name, code: loser.templtCode, message: delRes.message });
                }

                // Rate limit slightly
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }
    }

    return new Response(JSON.stringify({
        total_templates: allTemplates.length,
        duplicate_groups_found: duplicates.length,
        deleted_count: deleted.length,
        details: {
            duplicates,
            deleted,
            errors
        }
    }, null, 2), {
        headers: { 'Content-Type': 'application/json' }
    });
};
