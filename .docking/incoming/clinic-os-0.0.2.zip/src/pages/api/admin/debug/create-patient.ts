export const prerender = false;

export async function GET({ locals }: { locals: any }) {
    try {
        const db = locals.runtime.env.DB;
        const id = crypto.randomUUID();

        await db.prepare(`
            INSERT INTO patients (id, name, current_phone, gender, birth_date, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `).bind(id, '홍길동', '010-1234-5678', 'M', '1990-01-01', Math.floor(Date.now() / 1000), Math.floor(Date.now() / 1000)).run();

        return new Response(JSON.stringify({ success: true, id }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
