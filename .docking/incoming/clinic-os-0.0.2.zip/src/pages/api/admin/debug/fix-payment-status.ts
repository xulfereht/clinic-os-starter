import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response('DB not found', { status: 500 });
    }

    try {
        const updates = [];

        // 1. Fix Paid Customers (active)
        const paidPatients = await db.prepare(`
            SELECT id, name, total_payment, status 
            FROM patients 
            WHERE total_payment > 0 AND status != 'active'
        `).run();

        for (const p of paidPatients.results) {
            await db.prepare(`UPDATE patients SET status = 'active' WHERE id = ?`).bind(p.id).run();
            updates.push(`[Paid] ${p.name}: ${p.status} -> active`);
        }

        // 2. Fix Intake Customers (visit/remote)
        // Only target 'inquiry' status to avoid overwriting manually set statuses
        const inquiryPatients = await db.prepare(`
            SELECT id, name, notes, status 
            FROM patients 
            WHERE status = 'inquiry' AND total_payment = 0
        `).run();

        for (const p of inquiryPatients.results) {
            let newStatus = '';
            if (p.notes && p.notes.includes('비대면 진료 접수')) {
                newStatus = 'remote_first_visit';
            } else if (p.notes && (p.notes.includes('방문 목적') || p.notes.includes('초진 접수'))) {
                newStatus = 'visit_first_visit';
            }

            if (newStatus) {
                await db.prepare(`UPDATE patients SET status = ? WHERE id = ?`).bind(newStatus, p.id).run();
                updates.push(`[Intake] ${p.name}: ${p.status} -> ${newStatus}`);
            }
        }

        return new Response(JSON.stringify({
            message: 'Fixed patient statuses',
            count: updates.length,
            updates
        }, null, 2), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        return new Response(e.message, { status: 500 });
    }
};
