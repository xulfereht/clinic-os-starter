
import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) return new Response('No DB binding found', { status: 500 });

    try {
        // Try selecting to see if it exists
        try {
            await db.prepare("SELECT alimtalk_status FROM message_templates LIMIT 1").first();
            return new Response('Column alimtalk_status already exists.', { status: 200 });
        } catch (e) {
            // Column missing, proceed to add
            console.log("Column missing, adding...");
        }

        await db.prepare("ALTER TABLE message_templates ADD COLUMN alimtalk_status TEXT DEFAULT NULL").run();

        return new Response('Successfully added alimtalk_status column.', { status: 200 });
    } catch (e: any) {
        return new Response(`Error: ${e.message}`, { status: 500 });
    }
};
