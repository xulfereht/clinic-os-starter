
import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response('No DB', { status: 500 });

    try {
        await db.prepare("ALTER TABLE shipments ADD COLUMN sms_sent_at INTEGER").run();
        await db.prepare("ALTER TABLE shipments ADD COLUMN sms_status TEXT").run();

        return new Response(JSON.stringify({ success: true, message: "Columns added" }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
