
import type { APIRoute } from 'astro';
import { getAligoConfig, getAligoTemplates } from '../../../../lib/aligo';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const env = locals.runtime?.env;

    if (!db) return new Response('No DB', { status: 500 });

    // 1. Load Config
    const config = await getAligoConfig(env, db);

    if (!config) {
        return new Response(JSON.stringify({ error: 'Config missing' }), { status: 500 });
    }

    // 3. Call Aligo (List Templates) using shared library function
    const result = await getAligoTemplates(config);

    return new Response(JSON.stringify({
        config: {
            // Mask key for security in logs/response
            key_preview: config.key ? config.key.substring(0, 4) + '...' : 'missing',
            user_id: config.userid,
            sender_key_preview: config.senderKey ? config.senderKey.substring(0, 4) + '...' : 'missing',
            base_url: config.baseUrl
        },
        aligo_response: result
    }, null, 2), {
        headers: { 'Content-Type': 'application/json' }
    });
};
