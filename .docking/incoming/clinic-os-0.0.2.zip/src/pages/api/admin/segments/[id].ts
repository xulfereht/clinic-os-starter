import type { APIRoute } from 'astro';

export const DELETE: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    if (!id) {
        return new Response(JSON.stringify({ error: 'Segment ID required' }), { status: 400 });
    }

    try {
        // Soft delete by setting is_active = 0
        await db.prepare(`
            UPDATE segments SET is_active = 0, updated_at = strftime('%s', 'now')
            WHERE id = ?
        `).bind(id).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        console.error('[Delete Segment] Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const PUT: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { name, criteria } = body;

        await db.prepare(`
            UPDATE segments 
            SET name = ?, criteria = ?, updated_at = strftime('%s', 'now')
            WHERE id = ?
        `).bind(name, JSON.stringify(criteria), id).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
