export const prerender = false;

import type { APIRoute } from 'astro';
import { generateSegmentSql, type SegmentCriteria } from '../../../../lib/segment-engine';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const criteria = body.criteria as SegmentCriteria;
        const exportFormat = body.export; // 'csv' or 'excel'

        if (!criteria) {
            return new Response(JSON.stringify({ error: 'Criteria is required' }), { status: 400 });
        }

        // Generate SQL
        const { sql, params } = generateSegmentSql(criteria);

        // Count total
        const countSql = `SELECT COUNT(*) as count FROM patients WHERE deleted_at IS NULL AND ${sql}`;
        const countResult = await db.prepare(countSql).bind(...params).first();
        const totalCount = countResult?.count || 0;

        if (exportFormat === 'csv' || exportFormat === 'excel') {
            // Export mode - fetch all matching patients (name, phone only)
            const exportSql = `SELECT name, current_phone FROM patients WHERE deleted_at IS NULL AND ${sql} ORDER BY name`;
            const { results } = await db.prepare(exportSql).bind(...params).run();

            if (exportFormat === 'excel') {
                // Simple Excel XML format (compatible with Excel)
                const rows = (results || []).map((row: any) =>
                    `<Row><Cell><Data ss:Type="String">${escapeXml(row.name || '')}</Data></Cell><Cell><Data ss:Type="String">${escapeXml(row.current_phone || '')}</Data></Cell></Row>`
                ).join('');

                const excelXml = `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Worksheet ss:Name="세그먼트">
<Table>
<Row><Cell><Data ss:Type="String">이름</Data></Cell><Cell><Data ss:Type="String">연락처</Data></Cell></Row>
${rows}
</Table>
</Worksheet>
</Workbook>`;

                return new Response(excelXml, {
                    status: 200,
                    headers: {
                        'Content-Type': 'application/vnd.ms-excel',
                        'Content-Disposition': `attachment; filename="segment_export_${Date.now()}.xls"`
                    }
                });
            }

            // CSV format
            const csvLines = ['이름,연락처'];
            for (const row of (results || [])) {
                const name = ((row as any).name || '').replace(/,/g, ' ');
                const phone = ((row as any).current_phone || '').replace(/,/g, ' ');
                csvLines.push(`${name},${phone}`);
            }
            const csvContent = csvLines.join('\n');

            return new Response(csvContent, {
                status: 200,
                headers: {
                    'Content-Type': 'text/csv; charset=utf-8',
                    'Content-Disposition': `attachment; filename="segment_export_${Date.now()}.csv"`
                }
            });
        }

        // Normal mode - return paginated patient list
        const limit = Math.min(body.limit || 20, 500);
        const offset = body.offset || 0;
        const now = Math.floor(Date.now() / 1000);
        const oneYearAgo = now - (365 * 24 * 60 * 60);

        const listSql = `SELECT id, name, current_phone, chart_number, status, last_visit_date, total_payment, visit_count, last_activity_at 
                         FROM patients WHERE deleted_at IS NULL AND ${sql} 
                         ORDER BY name LIMIT ? OFFSET ?`;
        const { results } = await db.prepare(listSql).bind(...params, limit, offset).run();

        // Compute activity-based status for each patient
        const patientsWithComputedStatus = (results || []).map((p: any) => {
            let computed = p.status;

            // Inquiry criteria: visit_first_visit (< 2 visits) OR remote_first_visit (0 payment)
            const isInquiry = (p.status === 'visit_first_visit' && (p.visit_count === null || p.visit_count < 2)) ||
                (p.status === 'remote_first_visit' && (p.total_payment === null || p.total_payment === 0));

            // Active criteria (Recent activity)
            const isRecent = p.last_activity_at && p.last_activity_at >= oneYearAgo;

            if (!isRecent) {
                computed = 'inactive';
            } else if (isInquiry) {
                computed = p.status;
            } else {
                computed = 'active';
            }

            return { ...p, computed_status: computed };
        });

        return new Response(JSON.stringify({
            sql: sql,
            count: totalCount,
            patients: patientsWithComputedStatus,
            hasMore: offset + (results?.length || 0) < totalCount,
            nextOffset: offset + (results?.length || 0)
        }), { status: 200 });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

function escapeXml(str: string): string {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
