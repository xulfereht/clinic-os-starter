export const prerender = false;

import type { APIRoute } from 'astro';
import { generateSegmentSql, type SegmentCriteria } from '../../../../lib/segment-engine';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { name, description, criteria } = body;

        if (!name || !criteria) {
            return new Response(JSON.stringify({ error: 'Name and Criteria are required' }), { status: 400 });
        }

        // Generate the SQL representation for easy execution later
        // Note: We might re-generate this on use to ensure latest logic, but storing it is good for caching or direct use.
        // However, the `criteria` JSON is the source of truth.
        const { sql } = generateSegmentSql(criteria);

        // Save to DB
        const criteriaJson = JSON.stringify(criteria);

        // The query_sql column stores the FULL query or just the sub-query? 
        // Existing segments might use full sub-queries. The new system creates conditions.
        // Let's store "SELECT id FROM patients WHERE ..." as the query_sql to be compatible with `getSegmentMembers` logic if any.
        // Or better, just store the WHERE clause part if we refactor.
        // But for compatibility with `patient detail` calculated segments logic (User logic: Check if patient is in segment),
        // The logic was: `SELECT 1 FROM (${seg.query_sql}) WHERE patient_id = ?`
        // So `query_sql` must be a SELECT statement returning IDs or similar.

        const fullQuerySql = `SELECT id as patient_id FROM patients WHERE deleted_at IS NULL AND (${sql})`;

        const result = await db.prepare(`
            INSERT INTO segments (name, description, criteria, query_sql, is_active, created_at, updated_at)
            VALUES (?, ?, ?, ?, 1, strftime('%s', 'now'), strftime('%s', 'now'))
            RETURNING id
        `).bind(name, description || '', criteriaJson, fullQuerySql).first();

        return new Response(JSON.stringify({
            id: result?.id,
            message: 'Segment saved successfully'
        }), { status: 201 });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { results } = await db.prepare("SELECT * FROM segments WHERE is_active = 1 ORDER BY created_at DESC").run();
    return new Response(JSON.stringify(results), { status: 200 });
};
