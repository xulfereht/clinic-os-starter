import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ url, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    const type = url.searchParams.get('type') || 'total';
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '20'), 100);
    const offset = parseInt(url.searchParams.get('offset') || '0');
    const now = Math.floor(Date.now() / 1000);
    const oneYearAgo = now - (365 * 24 * 60 * 60);

    let whereClause = 'deleted_at IS NULL';

    switch (type) {
        case 'inquiry':
            // 신규/잠재: 최근 1년 내 활동이 있고, (초진 내원 후 2회차 미내원 OR 비대면 후 미결제)
            whereClause += ` AND last_activity_at IS NOT NULL AND last_activity_at >= ${oneYearAgo}`;
            whereClause += ` AND (
                (status = 'visit_first_visit' AND (visit_count IS NULL OR visit_count < 2))
                OR (status = 'remote_first_visit' AND (total_payment IS NULL OR total_payment = 0))
            )`;
            break;
        case 'active':
            // 활성: 1년 내 활동 있음 (Inquiry 제외)
            whereClause += ` AND last_activity_at IS NOT NULL AND last_activity_at >= ${oneYearAgo}`;
            whereClause += ` AND NOT (
                (status = 'visit_first_visit' AND (visit_count IS NULL OR visit_count < 2))
                OR (status = 'remote_first_visit' AND (total_payment IS NULL OR total_payment = 0))
            )`;
            break;
        case 'inactive':
            // 비활성: 1년 넘게 활동 없거나 NULL (Inquiry 여부 상관없이 1년 지났으면 비활성)
            whereClause += ` AND (last_activity_at IS NULL OR last_activity_at < ${oneYearAgo})`;
            break;
        case 'total':
        default:
            // 전체: 삭제 안 된 모든 환자
            break;
    }

    try {
        // Get count
        const countResult = await db.prepare(`SELECT COUNT(*) as count FROM patients WHERE ${whereClause}`).first();
        const count = (countResult?.count as number) || 0;

        // Get paginated patients
        const { results } = await db.prepare(`
            SELECT id, name, current_phone, chart_number, status, visit_count, total_payment, payment_count, last_activity_at, created_at
            FROM patients 
            WHERE ${whereClause}
            ORDER BY last_activity_at DESC NULLS LAST, created_at DESC
            LIMIT ? OFFSET ?
        `).bind(limit, offset).run();

        // Add computed_status based on filter type for display
        // Add computed_status based on activity logic
        const patientsWithComputedStatus = (results || []).map((p: any) => {
            let computed = p.status;

            // Inquiry criteria
            const isInquiry = (p.status === 'visit_first_visit' && (p.visit_count === null || p.visit_count < 2)) ||
                (p.status === 'remote_first_visit' && (p.total_payment === null || p.total_payment === 0));

            // Active criteria (Recent activity)
            const isRecent = p.last_activity_at && p.last_activity_at >= oneYearAgo;

            if (!isRecent) {
                computed = 'inactive';
            } else if (isInquiry) {
                computed = p.status;
            } else {
                computed = 'active';
            }

            return { ...p, computed_status: computed };
        });

        return new Response(JSON.stringify({
            count,
            patients: patientsWithComputedStatus,
            hasMore: offset + results.length < count,
            nextOffset: offset + results.length
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        console.error('[Stats Preview] Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
