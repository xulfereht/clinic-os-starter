import type { APIRoute } from "astro";

export const prerender = false;

export const GET: APIRoute = async ({ url }) => {
    const type = url.searchParams.get('type') || 'tracking';

    let headers: string[] = [];
    let sampleData: string[][] = [];
    let filename = '';

    if (type === 'tracking') {
        headers = ['주문ID', '송장번호', '택배사'];
        sampleData = [
            ['order_abc123', '1234567890123', 'CJ대한통운'],
            ['order_def456', '9876543210987', '한진택배']
        ];
        filename = 'tracking_template';
    } else if (type === 'patients') {
        headers = ['이름', '연락처', '생년월일', '성별', '주소', '메모'];
        sampleData = [
            ['홍길동', '010-1234-5678', '1990-01-15', '남', '서울시 강남구 테헤란로 123', '비대면 다이어트'],
            ['김영희', '010-9876-5432', '1985-07-22', '여', '경기도 성남시 분당구 판교로 456', '']
        ];
        filename = 'patients_template';
    }

    // Generate CSV
    const BOM = '\uFEFF';
    const csv = BOM + [
        '# 아래 샘플 데이터를 지우고 실제 데이터를 입력하세요',
        headers.join(','),
        ...sampleData.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    return new Response(csv, {
        status: 200,
        headers: {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': `attachment; filename="${filename}.csv"`
        }
    });
};
