import type { APIRoute } from "astro";

export const prerender = false;

// GET: List all converters or get one by ID
export const GET: APIRoute = async ({ url, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
    }

    const id = url.searchParams.get('id');
    const targetType = url.searchParams.get('targetType');

    try {
        if (id) {
            const result = await db.prepare("SELECT * FROM data_converters WHERE id = ?").bind(id).first();
            if (!result) {
                return new Response(JSON.stringify({ error: 'Converter not found' }), { status: 404 });
            }
            return new Response(JSON.stringify({
                ...result,
                config: JSON.parse(result.config || '{}')
            }), {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        let query = "SELECT * FROM data_converters";
        if (targetType) {
            query += ` WHERE target_type = '${targetType}'`;
        }
        query += " ORDER BY created_at DESC";

        const results = await db.prepare(query).all();
        const converters = (results.results || []).map((c: any) => ({
            ...c,
            config: JSON.parse(c.config || '{}')
        }));

        return new Response(JSON.stringify(converters), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error: any) {
        console.error('[Converters API] Error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};

// POST: Create new converter
export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { name, description, targetType, config } = body;

        if (!name || !targetType || !config) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
        }

        const id = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        await db.prepare(`
            INSERT INTO data_converters (id, name, description, target_type, config, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `).bind(
            id,
            name,
            description || '',
            targetType,
            JSON.stringify(config),
            now,
            now
        ).run();

        return new Response(JSON.stringify({ success: true, id }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error: any) {
        console.error('[Converters API] Error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};

// DELETE: Remove converter
export const DELETE: APIRoute = async ({ url, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
    }

    const id = url.searchParams.get('id');
    if (!id) {
        return new Response(JSON.stringify({ error: 'ID required' }), { status: 400 });
    }

    try {
        await db.prepare("DELETE FROM data_converters WHERE id = ?").bind(id).run();
        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error: any) {
        console.error('[Converters API] Error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};
