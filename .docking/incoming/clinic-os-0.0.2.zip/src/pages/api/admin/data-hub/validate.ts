import type { APIRoute } from "astro";

export const prerender = false;

export const POST: APIRoute = async ({ request }) => {
    try {
        const formData = await request.formData();
        const file = formData.get('file') as File;
        const type = formData.get('type') as string;

        if (!file) {
            return new Response(JSON.stringify({ error: 'No file provided' }), { status: 400 });
        }

        const text = await file.text();
        const lines = text.split('\n').filter(line => line.trim() && !line.startsWith('#'));

        if (lines.length < 2) {
            return new Response(JSON.stringify({
                error: 'File is empty or has no data rows',
                data: [],
                errors: ['파일에 데이터가 없습니다']
            }), { status: 200 });
        }

        const headers = parseCSVLine(lines[0]);
        const data: any[] = [];
        const errors: string[] = [];

        for (let i = 1; i < lines.length; i++) {
            const values = parseCSVLine(lines[i]);
            if (values.length === 0) continue;

            const row: any = {};
            headers.forEach((h, idx) => {
                row[h] = values[idx] || '';
            });

            // Validate based on type
            const rowErrors = validateRow(type, row, i + 1);
            if (rowErrors.length > 0) {
                errors.push(...rowErrors);
            } else {
                data.push(row);
            }
        }

        return new Response(JSON.stringify({ data, errors }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error: any) {
        console.error('[Validate API] Error:', error);
        return new Response(JSON.stringify({
            error: error.message,
            data: [],
            errors: ['파일 처리 중 오류가 발생했습니다']
        }), { status: 200 });
    }
};

function parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = '';
        } else {
            current += char;
        }
    }
    result.push(current.trim());
    return result;
}

function validateRow(type: string, row: any, lineNum: number): string[] {
    const errors: string[] = [];

    if (type === 'tracking') {
        if (!row['주문ID']) {
            errors.push(`${lineNum}행: 주문ID가 없습니다`);
        }
        if (!row['송장번호']) {
            errors.push(`${lineNum}행: 송장번호가 없습니다`);
        }
    } else if (type === 'patients') {
        if (!row['이름']) {
            errors.push(`${lineNum}행: 이름이 없습니다`);
        }
        if (!row['연락처']) {
            errors.push(`${lineNum}행: 연락처가 없습니다`);
        } else if (!/^\d{2,3}-\d{3,4}-\d{4}$/.test(row['연락처']) && !/^\d{10,11}$/.test(row['연락처'])) {
            errors.push(`${lineNum}행: 연락처 형식이 올바르지 않습니다 (010-1234-5678)`);
        }
    }

    return errors;
}
