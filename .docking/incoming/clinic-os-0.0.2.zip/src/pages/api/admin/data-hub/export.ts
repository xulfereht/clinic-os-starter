import type { APIRoute } from "astro";

export const prerender = false;

export const GET: APIRoute = async ({ url, locals }) => {
    const type = url.searchParams.get('type') || 'leads';
    const range = url.searchParams.get('range') || 'month';
    const filter = url.searchParams.get('filter') || 'all';

    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response('DB not available', { status: 500 });
    }

    try {
        let data: any[] = [];
        let headers: string[] = [];
        let filename = '';

        // Calculate date filter
        const now = Math.floor(Date.now() / 1000);
        const day = 86400;
        let dateFilter = 0;
        if (range === 'today') dateFilter = now - day;
        else if (range === 'week') dateFilter = now - (7 * day);
        else if (range === 'month') dateFilter = now - (30 * day);

        if (type === 'leads') {
            headers = ['이름', '연락처', '유형', '상태', '환자구분', '접수일시', '증상/메모'];
            filename = 'leads';

            let query = `SELECT name, contact, type, status, patient_type, created_at, intake_data FROM leads`;
            if (range !== 'all') {
                query += ` WHERE created_at >= ${dateFilter}`;
            }
            query += ' ORDER BY created_at DESC';

            const result = await db.prepare(query).all();

            data = (result.results || []).map((row: any) => {
                let symptom = '';
                try {
                    const intakeData = JSON.parse(row.intake_data || '{}');
                    symptom = intakeData.main_symptom || '';
                } catch (e) { }

                return [
                    row.name,
                    row.contact,
                    row.type || '일반',
                    row.status || 'new',
                    row.patient_type === 'new' ? '초진' : '재진',
                    new Date(row.created_at * 1000).toLocaleString('ko-KR'),
                    symptom.substring(0, 100)
                ];
            });

        } else if (type === 'patients') {
            headers = ['차트번호', '이름', '연락처', '생년월일', '주소', '등록일'];
            filename = 'patients';

            let query = `SELECT chart_number, name, phone, birthdate, address, created_at FROM patients`;
            if (filter === 'new') {
                query += ` WHERE created_at >= ${now - (30 * day)}`;
            }
            query += ' ORDER BY created_at DESC';

            const result = await db.prepare(query).all();

            data = (result.results || []).map((row: any) => [
                row.chart_number || '',
                row.name,
                row.phone,
                row.birthdate || '',
                row.address || '',
                new Date(row.created_at * 1000).toLocaleDateString('ko-KR')
            ]);

        } else if (type === 'shipping') {
            headers = ['주문ID', '환자명', '연락처', '주소', '상품', '메모', '상태'];
            filename = 'shipping';

            let query = `
                SELECT s.id, p.name, p.phone, s.address, s.items, s.note, s.status
                FROM shipments s
                LEFT JOIN patients p ON s.patient_id = p.id
            `;
            if (filter === 'pending') {
                query += ` WHERE s.status = 'pending'`;
            }
            query += ' ORDER BY s.created_at DESC';

            const result = await db.prepare(query).all();

            data = (result.results || []).map((row: any) => {
                let items = '';
                try {
                    const itemsData = JSON.parse(row.items || '[]');
                    items = itemsData.map((i: any) => i.name || i).join(', ');
                } catch (e) { }

                return [
                    row.id,
                    row.name || '',
                    row.phone || '',
                    row.address || '',
                    items,
                    row.note || '',
                    row.status || 'pending'
                ];
            });
        }

        // Generate CSV
        const BOM = '\uFEFF'; // For Excel UTF-8 support
        const csv = BOM + [headers.join(','), ...data.map(row =>
            row.map((cell: any) => `"${String(cell || '').replace(/"/g, '""')}"`).join(',')
        )].join('\n');

        return new Response(csv, {
            status: 200,
            headers: {
                'Content-Type': 'text/csv; charset=utf-8',
                'Content-Disposition': `attachment; filename="${filename}_${new Date().toISOString().split('T')[0]}.csv"`
            }
        });

    } catch (error: any) {
        console.error('[Export API] Error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};
