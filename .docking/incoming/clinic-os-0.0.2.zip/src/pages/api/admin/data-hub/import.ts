import type { APIRoute } from "astro";

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
        }

        const body = await request.json();
        const { type, data } = body;

        if (!data || !Array.isArray(data) || data.length === 0) {
            return new Response(JSON.stringify({ error: 'No data to import' }), { status: 400 });
        }

        let imported = 0;

        if (type === 'tracking') {
            // Update shipments with tracking numbers
            for (const row of data) {
                const orderId = row['주문ID'];
                const trackingNumber = row['송장번호'];
                const carrier = row['택배사'] || 'CJ대한통운';

                if (!orderId || !trackingNumber) continue;

                try {
                    await db.prepare(`
                        UPDATE shipments 
                        SET tracking_number = ?, carrier = ?, status = 'shipped', shipped_at = ?
                        WHERE id = ? OR id LIKE ?
                    `).bind(
                        trackingNumber,
                        carrier,
                        Math.floor(Date.now() / 1000),
                        orderId,
                        `%${orderId}%`
                    ).run();
                    imported++;
                } catch (e) {
                    console.error(`Failed to update tracking for ${orderId}:`, e);
                }
            }

        } else if (type === 'patients') {
            // Insert new patients
            const now = Math.floor(Date.now() / 1000);

            for (const row of data) {
                const name = row['이름'];
                let phone = row['연락처'];
                const birthdate = row['생년월일'] || null;
                const gender = row['성별'] === '남' ? 'M' : row['성별'] === '여' ? 'F' : null;
                const address = row['주소'] || null;
                const memo = row['메모'] || null;

                if (!name || !phone) continue;

                // Normalize phone number
                phone = phone.replace(/-/g, '');
                if (!phone.startsWith('0')) phone = '0' + phone;

                // Generate chart number
                const chartPrefix = new Date().getFullYear().toString().slice(-2) + (new Date().getMonth() + 1).toString().padStart(2, '0');
                const countResult = await db.prepare(`SELECT COUNT(*) as count FROM patients WHERE chart_number LIKE ?`).bind(`${chartPrefix}%`).first() as { count: number } | null;
                const nextNum = ((countResult?.count || 0) + 1).toString().padStart(4, '0');
                const chartNumber = chartPrefix + nextNum;

                try {
                    await db.prepare(`
                        INSERT INTO patients (id, chart_number, name, phone, birthdate, gender, address, memo, status, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)
                    `).bind(
                        crypto.randomUUID(),
                        chartNumber,
                        name,
                        phone,
                        birthdate,
                        gender,
                        address,
                        memo,
                        now,
                        now
                    ).run();
                    imported++;
                } catch (e) {
                    console.error(`Failed to insert patient ${name}:`, e);
                }
            }
        }

        return new Response(JSON.stringify({
            success: true,
            imported,
            total: data.length
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error: any) {
        console.error('[Import API] Error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};
