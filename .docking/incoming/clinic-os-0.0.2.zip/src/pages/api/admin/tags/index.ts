import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    const db = locals.runtime.env.DB;
    try {
        const { results } = await db.prepare(`
            SELECT * FROM patient_tags 
            WHERE deleted_at IS NULL 
            ORDER BY created_at DESC
        `).run();
        return new Response(JSON.stringify(results));
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ locals, request }) => {
    const db = locals.runtime.env.DB;
    try {
        const body = await request.json();
        const { name, color, category } = body;

        if (!name) {
            return new Response(JSON.stringify({ error: 'Name is required' }), { status: 400 });
        }

        const id = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        await db.prepare(`
            INSERT INTO patient_tags (id, name, color, category, created_at)
            VALUES (?, ?, ?, ?, ?)
        `).bind(id, name, color || 'blue', category || '일반', now).run();

        return new Response(JSON.stringify({ success: true, id }), { status: 201 });
    } catch (e: any) {
        if (e.message.includes('UNIQUE constraint failed')) {
            return new Response(JSON.stringify({ error: 'Duplicate tag name' }), { status: 409 });
        }
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
