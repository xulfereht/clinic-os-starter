import type { APIRoute } from 'astro';

export const DELETE: APIRoute = async ({ params, locals }) => {
    const db = locals.runtime.env.DB;
    const { id } = params;

    try {
        await db.prepare("UPDATE patient_tags SET deleted_at = ? WHERE id = ?")
            .bind(Math.floor(Date.now() / 1000), id)
            .run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const PATCH: APIRoute = async ({ params, request, locals }) => {
    const db = locals.runtime.env.DB;
    const { id } = params;

    try {
        const body = await request.json();
        const { name, color, category } = body;

        let query = "UPDATE patient_tags SET ";
        const updates = [];
        const values = [];

        if (name) {
            updates.push("name = ?");
            values.push(name);
        }
        if (color) {
            updates.push("color = ?");
            values.push(color);
        }
        if (category) {
            updates.push("category = ?");
            values.push(category);
        }

        if (updates.length === 0) {
            return new Response(JSON.stringify({ error: 'No fields to update' }), { status: 400 });
        }

        query += updates.join(", ") + " WHERE id = ?";
        values.push(id);

        await db.prepare(query).bind(...values).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        if (e.message.includes('UNIQUE constraint failed')) {
            return new Response(JSON.stringify({ error: '이미 존재하는 태그명입니다.' }), { status: 409 });
        }
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
