import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ locals }) => {
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response('Database not available', { status: 500 });
    }

    try {
        // 1. Fetch all programs
        const { results: programs } = await db.prepare("SELECT * FROM programs").all();

        let updatedCount = 0;
        const logs: string[] = [];

        for (const program of programs) {
            if (!program.sections) continue;

            let sections: any[] = [];
            try {
                sections = JSON.parse(program.sections as string);
            } catch (e) {
                continue;
            }

            let modified = false;

            // 2. Iterate sections and find 'mechanism' that should be 'process'
            sections = sections.map(section => {
                // Check if type is mechanism AND title contains "절차" (Process) or "순서" (Order)
                // User specifically mentioned "진료 절차" (Treatment Process)
                if (
                    (section.type === 'mechanism' || section.type === 'Mechanism') &&
                    (section.title && (section.title.includes('절차') || section.title.includes('순서') || section.title.includes('Process')))
                ) {
                    logs.push(`[${program.title}] Migrating section "${section.title}" from ${section.type} to process`);
                    section.type = 'process'; // Change type
                    modified = true;
                }
                return section;
            });

            // 3. Save if modified
            if (modified) {
                await db.prepare("UPDATE programs SET sections = ? WHERE id = ?")
                    .bind(JSON.stringify(sections), program.id)
                    .run();
                updatedCount++;
            }
        }

        return new Response(JSON.stringify({
            success: true,
            updatedPrograms: updatedCount,
            logs
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
