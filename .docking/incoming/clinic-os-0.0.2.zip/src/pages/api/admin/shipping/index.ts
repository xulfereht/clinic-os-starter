import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const url = new URL(request.url);
        const statusFilter = url.searchParams.get('status') || 'active'; // active, completed
        const q = url.searchParams.get('q') || '';

        let query = `
            SELECT 
                so.*,
                p.name as patient_name,
                p.current_phone as patient_phone
            FROM shipping_orders so
            JOIN patients p ON so.patient_id = p.id
            WHERE 1=1
        `;
        const params: any[] = [];

        if (statusFilter === 'active') {
            query += " AND so.remaining_quantity > 0";
        } else if (statusFilter === 'completed') {
            query += " AND so.remaining_quantity = 0";
        }

        if (q) {
            query += " AND (p.name LIKE ? OR p.current_phone LIKE ? OR so.product_name LIKE ?)";
            params.push(`%${q}%`, `%${q}%`, `%${q}%`);
        }

        query += " ORDER BY so.next_shipping_date ASC";

        const { results } = await db.prepare(query).bind(...params).run();

        // Calculate Happy Call Status
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime() / 1000;

        const processedResults = results.map((item: any) => {
            let happyCallStatus = 'waiting';

            if (item.next_shipping_date) {
                const nextDate = item.next_shipping_date;
                const sevenDaysBefore = nextDate - (7 * 24 * 60 * 60);

                if (nextDate <= today) {
                    happyCallStatus = 'immediate'; // Deadline passed or is today
                } else if (today >= sevenDaysBefore && item.total_quantity > item.remaining_quantity) {
                    happyCallStatus = 'needed'; // Within 7 days window AND not first cycle (total > remaining)
                }
            } else {
                // Should not happen for active orders, but if so, treat as immediate
                happyCallStatus = 'immediate';
            }

            return {
                ...item,
                happy_call_status: happyCallStatus
            };
        });

        return new Response(JSON.stringify({ success: true, data: processedResults }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
