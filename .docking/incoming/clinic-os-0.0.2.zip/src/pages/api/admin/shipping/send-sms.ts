import type { APIRoute } from 'astro';
import { sendAligoMessage, getAligoConfig } from '../../../../lib/aligo';
import { sendAlimTalkMessage } from '../../../../lib/alimtalk-sender';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const env = locals.runtime?.env;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { shipmentIds, templateId, channel = 'SMS', alimtalkCode } = body;

        if (!shipmentIds || !Array.isArray(shipmentIds) || shipmentIds.length === 0) {
            return new Response(JSON.stringify({ error: 'No shipment IDs provided' }), { status: 400 });
        }

        // Get Aligo config
        const aligoConfig = await getAligoConfig(env, db);
        if (!aligoConfig || !aligoConfig.enabled) {
            return new Response(JSON.stringify({
                error: 'Aligo SMS가 설정되지 않았습니다. 설정 > 연동에서 설정해주세요.'
            }), { status: 400 });
        }

        // Get clinic name for SMS
        const clinicResult = await db.prepare("SELECT name FROM clinics WHERE id = 1").first() as { name: string } | null;
        const clinicName = String(clinicResult?.name || '한의원');

        // Get template if provided
        let templateContent: string | null = null;
        let templateButtons: string | null = null;

        if (templateId) {
            const template = await db.prepare(
                "SELECT content, buttons FROM message_templates WHERE id = ? AND is_active = 1"
            ).bind(templateId).first();
            if (template) {
                templateContent = String(template.content);
                templateButtons = template.buttons ? String(template.buttons) : null;
            }
        }

        let successCount = 0;
        let failCount = 0;
        const errors: string[] = [];

        for (const shipmentId of shipmentIds) {
            try {
                // Get shipment details with patient info
                const shipment = await db.prepare(`
                    SELECT 
                        s.*,
                        so.product_name,
                        p.name as patient_name,
                        p.current_phone as patient_phone
                    FROM shipments s
                    JOIN shipping_orders so ON s.shipping_order_id = so.id
                    JOIN patients p ON so.patient_id = p.id
                    WHERE s.id = ?
                `).bind(shipmentId).first();

                if (!shipment) {
                    failCount++;
                    errors.push(`발송 기록을 찾을 수 없음: ${shipmentId.substring(0, 8)}`);
                    continue;
                }

                // Skip if already sent
                if (shipment.sms_sent_at) {
                    failCount++;
                    errors.push(`이미 발송됨: ${shipment.patient_name}`);
                    continue;
                }

                // Validate phone
                const phone = String(shipment.patient_phone || '').replace(/-/g, '');
                if (!phone || phone.length < 10) {
                    failCount++;
                    errors.push(`전화번호 없음: ${shipment.patient_name}`);
                    continue;
                }

                // Build SMS message
                const trackingNumber = String(shipment.tracking_number || '');
                const cleanTrackingNumber = trackingNumber.replace(/[^0-9]/g, '');
                const trackingUrl = cleanTrackingNumber
                    ? `https://www.cjlogistics.com/ko/tool/parcel/tracking?gnbInvcNo=${cleanTrackingNumber}`
                    : '';

                let message: string;

                // For AlimTalk, we used strict format from DB (templateContent)
                // For SMS, we can use default if template is missing

                let finalContent = templateContent || '';

                if (!finalContent && channel === 'SMS') {
                    // Default SMS Message
                    finalContent = `[${clinicName}] 발송 안내\n\n${shipment.patient_name}님, 주문하신 한약이 발송되었습니다.\n\n처방명: ${shipment.product_name || '한약'}\n운송장: ${trackingNumber || '미등록'}${trackingUrl ? `\n조회: ${trackingUrl}` : ''}\n\n감사합니다.`;
                }

                // Common Substitution
                message = finalContent
                    .replace(/#{clinic_name}|{clinic_name}/g, clinicName)
                    .replace(/#{이름}|{이름}|#{name}|{name}|#{patient_name}|{patient_name}/g, String(shipment.patient_name || ''))
                    .replace(/#{product_name}|{product_name}/g, String(shipment.product_name || '한약'))
                    .replace(/#{tracking_number}|{tracking_number}/g, trackingNumber || '-')
                    .replace(/#{tracking_url}|{tracking_url}/g, trackingUrl || '-');

                // Send 
                let result;
                if (channel === 'ALIMTALK') {
                    if (!alimtalkCode) throw new Error('AlimTalk code missing');

                    // Use sendAlimTalkMessage facade
                    // Note: We use the already substituted 'message' as content
                    result = await sendAlimTalkMessage(aligoConfig, {
                        receiver: phone,
                        template: {
                            name: '배송알림', // Unused by Aligo, just meta
                            content: message,
                            alimtalk_code: alimtalkCode,
                            buttons: templateButtons
                        },
                        variables: {
                            clinic_name: clinicName,
                            clinic_phone: '',
                            patient_name: String(shipment.patient_name || ''),
                            patient_phone: phone,
                            // Extra vars required by template logic?
                            // Just fill minimal valid set
                        },
                        failover: 'Y'
                    });
                } else {
                    // SMS
                    result = await sendAligoMessage(aligoConfig, {
                        receiver: phone,
                        msg: message
                    });
                }

                const now = Math.floor(Date.now() / 1000);

                // Check for success (allow string '1' for SMS or code 0 for AlimTalk)
                const isSuccess = String(result.result_code) === '1' || (result as any).code === 0;

                if (isSuccess) {
                    // Update shipment with SMS status
                    await db.prepare(`
                        UPDATE shipments 
                        SET sms_sent_at = ?, sms_status = 'sent'
                        WHERE id = ?
                    `).bind(now, shipmentId).run();

                    // Log to message_logs
                    await db.prepare(`
                        INSERT INTO message_logs (type, message_type, patient_name, phone, content, status, result_code, created_at, sent_at)
                        VALUES ('shipping', ?, ?, ?, ?, 'sent', ?, ?, ?)
                    `).bind(
                        channel === 'ALIMTALK' ? 'AT' : 'SMS',
                        String(shipment.patient_name || '고객'),
                        phone,
                        message,
                        String((result as any).code || result.result_code || '0'),
                        now,
                        now
                    ).run();

                    successCount++;
                } else {
                    // Update with failed status
                    await db.prepare(`
                        UPDATE shipments 
                        SET sms_status = 'failed'
                        WHERE id = ?
                    `).bind(shipmentId).run();

                    failCount++;
                    const failReason = result.message || `Code: ${result.result_code}`;
                    // Include full result for debugging
                    const debugInfo = JSON.stringify(result);
                    console.error(`SMS Fail [${shipment.patient_name}]:`, result);
                    errors.push(`발송 실패 (${shipment.patient_name}): ${failReason} / Raw: ${debugInfo}`);
                }

            } catch (err: any) {
                failCount++;
                errors.push(`오류: ${err.message}`);
            }
        }

        return new Response(JSON.stringify({
            success: true,
            successCount,
            failCount,
            errors,
            error: errors.length > 0 ? errors.join('\n') : null
        }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('SMS Send Error:', e);
        return new Response(JSON.stringify({
            error: 'Failed to send SMS',
            details: e.message
        }), { status: 500 });
    }
};
