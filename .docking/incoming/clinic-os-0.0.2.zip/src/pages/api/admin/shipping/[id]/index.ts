import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // 1. Get Order Details
        const order = await db.prepare(`
            SELECT 
                so.*,
                p.name as patient_name,
                p.current_phone as patient_phone
            FROM shipping_orders so
            JOIN patients p ON so.patient_id = p.id
            WHERE so.id = ?
        `).bind(id).first();

        if (!order) {
            return new Response(JSON.stringify({ error: 'Order not found' }), { status: 404 });
        }

        // 2. Get Shipment History
        const { results: shipments } = await db.prepare(`
            SELECT * FROM shipments 
            WHERE shipping_order_id = ? 
            ORDER BY created_at DESC
        `).bind(id).run();


        // Calculate Happy Call Status
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime() / 1000;
        let happyCallStatus = 'waiting';

        const typedOrder = order as any;

        if (typedOrder.next_shipping_date) {
            const nextDate = typedOrder.next_shipping_date;
            const sevenDaysBefore = nextDate - (7 * 24 * 60 * 60);

            if (nextDate <= today) {
                happyCallStatus = 'immediate';
            } else if (today >= sevenDaysBefore && typedOrder.total_quantity > typedOrder.remaining_quantity) {
                happyCallStatus = 'needed';
            }
        } else {
            happyCallStatus = 'immediate';
        }

        return new Response(JSON.stringify({
            success: true,
            data: {
                ...order,
                happy_call_status: happyCallStatus,
                shipments
            }
        }), { status: 200 });


    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const PATCH: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { message } = body;

        // Verify existence
        const existing = await db.prepare("SELECT id FROM shipping_orders WHERE id = ?").bind(id).first();
        if (!existing) {
            return new Response(JSON.stringify({ error: 'Order not found' }), { status: 404 });
        }

        const now = Math.floor(Date.now() / 1000);

        if (message !== undefined) {
            await db.prepare(`
                UPDATE shipping_orders 
                SET message = ?, updated_at = ?
                WHERE id = ?
            `).bind(message, now, id).run();
        }

        return new Response(JSON.stringify({ success: true, message }), { status: 200 });
    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
