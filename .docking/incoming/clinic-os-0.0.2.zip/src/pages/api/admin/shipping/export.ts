
import type { APIRoute } from 'astro';
import * as XLSX from 'xlsx';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { orderIds, courier = 'cj' } = body;

        if (!orderIds || !Array.isArray(orderIds) || orderIds.length === 0) {
            return new Response(JSON.stringify({ error: 'No orders selected' }), { status: 400 });
        }

        // Fetch Orders + Patient Info
        const placeholders = orderIds.map(() => '?').join(',');
        const query = `
            SELECT 
                so.*,
                p.name as patient_name,
                p.current_phone,
                p.address_zip,
                p.address_road,
                p.address_detail,
                p.notes as patient_notes
            FROM shipping_orders so
            JOIN patients p ON so.patient_id = p.id
            WHERE so.id IN (${placeholders})
        `;

        const { results } = await db.prepare(query).bind(...orderIds).run();

        // VALIDATION: Check for missing zipcodes
        const invalidItems = results.filter((item: any) => !item.address_zip || item.address_zip.trim() === '');

        if (invalidItems.length > 0) {
            return new Response(JSON.stringify({
                error: 'MISSING_ZIPCODE',
                count: invalidItems.length,
                names: invalidItems.map((i: any) => i.patient_name)
            }), { status: 400 });
        }

        // Generate Excel Data Strategy
        let excelData: any[] = [];
        let header: string[] = [];

        switch (courier) {
            case 'cj':
                // CJ Logistics (CNPlus) Format
                // Header: ['a', 'b', 'name', 'phone', 'e', 'zipcode', 'address', 'h', 'i', 'j', 'k', 'l', 'm', 'requests', 'o', 'p', 'q']
                header = ['a', 'b', 'name', 'phone', 'e', 'zipcode', 'address', 'h', 'i', 'j', 'k', 'l', 'm', 'requests', 'o', 'p', 'q'];
                excelData = results.map((item: any) => {
                    const addressFull = `${item.address_road || ''} ${item.address_detail || ''}`.trim();
                    const cleanPhone = (item.current_phone || '').replace(/[^0-9]/g, '');

                    return {
                        'a': '',
                        'b': '',
                        'name': item.patient_name,
                        'phone': cleanPhone,
                        'e': '',
                        'zipcode': item.address_zip,
                        'address': addressFull,
                        'h': '',
                        'i': '',
                        'j': '',
                        'k': '',
                        'l': '',
                        'm': '',
                        'requests': item.message || '한약 배송',
                        'o': '',
                        'p': '',
                        'q': ''
                    };
                });
                break;

            default:
                return new Response(JSON.stringify({ error: `Unsupported courier: ${courier}` }), { status: 400 });
        }

        // Create Worksheet
        const worksheet = XLSX.utils.json_to_sheet(excelData, {
            header: header,
            skipHeader: false
        });

        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Shipping');

        // Generate Buffer
        const buf = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });

        return new Response(buf, {
            status: 200,
            headers: {
                'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'Content-Disposition': `attachment; filename="shipping_export_${courier}_${new Date().toISOString().split('T')[0]}.xlsx"`
            }
        });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
