import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { date } = body; // YYYY-MM-DD string

        if (!date) {
            return new Response(JSON.stringify({ error: 'Date is required' }), { status: 400 });
        }

        const nextDate = Math.floor(new Date(date).getTime() / 1000);
        const now = Math.floor(Date.now() / 1000);

        await db.prepare(`
            UPDATE shipping_orders 
            SET next_shipping_date = ?, 
                updated_at = ?
            WHERE id = ?
        `).bind(
            nextDate,
            now,
            id
        ).run();

        return new Response(JSON.stringify({ success: true, nextDate }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
