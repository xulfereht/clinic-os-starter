
import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const formData = await request.formData();
        const file = formData.get('file');

        if (!file || !(file instanceof File)) {
            return new Response(JSON.stringify({ error: 'No file uploaded' }), { status: 400 });
        }

        const arrayBuffer = await file.arrayBuffer();
        const decoder = new TextDecoder('euc-kr');
        const csvText = decoder.decode(arrayBuffer);

        const lines = csvText.split('\n');

        let successCount = 0;
        let failCount = 0;
        let errors: string[] = [];

        // Skip header (Row 0: Header "No,...")
        // Data starts from index 1 locally, but let's be safe and check content
        const dataLines = lines.slice(1).filter(line => line.trim() !== '');

        for (const line of dataLines) {
            const cols = line.split(',');
            // CSV Indices based on analysis:
            // 7: Tracking No
            // 15: Quantity (approx, checked manually) -> actually let's re-verify from my viewing.
            // 17: Recipient Name
            // 18: Phone (Masked)

            // Re-verification from my previous view:
            // [Line 1] 1,Incheon...,Date,Date,,Type,OrderNo,TRACKING(7),Code,Sender,Sender,Phone,Addr,Status,Item,QTY(15),RecptNo,NAME(17),PHONE(18),Addr,Media

            if (cols.length < 18) continue;

            const trackingNumber = cols[7]?.trim();
            const quantity = parseInt(cols[15]?.trim() || '1');
            const patientName = cols[17]?.trim();
            const maskedPhone = cols[18]?.trim(); // e.g. 010-1234-****

            if (!trackingNumber || !patientName || !maskedPhone) {
                failCount++;
                errors.push(`Missing data: ${patientName || 'Unknown'} - ${trackingNumber || 'No Tracking'}`);
                continue;
            }

            // Clean phone for matching (remove hyphens from the visible part)
            // e.g. "010-1234-****" -> prefix "0101234" ? Or just keep format matching?
            // DB phone is usually 010-1234-5678 or 01012345678.
            // Let's assume DB has hyphens or not. Best to strip non-digits and match partial.

            // Normalized Prefix from CSV:
            // "010-6858-****" -> "0106858"
            const visibleDigits = maskedPhone.replace(/[*-]/g, '');

            // Find Candidate Orders
            // We want orders that rely on this patient. 
            // Query for ACTIVE orders for patient with this name
            const { results: activeOrders } = await db.prepare(`
                SELECT so.id, so.remaining_quantity, so.total_quantity, p.id as patient_id, p.name, p.current_phone 
                FROM shipping_orders so
                JOIN patients p ON so.patient_id = p.id
                WHERE p.name = ? 
                AND so.remaining_quantity > 0
                ORDER BY so.created_at ASC
            `).bind(patientName).run();

            if (!activeOrders || activeOrders.length === 0) {
                failCount++;
                // errors.push(`No active order found for: ${patientName}`);
                // Don't spam errors for purely missing orders, but maybe useful for user?
                errors.push(`주문 없음: ${patientName}`);
                continue;
            }

            // Find matching patient by phone
            // We need to match the simplified CSV phone with the simplified DB phone
            const match = activeOrders.find((order: any) => {
                const dbPhone = (order.current_phone || '').replace(/-/g, '');
                // Check if dbPhone starts with the visible digits? 
                // Wait, "010-6858-****". The "6858" is the MID number.
                // Standard format: 010-AAAA-BBBB.
                // Masked: 010-AAAA-****.
                // So we match match startsWith(010AAAA).

                // Be careful if it's 010-AAA-BBBB (old format).
                // Just strip non-digits from CSV and check if DB phone starts with it.
                // "0106858" (7 digits). DB "01068581234". StartsWith is safe.

                return dbPhone.startsWith(visibleDigits);
            });

            if (!match) {
                failCount++;
                errors.push(`전화번호 불일치: ${patientName} (${maskedPhone})`);
                continue;
            }

            // Perform Update
            // 1. Create Shipment
            // 2. Update Shipping Order (bucket) using bucket logic

            try {
                // Determine deduction amount (usually 1 box/item from CSV quantity? or just 1?)
                // The CSV quantity is likely the number of boxes.
                // Usually we deduct 1 'unit' of the subscription per shipment event, unless quantity > 1.
                // Let's use the CSV quantity.
                const deductAmount = quantity > 0 ? quantity : 1;

                // Insert Shipment
                const shipmentId = crypto.randomUUID();
                await db.prepare(`
                    INSERT INTO shipments (id, shipping_order_id, type, status, shipped_at, tracking_number, deducted_quantity, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                `).bind(
                    shipmentId,
                    match.id,
                    'courier',
                    'shipped',
                    Math.floor(Date.now() / 1000),
                    trackingNumber,
                    deductAmount,
                    'CSV 일괄 업로드'
                ).run();

                // Update Shipping Order Bucket
                // Decrement remaining, Update last_shipped
                // Determine next shipping date? (Maybe add 21 days? Or leave it to manual/logic?)
                // For now just update the bucket state.

                // If remaining - deduct <= 0, it's completed?
                // Logic:
                const newRemaining = Math.max(0, match.remaining_quantity - deductAmount);
                const isCompleted = newRemaining === 0;

                // For next_shipping_date, if this is a recurring subscription, we might auto-advance.
                // But simplified: just set last_shipped_at. 
                // *User previously mentioned 21 days logic for Happy Call.*
                // Let's keep it simple: update remaining and last_shipped_at.

                await db.prepare(`
                    UPDATE shipping_orders 
                    SET remaining_quantity = ?, 
                        last_shipped_at = ?,
                        updated_at = ?
                    WHERE id = ?
                `).bind(
                    newRemaining,
                    Math.floor(Date.now() / 1000),
                    Math.floor(Date.now() / 1000),
                    match.id
                ).run();

                // Update Patient Last Shipping Date
                const nowKstStr = new Date(Date.now() + (9 * 60 * 60 * 1000)).toISOString().split('T')[0];
                await db.prepare(`
                    UPDATE patients 
                    SET last_shipping_date = ?, 
                        updated_at = unixepoch()
                    WHERE id = ?
                `).bind(nowKstStr, match.patient_id).run();

                successCount++;

            } catch (err: any) {
                console.error(err);
                failCount++;
                errors.push(`DB Error: ${patientName} - ${err.message}`);
            }
        }

        return new Response(JSON.stringify({
            success: true,
            successCount,
            failCount,
            errors
        }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({
            error: 'Failed to process CSV',
            details: e.message
        }), { status: 500 });
    }
};
