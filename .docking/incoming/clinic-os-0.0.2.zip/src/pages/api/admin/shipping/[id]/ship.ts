import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { type, trackingNumber, notes, date } = body; // date is YYYY-MM-DD string or null (use today)

        const now = Math.floor(Date.now() / 1000);
        let shippedAt = now;

        if (date) {
            // Current time in KST
            const nowKst = new Date().toLocaleString('en-US', { timeZone: 'Asia/Seoul' });
            const todayKst = new Date(nowKst);

            // Input date is YYYY-MM-DD. Create a date object for it.
            // We assume input date is also meant to be KST (since user is in Korea)
            const inputDate = new Date(date);

            // Compare YYYY-MM-DD parts
            const isToday =
                todayKst.getFullYear() === inputDate.getFullYear() &&
                todayKst.getMonth() === inputDate.getMonth() &&
                todayKst.getDate() === inputDate.getDate();

            if (isToday) {
                shippedAt = Math.floor(Date.now() / 1000);
            } else {
                // Set to noon to avoid timezone shifting issues
                inputDate.setHours(12, 0, 0, 0);
                shippedAt = Math.floor(inputDate.getTime() / 1000);
            }
        }

        // 1. Get current order state
        const order = await db.prepare("SELECT * FROM shipping_orders WHERE id = ?").bind(id).first() as any;
        if (!order) {
            return new Response(JSON.stringify({ error: 'Order not found' }), { status: 404 });
        }

        if (order.remaining_quantity <= 0) {
            return new Response(JSON.stringify({ error: 'No remaining quantity to ship' }), { status: 400 });
        }

        // 2. Create Shipment Record
        const deductedQuantity = body.skip_deduction ? 0 : 1;

        await db.prepare(`
            INSERT INTO shipments (id, shipping_order_id, type, status, shipped_at, tracking_number, notes, deducted_quantity, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            crypto.randomUUID(),
            id,
            type || 'courier',
            'shipped',
            shippedAt,
            trackingNumber || null,
            notes || '',
            deductedQuantity,
            now
        ).run();

        // 3. Update Shipping Order
        // If skip_deduction is true, we ONLY update last_shipped_at (maybe? or just leave it) and history.
        // Actually, if it's a reshipment, we probably shouldn't touch the next_shipping_date either.

        let newRemaining = order.remaining_quantity;
        let nextDate = order.next_shipping_date;
        let newStatus = order.status;

        if (!body.skip_deduction) {
            newRemaining = order.remaining_quantity - 1;
            // 28 days interval
            nextDate = shippedAt + (28 * 24 * 60 * 60);
            newStatus = newRemaining > 0 ? 'active' : 'completed';
        }

        await db.prepare(`
            UPDATE shipping_orders 
            SET remaining_quantity = ?, 
                last_shipped_at = ?, 
                next_shipping_date = ?,
                status = ?,
                updated_at = ?
            WHERE id = ?
        `).bind(
            newRemaining,
            shippedAt, // Always update last shipped time to reflect activity
            nextDate,
            newStatus,
            now,
            id
        ).run();

        // 4. Update Patient Last Activity and Last Shipping Date
        if (order.patient_id) {
            const shipDateStr = new Date((shippedAt * 1000) + (9 * 60 * 60 * 1000)).toISOString().split('T')[0];
            await db.prepare(`
                UPDATE patients 
                SET last_activity_at = unixepoch(), 
                    updated_at = unixepoch(),
                    last_shipping_date = ?
                WHERE id = ?
            `).bind(shipDateStr, order.patient_id).run();
        }

        return new Response(JSON.stringify({ success: true, nextDate }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
