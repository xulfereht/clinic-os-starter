import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    try {
        const body = await request.json();
        const { myId, targetId } = body;

        if (!myId || !targetId) {
            return new Response(JSON.stringify({ error: 'Both myId and targetId are required' }), { status: 400 });
        }

        // Logic Change:
        // 1. Check if there is an ACTIVE (non-archived) channel for these 2 users.
        //    (We no longer rely on deterministic ID 'ch_A_B' because we want to allow multiple sessions)

        const activeChannel = await db.prepare(`
            SELECT c.id, cm.is_hidden
            FROM channels c
            JOIN channel_members cm ON c.id = cm.channel_id
            WHERE c.type = 'direct'
            AND c.status != 'archived'
            AND cm.user_id = ? 
            AND c.id IN (
                SELECT channel_id FROM channel_members WHERE user_id = ?
            )
            ORDER BY c.created_at DESC
            LIMIT 1
        `).bind(myId, targetId).first();

        if (activeChannel) {
            // Found active channel
            const channelId = activeChannel.id;

            // Unhide if hidden for me
            if (activeChannel.is_hidden) {
                await db.prepare('UPDATE channel_members SET is_hidden = 0 WHERE channel_id = ? AND user_id = ?').bind(channelId, myId).run();
            }
            // Also ensure unhidden for target? Probably good for "New Message" effect, but startChatWith is usually initiator actions.
            // Let's just update me for now.

            return new Response(JSON.stringify({ channelId }), {
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // 2. No active channel found -> Create NEW Channel (New Session)
        const now = Math.floor(Date.now() / 1000);
        const channelId = crypto.randomUUID(); // Use UUID for unique new session

        console.log('[DirectAPI] Creating new channel:', channelId, 'for', myId, targetId);

        // Create Channel
        await db.prepare(`
            INSERT INTO channels (id, type, created_at, last_message_at, status)
            VALUES (?, 'direct', ?, ?, 'active')
        `).bind(channelId, now, now).run();

        // Add Members - Use sequential execution for better stability
        const addMemberQuery = `INSERT INTO channel_members (channel_id, user_id, joined_at, is_hidden) VALUES (?, ?, ?, 0)`;

        try {
            await db.prepare(addMemberQuery).bind(channelId, myId, now).run();
        } catch (e: any) {
            console.error('[DirectAPI] Failed to add sender:', e);
            throw new Error(`Failed to add sender (${myId}): ${e.message}`);
        }

        try {
            await db.prepare(addMemberQuery).bind(channelId, targetId, now).run();
        } catch (e: any) {
            console.error('[DirectAPI] Failed to add target:', e);
            throw new Error(`Failed to add target (${targetId}): ${e.message}`);
        }

        return new Response(JSON.stringify({ channelId }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Direct channel error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
