import type { APIRoute } from 'astro';

export const PUT: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const userId = locals.user?.id;

    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });
    if (!userId) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });

    const { id: channelId } = params;

    try {
        const body = await request.json();
        const { is_hidden } = body;

        if (typeof is_hidden !== 'boolean') {
            return new Response(JSON.stringify({ error: 'Invalid hidden status' }), { status: 400 });
        }

        // Update member status
        await db.prepare('UPDATE channel_members SET is_hidden = ? WHERE channel_id = ? AND user_id = ?')
            .bind(is_hidden ? 1 : 0, channelId, userId)
            .run();

        return new Response(JSON.stringify({ success: true, is_hidden }), { status: 200 });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
