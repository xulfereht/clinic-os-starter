
import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    const channelId = params.id;
    if (!channelId) return new Response(JSON.stringify({ error: 'Channel ID required' }), { status: 400 });

    try {
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) return new Response(JSON.stringify({ error: 'DB connection failed' }), { status: 500 });

        // Update channel status to closed
        await db.prepare(`
            UPDATE channels 
            SET status = 'closed'
            WHERE id = ?
        `).bind(channelId).run();

        // Insert system message to notify customer
        const now = Math.floor(Date.now() / 1000);
        await db.prepare(`
            INSERT INTO admin_messages (id, channel_id, sender_id, content, created_at)
            VALUES (?, ?, 'system', 'SYSTEM:CLOSED', ?)
        `).bind(crypto.randomUUID(), channelId, now).run();

        // Optional: If linked to a lead, verify logic (for now just close channel)
        // You might want to update lead status too if that's the business rule.

        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
    }
};
