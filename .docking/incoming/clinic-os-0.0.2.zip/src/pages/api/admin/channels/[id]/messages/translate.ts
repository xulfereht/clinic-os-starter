import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    // @ts-ignore
    const admin = locals.user;
    if (!admin) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });

    const { id: channelId } = params;

    try {
        const body = await request.json();
        const { messageId, targetLang = 'ko' } = body;

        // 0. Pre-check API Key
        // This allows specific frontend handling (redirect to settings)
        const config = await db.prepare("SELECT api_key FROM ai_configs WHERE provider = 'google_translate' AND is_active = 1").first();
        if (!config || !config.api_key) {
            return new Response(JSON.stringify({ error: 'MISSING_API_KEY' }), { status: 422 });
        }

        // 1. Fetch Message Content
        const message = await db.prepare("SELECT content, sender_id FROM admin_messages WHERE id = ?").bind(messageId).first();
        if (!message) {
            return new Response(JSON.stringify({ error: 'Message not found' }), { status: 404 });
        }

        // 2. Initialize Orchestrator
        // Use dynamic import to avoid load issues if file missing (though we checked it exists)
        const { TranslationOrchestrator } = await import('../../../../../../lib/translation/orchestrator');
        const orchestrator = new TranslationOrchestrator(db);

        // 3. Detect Language (if needed) or force translate
        // We'll just ask to translate to targetLang (Korean usually).
        // If content is already in targetLang, orchestrator handles it (returns null/original).

        // However, user "Manually" clicked translate, so they likely WANT a translation.
        // We pass sourceLang=undefined to let Google detect it.

        const translatedText = await orchestrator.translateAndSave(messageId, message.content, targetLang as string);

        if (!translatedText) {
            // Maybe it failed or was same language.
            // Try fetching it from DB in case it was ALREADY translated?
            const existing = await db.prepare("SELECT translated_text FROM message_translations WHERE message_id = ? AND locale = ?").bind(messageId, targetLang).first();
            if (existing) {
                return new Response(JSON.stringify({ success: true, translation: existing.translated_text }), { status: 200 });
            }

            return new Response(JSON.stringify({ error: 'Translation returned empty (possibly same language)' }), { status: 400 });
        }

        return new Response(JSON.stringify({ success: true, translation: translatedText }), { status: 200 });

    } catch (e: any) {
        console.error('Manual translation failed:', e);
        return new Response(JSON.stringify({ error: e.message || 'Translation failed' }), { status: 500 });
    }
};
