import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    const { id: channelId } = params;

    try {
        const body = await request.json();
        const { userId } = body;

        if (!userId) {
            return new Response(JSON.stringify({ error: 'userId required' }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);

        // Check if is a member
        const existing = await db.prepare(`
            SELECT * FROM channel_members WHERE channel_id = ? AND user_id = ?
        `).bind(channelId, userId).first();

        if (!existing) {
            return new Response(JSON.stringify({ success: true, message: 'Not a member' }), {
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Remove from members
        await db.prepare(`
            DELETE FROM channel_members WHERE channel_id = ? AND user_id = ?
        `).bind(channelId, userId).run();

        // Get staff info for system message
        const staff = await db.prepare('SELECT name FROM staff WHERE id = ?').bind(userId).first();

        // Add system message about leaving (internal only - 'system' sender)
        const messageId = crypto.randomUUID();
        const systemMessage = `${staff?.name || '상담원'}님이 상담에서 나갔습니다.`;
        await db.prepare(`
            INSERT INTO admin_messages (id, channel_id, sender_id, content, created_at)
            VALUES (?, ?, 'system', ?, ?)
        `).bind(messageId, channelId, systemMessage, now).run();

        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Leave channel error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
