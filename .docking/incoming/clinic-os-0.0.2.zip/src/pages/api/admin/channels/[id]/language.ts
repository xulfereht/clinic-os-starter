import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const pusher = locals.runtime?.env?.PUSHER;

    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    const { id: channelId } = params;
    const body = await request.json();
    const { language } = body;

    if (!language) {
        return new Response(JSON.stringify({ error: 'Language is required' }), { status: 400 });
    }

    try {
        const channel = await db.prepare('SELECT lead_id FROM channels WHERE id = ?').bind(channelId).first();
        if (!channel || !channel.lead_id) {
            return new Response(JSON.stringify({ error: 'Channel or Lead not found' }), { status: 404 });
        }

        // Update lead language
        await db.prepare('UPDATE leads SET language = ? WHERE id = ?')
            .bind(language, channel.lead_id)
            .run();

        // Optional: Log action
        // await db.prepare("INSERT INTO admin_audit_logs ...").run(); 

        return new Response(JSON.stringify({ success: true, language }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        console.error('Failed to update language:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
