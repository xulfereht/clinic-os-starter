import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    const channelId = params.id;
    if (!channelId) {
        return new Response(JSON.stringify({ error: 'Channel ID required' }), { status: 400 });
    }

    try {
        const body = await request.json();
        const { enabled } = body;

        if (typeof enabled !== 'boolean') {
            return new Response(JSON.stringify({ error: 'Invalid enabled value' }), { status: 400 });
        }

        // Update channel
        await db.prepare("UPDATE channels SET translation_enabled = ? WHERE id = ?")
            .bind(enabled ? 1 : 0, channelId)
            .run();

        return new Response(JSON.stringify({ success: true, enabled }));
    } catch (e: any) {
        console.error('Failed to update translation mode:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
