import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    const url = new URL(request.url);
    const userId = url.searchParams.get('userId');
    const { id: channelId } = params;

    try {
        // 1. Get channel details
        const channel = await db.prepare('SELECT * FROM channels WHERE id = ?').bind(channelId).first();
        if (!channel) {
            return new Response(JSON.stringify({ error: 'Channel not found' }), { status: 404 });
        }

        // 2. Get members with their info
        const { results: memberRows } = await db.prepare(`
            SELECT cm.user_id, cm.joined_at, s.name, s.image, s.role, s.email
            FROM channel_members cm
            LEFT JOIN staff s ON cm.user_id = s.id
            WHERE cm.channel_id = ?
        `).bind(channelId).all();
        const members = memberRows.map((m: any) => ({
            id: m.user_id,
            name: m.name || m.user_id,
            image: m.image,
            role: m.role,
            email: m.email,
            joined_at: m.joined_at,
        }));

        // 3. If customer support, get lead info
        let lead = null;
        if (channel.type === 'customer_support' && channel.lead_id) {
            lead = await db.prepare('SELECT * FROM leads WHERE id = ?').bind(channel.lead_id).first();
        }

        // 4. Compute display_name and display_image
        let displayName = channel.name;
        let displayImage = null;
        if (channel.type === 'direct' && userId) {
            const partner = members.find((m: any) => m.id !== userId);
            if (partner) {
                displayName = partner.name;
                displayImage = partner.image;
            }
        } else if (channel.type === 'group') {
            if (!channel.name || channel.name === '그룹 채팅') {
                displayName = members.map((m: any) => m.name).join(', ');
            }
        } else if (channel.type === 'customer_support' && lead) {
            displayName = lead.name || '고객';
        }

        return new Response(JSON.stringify({
            channel: {
                ...channel,
                display_name: displayName,
                display_image: displayImage,
            },
            members,
            lead,
        }), {
            headers: { 'Content-Type': 'application/json' },
        });
    } catch (e: any) {
        console.error('Channel info error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
