import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    const url = new URL(request.url);
    const userId = url.searchParams.get('userId');

    if (!userId) return new Response(JSON.stringify({ error: 'UserId required' }), { status: 400 });

    try {
        // [Safety Check] Ensure Public Channel Exists & I am a member
        const publicChannelId = 'global-public-channel';
        const now = Math.floor(Date.now() / 1000);

        // 1. Check/Create Public Channel
        await db.prepare(`
            INSERT OR IGNORE INTO channels (id, type, name, created_at, last_message_at)
            VALUES (?, 'public', '전체 대화방', ?, ?)
        `).bind(publicChannelId, now, now).run();

        // 2. Check if user exists in staff table (to avoid FK constraint error)
        const userExists = await db.prepare('SELECT id FROM staff WHERE id = ?').bind(userId).first();

        if (userExists) {
            // 3. Check/Join Public Channel (only if user is valid staff)
            await db.prepare(`
                INSERT OR IGNORE INTO channel_members (channel_id, user_id, joined_at)
                VALUES (?, ?, ?)
            `).bind(publicChannelId, userId, now).run();
        }


        // 1. Get my channels (Team Chat)
        // Also fetch the other member info if it's a DM
        // Use simpler query to avoid potential JOIN issues if schema is murky
        const { results: myChannels } = await db.prepare(`
            SELECT 
                c.*,
                cm.last_read_at as my_last_read_at,
                cm.is_hidden as is_hidden,
                (SELECT COUNT(*) FROM admin_messages m WHERE m.channel_id = c.id AND m.created_at > cm.last_read_at) as unread_count,
                (SELECT content FROM admin_messages m WHERE m.channel_id = c.id ORDER BY created_at DESC LIMIT 1) as computed_last_message,
                (SELECT sender_id FROM admin_messages m WHERE m.channel_id = c.id ORDER BY created_at DESC LIMIT 1) as last_sender_id
            FROM channels c
            JOIN channel_members cm ON c.id = cm.channel_id
            WHERE cm.user_id = ?
            ORDER BY c.last_message_at DESC
        `).bind(userId).all();

        // 2. Get Customer Support Channels (Visible to all admins)
        // Calculate unread based on member's last_read_at if they are a member
        const { results: customerChannels } = await db.prepare(`
            SELECT 
                c.*,
                COALESCE(cm.last_read_at, 0) as my_last_read_at, 
                COALESCE((SELECT COUNT(*) FROM admin_messages m WHERE m.channel_id = c.id AND m.created_at > COALESCE(cm.last_read_at, 0)), 0) as unread_count,
                (SELECT content FROM admin_messages m WHERE m.channel_id = c.id ORDER BY created_at DESC LIMIT 1) as computed_last_message,
                (SELECT sender_id FROM admin_messages m WHERE m.channel_id = c.id ORDER BY created_at DESC LIMIT 1) as last_sender_id
            FROM channels c
            LEFT JOIN channel_members cm ON c.id = cm.channel_id AND cm.user_id = ?
            WHERE c.type = 'customer_support'
            ORDER BY c.last_message_at DESC
        `).bind(userId).all();

        // Combine
        const allRows = [...(myChannels || []), ...(customerChannels || [])];
        // Unique by ID (just in case)
        const uniqueRows = Array.from(new Map(allRows.map((item: any) => [item.id, item])).values());

        // 3. Proceess results to add helpful metadata
        const { results: staff } = await db.prepare('SELECT id, name, image FROM staff').all();
        const staffMap = new Map(staff.map((s: any) => [s.id, s]));

        const channels = await Promise.all(uniqueRows.map(async (c: any) => {
            let displayName = c.name;
            let displayImage = null;
            let memberNames: string[] = [];

            if (c.type === 'direct') {
                // Find the other member
                const { results: otherMembers } = await db.prepare(`
                    SELECT user_id FROM channel_members WHERE channel_id = ? AND user_id != ?
                `).bind(c.id, userId).all();

                if (otherMembers.length > 0) {
                    const partnerId = otherMembers[0].user_id;
                    const partner = staffMap.get(partnerId);
                    if (partner) {
                        displayName = partner.name;
                        displayImage = partner.image;
                        memberNames = [partner.name];
                    }
                }
            } else if (c.type === 'group') {
                // Get all group members
                const { results: groupMembers } = await db.prepare(`
                    SELECT user_id FROM channel_members WHERE channel_id = ?
                `).bind(c.id).all();
                memberNames = groupMembers
                    .map((m: any) => staffMap.get(m.user_id)?.name)
                    .filter(Boolean) as string[];

                // Auto-generate group name if not set
                if (!c.name || c.name === '그룹 채팅') {
                    displayName = memberNames.join(', ') || '그룹 채팅';
                }
            } else if (c.type === 'customer_support') {
                // For customer support, name is already set to Customer Name (e.g. "홍길동")
                // Image could be null or a generic user icon
            }

            return {
                ...c,
                display_name: displayName,
                display_image: displayImage,
                member_names: memberNames,
                // Prioritize computed_last_message (real-time) over c.last_message (cached/column)
                last_message: c.computed_last_message || c.last_message
            };
        }));

        // Sort again by last_message_at
        channels.sort((a, b) => (b.last_message_at || 0) - (a.last_message_at || 0));

        return new Response(JSON.stringify({ channels }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error("API Error /admin/channels:", e);
        return new Response(JSON.stringify({ error: e.message, stack: e.stack }), { status: 500 });
    }
};
