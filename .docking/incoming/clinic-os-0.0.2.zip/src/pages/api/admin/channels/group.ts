import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    try {
        const body = await request.json();
        const { name, members, creatorId } = body;

        if (!members || members.length === 0) {
            return new Response(JSON.stringify({ error: 'Members required' }), { status: 400 });
        }

        const channelId = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        // 1. Create Channel
        await db.prepare(`
            INSERT INTO channels (id, name, type, created_at, last_message_at)
            VALUES (?, ?, 'group', ?, ?)
        `).bind(channelId, name || '그룹 채팅', now, now).run();

        // 2. Add Members (Creator + Selected Members)
        // Wrap each in try-catch to handle FK constraints gracefully
        const allMembers = new Set([...members, creatorId]);

        for (const memberId of allMembers) {
            try {
                await db.prepare(`
                    INSERT INTO channel_members (channel_id, user_id, joined_at, last_read_at)
                    VALUES (?, ?, ?, ?)
                `).bind(channelId, memberId, now, now).run();
            } catch (e) {
                console.warn('Could not add member (FK constraint?):', memberId);
            }
        }

        return new Response(JSON.stringify({ success: true, channelId }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Group channel error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
