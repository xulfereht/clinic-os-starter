import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    const { id: channelId } = params;

    let userId = '';

    try {
        const body = await request.json();
        userId = body.userId;

        if (!userId) {
            return new Response(JSON.stringify({ error: 'userId required' }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);

        // Check if user exists in staff table
        const staff = await db.prepare('SELECT id, name FROM staff WHERE id = ?').bind(userId).first();

        // If not a staff member (super admin), just allow viewing without adding to channel_members
        if (!staff) {
            return new Response(JSON.stringify({ success: true, message: 'Super admin - view only' }), {
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Check if already a member
        const existing = await db.prepare(`
            SELECT * FROM channel_members WHERE channel_id = ? AND user_id = ?
        `).bind(channelId, userId).first();

        if (existing) {
            return new Response(JSON.stringify({ success: true, message: 'Already a member' }), {
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Add as member (only for staff)
        await db.prepare(`
            INSERT INTO channel_members (channel_id, user_id, joined_at, last_read_at)
            VALUES (?, ?, ?, ?)
        `).bind(channelId, userId, now, now).run();

        // Add system message about joining (using 'system' as sender_id)
        const messageId = crypto.randomUUID();
        const staffName = staff?.name || '상담원';
        const systemMessage = `SYSTEM:JOINED|${staffName}`;

        await db.prepare(`
            INSERT INTO admin_messages (id, channel_id, sender_id, content, created_at)
            VALUES (?, ?, 'system', ?, ?)
        `).bind(messageId, channelId, systemMessage, now).run();

        // Update channel last_message_at
        await db.prepare(`
            UPDATE channels SET last_message_at = ?, last_message = ? WHERE id = ?
        `).bind(now, systemMessage, channelId).run();

        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Join channel error:', e, '- channelId:', channelId, 'userId:', userId);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
