import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    const { id: channelId } = params;

    try {
        const body = await request.json();
        const { userId } = body;
        const now = Math.floor(Date.now() / 1000);

        await db.prepare(`
            UPDATE channel_members SET last_read_at = ? WHERE channel_id = ? AND user_id = ?
        `).bind(now, channelId, userId).run();

        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
