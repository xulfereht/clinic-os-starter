import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    const { id: channelId } = params;
    const url = new URL(request.url);
    const limit = url.searchParams.get('limit') || '50';
    const before = url.searchParams.get('before'); // timestamp for pagination

    try {
        // Attempt 1: Fetch with translations
        // This might fail if 'message_translations' table doesn't exist yet
        try {
            let query = `
                SELECT 
                    m.*, 
                    COALESCE(s.name, l.name, '알 수 없음') as sender_name,
                    s.image as sender_image,
                    CASE WHEN s.id IS NOT NULL THEN 'staff' ELSE 'customer' END as sender_type,
                    (
                        (SELECT COUNT(*) FROM channel_members cm WHERE cm.channel_id = m.channel_id) -
                        (SELECT COUNT(*) FROM channel_members cm WHERE cm.channel_id = m.channel_id AND cm.last_read_at >= m.created_at)
                    ) as unread_count,
                    mt.translated_text as translation,
                    mt.locale as translation_locale
                FROM admin_messages m
                LEFT JOIN staff s ON m.sender_id = s.id
                LEFT JOIN leads l ON m.sender_id = l.id
                LEFT JOIN message_translations mt ON m.id = mt.message_id
                WHERE m.channel_id = ?
            `;
            const args = [channelId];

            if (before) {
                query += ` AND m.created_at < ?`;
                args.push(before);
            }

            query += ` ORDER BY m.created_at DESC LIMIT ?`;
            args.push(limit);

            const { results } = await db.prepare(query).bind(...args).all();

            return new Response(JSON.stringify({ messages: results.reverse() }), {
                headers: { 'Content-Type': 'application/json' }
            });

        } catch (tableError) {
            console.warn('Failed to fetch translations, falling back to basic message fetch:', tableError);

            // Attempt 2: Fallback without translations
            let query = `
                SELECT 
                    m.*, 
                    COALESCE(s.name, l.name, '알 수 없음') as sender_name,
                    s.image as sender_image,
                    CASE WHEN s.id IS NOT NULL THEN 'staff' ELSE 'customer' END as sender_type,
                    (
                        (SELECT COUNT(*) FROM channel_members cm WHERE cm.channel_id = m.channel_id) -
                        (SELECT COUNT(*) FROM channel_members cm WHERE cm.channel_id = m.channel_id AND cm.last_read_at >= m.created_at)
                    ) as unread_count
                FROM admin_messages m
                LEFT JOIN staff s ON m.sender_id = s.id
                LEFT JOIN leads l ON m.sender_id = l.id
                WHERE m.channel_id = ?
            `;
            const args = [channelId];

            if (before) {
                query += ` AND m.created_at < ?`;
                args.push(before);
            }

            query += ` ORDER BY m.created_at DESC LIMIT ?`;
            args.push(limit);

            const { results } = await db.prepare(query).bind(...args).all();

            return new Response(JSON.stringify({ messages: results.reverse() }), {
                headers: { 'Content-Type': 'application/json' }
            });
        }
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const env = locals.runtime?.env; // Need env for Aligo config

    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    const { id: channelId } = params;

    try {
        const body = await request.json();
        const { senderId, content, fileUrl, fileType, fileName, send_sms, translate } = body;

        // Define missing variables
        const type = fileUrl ? 'file' : 'text';
        const fileSize = body.fileSize || null;
        const now = Math.floor(Date.now() / 1000);

        // 1. Insert Message
        const msgId = crypto.randomUUID();

        // 2. Insert message
        const { success } = await db.prepare(`
            INSERT INTO admin_messages (id, channel_id, sender_id, content, file_url, file_type, file_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(msgId, channelId, senderId, content, fileUrl || null, fileType || null, fileName || null, now).run();

        if (success) {
            // Update channel last_message (non-critical - don't fail if this errors)
            try {
                await db.prepare(`
                    UPDATE channels SET last_message = ?, last_message_at = ? WHERE id = ?
                `).bind(type === 'file' ? '(파일)' : content, now, channelId).run();
            } catch (channelUpdateError) {
                console.error('Channel update failed:', channelUpdateError);
            }

            // [FIX] Update sender's last_read_at to prevent unread count for self
            try {
                await db.prepare(`
                    UPDATE channel_members SET last_read_at = ? WHERE channel_id = ? AND user_id = ?
                `).bind(now, channelId, senderId).run();
            } catch (readUpdateError) {
                console.error('Read status update failed:', readUpdateError);
            }

            // ------------------------------------------------------------
            // 🌐 TRANSLATION LOGIC
            // ------------------------------------------------------------
            try {
                // Lazy load orchestrator
                const { TranslationOrchestrator } = await import('../../../../../../lib/translation/orchestrator');
                const orchestrator = new TranslationOrchestrator(db);

                // Use 'content' for text messages
                if (type === 'text' && content) {

                    // Case A: Staff sending message
                    if (senderId) {
                        try {
                            // Check staff details to confirm it's a staff member
                            const staff = await db.prepare("SELECT id FROM staff WHERE id = ?").bind(senderId).first();

                            if (staff) {
                                // 1. Get Patient's Language for this channel
                                const channel = await db.prepare("SELECT lead_id FROM channels WHERE id = ?").bind(channelId).first();
                                if (channel && channel.lead_id) {
                                    const lead = await db.prepare("SELECT language FROM leads WHERE id = ?").bind(channel.lead_id).first();
                                    const targetLang = (lead as any)?.language || 'ko'; // Default to Korean if not set
                                    let finalTarget = targetLang;

                                    // 🔹 Fallback: If Translation Mode is ON but target is 'ko', force 'en'
                                    // This handles cases where lead language isn't updated yet (e.g. "english plz")
                                    if (translate && targetLang === 'ko') {
                                        finalTarget = 'en';
                                    }

                                    // 🔹 Only translate if toggle is ON and target is NOT Korean
                                    if (translate && finalTarget !== 'ko') {
                                        console.log(`[Translation] Staff message -> Translating to ${finalTarget}`);
                                        await orchestrator.translateAndSave(msgId, content, finalTarget, 'ko');
                                    }
                                }
                            } else {
                                // Case B: Patient (Lead) sending message
                                // Detect language
                                const detectedLang = await orchestrator.detectLanguage(content);
                                console.log(`[Translation] Patient message detected as: ${detectedLang}`);

                                // Identify patient to update their language setting if needed
                                const channel = await db.prepare("SELECT lead_id FROM channels WHERE id = ?").bind(channelId).first();
                                if (channel && channel.lead_id && detectedLang !== 'und' && detectedLang !== 'ko') {
                                    // Update lead's language preference if different
                                    await db.prepare("UPDATE leads SET language = ? WHERE id = ? AND language = 'ko'").bind(detectedLang, channel.lead_id).run();
                                }

                                // If not Korean, translate to Korean for Staff
                                if (detectedLang !== 'ko' && detectedLang !== 'und') {
                                    console.log(`[Translation] Patient message -> Translating to Korean`);
                                    await orchestrator.translateAndSave(msgId, content, 'ko', detectedLang);
                                }
                            }
                        } catch (innerErr) {
                            console.error('[Translation] Error processing sender logic:', innerErr);
                        }
                    }
                }
            } catch (translationErr) {
                console.error('[Translation] Integration failed:', translationErr);
                // Non-blocking: don't fail the message send if translation fails
            }

            // SEND SMS if requested
            if (send_sms && type === 'text') {
                try {
                    const channel = await db.prepare('SELECT lead_id FROM channels WHERE id = ?').bind(channelId).first() as { lead_id: string } | null;
                    if (channel && channel.lead_id) {
                        const lead = await db.prepare('SELECT phone, last_seen FROM leads WHERE id = ?').bind(channel.lead_id).first() as { phone: string, last_seen: number } | null;

                        if (lead && lead.phone) {
                            const { sendAligoMessage, getAligoConfig } = await import('../../../../../../lib/aligo');
                            // @ts-ignore
                            const config = await getAligoConfig(env, db);

                            if (config && config.enabled) {
                                let smsContent = content;

                                // Smart Notification: Check if offline (10 mins = 600 secs)
                                const isOffline = !lead.last_seen || (Math.floor(Date.now() / 1000) - lead.last_seen > 600);

                                if (isOffline) {
                                    // Append Magic Link
                                    const magicLink = `https://brd-clinic.pages.dev/chat?leadId=${channel.lead_id}`;
                                    smsContent += `\n\n💬 답변 확인하기:\n${magicLink}`;
                                }

                                const smsResult = await sendAligoMessage(config, {
                                    receiver: lead.phone,
                                    msg: smsContent,
                                    title: '상담 답변'
                                });

                                // Log it
                                await db.prepare(`
                                    INSERT INTO message_logs (phone, content, status, error_message, type, lead_id, channel_id, admin_id, sent_at, created_at)
                                    VALUES (?, ?, ?, ?, 'chat_reply', ?, ?, ?, ?, strftime('%s', 'now'))
                                 `).bind(
                                    lead.phone,
                                    smsContent,
                                    smsResult.result_code === '1' ? 'sent' : 'failed',
                                    smsResult.result_code === '1' ? null : (smsResult.message || 'Unknown error'),
                                    channel.lead_id,
                                    channelId,
                                    senderId,
                                    Math.floor(Date.now() / 1000)
                                ).run();
                            }
                        }
                    }
                } catch (smsError) {
                    console.error('Auto-SMS failed:', smsError);
                }
            }

            // SEND TO NAVER TALKTALK if this is a Naver TalkTalk channel
            if (channelId?.startsWith('naver_') && type === 'text' && content) {
                try {
                    const { sendNaverTalkMessage, sendNaverTalkImage, getNaverTalkConfig } = await import('../../../../../../lib/integrations/naver-talktalk');
                    const naverConfig = await getNaverTalkConfig(db);

                    if (naverConfig && naverConfig.enabled) {
                        // Extract user ID from channel ID (remove 'naver_' prefix)
                        const naverUserId = channelId.replace('naver_', '');

                        if (fileUrl && fileType?.startsWith('image')) {
                            // Send image
                            const imageResult = await sendNaverTalkImage(naverConfig, naverUserId, fileUrl);
                            console.log('[NaverTalk] Image send result:', imageResult);
                        } else {
                            // Send text
                            const textResult = await sendNaverTalkMessage(naverConfig, naverUserId, content);
                            console.log('[NaverTalk] Text send result:', textResult);
                        }
                    }
                } catch (naverError) {
                    console.error('[NaverTalk] Reply failed:', naverError);
                }
            }

            return new Response(JSON.stringify({ success: true, id: msgId }), { status: 200 });
        } else {
            return new Response(JSON.stringify({ success: false, error: 'Database insert failed' }), { status: 500 });
        }

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
