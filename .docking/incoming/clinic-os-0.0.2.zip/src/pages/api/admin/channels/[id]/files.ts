import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    const { id: channelId } = params;

    try {
        const { results } = await db.prepare(`
            SELECT m.*, s.name as sender_name 
            FROM admin_messages m
            LEFT JOIN staff s ON m.sender_id = s.id
            WHERE m.channel_id = ? AND m.file_url IS NOT NULL
            ORDER BY m.created_at DESC
        `).bind(channelId).all();

        return new Response(JSON.stringify({ files: results }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
