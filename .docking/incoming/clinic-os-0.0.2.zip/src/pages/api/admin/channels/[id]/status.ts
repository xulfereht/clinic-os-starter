import type { APIRoute } from 'astro';

export const PUT: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    const { id: channelId } = params;

    try {
        const body = await request.json();
        const { status } = body; // 'active' or 'archived'

        if (!['active', 'archived'].includes(status)) {
            return new Response(JSON.stringify({ error: 'Invalid status' }), { status: 400 });
        }

        // Update status
        await db.prepare('UPDATE channels SET status = ? WHERE id = ?').bind(status, channelId).run();

        return new Response(JSON.stringify({ success: true, status }), { status: 200 });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
