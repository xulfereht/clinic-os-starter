import type { APIRoute } from 'astro';

export const DELETE: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const bucket = locals.runtime?.env?.BUCKET;

    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    const { id: channelId, messageId } = params;

    try {
        const body = await request.json();
        const { userId } = body;

        if (!userId) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });

        // Verify ownership and get file info
        const msg = await db.prepare('SELECT sender_id, file_url FROM admin_messages WHERE id = ?').bind(messageId).first();
        if (!msg) return new Response(JSON.stringify({ error: 'Not found' }), { status: 404 });

        if (msg.sender_id !== userId) {
            return new Response(JSON.stringify({ error: 'Permission denied' }), { status: 403 });
        }

        // Delete file from R2 if exists
        if (msg.file_url && bucket) {
            try {
                // Extract R2 key from URL: /api/files/ephemeral/2024-12/abc.pdf?sig=...
                const urlPath = (msg.file_url as string).split('?')[0]; // Remove query params
                const r2Key = urlPath.replace('/api/files/', ''); // Get R2 key

                if (r2Key && r2Key.startsWith('ephemeral/')) {
                    await bucket.delete(r2Key);
                    console.log(`[Message Delete] Deleted R2 file: ${r2Key}`);
                }
            } catch (e) {
                console.error('[Message Delete] Failed to delete R2 file:', e);
                // Continue with message deletion even if file delete fails
            }
        }

        // Soft delete message
        const now = Math.floor(Date.now() / 1000);
        await db.prepare('UPDATE admin_messages SET deleted_at = ? WHERE id = ?')
            .bind(now, messageId).run();

        return new Response(JSON.stringify({ success: true }));
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
