import type { APIRoute } from 'astro';

export const PATCH: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { next_shipping_date, remaining_quantity, status, notes } = body;

        // Validation (Basic)
        // Check if shipping order exists? implied by update

        const updates: string[] = [];
        const values: any[] = [];

        if (next_shipping_date !== undefined) {
            updates.push('next_shipping_date = ?');
            values.push(next_shipping_date ? Math.floor(new Date(next_shipping_date).getTime() / 1000) : null);
        }

        if (remaining_quantity !== undefined) {
            updates.push('remaining_quantity = ?');
            values.push(parseInt(remaining_quantity));
        }

        if (status !== undefined) {
            updates.push('status = ?');
            values.push(status);
        }

        updates.push('updated_at = unixepoch()');

        if (updates.length > 0) {
            values.push(id);
            await db.prepare(`
                UPDATE shipping_orders
                SET ${updates.join(', ')}
                WHERE id = ?
            `).bind(...values).run();

            // Log this change? Maybe later.
        }

        return new Response(JSON.stringify({ success: true }));
    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
