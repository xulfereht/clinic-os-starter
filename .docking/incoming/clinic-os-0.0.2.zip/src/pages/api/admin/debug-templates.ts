
import type { APIRoute } from "astro";

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;
    const { results } = await db.prepare("SELECT * FROM message_templates LIMIT 5").all();
    return new Response(JSON.stringify(results, null, 2), {
        headers: { "Content-Type": "application/json" }
    });
};
