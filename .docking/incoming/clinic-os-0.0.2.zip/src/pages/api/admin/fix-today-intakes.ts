export const prerender = false;

export async function GET({ locals }) {
    const db = locals.runtime.env.DB;
    const now = Math.floor(Date.now() / 1000);
    const todayStart = now - (now % 86400); // Rough approximation, better to use proper KST

    const KST_OFFSET = 9 * 60 * 60;
    const nowKST = now + KST_OFFSET;
    const todayKSTStart = Math.floor(nowKST / 86400) * 86400 - KST_OFFSET;

    const results = {
        leadsCreated: 0,
        visitsCreated: 0,
        details: []
    };

    try {
        // 1. Find patients created TODAY who:
        //    a) Have NO Lead
        //    b) Have NO 'Visit' event
        //    c) Are 'online' source (intake form)

        // Get today's new patients
        const { results: newPatients } = await db.prepare(`
            SELECT * FROM patients 
            WHERE created_at >= ? 
            AND channel = 'intake_form'
        `).bind(todayKSTStart).run();

        for (const p of newPatients) {
            // Check for Lead
            const normalizedPhone = p.current_phone.replace(/\D/g, '');
            const lead = await db.prepare("SELECT id, status, channel FROM leads WHERE replace(replace(contact, '-', ''), ' ', '') = ?").bind(normalizedPhone).first();

            if (!lead) {
                // CREATE LEAD
                const leadId = crypto.randomUUID();
                await db.prepare(`
                    INSERT INTO leads (
                        id, name, contact, type, status, channel, patient_type, intake_data, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `).bind(
                    leadId,
                    p.name,
                    p.current_phone,
                    'visit',
                    'first_visit_walkin',
                    'walk-in',
                    'new',
                    JSON.stringify({ source: 'retro-fix' }),
                    now,
                    now
                ).run();
                results.leadsCreated++;
                results.details.push(`Created Lead for ${p.name}`);
            } else {
                // UPDATE EXISTING AUTO-LEAD STATUS (Retroactive Fix for previous run)
                if (lead.status === 'new' && lead.channel === 'walk-in') {
                    await db.prepare("UPDATE leads SET status = 'first_visit_walkin' WHERE id = ?").bind(lead.id).run();
                    results.details.push(`Updated Lead Status to 'first_visit_walkin' for ${p.name}`);
                }
            }

            // Check for Visit Event
            const visitEvent = await db.prepare("SELECT id FROM patient_events WHERE patient_id = ? AND type = 'visit'").bind(p.id).first();

            if (!visitEvent) {
                // CREATE VISIT EVENT
                const eventId = crypto.randomUUID();
                await db.prepare(`
                    INSERT INTO patient_events (
                        id, patient_id, type, title, content, event_date, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                `).bind(
                    eventId,
                    p.id,
                    'visit',
                    '초진 내원 접수', // Matching title
                    '모바일 문진표 접수 확인 (자동 내원 등록 - Retroactive Fix)',
                    now,
                    now
                ).run();
                results.visitsCreated++;
                results.details.push(`Created Visit Event for ${p.name}`);
            }
        }

        // DEBUGGING MODE: Analyze why no events are being hydrated
        const oneDayAgo = now - 86400;
        const { results: allEvents } = await db.prepare(`
            SELECT id, patient_id, type, title, content, created_at FROM patient_events 
            WHERE created_at >= ?
            ORDER BY created_at DESC
        `).bind(oneDayAgo).run();

        const debugInfo = [];

        for (const ev of allEvents) {
            const sub = await db.prepare("SELECT id FROM intake_submissions WHERE patient_id = ?").bind(ev.patient_id).first();
            const lead = await db.prepare("SELECT id FROM leads WHERE patient_id = ?").bind(ev.patient_id).first();

            debugInfo.push({
                event_id: ev.id,
                type: ev.type,
                title: ev.title,
                patient_id: ev.patient_id,
                has_submission: !!sub,
                has_lead: !!lead,
                content_preview: ev.content.substring(0, 20)
            });

            // Perform Update if it IS an intake event and we HAVE data
            if (ev.type === 'intake' && (sub || lead)) {
                // Fetch Data
                let intakeData = null;
                if (lead) {
                    const l = await db.prepare("SELECT intake_data FROM leads WHERE id = ?").bind(lead.id).first();
                    if (l?.intake_data) intakeData = JSON.parse(l.intake_data);
                } else if (sub) {
                    const s = await db.prepare("SELECT intake_data FROM intake_submissions WHERE id = ?").bind(sub.id).first();
                    if (s?.intake_data) intakeData = JSON.parse(s.intake_data);
                }

                if (intakeData) {
                    // Reconstruct (Simplified for stability)
                    let newContent = `[문진표 접수 항목] (복구됨)\n`;
                    newContent += `방문 목적: ${intakeData.visit_category || '-'}\n`;
                    newContent += `주요 증상: ${intakeData.main_symptom || '-'}\n`;
                    newContent += `증상 기간: ${intakeData.duration || '-'}\n`;
                    if (intakeData.referral?.length > 0) newContent += `내원 경로: ${intakeData.referral.join(', ')}\n`;

                    await db.prepare("UPDATE patient_events SET content = ? WHERE id = ?").bind(newContent, ev.id).run();
                    results.details.push(`FIXED Event ${ev.id} for Patient ${ev.patient_id}`);
                }
            }
        }

        results.debug = debugInfo;

        return new Response(JSON.stringify({ success: true, results }, null, 2));

    } catch (e) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
