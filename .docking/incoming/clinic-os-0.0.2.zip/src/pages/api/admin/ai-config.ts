import type { APIRoute } from 'astro';

export const prerender = false;

export const GET: APIRoute = async ({ locals }) => {
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const configs = await db.prepare("SELECT * FROM ai_configs ORDER BY provider").all();

        // Mask API keys for security
        const safeConfigs = configs.results.map((c: any) => ({
            ...c,
            api_key: c.api_key ? `${c.api_key.substring(0, 4)}...${c.api_key.substring(c.api_key.length - 4)}` : '',
            has_key: !!c.api_key
        }));

        return new Response(JSON.stringify(safeConfigs), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { provider, api_key, model, is_active } = body;

        if (!provider) {
            return new Response(JSON.stringify({ error: 'Provider is required' }), { status: 400 });
        }

        // Check if exists
        const existing = await db.prepare("SELECT id FROM ai_configs WHERE provider = ?").bind(provider).first();

        if (existing) {
            // Update
            let query = "UPDATE ai_configs SET model = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP";
            const params = [model, is_active ? 1 : 0];

            // Only update API key if provided (not empty string)
            if (api_key) {
                query += ", api_key = ?";
                params.push(api_key);
            }

            query += " WHERE provider = ?";
            params.push(provider);

            await db.prepare(query).bind(...params).run();
        } else {
            // Insert
            if (!api_key) {
                return new Response(JSON.stringify({ error: 'API Key is required for new provider' }), { status: 400 });
            }
            await db.prepare(
                "INSERT INTO ai_configs (provider, api_key, model, is_active) VALUES (?, ?, ?, ?)"
            ).bind(provider, api_key, model, is_active ? 1 : 0).run();
        }

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
