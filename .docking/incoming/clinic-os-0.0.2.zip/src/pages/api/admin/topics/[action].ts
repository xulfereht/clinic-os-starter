import type { APIRoute } from 'astro';
import { AEOStore } from '../../../../lib/aeo-store';

export const POST: APIRoute = async ({ request, locals, redirect }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response('Database not available', { status: 500 });

    // Auth Check (Basic) - assumes AdminLayout protects the UI
    if (!locals.user) return new Response('Unauthorized', { status: 401 });

    const formData = await request.formData();
    const action = request.url.split('/').pop(); // create or update
    const store = new AEOStore(db);

    try {
        const title = formData.get('title') as string;
        const slug = formData.get('slug') as string;
        const summary = formData.get('summary') as string;
        const supervisor_id = formData.get('supervisor_id') as string;
        const related_program_id = formData.get('related_program_id') as string;
        const thumbnail_url = formData.get('thumbnail_url') as string;
        const translations = formData.get('translations') as string;

        if (action === 'create') {
            const id = await store.createTopic({
                title,
                slug,
                summary,
                supervisor_id,
                related_program_id,
                thumbnail_url,
                translations: translations || '{}'
            });
            return redirect(`/admin/topics/${id}`);
        }

        if (action === 'update') {
            const id = formData.get('id') as string;
            await store.updateTopic(parseInt(id), {
                title,
                slug,
                summary,
                supervisor_id,
                related_program_id,
                thumbnail_url,
                translations: translations || '{}'
            });
            return redirect(`/admin/topics/${id}`);
        }

    } catch (e) {
        console.error('Topic Action Error', e);
        return new Response('Error processing request', { status: 500 });
    }

    return redirect('/admin/topics');
};
