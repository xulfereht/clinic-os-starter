import type { APIRoute } from 'astro';
import { AEOStore } from '../../../../../../lib/aeo-store';

export const POST: APIRoute = async ({ request, locals, redirect, params }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response('Database not available', { status: 500 });

    if (!locals.user) return new Response('Unauthorized', { status: 401 });

    const formData = await request.formData();
    const action = request.url.split('/').pop(); // create or update
    const store = new AEOStore(db);
    const topicId = parseInt(formData.get('topic_id') as string);

    try {
        const question = formData.get('question') as string;
        const answer_short = formData.get('answer_short') as string;
        const answer_detail = formData.get('answer_detail') as string;
        const status = formData.get('status') as any;
        const tagsRaw = formData.get('tags') as string;

        // New AEO Fields
        const conditionId = formData.get('condition_id') ? parseInt(formData.get('condition_id') as string) : undefined;
        const slug = formData.get('slug') as string;
        const cluster = formData.get('cluster') as string;

        // Parse CSV tags to JSON array
        const tags = tagsRaw.split(',').map(t => t.trim()).filter(Boolean);

        // Legacy compatibility: category = cluster
        const category = cluster || (formData.get('category') as string);
        const translations = formData.get('translations') as string;

        if (action === 'create') {
            await store.createFAQ({
                topic_id: topicId,
                category,
                cluster,
                slug,
                condition_id: conditionId,
                question,
                answer_short,
                answer_detail,
                status,
                tags,
                translations: translations || '{}'
            });
        }

        if (action === 'update') {
            const id = parseInt(formData.get('id') as string);
            await store.updateFAQ(id, {
                category,
                cluster,
                slug,
                condition_id: conditionId,
                question,
                answer_short,
                answer_detail,
                status,
                tags,
                translations: translations || '{}'
            });
        }

        return redirect(`/admin/topics/${topicId}`);

    } catch (e) {
        console.error('FAQ Action Error', e);
        return new Response('Error processing request', { status: 500 });
    }
};
