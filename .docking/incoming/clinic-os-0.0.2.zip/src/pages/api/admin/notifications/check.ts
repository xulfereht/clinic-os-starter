import type { APIRoute } from 'astro';

export const prerender = false;

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    // Get 'since' timestamp from query param (for counting new leads since last check)
    const sinceTs = parseInt(url.searchParams.get('since') || '0');

    try {
        // 1. Check for new leads (status = 'new' or 'pending')
        const leadResult = await db.prepare(`
            SELECT 
                COUNT(*) as count,
                MAX(created_at) as latest_timestamp,
                MAX(id) as latest_id
            FROM leads 
            WHERE status IN ('new', 'pending')
        `).first();

        const leadCount = leadResult && typeof leadResult.count === 'number' ? leadResult.count : 0;
        const latestLeadTimestamp = leadResult && leadResult.latest_timestamp ? leadResult.latest_timestamp : 0;
        const latestLeadId = leadResult && leadResult.latest_id ? leadResult.latest_id : null;

        // Count leads created AFTER the 'since' timestamp (for accurate new notification)
        let newLeadCount = 0;
        let latestLeadData = null;

        if (sinceTs > 0) {
            const newResult = await db.prepare(`
                SELECT COUNT(*) as count FROM leads WHERE created_at > ?
            `).bind(sinceTs).first();
            newLeadCount = newResult && typeof newResult.count === 'number' ? newResult.count : 0;

            if (newLeadCount > 0) {
                const lead = await db.prepare(`
                    SELECT id, name, type, patient_type, channel, intake_data, summary, patient_id 
                    FROM leads 
                    WHERE created_at > ? 
                    ORDER BY created_at DESC 
                    LIMIT 1
                `).bind(sinceTs).first();

                if (lead) {
                    let typeLabel = '';
                    if (lead.channel === 'naver_reservation') {
                        typeLabel = '네이버예약';
                    } else {
                        const typeMap: Record<string, string> = {
                            'visit': '내원상담',
                            'consultation': '전화상담',
                            'procedure': '시술예약',
                            'diet': '다이어트',
                            'general': '일반진료',
                            'remote': '비대면',
                            'event': '이벤트 신청',
                            'chat': '채팅상담',
                            'inquiry': '일반문의'
                        };

                        // Prioritize Patient Type for Consultation
                        if (lead.type === 'consultation') {
                            const pTypeStr = String(lead.patient_type);
                            if (pTypeStr === 'returning' || pTypeStr === 'existing_customer') {
                                typeLabel = '재진';
                            } else {
                                typeLabel = '초진';
                            }
                        } else {
                            typeLabel = typeMap[String(lead.type)] || String(lead.type);

                            const patientTypeMap: Record<string, string> = {
                                'new': '초진',
                                'returning': '재진',
                                'existing_customer': '재진'
                            };
                            const pType = patientTypeMap[String(lead.patient_type)];
                            if (pType) typeLabel += `(${pType})`;
                        }
                    }

                    // Channel Map
                    const channelMap: Record<string, string> = {
                        'chatgpt_app': 'AI 상담',
                        'intake_form': '접수 양식',
                        'phone': '전화',
                        'web_widget': '웹 상담',
                        'kakao': '카카오톡',
                        'naver_talk': '네이버 톡톡',
                        'walk-in': '내원',
                        'walk_in': '내원',
                        'naver_reservation': '네이버 예약',
                        'campaign_2025_year_end': '2025 연말 이벤트'
                    };
                    const channelLabel = channelMap[String(lead.channel)] || lead.channel;

                    // Parse intake data or summary for more context
                    let context = '';
                    try {
                        const rawData = lead.intake_data || '{}';
                        const intake = JSON.parse(String(rawData));
                        if (intake.main_symptom) context = intake.main_symptom;
                        else if (intake.visit_category) context = intake.visit_category;
                        else if (intake.notes) context = intake.notes;
                    } catch (e) { }

                    // Fallback to summary extraction if context is empty
                    if (!context && lead.summary) {
                        const summary = String(lead.summary);
                        const programMatch = summary.match(/\[관심프로그램\]\s*(.+)/);
                        if (programMatch) {
                            context = programMatch[1].trim();
                        } else {
                            const symptomMatch = summary.match(/\[주증상\]\s*(.+)/);
                            if (symptomMatch) context = symptomMatch[1].trim();
                        }
                    }

                    latestLeadData = {
                        id: lead.id,
                        name: lead.name,
                        type: typeLabel,
                        channel: channelLabel,
                        context: context,
                        patientType: lead.patient_type,
                        isReturning: !!lead.patient_id
                    };

                    // [Safety Check] correct patient_type if it is 'new' but phone exists in DB
                    // This fixes display for leads that were missed during ingestion
                    if (lead.patient_type === 'new' || lead.patient_type === 'new_lead') {
                        try {
                            const { findPatientByPhone } = await import('../../../../lib/patients/lookup');
                            const match = await findPatientByPhone(db, lead.contact);
                            if (match) {
                                latestLeadData.patientType = 'returning';
                                // Re-calculate label
                                if (latestLeadData.type === '초진') {
                                    latestLeadData.type = '재진';
                                } else if (latestLeadData.type.includes('초진')) {
                                    latestLeadData.type = latestLeadData.type.replace('초진', '재진');
                                }
                            }
                        } catch (e) {
                            // Ignore lookup errors during check, fallback to stored value is fine
                        }
                    }
                }
            }
        }

        // 2. Check for unread customer support messages
        const csResult = await db.prepare(`
            SELECT COUNT(*) as count
            FROM channels c
            WHERE c.type = 'customer_support'
            AND c.status = 'active'
            AND c.last_message_at > (
                SELECT COALESCE(MAX(cm.last_read_at), 0)
                FROM channel_members cm
                WHERE cm.channel_id = c.id
            )
        `).first();

        // 3. Check for unread Team Chat messages (Direct, Group, Public)
        let teamWithUnreadCount = 0;
        let latestTeamMessage: any = null;
        // @ts-ignore
        const userId = locals.user?.id;

        if (userId) {
            const teamResult = await db.prepare(`
                SELECT COUNT(*) as count
                FROM channels c
                JOIN channel_members cm ON c.id = cm.channel_id
                WHERE cm.user_id = ?
                AND c.type IN ('public', 'direct', 'group')
                AND c.last_message_at > cm.last_read_at
            `).bind(userId).first();
            teamWithUnreadCount = teamResult && typeof teamResult.count === 'number' ? teamResult.count : 0;

            if (teamWithUnreadCount > 0) {
                // Fetch latest unread message
                const latestMsg = await db.prepare(`
                    SELECT 
                        m.content, 
                        m.created_at, 
                        m.channel_id,
                        s.name as sender_name
                    FROM admin_messages m
                    JOIN channels c ON m.channel_id = c.id
                    JOIN channel_members cm ON c.id = cm.channel_id
                    LEFT JOIN staff s ON m.sender_id = s.id
                    WHERE cm.user_id = ?
                    AND c.type IN ('public', 'direct', 'group')
                    AND m.created_at > cm.last_read_at
                    ORDER BY m.created_at DESC
                    LIMIT 1
                `).bind(userId).first();

                if (latestMsg) {
                    latestTeamMessage = {
                        content: latestMsg.content,
                        sender: latestMsg.sender_name || '알 수 없음',
                        channelId: latestMsg.channel_id,
                        createdAt: latestMsg.created_at
                    };
                }
            }
        }

        const customerSupportCount = csResult && typeof csResult.count === 'number' ? csResult.count : 0;

        // 4. Check for Mentions (High Priority)
        let mentionCount = 0;
        let latestMention: any = null;

        if (userId) {
            const mentionRes = await db.prepare(`
                SELECT 
                    COUNT(*) as count,
                    MAX(m.created_at) as latest_at
                FROM admin_messages m
                JOIN channel_members cm ON m.channel_id = cm.channel_id
                WHERE cm.user_id = ?
                AND m.created_at > cm.last_read_at
                AND m.content LIKE ?
            `).bind(userId, `%[MENTION:${userId}:%`).first();

            mentionCount = mentionRes && typeof mentionRes.count === 'number' ? mentionRes.count : 0;

            if (mentionCount > 0) {
                const m = await db.prepare(`
                    SELECT 
                        m.content, 
                        m.created_at, 
                        m.channel_id,
                        s.name as sender_name
                    FROM admin_messages m
                    JOIN channel_members cm ON m.channel_id = cm.channel_id
                    LEFT JOIN staff s ON m.sender_id = s.id
                    WHERE cm.user_id = ?
                    AND m.created_at > cm.last_read_at
                    AND m.content LIKE ?
                    ORDER BY m.created_at DESC
                    LIMIT 1
                `).bind(userId, `%[MENTION:${userId}:%`).first();

                if (m) {
                    latestMention = {
                        content: m.content,
                        sender: m.sender_name || '알 수 없음',
                        channelId: m.channel_id,
                        createdAt: m.created_at
                    };
                }
            }
        }

        return new Response(JSON.stringify({
            // Legacy fields
            count: leadCount,
            latestTimestamp: latestLeadTimestamp,
            latestId: latestLeadId,
            newCount: newLeadCount, // Count of leads created after 'since' timestamp
            // New fields
            leads: {
                count: leadCount,
                newCount: newLeadCount,
                latestId: latestLeadId,
                latestLead: latestLeadData
            },
            customerSupport: {
                unreadChannels: customerSupportCount
            },
            teamChat: {
                unreadChannels: teamWithUnreadCount,
                latestMessage: latestTeamMessage,
                mentions: {
                    count: mentionCount,
                    latest: latestMention
                }
            }
        }), {
            status: 200,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    } catch (e) {
        console.error("Notification Check Error:", e);
        return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
    }
};
