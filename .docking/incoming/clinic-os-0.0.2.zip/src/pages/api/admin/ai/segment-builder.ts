import type { APIRoute } from 'astro';

export const prerender = false;

// FIELD DEFINITIONS FOR PROMPT CONTEXT
const FIELD_CONTEXT = `
Available Fields for Patient Segmentation:
- name (string)
- phone (string)
- gender (select: 'M', 'F')
- birth_date (date, YYYY-MM-DD)
- address (string)
- status (select: 'active', 'visit_first_visit', 'remote_first_visit')
- lifecycle_stage (select: 'potential', 'new_visit', 'active', 'churned')
- tier (select: 'standard', 'vip', 'premium')
- channel (select: 'intake_form', 'walk_in', 'referral', 'imported')
- visit_count (number)
- first_visit_date (date)
- last_visit_date (date)
- reservation_date (date, supports relative dates: relative_date operator)
- total_payment (number)
- sms_consent (boolean)
- email_consent (boolean)
- tags (string, JSON array)
- first_source (string)

Operators:
- string: equals, contains, starts_with
- number: gt, lt, gte, lte, equals, between ([min, max])
- date: gte, lte, between ([start, end]), relative_date (integer, e.g. +1 for tomorrow, 0 for today, -1 for yesterday)
- select: equals, in ([val1, val2])
- boolean: is_true, is_false

Output Format: JSON only, structure { "operator": "AND" | "OR", "conditions": [ { "field": "...", "operator": "...", "value": ... } ] }
`;

async function callLLM(provider: string, apiKey: string, model: string, userQuery: string) {
    const systemPrompt = `You are a helper for a CRM system. ${FIELD_CONTEXT}
    Convert the user's natural language request into a valid JSON segment criteria. 
    Analyze the intent carefully.
    
    Examples:
    - "Tomorrow's reservations" -> { "field": "reservation_date", "operator": "relative_date", "value": "+1" }
    - "Male patients" -> { "field": "gender", "operator": "equals", "value": "M" }
    - "VIP (High spenders)" -> { "field": "total_payment", "operator": "gte", "value": "1000000" }
    - "New patients" -> { "field": "visit_count", "operator": "lte", "value": "1" }

    Important rules:
    - Return ONLY valid JSON. No markdown formatting.
    - Do not invent fields not listed above.
    - If ambiguous, prioritize reservation_date logic if "reservation" or "appointment" is mentioned.
    `;

    if (provider === 'openai') {
        const res = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: model || 'gpt-4o',
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userQuery }
                ],
                temperature: 0
            })
        });

        if (!res.ok) {
            const err = await res.json();
            throw new Error(`OpenAI API Error: ${err.error?.message || res.statusText}`);
        }

        const data = await res.json();
        let content = data.choices[0].message.content;
        // Clean markdown code blocks if present
        content = content.replace(/```json/g, '').replace(/```/g, '').trim();
        return JSON.parse(content);

    } else if (provider === 'gemini') {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model || 'gemini-1.5-flash'}:generateContent?key=${apiKey}`;
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [{ text: `${systemPrompt}\n\nUser Query: ${userQuery}` }]
                }]
            })
        });

        if (!res.ok) {
            const err = await res.json();
            throw new Error(`Gemini API Error: ${err.error?.message || res.statusText}`);
        }

        const data = await res.json();
        let content = data.candidates[0].content.parts[0].text;
        content = content.replace(/```json/g, '').replace(/```/g, '').trim();
        return JSON.parse(content);
    }

    throw new Error(`Provider ${provider} not supported yet.`);
}

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    try {
        const body = await request.json();
        const { query } = body;

        if (!query) return new Response(JSON.stringify({ error: 'Query is required' }), { status: 400 });

        // 1. Determine Provider (Routing or Default)
        // Check for explicit mapping first
        const mapping = await db.prepare("SELECT provider FROM ai_feature_mappings WHERE feature_key = 'segment_builder'").first();

        let config;
        if (mapping && mapping.provider) {
            config = await db.prepare(
                "SELECT * FROM ai_configs WHERE provider = ? AND is_active = 1 AND api_key IS NOT NULL AND api_key != ''"
            ).bind(mapping.provider).first();
        }

        // Fallback: Get any active LLM Config
        if (!config) {
            config = await db.prepare(
                "SELECT * FROM ai_configs WHERE is_active = 1 AND provider IN ('openai', 'gemini') AND api_key IS NOT NULL AND api_key != '' ORDER BY updated_at DESC LIMIT 1"
            ).first();
        }

        if (!config) {
            return new Response(JSON.stringify({
                success: false,
                message: '활성화된 AI 설정이 없습니다. [관리자 > 설정 > AI 설정]에서 API Key를 등록하고 활성화해주세요.'
            }), { status: 400 });
        }

        // 2. Call LLM
        let criteria;
        try {
            criteria = await callLLM(config.provider as string, config.api_key as string, config.model as string, query);
        } catch (apiError: any) {
            console.error('AI API Error:', apiError);
            return new Response(JSON.stringify({
                success: false,
                message: `AI 요청 실패: ${apiError.message}`
            }), { status: 500 });
        }

        // 3. Validate Result Structure (Basic)
        if (!criteria || !criteria.conditions || !Array.isArray(criteria.conditions)) {
            return new Response(JSON.stringify({
                success: false,
                message: 'AI가 유효한 조건을 생성하지 못했습니다. 다시 시도해주세요.'
            }), { status: 500 });
        }

        return new Response(JSON.stringify({
            success: true,
            criteria: {
                ...criteria,
                conditions: criteria.conditions.map((c: any) => ({ ...c, id: Math.random().toString() }))
            },
            message: `${criteria.conditions.length}개의 조건을 생성했습니다.`
        }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
