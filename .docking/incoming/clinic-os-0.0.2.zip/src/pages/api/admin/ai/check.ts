import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    // @ts-ignore
    if (!locals.user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });

    try {
        const config = await db.prepare(
            "SELECT api_key FROM ai_configs WHERE provider = 'google_translate' AND is_active = 1"
        ).first();

        if (config && config.api_key) {
            return new Response(JSON.stringify({ configured: true }), { status: 200 });
        } else {
            return new Response(JSON.stringify({ configured: false }), { status: 200 });
        }
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
