import type { APIRoute } from 'astro';

export const prerender = false;

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    try {
        const url = new URL(request.url);
        const feature = url.searchParams.get('feature');

        if (!feature) {
            return new Response(JSON.stringify({ error: 'Feature parameter is required' }), { status: 400 });
        }

        // 1. Check for explicit mapping
        const mapping = await db.prepare("SELECT provider FROM ai_feature_mappings WHERE feature_key = ?").bind(feature).first();

        let config;
        if (mapping && mapping.provider) {
            // Check if mapped provider is active
            config = await db.prepare(
                "SELECT provider, model FROM ai_configs WHERE provider = ? AND is_active = 1 AND api_key IS NOT NULL AND api_key != ''"
            ).bind(mapping.provider).first();
        } else {
            // Fallback Logic (Specific to feature)
            if (feature === 'segment_builder') {
                // Default: Any active LLM
                config = await db.prepare(
                    "SELECT provider, model FROM ai_configs WHERE is_active = 1 AND provider IN ('openai', 'gemini') AND api_key IS NOT NULL AND api_key != '' ORDER BY updated_at DESC LIMIT 1"
                ).first();
            } else if (feature === 'translator') {
                // Default: Any active Translator or LLM
                config = await db.prepare(
                    "SELECT provider, model FROM ai_configs WHERE is_active = 1 AND (provider = 'google_translate' OR provider IN ('openai', 'gemini')) AND api_key IS NOT NULL AND api_key != '' ORDER BY updated_at DESC LIMIT 1"
                ).first();
            }
        }

        return new Response(JSON.stringify({
            available: !!config,
            provider: config?.provider || null,
            model: config?.model || null
        }), { status: 200 });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
