/**
 * Super Admin Password Change API
 */

import type { APIRoute } from 'astro';

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
        }

        const user = locals.user;

        // Only allow super admin
        if (!user || (user.id !== 'legacy_super_admin' && user.role !== '최고관리자')) {
            return new Response(JSON.stringify({ error: '권한이 없습니다.' }), { status: 403 });
        }

        const { currentPassword, newPassword } = await request.json();

        if (!currentPassword || !newPassword) {
            return new Response(JSON.stringify({ error: '현재 비밀번호와 새 비밀번호를 입력해주세요.' }), { status: 400 });
        }

        // Get super admin from DB
        const superAdmin = await db.prepare(
            'SELECT * FROM super_admins LIMIT 1'
        ).first();

        if (!superAdmin) {
            return new Response(JSON.stringify({ error: '슈퍼 관리자 계정을 찾을 수 없습니다.' }), { status: 404 });
        }

        // Verify current password
        const currentHash = await hashPassword(currentPassword);
        if (currentHash !== superAdmin.password_hash) {
            return new Response(JSON.stringify({ error: '현재 비밀번호가 올바르지 않습니다.' }), { status: 400 });
        }

        // Hash new password
        const newHash = await hashPassword(newPassword);

        // Update password
        await db.prepare(
            'UPDATE super_admins SET password_hash = ? WHERE id = ?'
        ).bind(newHash, superAdmin.id).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });

    } catch (e: any) {
        console.error('[Super Admin Password API] Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

async function hashPassword(password: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hashBuffer))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}
