import type { APIRoute } from 'astro';
import { PERMISSION_PRESETS } from '../../../../lib/permissions';

export const GET: APIRoute = async ({ locals }) => {
    const db = locals.runtime.env.DB;

    try {
        // Fetch custom presets from DB
        const result = await db.prepare(
            "SELECT value FROM site_settings WHERE category = 'permissions' AND key = 'custom_presets'"
        ).first();

        let customPresets = {};
        if (result && result.value) {
            try {
                customPresets = JSON.parse(result.value);
            } catch (e) {
                console.error("Failed to parse custom presets", e);
            }
        }

        // Merge defaults with custom (Custom overrides default if same key, but we usually want unique keys)
        // We'll prefix custom keys or just merge.
        const mergedPresets = { ...PERMISSION_PRESETS, ...customPresets };

        return new Response(JSON.stringify(mergedPresets), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: 'Failed to fetch presets' }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    const db = locals.runtime.env.DB;

    try {
        const body = await request.json();
        const { key, label, description, targetRole, permissions, action } = body;

        // Fetch existing
        const result = await db.prepare(
            "SELECT value FROM site_settings WHERE category = 'permissions' AND key = 'custom_presets'"
        ).first();

        let customPresets = {};
        if (result && result.value) {
            try {
                customPresets = JSON.parse(result.value);
            } catch (e) { }
        }

        if (action === 'delete') {
            delete customPresets[key];
        } else {
            // Create or Update
            // Validate key to avoid overwriting system defaults if we want to protect them
            if (PERMISSION_PRESETS[key]) {
                return new Response(JSON.stringify({ error: 'Cannot modify system presets' }), { status: 400 });
            }

            customPresets[key] = {
                label,
                description,
                targetRole,
                permissions
            };
        }

        // Save back to DB
        await db.prepare(`
            INSERT INTO site_settings (category, key, value, updated_at)
            VALUES ('permissions', 'custom_presets', ?, unixepoch())
            ON CONFLICT(category, key) DO UPDATE SET
                value = excluded.value,
                updated_at = unixepoch()
        `).bind(JSON.stringify(customPresets)).run();

        return new Response(JSON.stringify({ success: true, presets: { ...PERMISSION_PRESETS, ...customPresets } }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: 'Failed to save preset' }), { status: 500 });
    }
};
