import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });

    try {
        // Check if settings table exists (it might be 'settings' or 'clinic_settings' based on previous inspection)
        // Based on inspection, it is 'settings'
        const setting = await db.prepare("SELECT value FROM settings WHERE key = 'member_approval_mode'").first();

        return new Response(JSON.stringify({
            mode: setting ? setting.value : 'manual' // Default to manual
        }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });

    try {
        const body = await request.json();
        const { mode } = body;

        if (mode !== 'manual' && mode !== 'auto') {
            return new Response(JSON.stringify({ error: "Invalid mode" }), { status: 400 });
        }

        // Upsert setting
        const existing = await db.prepare("SELECT key FROM settings WHERE key = 'member_approval_mode'").first();

        if (existing) {
            await db.prepare("UPDATE settings SET value = ?, updated_at = strftime('%s', 'now') WHERE key = 'member_approval_mode'").bind(mode).run();
        } else {
            await db.prepare("INSERT INTO settings (key, value, updated_at) VALUES ('member_approval_mode', ?, strftime('%s', 'now'))").bind(mode).run();
        }

        return new Response(JSON.stringify({ status: "ok", mode }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
