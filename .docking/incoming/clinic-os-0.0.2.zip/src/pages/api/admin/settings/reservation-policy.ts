import type { APIRoute } from 'astro';

// GET - Retrieve current reservation policy
export const GET: APIRoute = async ({ locals }) => {
    const db = locals.runtime.env.DB;

    try {
        const settings = await db.prepare(`SELECT * FROM settings LIMIT 1`).first();
        return new Response(JSON.stringify({
            reservation_slot_minutes: settings?.reservation_slot_minutes ?? 30,
            max_patients_per_slot: settings?.max_patients_per_slot ?? 3,
            enforce_clinic_hours: settings?.enforce_clinic_hours ?? 1
        }));
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

// PUT - Update reservation policy
export const PUT: APIRoute = async ({ locals, request }) => {
    const db = locals.runtime.env.DB;
    const body = await request.json();

    const { reservation_slot_minutes, max_patients_per_slot, enforce_clinic_hours } = body;

    try {
        // Check if settings row exists
        const existing = await db.prepare(`SELECT id FROM settings LIMIT 1`).first();

        if (existing) {
            // Update existing
            await db.prepare(`
                UPDATE settings SET 
                    reservation_slot_minutes = ?,
                    max_patients_per_slot = ?,
                    enforce_clinic_hours = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            `).bind(
                reservation_slot_minutes ?? 30,
                max_patients_per_slot ?? 3,
                enforce_clinic_hours ?? 1,
                existing.id
            ).run();
        } else {
            // Insert new settings row (should rarely happen if settings table is properly initialized)
            await db.prepare(`
                INSERT INTO settings (id, reservation_slot_minutes, max_patients_per_slot, enforce_clinic_hours)
                VALUES (1, ?, ?, ?)
            `).bind(
                reservation_slot_minutes ?? 30,
                max_patients_per_slot ?? 3,
                enforce_clinic_hours ?? 1
            ).run();
        }

        return new Response(JSON.stringify({ success: true }));
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
