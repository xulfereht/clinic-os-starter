import type { APIRoute } from "astro";
import { sendSlackTestMessage } from "../../../../lib/integrations/slack";

export const prerender = false;

// GET: Fetch current integrations settings
export const GET: APIRoute = async ({ locals }) => {
    try {
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
        }

        const result = await db.prepare("SELECT integrations FROM clinics WHERE id = 1").first();

        let integrations = {
            slack: {
                enabled: false,
                webhookUrl: '',
                channel: ''
            }
        };

        if (result?.integrations) {
            try {
                integrations = JSON.parse(result.integrations as string);
            } catch (e) {
                console.error('Failed to parse integrations JSON:', e);
            }
        }

        return new Response(JSON.stringify(integrations), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error: any) {
        console.error('[Integrations API] Error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};

// POST: Save integrations settings
export const POST: APIRoute = async ({ request, locals }) => {
    try {
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
        }

        const body = await request.json();
        const { action, integrations, webhookUrl } = body;

        // Handle test message action
        if (action === 'test_slack') {
            if (!webhookUrl) {
                return new Response(JSON.stringify({ error: 'Webhook URL is required' }), { status: 400 });
            }
            const result = await sendSlackTestMessage(webhookUrl);
            return new Response(JSON.stringify(result), {
                status: result.success ? 200 : 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Handle Aligo connection test (Balance check)
        if (action === 'test_aligo') {
            const { config } = body;
            if (!config?.apiKey || !config?.userId || !config?.sender) {
                return new Response(JSON.stringify({ error: 'Missing Aligo configuration' }), { status: 400 });
            }

            const formData = new FormData();
            formData.append('key', config.apiKey);
            formData.append('user_id', config.userId);

            // Use proxy URL if provided, otherwise default to direct Aligo API
            const baseUrl = config.baseUrl ? config.baseUrl.replace(/\/+$/, '') + '/' : 'https://apis.aligo.in/';
            const endpoint = `${baseUrl}remain/`;

            const res = await fetch(endpoint, {
                method: 'POST',
                body: formData
            });

            // Check if response is JSON
            const contentType = res.headers.get('content-type') || '';
            const text = await res.text();

            if (!contentType.includes('application/json') && text.startsWith('<')) {
                return new Response(JSON.stringify({
                    success: false,
                    error: `프록시 서버 오류: HTML 응답이 반환되었습니다. 프록시 URL(${endpoint})을 확인하세요.`
                }), { status: 400 });
            }

            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                return new Response(JSON.stringify({
                    success: false,
                    error: `응답 파싱 오류: ${text.substring(0, 100)}`
                }), { status: 400 });
            }

            if (data.result_code === '1') {
                return new Response(JSON.stringify({ success: true, message: `잔액: SMS ${data.SMS_CNT}건 / LMS ${data.LMS_CNT}건` }), { status: 200 });
            } else {
                return new Response(JSON.stringify({ success: false, error: data.message || 'Auth Failed' }), { status: 400 });
            }
        }

        // Handle Aligo send test
        if (action === 'test_send_aligo') {
            const { config, receiver, message } = body;
            if (!config?.apiKey || !config?.userId || !config?.sender || !receiver || !message) {
                return new Response(JSON.stringify({ error: 'Missing configuration or message details' }), { status: 400 });
            }

            // Re-use lib function but force specific config
            const aligoConfig: import('../../../../lib/aligo').AligoConfig = {
                key: config.apiKey,
                userid: config.userId,
                sender: config.sender,
                baseUrl: config.baseUrl,
                testmode_yn: 'N' // Force real send for test
            };

            // Dynamic import to avoid circular dependency issues if any, or just import
            const { sendAligoMessage } = await import('../../../../lib/aligo');

            const result = await sendAligoMessage(aligoConfig, {
                receiver,
                msg: message,
                title: '테스트'
            });

            if (result.result_code === '1') {
                return new Response(JSON.stringify({ success: true, message: `전송 성공 (ID: ${result.msg_id})` }), { status: 200 });
            } else {
                return new Response(JSON.stringify({ success: false, error: result.message }), { status: 400 });
            }
        }

        // Handle Naver TalkTalk connection test
        if (action === 'test_naver_talk') {
            const { token } = body;
            if (!token) {
                return new Response(JSON.stringify({ error: 'Authorization Token is required' }), { status: 400 });
            }

            // For now, we just validate the token format
            // Actual API validation would require sending a test message to a known user
            // The token should start with 'Bearer ' or just be the raw token
            const authToken = token.startsWith('Bearer ') ? token : token;

            if (authToken.length < 10) {
                return new Response(JSON.stringify({ success: false, error: 'Token이 너무 짧습니다. 올바른 토큰인지 확인해주세요.' }), { status: 400 });
            }

            // Return success - the actual validation will happen when messages are received
            return new Response(JSON.stringify({
                success: true,
                message: 'Token 형식이 유효합니다. Webhook 등록 후 메시지가 수신되면 연동이 완료됩니다.'
            }), { status: 200 });
        }

        // Handle Kakao webhook test
        if (action === 'test_kakao') {
            // Test the Kakao webhook endpoint by making a GET request
            try {
                const origin = request.headers.get('origin') || request.headers.get('host') || '';
                const protocol = origin.includes('localhost') ? 'http' : 'https';
                const baseUrl = origin.startsWith('http') ? origin : `${protocol}://${origin}`;

                const testRes = await fetch(`${baseUrl}/api/kakao/webhook`);
                const testData = await testRes.json();

                if (testData.status === 'ok') {
                    return new Response(JSON.stringify({
                        success: true,
                        message: '카카오 웹훅 엔드포인트가 정상 작동합니다.'
                    }), { status: 200 });
                } else {
                    return new Response(JSON.stringify({
                        success: false,
                        error: '웹훅 엔드포인트 응답 오류'
                    }), { status: 400 });
                }
            } catch (e: any) {
                return new Response(JSON.stringify({
                    success: false,
                    error: `웹훅 테스트 실패: ${e.message}`
                }), { status: 400 });
            }
        }

        // Save integrations settings
        if (action === 'save') {
            await db.prepare(`
                UPDATE clinics SET integrations = ? WHERE id = 1
            `).bind(JSON.stringify(integrations)).run();

            return new Response(JSON.stringify({ success: true }), {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        return new Response(JSON.stringify({ error: 'Invalid action' }), { status: 400 });

    } catch (error: any) {
        console.error('[Integrations API] Error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};
