import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const settings = await request.json();

        // Validate required fields
        if (typeof settings.enabled !== 'boolean') {
            return new Response(JSON.stringify({ error: 'Invalid settings' }), { status: 400 });
        }

        const value = JSON.stringify(settings);

        // Upsert into settings table
        await db.prepare(`
            INSERT INTO settings (key, value, updated_at)
            VALUES ('widget_settings', ?, unixepoch())
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        `).bind(value).run();

        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Widget settings error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // Fetch widget settings
        const row = await db.prepare("SELECT value FROM settings WHERE key = 'widget_settings'").first();

        // Fetch business hours from clinic_weekly_schedules
        const { results: schedules } = await db.prepare(`
            SELECT day_of_week, is_closed, open_time, close_time 
            FROM clinic_weekly_schedules 
            ORDER BY day_of_week
        `).all();

        // Get language from query param (default to 'ko')
        const url = new URL(request.url);
        const lang = url.searchParams.get('lang') || 'ko';

        // Localization Resource
        const LOCALE_MAP: any = {
            ko: { days: ['일', '월', '화', '수', '목', '금', '토'], weekdays: '평일', everyday: '매일' },
            en: { days: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], weekdays: 'Weekdays', everyday: 'Everyday' },
            zh: { days: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'], weekdays: '工作日', everyday: '每天' },
            ja: { days: ['日', '月', '火', '水', '木', '金', '土'], weekdays: '平日', everyday: '毎日' },
            vi: { days: ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'], weekdays: 'Trong tuần', everyday: 'Hằng ngày' }
        };

        // Fetch Clinic Names for i18n
        const { results: clinicNames } = await db.prepare(
            `SELECT key, value FROM site_settings WHERE category IN ('i18n') AND key IN ('name_en', 'name_ja', 'name_zh', 'name_vi')`
        ).all();

        // Robust fetch: Try generic first row if specific ID fails, matching clinic.ts
        const defaultNameRow = await db.prepare("SELECT name FROM clinics LIMIT 1").first();
        const defaultName = defaultNameRow?.name || "Clinic";

        const nameMap: any = {
            ko: defaultName,
            en: clinicNames?.find((r: any) => r.key === 'name_en')?.value || defaultName,
            ja: clinicNames?.find((r: any) => r.key === 'name_ja')?.value || defaultName,
            zh: clinicNames?.find((r: any) => r.key === 'name_zh')?.value || defaultName,
            vi: clinicNames?.find((r: any) => r.key === 'name_vi')?.value || defaultName
        };

        const t = LOCALE_MAP[lang] || LOCALE_MAP['en'];
        const clinicName = nameMap[lang] || nameMap['en'];

        // Build business hours string from schedules
        let businessHoursString = '';
        if (schedules && schedules.length > 0) {
            const dayNames = t.days;
            const openDays = schedules.filter((s: any) => !s.is_closed);

            // Group by same hours
            const hourGroups: { [key: string]: number[] } = {};
            openDays.forEach((s: any) => {
                const key = `${s.open_time}-${s.close_time}`;
                if (!hourGroups[key]) hourGroups[key] = [];
                hourGroups[key].push(s.day_of_week);
            });

            // Format: "Term 09:00-18:00 | Day 09:00-13:00"
            const parts: string[] = [];
            for (const [hours, days] of Object.entries(hourGroups)) {
                const [open, close] = hours.split('-');
                // Check if weekdays (Mon-Fri = 1-5)
                const isWeekdays = days.length === 5 &&
                    [1, 2, 3, 4, 5].every(d => days.includes(d));

                if (isWeekdays) {
                    parts.push(`${t.weekdays} ${open} - ${close}`);
                } else {
                    const dayStr = days.map(d => dayNames[d]).join('·');
                    parts.push(`${dayStr} ${open} - ${close}`);
                }
            }
            businessHoursString = parts.join(' | ') || `${t.everyday} 09:00 - 18:00`;
        }

        const defaultSettings = {
            enabled: true,
            title: clinicName, // Add dynamic title
            primaryColor: '#0f172a',
            position: 'right',
            welcomeMessage: '안녕하세요! 무엇을 도와드릴까요?',
            offlineMessage: '현재 운영시간이 아닙니다.',
            businessHours: businessHoursString || '평일 09:00 - 18:00',
            showBusinessHours: true,
            collectName: true,
            collectPhone: true,
            autoReply: false,
            autoReplyMessage: '문의 감사합니다. 상담원이 곧 연결됩니다.'
        };

        let settings = defaultSettings;
        if (row?.value) {
            const saved = JSON.parse(row.value as string);
            // If saved businessHours is empty/undefined, use auto-fetched
            // If saved has a value, use the saved value as override
            settings = {
                ...defaultSettings,
                ...saved,
                businessHours: saved.businessHours || businessHoursString || defaultSettings.businessHours,
                title: clinicName // Always override title with DB source of truth for current lang
            };
        }

        return new Response(JSON.stringify(settings), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Widget settings error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
