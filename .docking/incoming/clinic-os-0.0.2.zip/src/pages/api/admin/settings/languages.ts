import type { APIRoute } from 'astro';

export const prerender = false;

// GET - List all languages
export const GET: APIRoute = async ({ locals }) => {
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database unavailable' }), { status: 500 });
    }

    try {
        const { results } = await db.prepare(
            "SELECT * FROM supported_locales ORDER BY sort_order ASC"
        ).all();

        return new Response(JSON.stringify(results || []), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Failed to fetch languages:', e);
        return new Response(JSON.stringify({ error: 'Failed to fetch languages' }), { status: 500 });
    }
};

// POST - Add new language
export const POST: APIRoute = async ({ request, locals }) => {
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database unavailable' }), { status: 500 });
    }

    try {
        const { code, name, native_name, flag } = await request.json();

        if (!code || !name || !native_name || !flag) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
        }

        // Check if code already exists
        const existing = await db.prepare("SELECT code FROM supported_locales WHERE code = ?").bind(code).first();
        if (existing) {
            return new Response(JSON.stringify({ error: '이미 존재하는 언어 코드입니다' }), { status: 400 });
        }

        // Get max sort_order
        const maxOrder = await db.prepare("SELECT MAX(sort_order) as max FROM supported_locales").first();
        const sortOrder = (maxOrder?.max || 0) + 1;

        await db.prepare(`
            INSERT INTO supported_locales (code, name, native_name, flag, is_active, sort_order, created_at, updated_at)
            VALUES (?, ?, ?, ?, 0, ?, unixepoch(), unixepoch())
        `).bind(code, name, native_name, flag, sortOrder).run();

        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Failed to add language:', e);
        return new Response(JSON.stringify({ error: 'Failed to add language' }), { status: 500 });
    }
};

// PATCH - Update language (toggle active status)
export const PATCH: APIRoute = async ({ request, locals }) => {
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database unavailable' }), { status: 500 });
    }

    try {
        const { code, is_active, name, native_name, flag } = await request.json();

        if (!code) {
            return new Response(JSON.stringify({ error: 'Missing code' }), { status: 400 });
        }

        // Build dynamic update
        const updates: string[] = [];
        const values: any[] = [];

        if (is_active !== undefined) {
            updates.push('is_active = ?');
            values.push(is_active ? 1 : 0);
        }
        if (name) {
            updates.push('name = ?');
            values.push(name);
        }
        if (native_name) {
            updates.push('native_name = ?');
            values.push(native_name);
        }
        if (flag) {
            updates.push('flag = ?');
            values.push(flag);
        }

        if (updates.length === 0) {
            return new Response(JSON.stringify({ error: 'No updates provided' }), { status: 400 });
        }

        updates.push('updated_at = unixepoch()');
        values.push(code);

        await db.prepare(`
            UPDATE supported_locales SET ${updates.join(', ')} WHERE code = ?
        `).bind(...values).run();

        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Failed to update language:', e);
        return new Response(JSON.stringify({ error: 'Failed to update language' }), { status: 500 });
    }
};

// DELETE - Remove language
export const DELETE: APIRoute = async ({ request, locals }) => {
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database unavailable' }), { status: 500 });
    }

    try {
        const { code } = await request.json();

        if (!code) {
            return new Response(JSON.stringify({ error: 'Missing code' }), { status: 400 });
        }

        // Prevent deleting default locale
        if (code === 'ko') {
            return new Response(JSON.stringify({ error: '기본 언어는 삭제할 수 없습니다' }), { status: 400 });
        }

        await db.prepare("DELETE FROM supported_locales WHERE code = ?").bind(code).run();

        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Failed to delete language:', e);
        return new Response(JSON.stringify({ error: 'Failed to delete language' }), { status: 500 });
    }
};
