import type { APIRoute } from 'astro';

/**
 * DEPRECATED: This legacy API is no longer used.
 * All messaging now goes through the channel-based API:
 *   - GET /api/admin/channels/[channelId]/messages
 *   - POST /api/admin/channels/[channelId]/messages
 * 
 * Keeping DELETE for backwards compatibility (message deletion by ID).
 */

export const GET: APIRoute = async () => {
    return new Response(JSON.stringify({
        error: 'DEPRECATED: Use /api/admin/channels/[channelId]/messages instead',
        redirect: '/api/admin/channels'
    }), { status: 410 }); // 410 Gone
};

export const POST: APIRoute = async () => {
    return new Response(JSON.stringify({
        error: 'DEPRECATED: Use /api/admin/channels/[channelId]/messages instead',
        redirect: '/api/admin/channels'
    }), { status: 410 });
};

export const DELETE: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    try {
        const url = new URL(request.url);
        const id = url.searchParams.get('id');
        const currentAdminId = url.searchParams.get('currentAdminId');

        if (!id || !currentAdminId) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
        }

        // Verify ownership
        const msg = await db.prepare("SELECT sender_id FROM admin_messages WHERE id = ?").bind(id).first();
        if (!msg) {
            return new Response(JSON.stringify({ error: 'Message not found' }), { status: 404 });
        }
        if (msg.sender_id !== currentAdminId) {
            return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 403 });
        }

        // Soft delete
        const now = Math.floor(Date.now() / 1000);
        await db.prepare("UPDATE admin_messages SET deleted_at = ? WHERE id = ?").bind(now, id).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
