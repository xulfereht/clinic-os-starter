import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    // @ts-ignore
    const currentAdminId = locals.user?.id;
    if (!currentAdminId) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    const url = new URL(request.url);
    const q = url.searchParams.get('q');
    const limit = url.searchParams.get('limit') || '20';

    if (!q || q.length < 2) {
        return new Response(JSON.stringify({ messages: [] }), {
            headers: { 'Content-Type': 'application/json' }
        });
    }

    try {
        // Search messages ONLY in channels the user is a member of
        const query = `
            SELECT 
                m.*, 
                c.name as channel_name,
                c.type as channel_type,
                COALESCE(s.name, l.name, '알 수 없음') as sender_name,
                s.image as sender_image
            FROM admin_messages m
            JOIN channels c ON m.channel_id = c.id
            JOIN channel_members cm ON c.id = cm.channel_id
            LEFT JOIN staff s ON m.sender_id = s.id
            LEFT JOIN leads l ON m.sender_id = l.id
            WHERE cm.user_id = ? 
            AND m.content LIKE ?
            ORDER BY m.created_at DESC
            LIMIT ?
        `;

        const { results } = await db.prepare(query).bind(currentAdminId, `%${q}%`, limit).all();

        return new Response(JSON.stringify({ messages: results }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Search error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
