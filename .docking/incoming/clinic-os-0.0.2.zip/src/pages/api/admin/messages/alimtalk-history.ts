import type { APIRoute } from 'astro';
import { getAligoConfig, getAlimTalkHistory } from '../../../../lib/aligo';

export const GET: APIRoute = async ({ request, locals }) => {
    const user = locals.user;
    if (!user) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    const db = locals.runtime?.env?.DB as any;
    const env = locals.runtime?.env as any;

    try {
        const url = new URL(request.url);
        const page = Number(url.searchParams.get('page')) || 1;
        const limit = Number(url.searchParams.get('limit')) || 30;

        // Default to today/yesterday if needed, but API defaults are usually recent
        const start_date = url.searchParams.get('start_date') || undefined;
        const end_date = url.searchParams.get('end_date') || undefined;

        const config = await getAligoConfig(env, db);
        if (!config) {
            return new Response(JSON.stringify({ error: 'Configuration Missing' }), { status: 500 });
        }

        const mid = url.searchParams.get('mid');
        if (mid) {
            // Fetch Detail
            const { getAlimTalkDetail } = await import('../../../../lib/aligo');
            const result = await getAlimTalkDetail(config, mid);
            return new Response(JSON.stringify(result), { status: 200 });
        }

        const result = await getAlimTalkHistory(config, { page, limit, start_date, end_date });
        return new Response(JSON.stringify(result), { status: 200 });

    } catch (error) {
        console.error('AlimTalk History Error:', error);
        return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
    }
};
