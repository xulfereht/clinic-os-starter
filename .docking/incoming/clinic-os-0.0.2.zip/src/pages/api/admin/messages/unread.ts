import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
    }

    const url = new URL(request.url);
    const adminId = url.searchParams.get('adminId');

    if (!adminId) {
        return new Response(JSON.stringify({ error: 'adminId required' }), { status: 400 });
    }

    try {
        // Get messages that this admin hasn't read yet based on channel last_read_at
        const { results } = await db.prepare(`
            SELECT m.*, s.name as sender_name, s.image as sender_image
            FROM admin_messages m
            JOIN channel_members cm ON m.channel_id = cm.channel_id
            JOIN staff s ON m.sender_id = s.id
            WHERE cm.user_id = ?
            AND m.sender_id != ? -- Exclude my own messages
            AND m.created_at > cm.last_read_at
            ORDER BY m.created_at DESC
            LIMIT 10
        `).bind(adminId, adminId).all();

        return new Response(JSON.stringify({
            unreadMessages: results,
            count: results.length
        }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Error fetching unread messages:', e);
        return new Response(JSON.stringify({ error: 'Failed to fetch unread messages' }), { status: 500 });
    }
};
