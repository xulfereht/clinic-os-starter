import type { APIRoute } from 'astro';

/**
 * On-demand translation for a specific message.
 * Called when admin clicks "Translate" button on a message.
 */
export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    try {
        const { messageId, channelId } = await request.json();

        if (!messageId || !channelId) {
            return new Response(JSON.stringify({ error: 'Missing messageId or channelId' }), { status: 400 });
        }

        // 1. Get the message
        const message = await db.prepare("SELECT id, content, sender_id FROM admin_messages WHERE id = ?").bind(messageId).first();
        if (!message || !message.content) {
            return new Response(JSON.stringify({ error: 'Message not found' }), { status: 404 });
        }

        // 2. Get channel to determine lead and their language
        const channel = await db.prepare("SELECT lead_id FROM channels WHERE id = ?").bind(channelId).first();
        if (!channel || !channel.lead_id) {
            return new Response(JSON.stringify({ error: 'Channel or lead not found' }), { status: 404 });
        }

        // 3. Check if sender is staff or lead
        const staff = await db.prepare("SELECT id FROM staff WHERE id = ?").bind(message.sender_id).first();
        const isStaff = !!staff;

        // 4. Get lead language (this is updated when admin changes target language)
        const lead = await db.prepare("SELECT language FROM leads WHERE id = ?").bind(channel.lead_id).first() as any;
        const leadLang = lead?.language || 'ko';

        // 5. Determine translation direction
        let targetLang: string;
        let sourceLang: string;

        if (isStaff) {
            // Staff message: Translate from Korean to Lead's language
            if (leadLang === 'ko') {
                return new Response(JSON.stringify({ success: true, message: 'Lead is Korean, no translation needed' }));
            }
            targetLang = leadLang;
            sourceLang = 'ko';
        } else {
            // Customer message: Translate from their language to Korean
            // Detect language first
            const { TranslationOrchestrator } = await import('../../../../lib/translation/orchestrator');
            const orchestrator = new TranslationOrchestrator(db);
            const detectedLang = await orchestrator.detectLanguage(message.content as string);

            if (detectedLang === 'ko' || detectedLang === 'und') {
                return new Response(JSON.stringify({ success: true, message: 'Already in Korean or undetected' }));
            }

            // Update lead language if not set
            if (leadLang === 'ko') {
                await db.prepare("UPDATE leads SET language = ? WHERE id = ?").bind(detectedLang, channel.lead_id).run();
            }

            targetLang = 'ko';
            sourceLang = detectedLang;
        }

        const { TranslationOrchestrator } = await import('../../../../lib/translation/orchestrator');
        const orchestrator = new TranslationOrchestrator(db);
        const translatedText = await orchestrator.translateAndSave(messageId, message.content as string, targetLang, sourceLang);

        if (!translatedText) {
            return new Response(JSON.stringify({ error: 'Translation failed or service not configured' }), { status: 500 });
        }

        return new Response(JSON.stringify({ success: true, translatedText }));

    } catch (e: any) {
        console.error('[Translate API]', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
