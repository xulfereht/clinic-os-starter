import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { adminId, messageId } = body;

        if (!adminId) {
            return new Response(JSON.stringify({ error: 'adminId required' }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);

        if (messageId) {
            // Mark a specific message as read
            const id = crypto.randomUUID();
            await db.prepare(`
                INSERT OR IGNORE INTO message_reads (id, message_id, reader_id, read_at)
                VALUES (?, ?, ?, ?)
            `).bind(id, messageId, adminId, now).run();
        } else {
            // Mark all unread messages as read
            const { results: unreadMessages } = await db.prepare(`
                SELECT m.id FROM admin_messages m
                LEFT JOIN message_reads r ON m.id = r.message_id AND r.reader_id = ?
                WHERE m.sender_id != ? AND r.id IS NULL
            `).bind(adminId, adminId).all();

            for (const msg of unreadMessages) {
                const id = crypto.randomUUID();
                await db.prepare(`
                    INSERT OR IGNORE INTO message_reads (id, message_id, reader_id, read_at)
                    VALUES (?, ?, ?, ?)
                `).bind(id, msg.id, adminId, now).run();
            }
        }

        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Error marking messages as read:', e);
        return new Response(JSON.stringify({ error: 'Failed to mark as read' }), { status: 500 });
    }
};
