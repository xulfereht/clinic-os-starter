import type { APIRoute } from 'astro';
import { sendAligoMessage, sendAlimTalk, getAligoConfig } from '../../../../lib/aligo';
import { getSurveyLink } from '../../../../lib/survey-registry';
import { generateSignedUrl } from '../../../../lib/crypto';
import { createShortLink } from '../../../../lib/shortener';

export const GET: APIRoute = async () => {
    return new Response(JSON.stringify({ status: 'ok', message: 'Send endpoint is ready' }), { status: 200 });
};

export const POST: APIRoute = async ({ request, locals }) => {
    const user = locals.user;
    if (!user) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    const db = locals.runtime?.env?.DB as any;
    const env = locals.runtime?.env as any;

    try {
        const body = await request.json();

        let { patientId, message, channel, alimtalk_code, template_id, title, survey_id } = body;

        // Default channel
        if (!channel) channel = 'SMS';

        console.log('[API] Sending Message:', { patientId, channel, alimtalk_code, template_id });

        if (!patientId) {
            return new Response(JSON.stringify({ error: 'Patient ID is required' }), { status: 400 });
        }
        if (!message) {
            return new Response(JSON.stringify({ error: 'Message content is required' }), { status: 400 });
        }

        // AUTO-DETECT REMOVED: Respect frontend channel selection
        /*
        if (template_id) {
            const template = await db.prepare('SELECT alimtalk_code FROM message_templates WHERE id = ?').bind(template_id).first();
            if (template && template.alimtalk_code) {
                console.log(`[Auto-Switch] Template ${template_id} has code ${template.alimtalk_code}. Switching channel to ALIMTALK.`);
                channel = 'ALIMTALK';
                if (!alimtalk_code) {
                    alimtalk_code = template.alimtalk_code;
                }
            }
        }
        */

        // 1. Fetch Patient Info & Clinic Info
        const patient = await db.prepare('SELECT id, name, current_phone FROM patients WHERE id = ?').bind(patientId).first();
        if (!patient || !patient.current_phone) {
            return new Response(JSON.stringify({ error: 'Patient not found or no phone number' }), { status: 404 });
        }

        // Fetch Clinic Info via settings helper requires db, but we have raw query here.
        // Let's stick to raw query but use defaults.
        const clinic = await db.prepare("SELECT name, phone, address, bank_info FROM clinics LIMIT 1").first() as { name: string, phone: string, address: string, bank_info: string } | null;

        // Also fetch from settings table for url
        const urlSetting = await db.prepare("SELECT value FROM site_settings WHERE category='general' AND key='url'").first();

        const clinicName = clinic?.name || 'Clinic';
        const clinicPhone = clinic?.phone || '';
        const clinicAddress = clinic?.address || '';
        const bankInfo = clinic?.bank_info || '';
        const baseUrl = (urlSetting?.value as string) || 'https://sample-clinic.com';

        // Generate Survey Link
        const targetSurveyId = survey_id || 'diagnosis_weighted_v2';
        const rawUrl = getSurveyLink(targetSurveyId, String(patient.id), baseUrl);

        // Generate Signed Link
        // Use a default secret if env not available (should be in env)
        const secret = env.JWT_SECRET || 'clinic-survey-secret-key-2025';
        const signedUrl = await generateSignedUrl(rawUrl, secret);

        // Generate Short Link
        // We need to use the origin from the request or a configured base URL for the short link
        // baseUrl is 'https://brd-clinic.com', but short links are usually on 'https://www.baekrokdam.com' or similar?
        // The preview uses window.location.origin which is likely the admin domain.
        // But the short link generator in api/shorten.ts uses request.url origin for the short link domain itself.
        // Wait, if we are in admin API, request.url origin is the admin domain.
        // We probably want the short link to point to the main site or where /s/ handler is.
        // Let's assume the request origin is correct for now, or use the configured baseUrl.
        // Actually api/shorten.ts returns `${origin}/s/${code}`. 
        // If we run this on the server, we can construct it.
        // Let's use baseUrl (brd-clinic.com) or the request URL. 
        // If brd-clinic.com is the main domain handling /s/, we should use it.
        // Use CLOUDFLARE_URL from env or fallback
        const baseUrl = env.CLOUDFLARE_URL || 'https://clinic-os.pages.dev';

        // Generate Short Link for Survey
        let surveyUrl = signedUrl;
        try {
            const { code } = await createShortLink(db, signedUrl);
            surveyUrl = `${baseUrl}/s/${code}`;
        } catch (e) {
            console.error('Failed to shorten survey link:', e);
        }

        // Generate Upload Link
        const rawUploadUrl = `${baseUrl}/upload/${patientId}`;
        let uploadUrl = rawUploadUrl;
        try {
            const { code } = await createShortLink(db, rawUploadUrl);
            uploadUrl = `${baseUrl}/s/${code}`;
        } catch (e) {
            console.error('Failed to shorten upload link:', e);
        }

        // Fetch Next Reservation
        const now = new Date();
        const reservation = await db.prepare(`
            SELECT reserved_at FROM reservations 
            WHERE patient_id = ? 
            AND status NOT IN ('cancelled', 'no_show', 'completed')
            ORDER BY reserved_at ASC
        `).bind(patientId).all();

        // 8.1 Find Next Upcoming Reservation (JS Filtering for safety)
        let nextReservation = null;
        if (reservation && reservation.results) {
            const upcoming = reservation.results.filter((r: any) => {
                let rDate;
                if (typeof r.reserved_at === 'number') {
                    rDate = new Date(r.reserved_at * 1000);
                } else {
                    rDate = new Date(r.reserved_at);
                }
                return rDate > now;
            });

            if (upcoming.length > 0) {
                nextReservation = upcoming[0];
            }
        }

        let resDate = '';
        let resTime = '';
        let resDateTime = '';

        if (nextReservation && nextReservation.reserved_at) {
            let rDate: Date;
            if (typeof nextReservation.reserved_at === 'number') {
                rDate = new Date(nextReservation.reserved_at * 1000);
            } else {
                rDate = new Date(nextReservation.reserved_at);
            }

            // Format to KST (UTC+9)
            const kstOffset = 9 * 60 * 60 * 1000;
            const kstDate = new Date(rDate.getTime() + kstOffset);

            const month = kstDate.getUTCMonth() + 1;
            const day = kstDate.getUTCDate();
            const hour = kstDate.getUTCHours();
            const minute = kstDate.getUTCMinutes();
            const year = kstDate.getUTCFullYear();

            const pad = (n: number) => n.toString().padStart(2, '0');

            resDate = `${year}-${pad(month)}-${pad(day)}`;
            resTime = `${pad(hour)}:${pad(minute)}`;
            resDateTime = `${month}월 ${day}일 ${pad(hour)}:${pad(minute)}`;
        }

        // Variable Substitution
        let content = message;

        // Clinic Variables
        content = content.replace(/#{clinic_name}|{clinic_name}/g, clinicName);
        content = content.replace(/#{clinic_phone}|{clinic_phone}/g, clinicPhone);
        content = content.replace(/#{clinic_address}|{clinic_address}/g, clinicAddress);
        content = content.replace(/#{bank_info}|{bank_info}/g, bankInfo);
        // Clear old individual bank variables
        content = content.replace(/#{bank_name}|{bank_name}/g, '');
        content = content.replace(/#{bank_account}|{bank_account}/g, '');
        content = content.replace(/#{bank_holder}|{bank_holder}/g, '');
        content = content.replace(/#{url}|{url}|#{survey_link}|{survey_link}|#{survey_url}|{survey_url}/g, surveyUrl);
        content = content.replace(/#{upload_link}|{upload_link}|#{upload_url}|{upload_url}/g, uploadUrl);

        // Reservation Variables
        content = content.replace(/#{reservation_date}|{reservation_date}|#{예약일}/g, resDate);
        content = content.replace(/#{reservation_time}|{reservation_time}|#{예약시간}/g, resTime);
        content = content.replace(/#{reservation_datetime}|{reservation_datetime}|#{예약일시}/g, resDateTime);

        // Patient Variables
        content = content.replace(/#{이름}|{이름}|#{name}|{name}|#{patient_name}|{patient_name}/g, patient.name || '고객님');
        content = content.replace(/#{휴대폰}|{휴대폰}/g, patient.current_phone);
        content = content.replace(/#{tracking_number}|{tracking_number}/g, '');

        // 2. Configure Aligo
        const config = await getAligoConfig(env, db);
        if (!config) {
            return new Response(JSON.stringify({ error: 'SMS Configuration Missing' }), { status: 500 });
        }

        let sendResult;
        let msgType = '';
        let finalStatus = 'failed';
        let errorMessage = null;
        let debugInfo: any = null; // For AlimTalk debugging


        // 3. Send Message based on Channel
        // Apply variable substitution to Title/Subject as well
        let finalTitle = title || '';

        // If no title provided, use default with variable
        if (!finalTitle) {
            finalTitle = '#{clinic_name} 알림';
        }

        // Clinic Variables in Title
        finalTitle = finalTitle.replace(/#{clinic_name}|{clinic_name}/g, clinicName);
        finalTitle = finalTitle.replace(/#{clinic_phone}|{clinic_phone}/g, clinicPhone);

        // Patient Variables in Title
        finalTitle = finalTitle.replace(/#{이름}|{이름}|#{name}|{name}|#{patient_name}|{patient_name}/g, patient.name || '고객님');

        if (channel === 'ALIMTALK') {
            if (!alimtalk_code) {
                return new Response(JSON.stringify({ error: 'AlimTalk Template Code is required' }), { status: 400 });
            }

            // Fetch template to get buttons and name
            const template = await db.prepare('SELECT name, content, alimtalk_code, buttons FROM message_templates WHERE alimtalk_code = ?')
                .bind(alimtalk_code)
                .first() as { name: string; content: string; alimtalk_code: string; buttons: string | null } | null;

            if (!template) {
                return new Response(JSON.stringify({ error: 'Template not found' }), { status: 404 });
            }

            // Use shared library to send AlimTalk
            const { sendAlimTalkMessage } = await import('../../../../lib/alimtalk-sender');

            try {
                // Use `content` (from body message variable) as the template content
                // This ensures we respect the frontend's variable substitution (e.g. shipping info)
                sendResult = await sendAlimTalkMessage(config, {
                    receiver: patient.current_phone,
                    template: {
                        name: template.name,
                        content: content, // Use substituted content
                        alimtalk_code: template.alimtalk_code,
                        buttons: template.buttons
                    },
                    variables: {
                        clinic_name: clinicName,
                        clinic_phone: clinicPhone,
                        clinic_address: clinicAddress,
                        bank_info: bankInfo,
                        patient_name: patient.name || '고객님',
                        patient_phone: patient.current_phone,
                        reservation_date: resDate,
                        reservation_time: resTime,
                        reservation_datetime: resDateTime,
                        survey_url: surveyUrl,
                        upload_url: uploadUrl
                    },
                    failover: 'N'
                });
            } catch (error: any) {
                return new Response(JSON.stringify({
                    error: 'Failed to send AlimTalk',
                    details: error.message
                }), { status: 500 });
            }

            msgType = 'ALIMTALK';
        } else {
            // SMS / LMS
            sendResult = await sendAligoMessage(config, {
                receiver: patient.current_phone,
                msg: content,
                title: finalTitle,
                destination: `${patient.current_phone}|${patient.name}`
            });
            msgType = (content.length > 90) ? 'LMS' : 'SMS';
        }

        // 4. Handle Result & Logging
        // sendAlimTalk/sendAligoMessage return AligoResponse which has result_code (string)
        // Some responses might have 'code' (number) from raw parse, but interface defines result_code
        // CRITICAL FIX: AlimTalk success might be code: 0, while SMS is result_code: 1.
        // We check for result_code '1' OR (code exists and equals 0)
        // Safely access 'code' by casting to any
        const rawResult = sendResult as any;
        const isSuccess = (String(sendResult.result_code) === '1') || (rawResult.code !== undefined && Number(rawResult.code) === 0);

        finalStatus = isSuccess ? 'sent' : 'failed';

        // DEBUG: For AlimTalk, always log the full response to debug failovers. 
        // This helps identify why it fell back to SMS even if 'isSuccess' is true (failover success).
        if (msgType === 'ALIMTALK') {
            errorMessage = JSON.stringify(sendResult);
        } else {
            errorMessage = finalStatus === 'failed' ? (sendResult.message || 'Unknown Error') : null;
        }

        await db.prepare(`
            INSERT INTO message_logs (
                campaign_id, patient_id, patient_name, phone, 
                message_type, content, status, error_message, result_code, sent_at, type
            ) VALUES (
                NULL, ?, ?, ?, 
                ?, ?, ?, ?, ?, strftime('%s', 'now'), 'individual'
            )
        `).bind(
            patientId,
            patient.name,
            patient.current_phone,
            msgType,
            content,
            finalStatus,
            errorMessage,
            String(sendResult.result_code || '')
        ).run();

        if (finalStatus === 'sent') {
            return new Response(JSON.stringify({
                success: true,
                result: sendResult,
                debug: debugInfo // Include debug info for AlimTalk
            }), { status: 200 });
        } else {
            return new Response(JSON.stringify({
                success: false,
                error: errorMessage,
                debug: debugInfo // Include debug info for AlimTalk
            }), { status: 500 });
        }

    } catch (error) {
        console.error('Message Send Error:', error);
        return new Response(JSON.stringify({
            error: 'Internal Server Error',
            details: error instanceof Error ? error.message : String(error)
        }), { status: 500 });
    }
};
