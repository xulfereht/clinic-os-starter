import type { APIRoute } from 'astro';

export const prerender = false;

function cleanupSlug(text: string) {
    return text
        .toString()
        .toLowerCase()
        .trim()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '')
        .replace(/\-\-+/g, '-')
        .replace(/^-+/, '')
        .replace(/-+$/, '');
}

export const PUT: APIRoute = async ({ request, params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response("Database not available", { status: 500 });

    const { id } = params;
    if (!id) return new Response("ID is required", { status: 400 });

    try {
        const data = await request.json();

        let updateQuery = "UPDATE pages SET updated_at = ?";
        const bindParams: (string | number | null)[] = [Math.floor(Date.now() / 1000)];

        if (data.title) {
            updateQuery += ", title = ?";
            bindParams.push(data.title);
        }
        if (data.slug) {
            const slug = cleanupSlug(data.slug);
            // Check for conflict
            const conflict = await db.prepare("SELECT id FROM pages WHERE slug = ? AND id != ?").bind(slug, id).first();
            if (conflict) {
                return new Response(JSON.stringify({ error: "이미 존재하는 슬러그입니다." }), { status: 409 });
            }
            updateQuery += ", slug = ?";
            bindParams.push(slug);
        }
        if (data.description !== undefined) {
            updateQuery += ", description = ?";
            bindParams.push(data.description);
        }
        if (data.is_published !== undefined) {
            updateQuery += ", is_published = ?";
            bindParams.push(data.is_published ? 1 : 0);
        }
        if (data.sections !== undefined) {
            updateQuery += ", sections = ?";
            bindParams.push(JSON.stringify(data.sections));
        }
        if (data.translations !== undefined) {
            updateQuery += ", translations = ?";
            bindParams.push(JSON.stringify(data.translations));
        }

        updateQuery += " WHERE id = ?";
        bindParams.push(id);

        await db.prepare(updateQuery).bind(...bindParams).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });

    } catch (e: any) {
        console.error("Failed to update page:", e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}

export const DELETE: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response("Database not available", { status: 500 });

    const { id } = params;

    try {
        await db.prepare("DELETE FROM pages WHERE id = ?").bind(id).run();
        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
