
export const prerender = false;

import { cleanupSlug } from "../../../../lib/utils";

export async function POST({ request, locals }) {
    const db = locals.runtime.env.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const data = await request.json();

        // Validation
        if (!data.title) {
            return new Response(JSON.stringify({ error: "제목은 필수입니다." }), { status: 400 });
        }
        if (!data.slug) {
            return new Response(JSON.stringify({ error: "슬러그는 필수입니다." }), { status: 400 });
        }

        const slug = cleanupSlug(data.slug);

        // Check for duplicate slug
        const existing = await db.prepare("SELECT id FROM pages WHERE slug = ?").bind(slug).first();
        if (existing) {
            return new Response(JSON.stringify({ error: "이미 존재하는 슬러그입니다." }), { status: 409 });
        }

        const id = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        await db.prepare(`
            INSERT INTO pages (id, slug, title, description, sections, is_published, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            id,
            slug,
            data.title,
            data.description || '',
            '[]', // Empty sections initially
            0, // Default to unpublished
            now,
            now
        ).run();

        return new Response(JSON.stringify({ success: true, id }), { status: 200 });

    } catch (e) {
        console.error("Failed to create page:", e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
