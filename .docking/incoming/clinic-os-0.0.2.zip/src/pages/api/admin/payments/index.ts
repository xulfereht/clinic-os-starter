import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const url = new URL(request.url);
        const period = url.searchParams.get('period') || 'today'; // today, week, month, all
        const status = url.searchParams.get('status') || 'all';   // all, completed, refunded, cancelled
        const search = url.searchParams.get('q') || '';

        // Calculate date range in KST
        const now = new Date();
        const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
        const kstOffset = 9 * 60 * 60 * 1000;
        const nowKst = new Date(utc + kstOffset);

        const todayKst = new Date(nowKst);
        todayKst.setHours(0, 0, 0, 0);
        const todayStart = Math.floor(todayKst.getTime() / 1000);

        let startDate: number;
        switch (period) {
            case 'week':
                startDate = todayStart - (7 * 24 * 60 * 60);
                break;
            case 'month':
                startDate = todayStart - (30 * 24 * 60 * 60);
                break;
            case 'all':
                startDate = 0;
                break;
            default: // today
                startDate = todayStart;
        }

        // Build query
        let query = `
            SELECT 
                p.id,
                p.patient_id,
                p.product_id,
                p.amount,
                p.original_amount,
                p.discount_amount,
                p.quantity,
                p.method,
                p.status,
                p.notes,
                p.paid_at,
                p.created_at,
                p.refund_amount,
                pat.name as patient_name,
                pat.current_phone as patient_phone,
                prod.name as product_name
            FROM payments p
            LEFT JOIN patients pat ON p.patient_id = pat.id
            LEFT JOIN products prod ON p.product_id = prod.id
            WHERE p.paid_at >= ? AND p.deleted_at IS NULL
        `;
        const params: any[] = [startDate];

        if (status !== 'all') {
            query += ` AND p.status = ?`;
            params.push(status);
        }

        if (search) {
            query += ` AND (pat.name LIKE ? OR pat.current_phone LIKE ?)`;
            params.push(`%${search}%`, `%${search}%`);
        }

        query += ` ORDER BY p.paid_at DESC LIMIT 200`;

        const { results: payments } = await db.prepare(query).bind(...params).run();

        // Get summary stats
        const statsQuery = `
            SELECT 
                COUNT(*) as total_count,
                SUM(CASE WHEN status = 'completed' OR status IS NULL THEN amount ELSE 0 END) as total_revenue,
                SUM(CASE WHEN status = 'refunded' THEN amount ELSE 0 END) as total_refunded,
                SUM(CASE WHEN status = 'cancelled' THEN amount ELSE 0 END) as total_cancelled
            FROM payments
            WHERE paid_at >= ? AND deleted_at IS NULL
        `;
        const stats = await db.prepare(statsQuery).bind(startDate).first();

        return new Response(JSON.stringify({
            success: true,
            payments,
            stats: {
                count: stats?.total_count || 0,
                revenue: Number(stats?.total_revenue || 0),
                refunded: Number(stats?.total_refunded || 0),
                cancelled: Number(stats?.total_cancelled || 0),
                net: Number(stats?.total_revenue || 0) - Number(stats?.total_refunded || 0)
            },
            period,
            startDate
        }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
