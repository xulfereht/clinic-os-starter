import type { APIRoute } from 'astro';

export const DELETE: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // 1. Get full payment details before deleting
        const payment = await db.prepare(`
            SELECT p.*, prod.name as product_name 
            FROM payments p
            LEFT JOIN products prod ON p.product_id = prod.id
            WHERE p.id = ?
        `).bind(id).first() as any;

        if (!payment) {
            return new Response(JSON.stringify({ error: 'Payment not found' }), { status: 404 });
        }

        const now = Math.floor(Date.now() / 1000);
        const isRefundRecord = payment.amount < 0 || payment.status === 'refund';

        // 2. Handle Shipping Order adjustment
        const qty = Math.abs(payment.quantity || 1);
        if (qty > 0) {
            let productName = payment.product_name;
            if (!productName && payment.notes) {
                productName = (payment.notes as string).split('\n')[0].substring(0, 50);
            }

            if (productName) {
                const activeOrder = await db.prepare(`
                    SELECT * FROM shipping_orders 
                    WHERE patient_id = ? AND product_name = ? AND status = 'active'
                `).bind(payment.patient_id, productName).first() as { id: string, remaining_quantity: number, total_quantity: number } | null;

                if (activeOrder) {
                    let newTotal, newRemaining;

                    if (isRefundRecord) {
                        // Deleting a REFUND -> Restore the quantity (Undo Refund)
                        newTotal = activeOrder.total_quantity + qty;
                        newRemaining = activeOrder.remaining_quantity + qty;
                    } else {
                        // Deleting a PURCHASE -> Remove the quantity (Undo Purchase)
                        newTotal = Math.max(0, activeOrder.total_quantity - qty);
                        newRemaining = Math.max(0, activeOrder.remaining_quantity - qty);
                    }

                    await db.prepare(`
                        UPDATE shipping_orders 
                        SET total_quantity = ?, remaining_quantity = ?
                        WHERE id = ?
                    `).bind(newTotal, newRemaining, activeOrder.id).run();
                }
            }
        }

        // 2.5 Revert Original Payment Status (If deleting a refund)
        if (payment.original_payment_id) {
            const originalPayment = await db.prepare("SELECT * FROM payments WHERE id = ?").bind(payment.original_payment_id).first() as { id: string, amount: number, refund_amount: number, status: string } | null;

            if (originalPayment) {
                const refundAmountToRemove = Math.abs(payment.amount);
                const newRefundedAmount = Math.max(0, (originalPayment.refund_amount || 0) - refundAmountToRemove);

                let newStatus = 'paid';
                if (newRefundedAmount >= originalPayment.amount) {
                    newStatus = 'refunded';
                } else if (newRefundedAmount > 0) {
                    newStatus = 'partially_refunded';
                }

                await db.prepare("UPDATE payments SET refund_amount = ?, status = ?, updated_at = ? WHERE id = ?")
                    .bind(newRefundedAmount, newStatus, now, payment.original_payment_id)
                    .run();
            }
        }

        // 3. Soft Delete Payment
        await db.prepare("UPDATE payments SET deleted_at = ? WHERE id = ?").bind(now, id).run();

        // 4. Update Patient Stats (exclude deleted and refund records)
        // 4. Update Patient Stats
        const stats = await db.prepare(`
            SELECT SUM(amount) as total, COUNT(*) as count
            FROM payments 
            WHERE patient_id = ? AND (status = 'completed' OR status IS NULL) AND deleted_at IS NULL
        `).bind(payment.patient_id).first();

        const total = Number(stats?.total) || 0;
        const count = Number(stats?.count) || 0;

        await db.prepare(`
            UPDATE patients 
            SET total_payment = ?, 
                average_transaction = ?,
                payment_count = ?
            WHERE id = ?
        `).bind(
            total,
            count > 0 ? Math.floor(total / count) : 0,
            count,
            payment.patient_id
        ).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

// PATCH: Update payment (including refund records)
export const PATCH: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const now = Math.floor(Date.now() / 1000);

        // Get current payment info
        const payment = await db.prepare(`
            SELECT p.*, prod.name as product_name 
            FROM payments p 
            LEFT JOIN products prod ON p.product_id = prod.id
            WHERE p.id = ?
        `).bind(id).first() as any;

        if (!payment) {
            return new Response(JSON.stringify({ error: 'Payment not found' }), { status: 404 });
        }

        // Check if this is a field update (edit mode) or status change
        const isFieldUpdate = body.amount !== undefined || body.quantity !== undefined ||
            body.notes !== undefined || body.paid_at !== undefined ||
            body.discount_amount !== undefined || body.original_payment_id !== undefined ||
            body.product_id !== undefined;

        const isStatusChange = body.status !== undefined;

        if (isFieldUpdate) {
            // --- FIELD UPDATE MODE ---
            const updates: string[] = [];
            const values: any[] = [];

            // Track changes for history
            const changes: { field: string; from: any; to: any }[] = [];

            if (body.amount !== undefined && body.amount !== payment.amount) {
                updates.push('amount = ?');
                values.push(body.amount);
                changes.push({ field: '금액', from: payment.amount, to: body.amount });
            }
            if (body.quantity !== undefined && body.quantity !== payment.quantity) {
                updates.push('quantity = ?');
                values.push(body.quantity);
                changes.push({ field: '수량', from: payment.quantity || 1, to: body.quantity });
            }
            if (body.notes !== undefined && body.notes !== payment.notes) {
                updates.push('notes = ?');
                values.push(body.notes);
                changes.push({ field: '메모', from: payment.notes || '', to: body.notes });
            }
            if (body.discount_amount !== undefined && body.discount_amount !== payment.discount_amount) {
                updates.push('discount_amount = ?');
                values.push(body.discount_amount);
                changes.push({ field: '할인금액', from: payment.discount_amount || 0, to: body.discount_amount });
            }
            if (body.paid_at !== undefined) {
                const paidAtTs = body.paid_at ? Math.floor(new Date(body.paid_at).getTime() / 1000) : payment.paid_at;
                if (paidAtTs !== payment.paid_at) {
                    updates.push('paid_at = ?');
                    values.push(paidAtTs);
                    const oldDate = payment.paid_at ? new Date(payment.paid_at * 1000).toLocaleDateString('ko-KR') : '-';
                    const newDate = paidAtTs ? new Date(paidAtTs * 1000).toLocaleDateString('ko-KR') : '-';
                    changes.push({ field: '결제일', from: oldDate, to: newDate });
                }
            }
            if (body.original_payment_id !== undefined) {
                updates.push('original_payment_id = ?');
                values.push(body.original_payment_id || null);
            }
            if (body.product_id !== undefined && body.product_id !== payment.product_id) {
                updates.push('product_id = ?');
                values.push(body.product_id || null);
                changes.push({ field: '상품', from: payment.product_name || '-', to: body.product_id || '직접입력' });
            }

            // Only update if there are actual changes
            if (updates.length === 0) {
                return new Response(JSON.stringify({ success: true, message: 'No changes detected' }), { status: 200 });
            }

            // Add updated_at
            updates.push('updated_at = ?');
            values.push(now);

            values.push(id);

            await db.prepare(`UPDATE payments SET ${updates.join(', ')} WHERE id = ?`).bind(...values).run();

            // Create payment_update event in patient_events for audit trail
            if (changes.length > 0) {
                const eventId = crypto.randomUUID();
                const updateReason = body.update_reason || '사유 미입력';

                // Build change summary
                const changeSummary = changes.map(c => `${c.field}: ${c.from} → ${c.to}`).join('\n');
                const eventContent = `[수정 사유] ${updateReason}\n\n[변경 내역]\n${changeSummary}`;

                await db.prepare(`
                    INSERT INTO patient_events (id, patient_id, type, title, content, event_date, created_at)
                    VALUES (?, ?, 'payment_update', '결제 정보 수정', ?, ?, ?)
                `).bind(eventId, payment.patient_id, eventContent, now, now).run();
            }

            // Handle shipping quantity adjustment for refund records
            const isRefundRecord = payment.amount < 0 || payment.status === 'refund';

            if (isRefundRecord && body.quantity !== undefined && body.quantity !== payment.quantity) {
                const oldQty = Math.abs(payment.quantity || 0);
                const newQty = Math.abs(body.quantity || 0);
                const qtyDiff = newQty - oldQty; // positive = more refund, negative = less refund

                let productName = payment.product_name;
                if (!productName && payment.notes) {
                    productName = (payment.notes as string).split('\n')[0].substring(0, 50);
                }

                if (productName && qtyDiff !== 0) {
                    const activeOrder = await db.prepare(`
                        SELECT * FROM shipping_orders 
                        WHERE patient_id = ? AND product_name = ? AND status = 'active'
                    `).bind(payment.patient_id, productName).first() as { id: string, remaining_quantity: number, total_quantity: number } | null;

                    if (activeOrder) {
                        // qtyDiff > 0 means more quantity is being refunded, so reduce remaining more
                        // qtyDiff < 0 means less quantity is being refunded, so restore remaining
                        const newRemaining = Math.max(0, activeOrder.remaining_quantity - qtyDiff);

                        await db.prepare(`
                            UPDATE shipping_orders 
                            SET remaining_quantity = ?, updated_at = ?
                            WHERE id = ?
                        `).bind(newRemaining, now, activeOrder.id).run();
                    }
                }
            }

            // Recalculate patient stats
            const stats = await db.prepare(`
                SELECT SUM(amount) as total, COUNT(*) as count
                FROM payments 
                WHERE patient_id = ? AND (status = 'completed' OR status IS NULL) AND deleted_at IS NULL
            `).bind(payment.patient_id).first() as { total: number, count: number } | null;

            const total = Number(stats?.total) || 0;
            const count = Number(stats?.count) || 0;

            await db.prepare(`
                UPDATE patients 
                SET total_payment = ?, 
                    average_transaction = ?
                WHERE id = ?
            `).bind(
                total,
                count > 0 ? Math.floor(total / count) : 0,
                payment.patient_id
            ).run();

            return new Response(JSON.stringify({ success: true }), { status: 200 });
        }

        return new Response(JSON.stringify({ error: 'No valid fields to update' }), { status: 400 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
