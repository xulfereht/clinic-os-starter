import type { APIRoute } from 'astro';

// Create a refund as a separate payment record (negative amount)
export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { originalPaymentId, amount, notes, patientId, refundQuantity, refund_date } = body;

        if (!patientId || !amount || !originalPaymentId) {
            return new Response(JSON.stringify({ error: 'Missing required fields (patientId, amount, originalPaymentId)' }), { status: 400 });
        }

        const refundAmount = Math.abs(parseInt(amount));
        const paymentId = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        // User Request: "Log should be recorded at the time of recording. Different dates should be in notes."
        // We force the timestamp (paid_at) to be NOW.
        // If a specific date was provided, we append it to the notes.
        const refundDateTs = now;

        let dateNote = '';
        if (refund_date) {
            // Check if it's not today (simple string check or date comparison)
            const todayStr = new Date(now * 1000 + 9 * 60 * 60 * 1000).toISOString().split('T')[0]; // KST Today
            if (refund_date !== todayStr) {
                dateNote = ` (실제 환불일: ${refund_date})`;
            }
        }

        const finalNotes = (notes || '') + dateNote;

        // 1. Get original payment info first to link products and validate
        const originalPayment = await db.prepare("SELECT * FROM payments WHERE id = ?").bind(originalPaymentId).first() as { id: string, product_id: string, amount: number, refund_amount: number, status: string, quantity: number } | null;
        if (!originalPayment) {
            return new Response(JSON.stringify({ error: 'Original payment not found' }), { status: 404 });
        }

        // VALIDATION: Prevent over-refund
        const currentRefunded = originalPayment.refund_amount || 0;
        if (currentRefunded + refundAmount > originalPayment.amount) {
            return new Response(JSON.stringify({
                error: `Refund exceeds original amount. Max refundable: ${originalPayment.amount - currentRefunded}`
            }), { status: 400 });
        }

        const productId = originalPayment.product_id;
        const batchStatements = [];

        // 2. Handle Shipping Order Adjustment (If refund quantity provided)
        // If refundQuantity not provided or 0, use original payment's quantity (for full refunds)
        const originalQty = originalPayment.quantity || 1;
        const refundQty = refundQuantity ? parseInt(refundQuantity) : (currentRefunded + refundAmount >= originalPayment.amount ? originalQty : 0);
        if (refundQty > 0) {
            let productName = null;
            if (productId) {
                const prod = await db.prepare("SELECT name FROM products WHERE id = ?").bind(productId).first() as { name: string } | null;
                if (prod) productName = prod.name;
            }

            if (productName) {
                const activeOrder = await db.prepare(`
                     SELECT * FROM shipping_orders 
                     WHERE patient_id = ? AND product_name = ? AND status = 'active'
                 `).bind(patientId, productName).first() as { id: string, remaining_quantity: number, total_quantity: number } | null;

                if (activeOrder) {
                    // Reduce remaining quantity
                    const newRemaining = Math.max(0, activeOrder.remaining_quantity - refundQty);
                    // Use standard SQL parameter binding for stability
                    batchStatements.push(
                        db.prepare(`
                            UPDATE shipping_orders 
                            SET remaining_quantity = ?, updated_at = ?
                            WHERE id = ?
                        `).bind(newRemaining, now, activeOrder.id)
                    );
                }
            }
        }

        // 2.5 Update Original Payment Status & Refund Amount
        const newRefundedAmount = (originalPayment.refund_amount || 0) + refundAmount;
        let newStatus = originalPayment.status || 'paid';

        if (newRefundedAmount >= originalPayment.amount) {
            newStatus = 'refunded';
        } else if (newRefundedAmount > 0) {
            newStatus = 'partially_refunded';
        }

        batchStatements.push(
            db.prepare(`
                UPDATE payments 
                SET refund_amount = ?, status = ?, updated_at = ?
                WHERE id = ?
            `).bind(newRefundedAmount, newStatus, now, originalPaymentId)
        );

        // 3. Insert Refund Record (Negative Payment)
        const createdBy = locals.user?.id || null;
        batchStatements.push(
            db.prepare(`
                INSERT INTO payments (id, patient_id, product_id, amount, notes, paid_at, status, quantity, created_by, original_payment_id, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, 'refund', ?, ?, ?, ?, ?)
            `).bind(
                paymentId,
                patientId,
                productId,
                -Math.abs(refundAmount),
                notes || '',
                refundDateTs,
                refundQty,
                createdBy,
                originalPaymentId,
                now, // created_at
                now  // updated_at
            )
        );

        // 14. Log patient event
        const refundReason = body.refund_reason || notes || '없음';
        batchStatements.push(
            db.prepare(`
                INSERT INTO patient_events (id, patient_id, type, title, content, created_at, event_date)
                VALUES (?, ?, 'refund', '환불 처리', ?, ?, ?)
            `).bind(
                crypto.randomUUID(),
                patientId,
                `금액: ₩${Math.abs(refundAmount).toLocaleString()} | 사유: ${refundReason}`,
                now,
                now
            )
        );

        // EXECUTE BATCH TRANSACTION
        await db.batch(batchStatements);

        // Clear statements for next batch
        batchStatements.length = 0;

        // 6. Recalculate patient total (Safe to run separately after transaction)
        const stats = await db.prepare(`
            SELECT SUM(amount) as total, COUNT(*) as count
            FROM payments 
            WHERE patient_id = ? AND deleted_at IS NULL
        `).bind(patientId).first() as { total: number, count: number } | null;

        const total = Number(stats?.total) || 0;
        const count = Number(stats?.count) || 0;

        batchStatements.push(
            db.prepare(`
                UPDATE patients 
                SET total_payment = ?, 
                    average_transaction = ?,
                    status = CASE WHEN ? > 0 THEN 'active' ELSE status END,
                    last_activity_at = ?,
                    updated_at = ?
                WHERE id = ?
            `).bind(
                total,
                count > 0 ? Math.floor(total / count) : 0,
                total,
                now, // last_activity_at
                now, // updated_at
                patientId
            )
        );

        // EXECUTE BATCH TRANSACTION
        await db.batch(batchStatements);

        return new Response(JSON.stringify({ success: true, paymentId }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message || 'Refund processing failed' }), { status: 500 });
    }
};
