import type { APIRoute } from 'astro';
import { getClinicSettings } from '../../../../lib/clinic';

export const GET: APIRoute = async ({ locals }) => {
    const db = locals.runtime.env.DB;
    try {
        const settings = await getClinicSettings(db);
        return new Response(JSON.stringify({
            blockedIps: settings.analyticsConfig?.blockedIps || []
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error("Failed to fetch analytics config", e);
        return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    const db = locals.runtime.env.DB;
    try {
        const data = await request.json();
        const { blockedIps } = data;

        if (!Array.isArray(blockedIps)) {
            return new Response(JSON.stringify({ error: 'Invalid data format' }), { status: 400 });
        }

        // Fetch current row to check if exists
        let result = await db.prepare("SELECT id FROM clinics WHERE id = 1").first();

        const configJson = JSON.stringify({ blockedIps });

        if (result) {
            await db.prepare("UPDATE clinics SET analytics_config = ? WHERE id = 1")
                .bind(configJson).run();
        } else {
            // Should not happen usually, but for safety
            await db.prepare("INSERT INTO clinics (id, name, analytics_config) VALUES (1, 'Clinic', ?)")
                .bind(configJson).run();
        }

        return new Response(JSON.stringify({ success: true, blockedIps }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error("Failed to save analytics config", e);
        return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
    }
};
