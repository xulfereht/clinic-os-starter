import type { APIRoute } from 'astro';
import { AnalyticsService } from '../../../../lib/analytics';

export const GET: APIRoute = async ({ locals }) => {
    const db = locals.runtime.env.DB;
    try {
        const stats = await AnalyticsService.getRealtimeStats(db);
        return new Response(JSON.stringify(stats), {
            status: 200,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    } catch (e) {
        console.error("Realtime analytics error", e);
        return new Response(JSON.stringify({ error: 'Failed to fetch realtime stats' }), { status: 500 });
    }
};
