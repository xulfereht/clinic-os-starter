export const prerender = false;

export async function GET({ request, locals }: { request: Request; locals: any }) {
    const url = new URL(request.url);
    const query = url.searchParams.get('q') || '';

    if (!query) {
        return new Response(JSON.stringify({ results: [] }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    try {
        const db = locals.runtime.env.DB;

        // Normalize phone: remove hyphens for comparison
        const normalizedQuery = query.replace(/-/g, '');

        // Search by name or contact (normalize phone numbers for matching)
        const { results } = await db.prepare(`
            SELECT id, name, current_phone as contact, birth_date, gender 
            FROM patients 
            WHERE (
                name LIKE ? 
                OR current_phone LIKE ? 
                OR REPLACE(current_phone, '-', '') LIKE ?
            ) AND deleted_at IS NULL
            LIMIT 10
        `).bind(`%${query}%`, `%${query}%`, `%${normalizedQuery}%`).run();

        return new Response(JSON.stringify({ results }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
