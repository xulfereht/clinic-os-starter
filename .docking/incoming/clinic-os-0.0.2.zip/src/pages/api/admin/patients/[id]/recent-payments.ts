export const prerender = false;

// @ts-ignore
const db = import.meta.env.DB;

export async function GET({ params, locals }) {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!id || !db) {
        return new Response(JSON.stringify({ error: 'Invalid request' }), { status: 400 });
    }

    try {
        const { results } = await db.prepare(`
            SELECT 
                p.id,
                p.amount,
                p.paid_at,
                prod.name as product_name,
                p.notes
            FROM payments p
            LEFT JOIN products prod ON p.product_id = prod.id
            WHERE p.patient_id = ? 
            AND (p.status = 'completed' OR p.status IS NULL)
            AND p.amount > 0
            ORDER BY p.paid_at DESC
            LIMIT 10
        `).bind(id).run();

        return new Response(JSON.stringify({ results }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
