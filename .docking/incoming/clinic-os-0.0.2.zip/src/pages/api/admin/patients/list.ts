import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    const url = new URL(request.url);
    const search = url.searchParams.get('q') || '';
    const status = url.searchParams.get('status') || '';
    const sort = url.searchParams.get('sort') || 'latest'; // latest, spend, chart, name
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '30'), 100);
    const offset = parseInt(url.searchParams.get('offset') || '0');

    try {
        // Build WHERE clause
        let whereClause = "WHERE deleted_at IS NULL";
        const params: any[] = [];

        // Search filter (optimized - only indexed columns)
        if (search && search.length >= 1) {
            const searchPattern = `%${search}%`;

            // Check if input is likely a phone number (digits and hyphens only)
            const isPhoneLike = /^[0-9-]+$/.test(search);
            const normalizedPhone = search.replace(/-/g, '');

            if (isPhoneLike && normalizedPhone.length > 3) {
                // If it looks like a phone number, search specialized fields
                // We use OR logic carefully. 'current_phone' is indexed. 
                // searching "0101234" against "010-1234-5678" works if we wildcard correctly?
                // Actually 'LIKE %0101234%' on '010-1234-5678' fails without REPLACE.
                // BUT REPLACE kills the index.
                // Better approach: If user types "0101234", we can try to format it or search "010-1234%".
                // For now, let's keep it simple but index-friendly:
                // 1. Search name (always)
                // 2. Search chart_number (exact or like)
                // 3. Search phone (LIKE query) - users usually type "010-..." or "1234" (last 4 digits)

                // If user typed 4+ digits (e.g. 1234), it might be end of phone.
                whereClause += ` AND (
                    name LIKE ? 
                    OR current_phone LIKE ? 
                    OR chart_number LIKE ?
                )`;
                // Try to catch both raw input and formatted input if simple
                params.push(searchPattern, searchPattern, searchPattern);
            } else {
                // Standard Text Search
                whereClause += ` AND (
                    name LIKE ? 
                    OR chart_number LIKE ?
                    OR current_phone LIKE ?
                )`;
                params.push(searchPattern, searchPattern, searchPattern);
            }
        }

        // Status filter
        if (status && status !== 'all') {
            if (status === 'inactive') {
                whereClause += " AND status IN ('inactive', 'churned')";
            } else {
                whereClause += " AND status = ?";
                params.push(status);
            }
        }

        // Sort order (using existing columns - no subqueries!)
        let orderBy = "last_activity_at DESC NULLS LAST, updated_at DESC";
        if (sort === 'spend') {
            orderBy = "total_payment DESC NULLS LAST";
        } else if (sort === 'spend_asc') {
            orderBy = "total_payment ASC NULLS LAST";
        } else if (sort === 'chart') {
            orderBy = "CAST(chart_number AS INTEGER) ASC NULLS LAST";
        } else if (sort === 'chart_desc') {
            orderBy = "CAST(chart_number AS INTEGER) DESC NULLS LAST";
        } else if (sort === 'name') {
            orderBy = "name ASC";
        } else if (sort === 'name_desc') {
            orderBy = "name DESC";
        } else if (sort === 'latest_asc') {
            orderBy = "last_activity_at ASC NULLS LAST";
        }

        // Fast SELECT - no subqueries!
        const selectFields = `
            id, name, current_phone, chart_number, status, gender,
            birth_date, total_payment, visit_count, has_account,
            last_activity_at, last_visit_date, created_at, updated_at
        `;

        // Get total count first (for pagination)
        const countQuery = `SELECT COUNT(*) as count FROM patients ${whereClause}`;
        const countResult = await db.prepare(countQuery).bind(...params).first();
        const total = (countResult?.count as number) || 0;

        // Get paginated results
        const query = `SELECT ${selectFields} FROM patients ${whereClause} ORDER BY ${orderBy} LIMIT ? OFFSET ?`;
        const { results } = await db.prepare(query).bind(...params, limit, offset).all();

        return new Response(JSON.stringify({
            patients: results,
            total,
            hasMore: offset + results.length < total,
            offset: offset + results.length
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error: any) {
        console.error('Patients list error:', error);
        return new Response(JSON.stringify({ error: error.message }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};
