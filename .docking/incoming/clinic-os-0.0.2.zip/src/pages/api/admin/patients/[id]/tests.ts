import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const { results } = await db.prepare(`
            SELECT * FROM clinical_tests 
            WHERE patient_id = ? 
            ORDER BY test_date DESC, created_at DESC
        `).bind(id).run();

        return new Response(JSON.stringify(results), { status: 200 });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: 'Failed to fetch tests' }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { testType, testDate, images, data, note } = body;

        const testId = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        // Convert date string to timestamp if needed, or assume YYYY-MM-DD input
        // Store test_date as integer timestamp (start of day)
        const dateObj = new Date(testDate);
        const dateTs = Math.floor(dateObj.getTime() / 1000);

        await db.prepare(`
            INSERT INTO clinical_tests (id, patient_id, test_type, test_date, images, data, note, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            testId,
            id,
            testType,
            dateTs,
            JSON.stringify(images || []),
            JSON.stringify(data || {}),
            note || '',
            now
        ).run();

        return new Response(JSON.stringify({ success: true, id: testId }), { status: 201 });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: 'Failed to create test' }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const url = new URL(request.url);
    const testId = url.searchParams.get('testId');

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    if (!testId) {
        return new Response(JSON.stringify({ error: 'Test ID required' }), { status: 400 });
    }

    try {
        await db.prepare("UPDATE clinical_tests SET deleted_at = unixepoch() WHERE id = ?").bind(testId).run();
        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: 'Failed to delete test' }), { status: 500 });
    }
};
