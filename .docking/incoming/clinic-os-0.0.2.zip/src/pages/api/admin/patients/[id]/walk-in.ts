import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    const db = locals.runtime.env.DB;

    try {
        const body = await request.json();
        const { patient_id, doctor_id, notes } = body;

        if (!patient_id) {
            return new Response(JSON.stringify({ error: 'Patient ID required' }), { status: 400 });
        }

        // Require doctor_id for proper analytics tracking
        if (!doctor_id) {
            return new Response(JSON.stringify({ error: '담당의를 선택해주세요.' }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);

        // Check if this is first visit (초진) or return visit (재진)
        // Count previous visits for this patient from patient_events
        const prevVisits = await db.prepare(`
            SELECT COUNT(*) as count FROM patient_events 
            WHERE patient_id = ? AND type = 'visit'
        `).bind(patient_id).first<{ count: number }>();

        const isFirstVisit = !prevVisits || prevVisits.count === 0;
        const visitTitle = isFirstVisit ? '초진 내원' : '재진 내원';
        const visitContent = notes || (isFirstVisit ? '비예약 첫 내원' : '비예약 재진');

        // Create patient_events record directly (NOT a reservation)
        const eventId = crypto.randomUUID();
        await db.prepare(`
            INSERT INTO patient_events (id, patient_id, type, title, content, event_date, created_at, staff_id)
            VALUES (?, ?, 'visit', ?, ?, ?, ?, ?)
        `).bind(eventId, patient_id, visitTitle, visitContent, now, now, doctor_id || null).run();

        // Update patient's last_visit_date and last_activity_at
        const visitTime = new Date(now * 1000);
        const kstOffset = 9 * 60 * 60 * 1000;
        const localVisitTime = new Date(visitTime.getTime() + kstOffset);
        const visitDateStr = localVisitTime.toISOString().split('T')[0];

        await db.prepare(`
            UPDATE patients 
            SET last_visit_date = ?, 
                last_activity_at = unixepoch(),
                updated_at = unixepoch(),
                visit_count = COALESCE(visit_count, 0) + 1
            WHERE id = ?
        `).bind(visitDateStr, patient_id).run();

        // If doctor is specified, add to the content
        if (doctor_id) {
            const doctor = await db.prepare('SELECT name FROM staff WHERE id = ?').bind(doctor_id).first();
            if (doctor) {
                await db.prepare(`
                    UPDATE patient_events 
                    SET content = content || ' (담당: ' || ? || ')'
                    WHERE id = ?
                `).bind(doctor.name, eventId).run();
            }
        }

        return new Response(JSON.stringify({
            success: true,
            eventId,
            visitType: isFirstVisit ? 'first' : 'return'
        }), { status: 201 });

    } catch (e: any) {
        console.error('Walk-in creation error:', e);
        return new Response(JSON.stringify({ error: e.message || 'Unknown error' }), { status: 500 });
    }
};
