import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const result = await db.prepare(
            "SELECT MAX(CAST(chart_number AS INTEGER)) as max_num FROM patients WHERE chart_number IS NOT NULL"
        ).first() as { max_num: number | null } | null;

        const nextChartNumber = result?.max_num ? String(Number(result.max_num) + 1) : '1';

        return new Response(JSON.stringify({ nextChartNumber }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        console.error('Failed to get next chart number:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
