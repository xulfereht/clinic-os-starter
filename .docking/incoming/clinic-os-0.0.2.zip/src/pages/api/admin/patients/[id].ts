import type { APIRoute } from 'astro';

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const {
            name, phone, birthDate, gender, notes,
            occupation, region, zipcode, addressRoad, addressDetail, consultantId,
            referrerId, segments, status, tags, chartNumber
        } = body;

        const now = Math.floor(Date.now() / 1000);

        // 1. Fetch current patient data for comparison
        const currentPatient = await db.prepare("SELECT * FROM patients WHERE id = ?").bind(id).first();

        if (!currentPatient) {
            return new Response(JSON.stringify({ error: 'Patient not found' }), { status: 404 });
        }

        // 2. Build dynamic update query & Track changes
        let updateFields = [];
        let updateParams = [];
        let changes = [];

        if (name !== undefined) {
            updateFields.push("name = ?");
            updateParams.push(name);
            if (currentPatient.name !== name) changes.push(`이름 변경: ${currentPatient.name} -> ${name}`);
        }
        if (phone !== undefined) {
            updateFields.push("current_phone = ?");
            updateParams.push(phone);
            if (currentPatient.current_phone !== phone) changes.push(`연락처 변경: ${currentPatient.current_phone} -> ${phone}`);
        }
        if (birthDate !== undefined) {
            updateFields.push("birth_date = ?");
            updateParams.push(birthDate);
            if (currentPatient.birth_date !== birthDate) changes.push(`생년월일 변경: ${currentPatient.birth_date || '(없음)'} -> ${birthDate}`);
        }
        if (gender !== undefined) {
            updateFields.push("gender = ?");
            updateParams.push(gender);
            if (currentPatient.gender !== gender) changes.push(`성별 변경: ${currentPatient.gender === 'M' ? '남' : '여'} -> ${gender === 'M' ? '남' : '여'}`);
        }
        if (notes !== undefined) {
            updateFields.push("notes = ?");
            updateParams.push(notes);
            // Notes are usually just updated, maybe don't log every character change unless significant? 
            // User asked for "Special Instructions" to be a separate log, but this 'notes' field might still be used for something else or legacy.
            // Given the previous task refactored 'notes' to be logs, this field might be less used, but let's track it if it changes.
            if (currentPatient.notes !== notes) changes.push(`특이사항(구) 변경`);
        }
        if (occupation !== undefined) { updateFields.push("occupation = ?"); updateParams.push(occupation); }
        if (region !== undefined) { updateFields.push("region = ?"); updateParams.push(region); }

        // Address Logic
        let addressChanged = false;
        let oldAddress = `${currentPatient.address_road || ''} ${currentPatient.address_detail || ''}`.trim();
        let newAddressRoad = currentPatient.address_road;
        let newAddressDetail = currentPatient.address_detail;

        if (zipcode !== undefined) {
            updateFields.push("address_zip = ?");
            updateParams.push(zipcode);
            if (currentPatient.address_zip !== zipcode) addressChanged = true;
        }
        if (addressRoad !== undefined) {
            updateFields.push("address_road = ?");
            updateParams.push(addressRoad);
            if (currentPatient.address_road !== addressRoad) {
                addressChanged = true;
                newAddressRoad = addressRoad;
            }
        }
        if (addressDetail !== undefined) {
            updateFields.push("address_detail = ?");
            updateParams.push(addressDetail);
            if (currentPatient.address_detail !== addressDetail) {
                addressChanged = true;
                newAddressDetail = addressDetail;
            }
        }

        if (addressChanged) {
            const newAddressFull = `${newAddressRoad || ''} ${newAddressDetail || ''}`.trim();
            if (oldAddress !== newAddressFull) {
                changes.push(`주소 변경: ${oldAddress || '(없음)'} -> ${newAddressFull}`);
            }
        }

        if (consultantId !== undefined) { updateFields.push("consultant_id = ?"); updateParams.push(consultantId); }
        if (referrerId !== undefined) {
            updateFields.push("referrer_id = ?");
            updateParams.push(referrerId);
            if (currentPatient.referrer_id !== referrerId) changes.push(`추천인 변경`);
        }
        if (segments !== undefined) { updateFields.push("segments = ?"); updateParams.push(JSON.stringify(segments)); }
        if (status !== undefined) { updateFields.push("status = ?"); updateParams.push(status); }
        if (tags !== undefined) {
            updateFields.push("tags = ?");
            updateParams.push(tags);
            if (currentPatient.tags !== tags) changes.push(`태그 변경: ${currentPatient.tags || '(없음)'} -> ${tags}`);
        }
        if (chartNumber !== undefined) {
            // Check for duplicates if changing to a new chart number
            if (chartNumber && chartNumber !== currentPatient.chart_number) {
                const existingChart = await db.prepare("SELECT id FROM patients WHERE chart_number = ? AND id != ?").bind(chartNumber, id).first();
                if (existingChart) {
                    return new Response(JSON.stringify({ error: '이미 존재하는 차트 번호입니다.' }), { status: 409 });
                }
            }
            updateFields.push("chart_number = ?");
            updateParams.push(chartNumber || null);
            if (currentPatient.chart_number !== chartNumber) changes.push(`차트번호 변경: ${currentPatient.chart_number || '(없음)'} -> ${chartNumber || '(없음)'}`);
        }

        updateFields.push("updated_at = ?");
        updateParams.push(now);

        updateParams.push(id);

        if (updateFields.length > 1) { // At least updated_at
            // Execute Update
            await db.prepare(`
                UPDATE patients 
                SET ${updateFields.join(", ")}
                WHERE id = ?
            `).bind(...updateParams).run();

            // Log Changes if any
            if (changes.length > 0) {
                const logContent = changes.join('\n');
                await db.prepare(`
                    INSERT INTO patient_events (id, patient_id, type, title, content, event_date, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                `).bind(
                    crypto.randomUUID(),
                    id,
                    'info_update',
                    '정보 수정',
                    logContent,
                    now,
                    now
                ).run();
            }
        }

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
