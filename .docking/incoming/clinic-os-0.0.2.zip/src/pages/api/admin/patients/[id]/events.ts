import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { type, title, content, eventDate } = body;

        if (!type || !title) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
        }

        const eventId = crypto.randomUUID();
        const timestamp = eventDate ? Math.floor(new Date(eventDate).getTime() / 1000) : Math.floor(Date.now() / 1000);

        // Get Current Admin
        const adminSessionId = request.headers.get('Cookie')?.match(/admin_session=([^;]+)/)?.[1];
        let staffId = null;

        // Handle legacy super admin session
        if (adminSessionId === 'legacy_super_admin') {
            staffId = 'super_admin'; // Use a special ID for legacy admin
        } else if (adminSessionId) {
            const session = await db.prepare("SELECT staff_id FROM sessions WHERE id = ? AND expires_at > strftime('%s', 'now')").bind(adminSessionId).first();
            if (session) staffId = session.staff_id;
        }

        // For visit events, staff_id is required for analytics tracking
        if (type === 'visit' && !staffId) {
            return new Response(JSON.stringify({ error: '담당의 정보가 필요합니다. 다시 로그인해주세요.' }), { status: 400 });
        }

        await db.prepare(`
            INSERT INTO patient_events (id, patient_id, type, title, content, event_date, staff_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `).bind(eventId, id, type, title, content, timestamp, staffId).run();

        // Update patient's last activity time and increment visit count if type is visit
        if (type === 'visit') {
            await db.prepare(`
                UPDATE patients 
                SET last_activity_at = unixepoch(), 
                    updated_at = unixepoch(),
                    visit_count = COALESCE(visit_count, 0) + 1
                WHERE id = ?
            `).bind(id).run();
        } else {
            await db.prepare(`
                UPDATE patients SET last_activity_at = unixepoch(), updated_at = unixepoch() WHERE id = ?
            `).bind(id).run();
        }

        return new Response(JSON.stringify({ success: true, id: eventId }), { status: 200 });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: 'Failed to create event' }), { status: 500 });
    }
};
