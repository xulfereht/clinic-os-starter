import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { productId, amount, notes, originalAmount, discountAmount, promotionId, quantity, paidAt, isShipped } = body;

        if (!amount) {
            return new Response(JSON.stringify({ error: 'Amount is required' }), { status: 400 });
        }

        const paymentId = crypto.randomUUID();


        // Timestamp Logic Fix
        let paymentDate: number;
        const nowMs = Date.now();
        const kstOffset = 9 * 60 * 60 * 1000;

        // User consistency request: All records logged at creation time (Now)
        // If a different date is provided, note it in the notes.
        let finalNotes = notes || '';
        const kstToday = new Date(nowMs + kstOffset).toISOString().split('T')[0];

        if (paidAt && paidAt !== kstToday) {
            finalNotes += ` (실재 결제일: ${paidAt})`;
        }

        // Always set paymentDate (timestamp) to NOW
        paymentDate = Math.floor(nowMs / 1000);
        const now = Math.floor(Date.now() / 1000);

        // 1. Insert Payment
        const createdBy = locals.user?.id || null;
        await db.prepare(`
            INSERT INTO payments (
                id, patient_id, product_id, amount, notes, paid_at,
                original_amount, discount_amount, promotion_id, quantity, created_by,
                created_at, updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            paymentId,
            id,
            productId || null,
            parseInt(amount),
            finalNotes || '',
            paymentDate,
            originalAmount ? parseInt(originalAmount) : null,
            discountAmount ? parseInt(discountAmount) : 0,
            promotionId || null,
            quantity ? parseInt(quantity) : 1,
            createdBy,
            now, // created_at
            now  // updated_at
        ).run();

        // 2. Update Shipping Orders (Bucket Model)
        // Only if quantity > 0
        const qty = quantity ? parseInt(quantity) : 1;
        if (qty > 0) {
            let productName = '일반 결제'; // Default name
            if (productId) {
                const product = await db.prepare("SELECT name FROM products WHERE id = ?").bind(productId).first() as { name: string } | null;
                if (product) productName = product.name;
            } else if (notes) {
                // Try to use notes as product name if no product ID
                productName = String(notes || '').split('\n')[0].substring(0, 50);
            }

            // Determine status and remaining quantity based on isShipped
            const isAlreadyShipped = isShipped === true || isShipped === 'true';
            const status = isAlreadyShipped ? 'completed' : 'active';
            const remainingQty = isAlreadyShipped ? 0 : qty;

            // For historical/shipped items, next_shipping_date is null (completed)
            // For active items, calculate initial due date (3 business days)
            let initialDueDate: number | null = null;

            if (!isAlreadyShipped) {
                const today = new Date();
                let addedDays = 0;
                const targetDays = 3;
                while (addedDays < targetDays) {
                    today.setDate(today.getDate() + 1);
                    if (today.getDay() !== 0 && today.getDay() !== 6) {
                        addedDays++;
                    }
                }
                initialDueDate = Math.floor(today.getTime() / 1000);
            }

            // Try to find existing active order for this product
            const existingOrder = await db.prepare("SELECT * FROM shipping_orders WHERE patient_id = ? AND product_name = ? AND status = 'active'").bind(id, productName).first();

            if (existingOrder && !isAlreadyShipped) {
                // Update existing active order (only if adding new active items)
                let updateQuery = "UPDATE shipping_orders SET total_quantity = total_quantity + ?, remaining_quantity = remaining_quantity + ?, updated_at = ?";
                const updateParams: any[] = [qty, qty, now];

                // If next_shipping_date is null, set it to initialDueDate
                if (!existingOrder.next_shipping_date) {
                    updateQuery += ", next_shipping_date = ?";
                    updateParams.push(initialDueDate);
                }

                updateQuery += " WHERE id = ?";
                updateParams.push(existingOrder.id);

                await db.prepare(updateQuery).bind(...updateParams).run();
            } else {
                // Create new order (for new active items OR for already shipped items)
                // If already shipped, we create a completed order record for history
                await db.prepare(`
                    INSERT INTO shipping_orders (id, patient_id, product_name, total_quantity, remaining_quantity, next_shipping_date, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                `).bind(
                    crypto.randomUUID(),
                    id,
                    productName,
                    qty,
                    remainingQty,
                    initialDueDate,
                    status,
                    paymentDate, // Use payment date as creation date for historical accuracy
                    now
                ).run();
            }
        }

        // 3. Update Patient Stats (Total Payment, Visit Count if needed)
        // We recalculate total payment from scratch to be safe
        const stats = await db.prepare(`
            SELECT sum(amount) as total, count(*) as count
            FROM payments 
            WHERE patient_id = ? AND status = 'completed'
        `).bind(id).first();

        const total = Number(stats?.total) || 0;
        const count = Number(stats?.count) || 0;

        await db.prepare(`
            UPDATE patients 
            SET total_payment = ?, 
                average_transaction = ?,
                payment_count = ?,
                status = CASE WHEN ? > 0 THEN 'active' ELSE status END,
                last_activity_at = ?,
                updated_at = ?
            WHERE id = ?
        `).bind(
            total,
            count > 0 ? Math.floor(total / count) : 0,
            count,
            total, // Check if total > 0
            now, // last_activity_at
            now, // updated_at
            id
        ).run();

        return new Response(JSON.stringify({ success: true, paymentId }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
