import type { APIRoute } from 'astro';
import { sendAligoMessage, sendAlimTalk, getAligoConfig } from '../../../../../lib/aligo';

export const POST: APIRoute = async ({ params, request, locals }) => {
    const user = locals.user;
    if (!user) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    const { id: patientId } = params;
    if (!patientId) {
        return new Response(JSON.stringify({ error: 'Patient ID is required' }), { status: 400 });
    }

    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const env = locals.runtime?.env;

    try {
        const body = await request.json();
        const { message, channel = 'SMS', alimtalk_code, template_id } = body;
        const title = body.title;

        if (!message) {
            return new Response(JSON.stringify({ error: 'Message content is required' }), { status: 400 });
        }

        // 1. Fetch Patient Info
        const patient = await db.prepare('SELECT name, current_phone FROM patients WHERE id = ?').bind(patientId).first();
        if (!patient || !patient.current_phone) {
            return new Response(JSON.stringify({ error: 'Patient not found or no phone number' }), { status: 404 });
        }

        // 2. Configure Aligo
        const config = await getAligoConfig(env, db);
        if (!config) {
            return new Response(JSON.stringify({ error: 'SMS Configuration Missing' }), { status: 500 });
        }

        let sendResult;
        let msgType = '';
        let finalStatus = 'failed';
        let errorMessage = null;

        // 3. Send Message based on Channel
        if (channel === 'ALIMTALK') {
            if (!alimtalk_code) {
                return new Response(JSON.stringify({ error: 'AlimTalk Template Code is required' }), { status: 400 });
            }

            // For AlimTalk, we send the message using sendAlimTalk
            // We use the message content as the fallback SMS message as well (handled in lib)
            sendResult = await sendAlimTalk(config, {
                receiver: patient.current_phone,
                tpl_code: alimtalk_code,
                senderkey: config.senderKey,
                message_1: message, // Content is fallback message
                subject_1: title || '알림톡 발송 실패 안내', // Fallback subject
                emtitle_1: title, // Emphasized title (if template supports it)
                // Important: Aligo AlimTalk expects variables to be replaced in the content itself?
                // Actually, standard Aligo API requires content to match template EXACTLY (with variables filled).
                // So we pass the already substituted message.
                message: message,
                failover: "Y"
            });

            msgType = 'ALIMTALK';
        } else {
            // SMS / LMS
            sendResult = await sendAligoMessage(config, {
                receiver: patient.current_phone,
                msg: message,
                title: title,
                destination: `${patient.current_phone}|${patient.name}`
            });
            msgType = (message.length > 90) ? 'LMS' : 'SMS';
        }

        // 4. Handle Result & Logging
        finalStatus = (sendResult.result_code === '1' || sendResult.result_code === 1) ? 'sent' : 'failed';
        errorMessage = finalStatus === 'failed' ? sendResult.message : null;

        // If AlimTalk fallback occurred, Aligo returns success but type might change?
        // Actually Aligo API response for AlimTalk doesn't explicitly say "fell back" immediately usually.
        // It says success if the request was accepted.

        await db.prepare(`
            INSERT INTO message_logs (
                campaign_id, patient_id, patient_name, phone, 
                message_type, content, status, error_message, result_code, sent_at, type
            ) VALUES (
                NULL, ?, ?, ?, 
                ?, ?, ?, ?, ?, strftime('%s', 'now'), 'individual'
            )
        `).bind(
            patientId,
            patient.name,
            patient.current_phone,
            msgType,
            message,
            finalStatus,
            errorMessage,
            String(sendResult.result_code)
        ).run();

        if (finalStatus === 'sent') {
            return new Response(JSON.stringify({ success: true, result: sendResult }), { status: 200 });
        } else {
            return new Response(JSON.stringify({ success: false, error: errorMessage }), { status: 500 });
        }

    } catch (error) {
        console.error('Message Send Error:', error);
        return new Response(JSON.stringify({
            error: 'Internal Server Error',
            details: error instanceof Error ? error.message : String(error)
        }), { status: 500 });
    }
};
