import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // 1. Try to add the column if it doesn't exist
        try {
            await db.prepare("ALTER TABLE patients ADD COLUMN payment_count INTEGER DEFAULT 0").run();
        } catch (e) {
            // Ignore error if column already exists
            console.log("Column payment_count might already exist or error adding it:", e);
        }

        // 2. Batch update logic (Optimized)
        // Count all non-deleted, non-refund ONLY (amount > 0) payments? 
        // No, based on previous discussion, we use COUNT(*) of valid payments (status='completed' or null) 
        // regardless of amount sign (refunds counts as a transaction history).
        // payments.ts uses: SELECT count(*) FROM payments WHERE patient_id = ? AND status = 'completed'

        const result = await db.prepare(`
            UPDATE patients
            SET payment_count = (
                SELECT COUNT(*) 
                FROM payments 
                WHERE payments.patient_id = patients.id 
                AND (payments.status = 'completed' OR payments.status IS NULL)
                AND payments.deleted_at IS NULL
            )
            WHERE deleted_at IS NULL
        `).run();

        return new Response(JSON.stringify({
            success: true,
            message: `Schema updated & Payment counts backfilled successfully`,
            result
        }), { status: 200 });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
