export const prerender = false;

import { formatDuration, formatHerbalConsent } from "../../../lib/intake-formatter";

export async function GET({ locals }) {
    const db = locals.runtime.env.DB;
    const results = {
        totalFound: 0,
        updated: 0,
        errors: [],
        details: []
    };

    try {
        // Find all intake events
        const { results: events } = await db.prepare(`
            SELECT * FROM patient_events 
            WHERE type = 'intake'
            ORDER BY created_at DESC
        `).run();

        results.totalFound = events.length;

        for (const ev of events) {
            try {
                // Find source data (Lead or Submission)
                // 1. Check Submission
                const submission = await db.prepare("SELECT intake_data FROM intake_submissions WHERE patient_id = ?").bind(ev.patient_id).first();

                // 2. Check Lead (if no submission or matching logic preference)
                const lead = await db.prepare("SELECT intake_data FROM leads WHERE patient_id = ?").bind(ev.patient_id).first();

                let rawData = null;
                if (submission && submission.intake_data) {
                    rawData = JSON.parse(submission.intake_data);
                } else if (lead && lead.intake_data) {
                    rawData = JSON.parse(lead.intake_data);
                }

                if (!rawData) {
                    results.errors.push(`No raw data found for event ${ev.id} (Patient ${ev.patient_id})`);
                    continue;
                }

                // Re-generate Content
                let eventContent = '';
                const data = rawData;

                if (data.type === 'remote' || data.type === 'remote_integrated') {
                    eventContent += `[비대면 진료 접수${data.type === 'remote_integrated' ? ' (통합)' : ''}]\n`;
                    if (data.type === 'remote_integrated') {
                        eventContent += `신체정보: ${data.height || '?'}cm / ${data.current_weight || '?'}kg (목표: ${data.target_weight || '?'}kg)\n`;

                        const dietLabels = {
                            'diet_history': '다이어트 경험',
                            'meal_regularity': '식사 규칙성',
                            'snack_habit': '간식 습관',
                            'alcohol_habit': '음주 습관',
                            'activity_vigorous': '고강도 운동',
                            'activity_moderate': '중강도 운동',
                            'activity_walking': '걷기 시간',
                            'nrs_stress': '스트레스 (NRS)',
                            'nrs_body_image': '체형 스트레스 (NRS)'
                        };

                        const surveyResponses = [];
                        for (const [key, label] of Object.entries(dietLabels)) {
                            if (data[key] !== undefined && data[key] !== '') {
                                surveyResponses.push(`${label}: ${data[key]}`);
                            }
                        }
                        if (surveyResponses.length > 0) {
                            eventContent += `\n[설문 응답]\n${surveyResponses.join('\n')}\n`;
                        }
                    }
                    eventContent += `\n배송지: ${data.shipping_address || '-'}\n`;
                    if (data.shipping_request) eventContent += `배송요청: ${data.shipping_request}\n`;
                    eventContent += `현금영수증: ${data.cash_receipt_number || '-'}\n`;
                } else {
                    eventContent += `[문진표 접수 항목]\n`;
                    eventContent += `방문 목적: ${data.visit_category || '-'}\n`;
                    eventContent += `주요 증상: ${data.main_symptom || '-'}\n`;
                    eventContent += `증상 기간: ${formatDuration(data.duration)}\n`;

                    if (data.herbal_consent) {
                        eventContent += `\n[한약 치료 의사]\n`;
                        eventContent += `✓ ${formatHerbalConsent(data.herbal_consent)}\n`;
                    }

                    if (data.referral && data.referral.length > 0) {
                        eventContent += `\n[내원 경로]\n${Array.isArray(data.referral) ? data.referral.join(', ') : data.referral}\n`;
                    }
                }

                if (data.consentMetadata) {
                    eventContent += `\n[동의 내역]\n`;
                    eventContent += `개인정보: ${data.consentMetadata.privacy_consent ? '✓ 동의' : '✗ 미동의'}\n`;
                    if (data.type === 'remote') {
                        eventContent += `비대면 진료 동의: ${data.consentMetadata.remote_consent ? '✓ 동의' : '✗ 미동의'}\n`;
                    } else {
                        eventContent += `마케팅: ${data.consentMetadata.marketing_consent ? '✓ 동의' : '✗ 미동의'}\n`;
                    }
                    eventContent += `IP: ${data.consentMetadata.ip}\n`;
                    eventContent += `시각: ${data.consentMetadata.timestamp}`;
                }

                // Update DB
                await db.prepare("UPDATE patient_events SET content = ? WHERE id = ?").bind(eventContent, ev.id).run();
                results.updated++;
                results.details.push(`Updated Event ${ev.id}`);

            } catch (innerErr) {
                console.error(innerErr);
                results.errors.push(`Error processing event ${ev.id}: ${innerErr.message}`);
            }
        }

        return new Response(JSON.stringify(results, null, 2));
    } catch (e) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
