import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ request, locals }) => {
    try {
        const url = new URL(request.url);
        const staffId = url.searchParams.get('staff_id');
        const status = url.searchParams.get('status');

        let query = `
            SELECT l.*, s.name as staff_name 
            FROM staff_leaves l
            JOIN staff s ON l.staff_id = s.id
            WHERE 1=1
        `;
        const params = [];

        if (staffId) {
            query += ` AND l.staff_id = ?`;
            params.push(staffId);
        }
        if (status) {
            query += ` AND l.status = ?`;
            params.push(status);
        }

        query += ` ORDER BY l.start_date DESC`;

        const { results } = await locals.runtime.env.DB.prepare(query).bind(...params).run();

        return new Response(JSON.stringify(results), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const { staff_id, start_date, end_date, type, reason } = await request.json();

        await locals.runtime.env.DB.prepare(
            `INSERT INTO staff_leaves (staff_id, start_date, end_date, type, reason, status)
             VALUES (?, ?, ?, ?, ?, 'approved')` // Auto-approve for now as admin tool
        ).bind(staff_id, start_date, end_date, type, reason).run();

        return new Response(JSON.stringify({ message: 'Leave added' }), { status: 201 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ request, locals }) => {
    try {
        const url = new URL(request.url);
        const id = url.searchParams.get('id');

        if (!id) {
            return new Response(JSON.stringify({ error: 'ID is required' }), { status: 400 });
        }

        await locals.runtime.env.DB.prepare(
            `DELETE FROM staff_leaves WHERE id = ?`
        ).bind(id).run();

        return new Response(JSON.stringify({ message: 'Leave deleted' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
