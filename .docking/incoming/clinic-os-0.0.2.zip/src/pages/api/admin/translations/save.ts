import type { APIRoute } from 'astro';
import { isValidLocale, DEFAULT_LOCALE } from '../../../../lib/i18n';

// Helper to record translation history
async function recordHistory(
    db: any,
    contentType: string,
    contentId: string,
    locale: string,
    changes: { field: string; oldValue: string | null; newValue: string | null }[]
) {
    for (const change of changes) {
        if (change.oldValue !== change.newValue) {
            await db.prepare(`
                INSERT INTO translation_history (content_type, content_id, locale, field_name, old_value, new_value, changed_at)
                VALUES (?, ?, ?, ?, ?, ?, unixepoch())
            `).bind(contentType, contentId, locale, change.field, change.oldValue, change.newValue).run();
        }
    }
}

// Helper to get existing translation
async function getExistingTranslation(db: any, type: string, id: string, locale: string): Promise<any> {
    let table = '';
    let idCol = '';
    switch (type) {
        case 'faq': table = 'faq_translations'; idCol = 'faq_id'; break;
        case 'program': table = 'program_translations'; idCol = 'program_id'; break;
        case 'page': table = 'page_translations'; idCol = 'page_id'; break;
        case 'post': table = 'post_translations'; idCol = 'post_id'; break;
        case 'topic': table = 'topic_translations'; idCol = 'topic_id'; break;
        default: return null;
    }
    return await db.prepare(`SELECT * FROM ${table} WHERE ${idCol} = ? AND locale = ?`).bind(id, locale).first();
}

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ success: false, error: 'Database not available' }), {
                status: 500,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        const data = await request.json();
        const { type, id, locale, status, ...fields } = data;

        // Validate
        if (!type || !id || !locale) {
            return new Response(JSON.stringify({ success: false, error: 'Missing required fields' }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        if (!isValidLocale(locale) || locale === DEFAULT_LOCALE) {
            return new Response(JSON.stringify({ success: false, error: 'Invalid locale' }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        const now = Math.floor(Date.now() / 1000);
        const publishedAt = status === 'published' ? now : null;

        switch (type) {
            case 'faq': {
                const { question, answer_short, answer_detail } = fields;
                if (!question) {
                    return new Response(JSON.stringify({ success: false, error: 'Question is required' }), {
                        status: 400,
                        headers: { 'Content-Type': 'application/json' }
                    });
                }

                // Record history
                const existing = await getExistingTranslation(db, type, id, locale);
                await recordHistory(db, type, id, locale, [
                    { field: 'question', oldValue: existing?.question || null, newValue: question },
                    { field: 'answer_short', oldValue: existing?.answer_short || null, newValue: answer_short || null },
                    { field: 'answer_detail', oldValue: existing?.answer_detail || null, newValue: answer_detail || null }
                ]);

                await db.prepare(`
                    INSERT INTO faq_translations (faq_id, locale, question, answer_short, answer_detail, status, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(faq_id, locale) DO UPDATE SET
                        question = excluded.question,
                        answer_short = excluded.answer_short,
                        answer_detail = excluded.answer_detail,
                        status = excluded.status,
                        updated_at = excluded.updated_at
                `).bind(id, locale, question, answer_short || null, answer_detail || null, status, now).run();
                break;
            }

            case 'program': {
                const { title, description, pricing, features, sections } = fields;
                if (!title) {
                    return new Response(JSON.stringify({ success: false, error: 'Title is required' }), {
                        status: 400,
                        headers: { 'Content-Type': 'application/json' }
                    });
                }

                // Record history
                const existingProgram = await getExistingTranslation(db, type, id, locale);
                await recordHistory(db, type, id, locale, [
                    { field: 'title', oldValue: existingProgram?.title || null, newValue: title },
                    { field: 'description', oldValue: existingProgram?.description || null, newValue: description || null },
                    { field: 'sections', oldValue: existingProgram?.sections || null, newValue: sections || '[]' }
                ]);

                await db.prepare(`
                    INSERT INTO program_translations (program_id, locale, title, description, sections, status, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(program_id, locale) DO UPDATE SET
                        title = excluded.title,
                        description = excluded.description,
                        sections = excluded.sections,
                        status = excluded.status,
                        updated_at = excluded.updated_at
                `).bind(id, locale, title, description || null, sections || '[]', status, now).run();
                break;
            }

            case 'page': {
                const { title, description, content, sections } = fields;
                if (!title) {
                    return new Response(JSON.stringify({ success: false, error: 'Title is required' }), {
                        status: 400,
                        headers: { 'Content-Type': 'application/json' }
                    });
                }

                // Record history
                const existingPage = await getExistingTranslation(db, type, id, locale);
                await recordHistory(db, type, id, locale, [
                    { field: 'title', oldValue: existingPage?.title || null, newValue: title },
                    { field: 'description', oldValue: existingPage?.description || null, newValue: description || null },
                    { field: 'sections', oldValue: existingPage?.sections || null, newValue: sections || '[]' }
                ]);

                await db.prepare(`
                    INSERT INTO page_translations (page_id, locale, title, description, sections, status, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(page_id, locale) DO UPDATE SET
                        title = excluded.title,
                        description = excluded.description,
                        sections = excluded.sections,
                        status = excluded.status,
                        updated_at = excluded.updated_at
                `).bind(id, locale, title, description || null, sections || '[]', status, now).run();
                break;
            }

            case 'post': {
                const { title, content, excerpt } = fields;
                if (!title) {
                    return new Response(JSON.stringify({ success: false, error: 'Title is required' }), {
                        status: 400,
                        headers: { 'Content-Type': 'application/json' }
                    });
                }

                // Record history
                const existingPost = await getExistingTranslation(db, type, id, locale);
                await recordHistory(db, type, id, locale, [
                    { field: 'title', oldValue: existingPost?.title || null, newValue: title },
                    { field: 'content', oldValue: existingPost?.content || null, newValue: content || null },
                    { field: 'description', oldValue: existingPost?.description || null, newValue: excerpt || null }
                ]);

                await db.prepare(`
                    INSERT INTO post_translations (post_id, locale, title, content, description, status, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(post_id, locale) DO UPDATE SET
                        title = excluded.title,
                        content = excluded.content,
                        description = excluded.description,
                        status = excluded.status,
                        updated_at = excluded.updated_at
                `).bind(id, locale, title, content || null, excerpt || null, status, now).run();
                break;
            }

            case 'topic': {
                const { title, summary } = fields;
                if (!title) {
                    return new Response(JSON.stringify({ success: false, error: 'Title is required' }), {
                        status: 400,
                        headers: { 'Content-Type': 'application/json' }
                    });
                }

                // Record history
                const existingTopic = await getExistingTranslation(db, type, id, locale);
                await recordHistory(db, type, id, locale, [
                    { field: 'title', oldValue: existingTopic?.title || null, newValue: title },
                    { field: 'summary', oldValue: existingTopic?.summary || null, newValue: summary || null }
                ]);

                await db.prepare(`
                    INSERT INTO topic_translations (topic_id, locale, title, summary, status, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(topic_id, locale) DO UPDATE SET
                        title = excluded.title,
                        summary = excluded.summary,
                        status = excluded.status,
                        updated_at = excluded.updated_at
                `).bind(id, locale, title, summary || null, status, now).run();
                break;
            }

            default:
                return new Response(JSON.stringify({ success: false, error: 'Invalid type' }), {
                    status: 400,
                    headers: { 'Content-Type': 'application/json' }
                });
        }

        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Translation save error:', error);
        return new Response(JSON.stringify({ success: false, error: 'Internal server error' }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};
