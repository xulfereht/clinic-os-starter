import type { APIRoute } from 'astro';

export const prerender = false;

export const GET: APIRoute = async ({ url, locals }) => {
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database unavailable' }), { status: 500 });
    }

    const type = url.searchParams.get('type');
    const id = url.searchParams.get('id');
    const locale = url.searchParams.get('locale');

    if (!type || !id) {
        return new Response(JSON.stringify({ error: 'Missing type or id' }), { status: 400 });
    }

    try {
        let query = `
            SELECT * FROM translation_history
            WHERE content_type = ? AND content_id = ?
        `;
        const params: any[] = [type, id];

        if (locale) {
            query += ` AND locale = ?`;
            params.push(locale);
        }

        query += ` ORDER BY changed_at DESC LIMIT 50`;

        const { results } = await db.prepare(query).bind(...params).all();

        return new Response(JSON.stringify(results || []), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Failed to fetch translation history:', e);
        return new Response(JSON.stringify({ error: 'Failed to fetch history' }), { status: 500 });
    }
};
