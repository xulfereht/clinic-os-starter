import type { APIRoute } from 'astro';

export const prerender = false;

/**
 * UI Translations API
 * GET: List all UI translations (optionally filtered by locale or context)
 * PUT: Update a specific translation
 */

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database unavailable' }), { status: 500 });
    }

    const url = new URL(request.url);
    const locale = url.searchParams.get('locale');
    const context = url.searchParams.get('context');
    const search = url.searchParams.get('search');

    try {
        let query = 'SELECT id, key, locale, value, context, updated_at FROM ui_translations WHERE 1=1';
        const params: any[] = [];

        if (locale) {
            query += ' AND locale = ?';
            params.push(locale);
        }

        if (context) {
            query += ' AND context = ?';
            params.push(context);
        }

        if (search) {
            query += ' AND (key LIKE ? OR value LIKE ?)';
            params.push(`%${search}%`, `%${search}%`);
        }

        query += ' ORDER BY context, key, locale';

        const stmt = db.prepare(query);
        const result = params.length > 0
            ? await stmt.bind(...params).all()
            : await stmt.all();

        // Group by key for easier UI rendering
        const grouped: Record<string, any> = {};
        for (const row of (result.results || []) as Array<{ id: number, key: string, locale: string, value: string, context: string, updated_at: number }>) {
            if (!grouped[row.key]) {
                grouped[row.key] = {
                    key: row.key,
                    context: row.context,
                    translations: {}
                };
            }
            grouped[row.key].translations[row.locale] = {
                id: row.id,
                value: row.value,
                updated_at: row.updated_at
            };
        }

        // Get unique contexts for filter dropdown
        const contextsResult = await db.prepare(
            'SELECT DISTINCT context FROM ui_translations ORDER BY context'
        ).all();

        return new Response(JSON.stringify({
            translations: Object.values(grouped),
            contexts: (contextsResult.results || []).map((r: any) => r.context).filter(Boolean),
            total: Object.keys(grouped).length
        }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error: any) {
        console.error('UI Translations GET error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};

export const PUT: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database unavailable' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { key, locale, value, context } = body;

        if (!key || !locale) {
            return new Response(JSON.stringify({ error: 'key and locale are required' }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);

        // Upsert translation
        await db.prepare(`
            INSERT INTO ui_translations (key, locale, value, context, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(key, locale) DO UPDATE SET
                value = excluded.value,
                context = COALESCE(excluded.context, context),
                updated_at = excluded.updated_at
        `).bind(key, locale, value || '', context || null, now, now).run();

        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error: any) {
        console.error('UI Translations PUT error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database unavailable' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { translations } = body;

        if (!translations || !Array.isArray(translations)) {
            return new Response(JSON.stringify({ error: 'translations array required' }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);

        // Batch upsert
        for (const t of translations) {
            if (!t.key || !t.locale) continue;

            await db.prepare(`
                INSERT INTO ui_translations (key, locale, value, context, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(key, locale) DO UPDATE SET
                    value = excluded.value,
                    context = COALESCE(excluded.context, context),
                    updated_at = excluded.updated_at
            `).bind(t.key, t.locale, t.value || '', t.context || null, now, now).run();
        }

        return new Response(JSON.stringify({ success: true, count: translations.length }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error: any) {
        console.error('UI Translations POST error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};
