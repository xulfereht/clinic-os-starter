
import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB not found' }), { status: 500 });

    try {
        const { results } = await db.prepare("SELECT * FROM expense_templates ORDER BY created_at DESC").run();
        return new Response(JSON.stringify({ templates: results }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB not found' }), { status: 500 });

    try {
        const body = await request.json();
        const { name, title, amount, category, account_bank, account_number, account_holder } = body;

        if (!name) {
            return new Response(JSON.stringify({ error: 'Template name is required' }), { status: 400 });
        }

        const res = await db.prepare(`
            INSERT INTO expense_templates (name, title, amount, category, account_bank, account_number, account_holder)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `).bind(name, title, amount, category, account_bank, account_number, account_holder).run();

        if (res.success) {
            return new Response(JSON.stringify({ success: true, id: res.meta.last_row_id }), { status: 201 });
        } else {
            return new Response(JSON.stringify({ error: 'Failed to create template' }), { status: 500 });
        }

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const url = new URL(request.url);
    const id = url.searchParams.get('id');

    if (!db || !id) return new Response(JSON.stringify({ error: 'Invalid Request' }), { status: 400 });

    try {
        const res = await db.prepare(`DELETE FROM expense_templates WHERE id = ?`).bind(id).run();
        return new Response(JSON.stringify({ success: res.success }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}

export const PUT: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB not found' }), { status: 500 });

    try {
        const body = await request.json();
        const { id, name, title, amount, category, account_bank, account_number, account_holder } = body;

        if (!id || !name) {
            return new Response(JSON.stringify({ error: 'ID and Name are required' }), { status: 400 });
        }

        const res = await db.prepare(`
            UPDATE expense_templates 
            SET name = ?, title = ?, amount = ?, category = ?, account_bank = ?, account_number = ?, account_holder = ?
            WHERE id = ?
        `).bind(name, title, amount, category, account_bank, account_number, account_holder, id).run();

        if (res.success) {
            return new Response(JSON.stringify({ success: true }), { status: 200 });
        } else {
            return new Response(JSON.stringify({ error: 'Failed to update template' }), { status: 500 });
        }

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
