
import type { APIRoute } from 'astro';

export const PUT: APIRoute = async ({ locals, params, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;
    if (!db || !id) return new Response(JSON.stringify({ error: 'Invalid Request' }), { status: 400 });

    try {
        const body = await request.json();

        // Handle "Mark as Paid" shortcut
        if (body.action === 'mark_paid') {
            const now = new Date().toISOString().split('T')[0];
            const res = await db.prepare(`
                UPDATE expense_requests 
                SET status = 'PAID', is_paid = 1, paid_date = ?, updated_at = unixepoch()
                WHERE id = ?
            `).bind(now, id).run();
            return new Response(JSON.stringify({ success: res.success }), { status: 200 });
        }

        // Handle Full Update
        const fields = [];
        const values = [];
        const allowed = [
            'request_date', 'title', 'amount', 'category',
            'account_bank', 'account_number', 'account_holder',
            'requester_name', 'due_date', 'status', 'memo'
        ];

        for (const key of allowed) {
            if (body[key] !== undefined) {
                fields.push(`${key} = ?`);
                let val = body[key];
                if (val === '' && ['due_date', 'account_bank', 'account_number', 'account_holder', 'memo', 'proof_image'].includes(key)) {
                    val = null;
                }
                values.push(val);
            }
        }

        // Special handling for is_paid based on status
        if (body.status === 'PAID') {
            fields.push(`is_paid = 1`);
            fields.push(`paid_date = ?`);
            values.push(new Date().toISOString().split('T')[0]);
        } else if (body.status === 'PENDING' || body.status === 'REJECTED') {
            fields.push(`is_paid = 0`);
            fields.push(`paid_date = NULL`);
        }

        fields.push(`updated_at = unixepoch()`);
        values.push(id);

        const query = `UPDATE expense_requests SET ${fields.join(', ')} WHERE id = ?`;
        const res = await db.prepare(query).bind(...values).run();

        return new Response(JSON.stringify({ success: res.success }), { status: 200 });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ locals, params }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;
    if (!db || !id) return new Response(JSON.stringify({ error: 'Invalid Request' }), { status: 400 });

    try {
        const res = await db.prepare(`DELETE FROM expense_requests WHERE id = ?`).bind(id).run();
        return new Response(JSON.stringify({ success: res.success }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
