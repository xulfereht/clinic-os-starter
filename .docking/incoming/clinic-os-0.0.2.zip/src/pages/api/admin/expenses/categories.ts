
import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB not found' }), { status: 500 });

    try {
        const { results } = await db.prepare("SELECT * FROM expense_categories ORDER BY created_at ASC").run();
        return new Response(JSON.stringify({ categories: results }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB not found' }), { status: 500 });

    try {
        const body = await request.json();
        const { name, color } = body;

        if (!name) {
            return new Response(JSON.stringify({ error: 'Category name is required' }), { status: 400 });
        }

        const res = await db.prepare(`
            INSERT INTO expense_categories (name, color)
            VALUES (?, ?)
        `).bind(name, color || 'slate').run();

        if (res.success) {
            return new Response(JSON.stringify({ success: true, id: res.meta.last_row_id }), { status: 201 });
        } else {
            return new Response(JSON.stringify({ error: 'Failed to create category' }), { status: 500 });
        }

    } catch (e: any) {
        // Handle unique constraint
        if (e.message.includes('UNIQUE')) {
            return new Response(JSON.stringify({ error: 'Already exists' }), { status: 409 });
        }
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const url = new URL(request.url);
    const id = url.searchParams.get('id');

    if (!db || !id) return new Response(JSON.stringify({ error: 'Invalid Request' }), { status: 400 });

    try {
        const res = await db.prepare(`DELETE FROM expense_categories WHERE id = ?`).bind(id).run();
        return new Response(JSON.stringify({ success: res.success }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
