
import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB not found' }), { status: 500 });

    const url = new URL(request.url);
    const status = url.searchParams.get('status'); // 'all', 'pending', 'paid'
    const month = url.searchParams.get('month'); // 'YYYY-MM'
    const limit = parseInt(url.searchParams.get('limit') || '50');
    const offset = parseInt(url.searchParams.get('offset') || '0');

    try {
        let query = `SELECT * FROM expense_requests WHERE 1=1`;
        const params: any[] = [];

        if (month) {
            query += ` AND strftime('%Y-%m', request_date) = ?`;
            params.push(month);
        }

        if (status && status !== 'all') {
            query += ` AND status = ?`;
            params.push(status.toUpperCase());
        }

        query += ` ORDER BY request_date DESC, created_at DESC LIMIT ? OFFSET ?`;
        params.push(limit, offset);

        const { results } = await db.prepare(query).bind(...params).run();

        // Get total count for pagination
        let countQuery = `SELECT COUNT(*) as total FROM expense_requests WHERE 1=1`;
        const countParams: any[] = [];

        if (month) {
            countQuery += ` AND strftime('%Y-%m', request_date) = ?`;
            countParams.push(month);
        }

        if (status && status !== 'all') {
            countQuery += ` AND status = ?`;
            countParams.push(status.toUpperCase());
        }
        const countRes = await db.prepare(countQuery).bind(...countParams).first();

        // Calculate Stats (Monthly)
        // Adjust stats to reflect the SELECTED month's context
        const statsQuery = `
            SELECT 
                COUNT(*) as total_count,
                SUM(CASE WHEN is_paid = 0 THEN amount ELSE 0 END) as pending_amount,
                SUM(CASE WHEN is_paid = 1 THEN amount ELSE 0 END) as paid_amount
            FROM expense_requests
            WHERE strftime('%Y-%m', request_date) = ?
        `;
        // Default to current month if no month selected for stats? 
        // Or if user selects '2024-11', show stats for '2024-11'. 
        // Let's use the requested month or current month fallback.
        const statsMonth = month || new Date().toISOString().slice(0, 7);
        const stats = await db.prepare(statsQuery).bind(statsMonth).first();


        return new Response(JSON.stringify({
            expenses: results,
            total: countRes?.total || 0,
            stats: stats
        }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB not found' }), { status: 500 });

    // Auto-assign requester from session
    const user = locals.user;
    const authorName = user?.name || '관리자';

    try {
        const body = await request.json();
        const {
            request_date, title, amount, category,
            account_bank, account_number, account_holder,
            requester_name, due_date, proof_image, memo
        } = body;

        // Validation
        if (!title || !amount || !request_date) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
        }

        const query = `
            INSERT INTO expense_requests (
                request_date, title, amount, category,
                account_bank, account_number, account_holder,
                requester_name, due_date, proof_image, memo,
                status, is_paid
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', 0)
        `;

        const res = await db.prepare(query).bind(
            request_date,
            title,
            amount,
            category || '일반',
            account_bank || null,
            account_number || null,
            account_holder || null,
            authorName,
            due_date || null,
            proof_image || null,
            memo || null
        ).run();

        if (res.success) {
            return new Response(JSON.stringify({ success: true, id: res.meta.last_row_id }), { status: 201 });
        } else {
            return new Response(JSON.stringify({ error: 'Failed to insert' }), { status: 500 });
        }

    } catch (e: any) {
        console.error('Expense Create Error:', e);
        return new Response(JSON.stringify({ error: e.message || 'Unknown Error' }), { status: 500 });
    }
};
