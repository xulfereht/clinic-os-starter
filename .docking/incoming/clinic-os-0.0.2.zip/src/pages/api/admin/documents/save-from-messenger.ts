import type { APIRoute } from 'astro';

// Helper for HMAC Signature (reused)
async function generateSignature(key: string, secret: string): Promise<string> {
    const enc = new TextEncoder();
    const algorithm = { name: 'HMAC', hash: 'SHA-256' };
    const keyData = await crypto.subtle.importKey('raw', enc.encode(secret), algorithm, false, ['sign']);
    const signature = await crypto.subtle.sign(algorithm.name, keyData, enc.encode(key));
    return Array.from(new Uint8Array(signature))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}

export const POST: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const bucket = locals.runtime?.env?.BUCKET;
    // @ts-ignore
    const secret = (locals.runtime?.env?.ADMIN_PASSWORD || 'clinic-admin') as string;

    if (!db || !bucket) return new Response(JSON.stringify({ error: 'System error' }), { status: 500 });

    try {
        const { messageId, fileName, category, description } = await request.json();

        if (!messageId) return new Response(JSON.stringify({ error: 'Message ID required' }), { status: 400 });

        // 1. Get original file info from message
        const message = await db.prepare("SELECT * FROM admin_messages WHERE id = ?").bind(messageId).first();
        if (!message || !message.file_url) {
            return new Response(JSON.stringify({ error: 'Message or file not found' }), { status: 404 });
        }

        // Extract key from URL
        // URL format: /api/files/key?sig=... or full URL
        const urlObj = new URL(message.file_url as string, 'http://localhost');
        let srcKey = '';

        if (urlObj.pathname.startsWith('/api/files/')) {
            srcKey = urlObj.pathname.replace('/api/files/', '');
        } else {
            // Fallback: try to guess or direct R2 access? 
            // If we stored full public URL, we might need logic.
            // But currently we store `/api/files/...`
            return new Response(JSON.stringify({ error: 'Invalid file URL format' }), { status: 400 });
        }

        // 2. Fetch Object from R2
        const object = await bucket.get(srcKey);
        if (!object) {
            return new Response(JSON.stringify({ error: 'File object not found in storage' }), { status: 404 });
        }

        // 3. Re-upload to Company Drive
        const uuid = crypto.randomUUID();
        const finalName = fileName || message.file_name || srcKey.split('/').pop() || 'file';
        const ext = finalName.split('.').pop() || 'bin';
        const now = Math.floor(Date.now() / 1000);

        const targetKey = `company/documents/${uuid}.${ext}`;

        // Ensure content-type
        let contentType = object.httpMetadata?.contentType || 'application/octet-stream';
        if (contentType.startsWith('text/') && !contentType.includes('charset')) {
            contentType += '; charset=utf-8';
        }

        await bucket.put(targetKey, object.body, {
            httpMetadata: { contentType },
            customMetadata: {
                originalName: finalName,
                category,
                source: 'messenger',
                sourceMessageId: messageId
            }
        });

        // 4. Generate Signed URL
        const signature = await generateSignature(targetKey, secret);
        const signedUrl = `/api/files/${targetKey}?sig=${signature}`;

        // 5. Save to Documents DB
        await db.prepare(`
            INSERT INTO documents (id, filename, url, size, mime_type, category, uploaded_at, description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            uuid,
            finalName,
            signedUrl,
            object.size, // R2 object has size
            contentType,
            category || 'general',
            now,
            (description || `Saved from messenger (Msg ID: ${messageId})`) as string
        ).run();

        return new Response(JSON.stringify({ success: true, id: uuid }), { status: 200 });

    } catch (e: any) {
        console.error('Save from Messenger Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
