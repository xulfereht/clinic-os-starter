import type { APIRoute } from 'astro';

// Helper for HMAC Signature
async function generateSignature(key: string, secret: string): Promise<string> {
    const enc = new TextEncoder();
    const algorithm = { name: 'HMAC', hash: 'SHA-256' };
    const keyData = await crypto.subtle.importKey('raw', enc.encode(secret), algorithm, false, ['sign']);
    const signature = await crypto.subtle.sign(algorithm.name, keyData, enc.encode(key));
    return Array.from(new Uint8Array(signature))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}

export const GET: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });

    try {
        const url = new URL(request.url);
        const category = url.searchParams.get('category');

        let query = "SELECT * FROM documents ORDER BY uploaded_at DESC";
        if (category) {
            query = "SELECT * FROM documents WHERE category = ? ORDER BY uploaded_at DESC";
        }

        const { results } = await db.prepare(query).bind(category ? category : undefined).run();
        return new Response(JSON.stringify(results), { status: 200 });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: 'Failed to fetch' }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const bucket = locals.runtime?.env?.BUCKET;
    // @ts-ignore
    const secret = (locals.runtime?.env?.ADMIN_PASSWORD || 'clinic-admin') as string;

    if (!db || !bucket) return new Response(JSON.stringify({ error: 'System error' }), { status: 500 });

    try {
        const formData = await request.formData();
        const file = formData.get('file') as File;
        const category = formData.get('category') as string || 'general';
        const description = formData.get('description') as string || '';

        if (!file) return new Response(JSON.stringify({ error: 'No file' }), { status: 400 });

        const uuid = crypto.randomUUID();
        const ext = file.name.split('.').pop() || 'bin';
        const now = Math.floor(Date.now() / 1000); // Unix timestamp

        // Storage Path: company/documents/{uuid}.{ext}
        const storageKey = `company/documents/${uuid}.${ext}`;

        // 1. Upload to R2
        let contentType = file.type;
        // Ensure charset=utf-8 for text files
        if (contentType.startsWith('text/') && !contentType.includes('charset')) {
            contentType += '; charset=utf-8';
        }

        await bucket.put(storageKey, await file.arrayBuffer(), {
            httpMetadata: { contentType: contentType },
            customMetadata: {
                originalName: file.name,
                category
            }
        });

        // 2. Generate Signed URL
        const signature = await generateSignature(storageKey, secret);
        // Note: Using the secure proxy API
        const signedUrl = `/api/files/${storageKey}?sig=${signature}`;

        // 3. Save Metadata to DB
        await db.prepare(`
            INSERT INTO documents (id, filename, url, size, mime_type, category, uploaded_at, description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            uuid,
            file.name,
            signedUrl,
            file.size,
            file.type,
            category,
            now,
            description
        ).run();

        return new Response(JSON.stringify({ success: true, id: uuid, url: signedUrl }), { status: 200 });

    } catch (e: any) {
        console.error('Document Upload Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
