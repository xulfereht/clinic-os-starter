
import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, request }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;
    const url = new URL(request.url);
    const type = url.searchParams.get('type') || 'visit'; // visit | remote
    const stage = url.searchParams.get('stage') || 'inquiries'; // inquiries | reservations | visits | payments
    const period = url.searchParams.get('period') || 'current'; // current (7 days)

    // Time calculations (KST) - Sync with radiator.ts
    const nowSec = Math.floor(Date.now() / 1000);
    const kstOffsetSec = 9 * 60 * 60;
    const nowKstSec = nowSec + kstOffsetSec;

    // Today Boundaries (KST)
    const todayKstMidnightKst = Math.floor(nowKstSec / 86400) * 86400;
    const todayStart = todayKstMidnightKst - kstOffsetSec; // UTC timestamp for KST 00:00 today
    const todayEnd = todayStart + 86400;

    // Period Definition
    const PERIOD_DAYS = 7;
    const currentPeriodEnd = todayEnd;
    const currentPeriodStart = todayStart - ((PERIOD_DAYS - 1) * 86400);

    let query = '';
    let params: any[] = [];

    // Base Condition based on Type
    let typeCondition = "";
    if (type === 'remote') {
        typeCondition = "AND l.type = 'remote'";
    }

    // Common SELECT fields
    const selectFields = "l.id, l.name, l.contact, l.created_at, l.status, p.id as patient_id, p.chart_number";

    try {
        if (stage === 'inquiries') {
            query = `
                SELECT ${selectFields}, l.created_at as event_date
                FROM leads l
                LEFT JOIN patients p ON l.patient_id = p.id
                WHERE l.patient_type IN ('new', 'new_lead')
                ${typeCondition}
                AND l.deleted_at IS NULL
                AND l.created_at >= ? AND l.created_at < ?
                ORDER BY l.created_at DESC
            `;
            params = [currentPeriodStart, currentPeriodEnd];

        } else if (stage === 'reservations') {
            // First Reservation Only logic
            query = `
                SELECT ${selectFields}, r.reserved_at as event_date, r.id as reservation_id, s.name as doctor_name
                FROM reservations r
                JOIN patients p ON r.patient_id = p.id
                JOIN leads l ON (l.patient_id = p.id OR (l.contact IS NOT NULL AND l.contact != '' AND REPLACE(l.contact, '-', '') = REPLACE(p.current_phone, '-', '')))
                LEFT JOIN staff s ON r.doctor_id = s.id
                WHERE l.patient_type IN ('new', 'new_lead')
                ${typeCondition}
                AND l.deleted_at IS NULL
                AND r.created_at >= ? AND r.created_at < ? AND r.deleted_at IS NULL
                AND NOT EXISTS (SELECT 1 FROM reservations r2 WHERE r2.patient_id = r.patient_id AND r2.created_at < r.created_at AND r2.deleted_at IS NULL)
                ORDER BY r.reserved_at DESC
            `;
            params = [currentPeriodStart, currentPeriodEnd];

        } else if (stage === 'visits') {
            if (type === 'visit') {
                // Visit Events
                query = `
                    SELECT ${selectFields}, e.event_date, e.title
                    FROM patient_events e
                    JOIN patients p ON e.patient_id = p.id
                    JOIN leads l ON (l.patient_id = p.id OR (l.contact IS NOT NULL AND l.contact != '' AND REPLACE(l.contact, '-', '') = REPLACE(p.current_phone, '-', '')))
                    WHERE e.type='visit'
                    AND e.title LIKE '%초진%'
                    AND l.patient_type IN ('new', 'new_lead')
                    ${typeCondition}
                    AND l.deleted_at IS NULL
                    AND e.created_at >= ? AND e.created_at < ? AND e.deleted_at IS NULL
                    GROUP BY e.id
                    ORDER BY e.created_at DESC
                 `;
                params = [currentPeriodStart, currentPeriodEnd];
            } else {
                // Remote: Completed Reservations
                query = `
                    SELECT ${selectFields}, r.reserved_at as event_date
                    FROM reservations r
                    JOIN patients p ON r.patient_id = p.id
                    JOIN leads l ON (l.patient_id = p.id OR (l.contact IS NOT NULL AND l.contact != '' AND REPLACE(l.contact, '-', '') = REPLACE(p.current_phone, '-', '')))
                    WHERE r.status = 'completed'
                    AND l.patient_type IN ('new', 'new_lead')
                    ${typeCondition}
                    AND l.deleted_at IS NULL
                    AND r.reserved_at >= ? AND r.reserved_at < ? AND r.deleted_at IS NULL
                    AND NOT EXISTS (SELECT 1 FROM reservations r2 WHERE r2.patient_id = r.patient_id AND r2.status='completed' AND r2.reserved_at < r.reserved_at)
                    ORDER BY r.reserved_at DESC
                `;
                params = [currentPeriodStart, currentPeriodEnd];
            }

        } else if (stage === 'payments') {
            // First Payment
            query = `
                SELECT ${selectFields}, pay.paid_at as event_date, pay.amount
                FROM payments pay
                JOIN patients p ON pay.patient_id = p.id
                JOIN leads l ON (l.patient_id = p.id OR (l.contact IS NOT NULL AND l.contact != '' AND REPLACE(l.contact, '-', '') = REPLACE(p.current_phone, '-', '')))
                WHERE pay.amount > 0
                AND l.patient_type IN ('new', 'new_lead')
                ${typeCondition}
                AND l.deleted_at IS NULL
                AND pay.paid_at >= ? AND pay.paid_at < ? AND pay.deleted_at IS NULL
                AND NOT EXISTS (SELECT 1 FROM payments p2 WHERE p2.patient_id = pay.patient_id AND p2.paid_at < pay.paid_at AND p2.deleted_at IS NULL)
                GROUP BY pay.id
                ORDER BY pay.paid_at DESC
            `;
            params = [currentPeriodStart, currentPeriodEnd];
        }

        const { results } = await db.prepare(query).bind(...params).run();

        return new Response(JSON.stringify({
            data: results,
            meta: {
                type,
                stage,
                period,
                start: new Date(currentPeriodStart * 1000).toISOString(),
                end: new Date(currentPeriodEnd * 1000).toISOString()
            }
        }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Pipeline Details API Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
