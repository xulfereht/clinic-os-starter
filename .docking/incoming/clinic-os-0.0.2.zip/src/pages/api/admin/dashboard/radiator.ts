
import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;

    // Time calculations (KST)
    const nowSec = Math.floor(Date.now() / 1000);
    const kstOffsetSec = 9 * 60 * 60;
    const nowKstSec = nowSec + kstOffsetSec;

    // Today Boundaries (KST)
    const todayKstMidnightKst = Math.floor(nowKstSec / 86400) * 86400;
    const todayStart = todayKstMidnightKst - kstOffsetSec; // UTC timestamp for KST 00:00 today
    const todayEnd = todayStart + 86400;

    // Rolling 7-Day Periods for Health Indicator
    const PERIOD_DAYS = 7;
    const MA_PERIODS = 4; // Compare against 4 previous 7-day periods (28 days total)

    // Current Period: Last 7 days (including today)
    const currentPeriodEnd = todayEnd;
    const currentPeriodStart = todayStart - ((PERIOD_DAYS - 1) * 86400);

    // MA Periods: Previous 4 rolling 7-day windows
    // Period 1: days -14 to -8, Period 2: days -21 to -15, etc.
    const maPeriods: { start: number; end: number }[] = [];
    for (let i = 1; i <= MA_PERIODS; i++) {
        const periodEnd = currentPeriodStart - ((i - 1) * PERIOD_DAYS * 86400);
        const periodStart = periodEnd - (PERIOD_DAYS * 86400);
        maPeriods.push({ start: periodStart, end: periodEnd });
    }

    try {
        // --- 1. OPERATIONAL BOARD (Today) ---
        const { results: opStats } = await db.prepare(`
          SELECT 
            (SELECT COUNT(*) FROM patient_events WHERE type='visit' AND created_at >= ? AND deleted_at IS NULL) as today_visits,
            
            -- Today's New Patient Visits (First Visit based on title)
            (SELECT COUNT(*) FROM patient_events 
             WHERE type='visit' AND title = '초진 내원'
             AND created_at >= ? AND deleted_at IS NULL) as today_new_visits,

            (SELECT COUNT(*) FROM reservations WHERE reserved_at BETWEEN ? AND ? AND deleted_at IS NULL) as today_reservations,
            (SELECT COUNT(*) FROM payments WHERE paid_at >= ? AND amount > 0 AND deleted_at IS NULL) as today_payment_count,
            (SELECT SUM(amount) FROM payments WHERE paid_at >= ? AND deleted_at IS NULL) as today_revenue,
            (SELECT COUNT(*) FROM payments WHERE paid_at >= ? AND (status='refund' OR amount < 0) AND deleted_at IS NULL) as today_refunds,
            (SELECT COUNT(*) FROM leads WHERE created_at >= ? AND deleted_at IS NULL) as today_new_leads,
            
            -- Pending Inquiries (Total Waiting)
            (SELECT COUNT(*) FROM leads WHERE status = 'pending' AND deleted_at IS NULL) as pending_inquiries,

            -- Shipping Metrics (uses remaining_quantity only, refund consideration added separately)
            (SELECT COUNT(*) FROM shipping_orders WHERE remaining_quantity > 0 AND next_shipping_date < ?) as shipping_delayed_raw,
            (SELECT COUNT(*) FROM shipping_orders WHERE remaining_quantity > 0 AND next_shipping_date >= ? AND next_shipping_date <= ?) as shipping_imminent_raw

        `).bind(
            todayStart,             // today_visits
            todayStart,             // today_new_visits
            todayStart, todayEnd,   // today_reservations
            todayStart,             // today_payment_count
            todayStart,             // today_revenue
            todayStart,             // today_refunds
            todayStart,             // today_new_leads
            nowSec,                 // shipping_delayed (< now)
            nowSec,                 // shipping_imminent start (today)
            (nowSec + (3 * 86400))  // shipping_imminent end (today + 3 days)
        ).run();

        // --- 1.5 ACCURATE SHIPPING METRICS (Considering Refunds) ---
        const { results: shippingStats } = await db.prepare(`
            SELECT 
                so.id,
                so.remaining_quantity,
                so.next_shipping_date,
                so.product_name,
                so.patient_id,
                COALESCE((
                    SELECT SUM(CASE WHEN py.quantity = 0 OR py.quantity IS NULL THEN 1 ELSE ABS(py.quantity) END)
                    FROM payments py
                    LEFT JOIN products prod ON py.product_id = prod.id
                    WHERE py.patient_id = so.patient_id
                      AND (py.status = 'refund' OR py.amount < 0)
                      AND py.deleted_at IS NULL
                      AND prod.name = so.product_name
                ), 0) as refund_quantity
            FROM shipping_orders so
            JOIN patients p ON so.patient_id = p.id
            WHERE so.remaining_quantity > 0 AND p.deleted_at IS NULL
        `).run();

        // Calculate accurate counts considering refunds
        let shippingDelayed = 0;
        let shippingImminent = 0;
        const threeDaysLater = nowSec + (3 * 86400);

        for (const order of (shippingStats || []) as { remaining_quantity: number; refund_quantity: number; next_shipping_date: number }[]) {
            const effectiveRemaining = Math.max(0, (order.remaining_quantity || 0) - (order.refund_quantity || 0));
            if (effectiveRemaining <= 0) continue; // Skip fully refunded orders

            if (order.next_shipping_date && order.next_shipping_date < nowSec) {
                shippingDelayed++;
            } else if (order.next_shipping_date && order.next_shipping_date >= nowSec && order.next_shipping_date <= threeDaysLater) {
                shippingImminent++;
            }
        }

        // --- 2. NEW PATIENT PIPELINE (Rolling 7-Day with MA) ---
        // Helper to build query for specific type
        const buildPipelineQuery = (typeCondition: string, useVisitEvents: boolean) => `
            SELECT 
                -- 1. Inquiries (Created)
                (SELECT COUNT(*) FROM leads l
                 WHERE patient_type IN ('new', 'new_lead')
                 ${typeCondition}
                 AND deleted_at IS NULL 
                 AND created_at >= ? AND created_at < ?) as flow_inquiries,

                -- 2. Reservations (First Reservation Only)
                (SELECT COUNT(DISTINCT r.id) FROM reservations r
                 JOIN patients p ON r.patient_id = p.id
                 JOIN leads l ON (l.patient_id = p.id OR (l.contact IS NOT NULL AND l.contact != '' AND REPLACE(l.contact, '-', '') = REPLACE(p.current_phone, '-', '')))
                 WHERE l.patient_type IN ('new', 'new_lead') 
                 ${typeCondition}
                 AND l.deleted_at IS NULL
                 AND r.created_at >= ? AND r.created_at < ? AND r.deleted_at IS NULL
                 AND NOT EXISTS (SELECT 1 FROM reservations r2 WHERE r2.patient_id = r.patient_id AND r2.created_at < r.created_at AND r2.deleted_at IS NULL AND r2.status != 'cancelled')
                ) as flow_reservations,

                -- 3. Visits / Completed (Event or Status)
                ${useVisitEvents ? `
                (SELECT COUNT(DISTINCT e.id) FROM patient_events e
                 JOIN patients p ON e.patient_id = p.id
                 JOIN leads l ON (l.patient_id = p.id OR (l.contact IS NOT NULL AND l.contact != '' AND REPLACE(l.contact, '-', '') = REPLACE(p.current_phone, '-', '')))
                 WHERE e.type='visit'
                 AND e.title LIKE '%초진%'
                 AND l.patient_type IN ('new', 'new_lead') 
                 ${typeCondition}
                 AND l.deleted_at IS NULL
                 AND e.created_at >= ? AND e.created_at < ? AND e.deleted_at IS NULL)
                ` : `
                (SELECT COUNT(DISTINCT r.id) FROM reservations r
                 JOIN patients p ON r.patient_id = p.id
                 JOIN leads l ON (l.patient_id = p.id OR (l.contact IS NOT NULL AND l.contact != '' AND REPLACE(l.contact, '-', '') = REPLACE(p.current_phone, '-', '')))
                 WHERE r.status = 'completed'
                 AND l.patient_type IN ('new', 'new_lead') 
                 ${typeCondition}
                 AND l.deleted_at IS NULL
                 AND r.reserved_at >= ? AND r.reserved_at < ? AND r.deleted_at IS NULL
                 AND NOT EXISTS (SELECT 1 FROM reservations r2 WHERE r2.patient_id = r.patient_id AND r2.status='completed' AND r2.reserved_at < r.reserved_at AND r2.status != 'cancelled')
                )
                `} as flow_visits,

                -- 4. Payments (First Payment Only)
                (SELECT COUNT(DISTINCT p.id) FROM payments p
                 JOIN patients pat ON p.patient_id = pat.id
                 JOIN leads l ON (l.patient_id = pat.id OR (l.contact IS NOT NULL AND l.contact != '' AND REPLACE(l.contact, '-', '') = REPLACE(pat.current_phone, '-', '')))
                 WHERE p.amount > 0
                 AND l.patient_type IN ('new', 'new_lead') 
                 ${typeCondition}
                 AND l.deleted_at IS NULL
                 AND p.paid_at >= ? AND p.paid_at < ? AND p.deleted_at IS NULL
                 AND NOT EXISTS (SELECT 1 FROM payments p2 WHERE p2.patient_id = p.patient_id AND p2.paid_at < p.paid_at AND p2.deleted_at IS NULL)
                ) as flow_payments
        `;

        // Main Pipeline: No filter (All New Patients), Use Visit Events (High Accuracy for presence)
        const visitQuery = buildPipelineQuery("", true);

        // Remote Pipeline: Remote Only, Use Reservation Completion (since no visit event)
        const remoteQuery = buildPipelineQuery("AND l.type = 'remote'", false);

        const fetchPipelineData = async (query: string) => {
            // Current Period
            const { results: currFlow } = await db.prepare(query)
                .bind(
                    currentPeriodStart, currentPeriodEnd,
                    currentPeriodStart, currentPeriodEnd,
                    currentPeriodStart, currentPeriodEnd,
                    currentPeriodStart, currentPeriodEnd
                ).run();

            // MA Periods
            const maResults: any[] = [];
            for (const period of maPeriods) {
                const { results } = await db.prepare(query)
                    .bind(
                        period.start, period.end,
                        period.start, period.end,
                        period.start, period.end,
                        period.start, period.end
                    ).run();
                maResults.push(results[0] || {});
            }

            // Calculate MA
            const calcMA = (key: string) => {
                const values = maResults.map(r => r[key] || 0);
                const sum = values.reduce((a: number, b: number) => a + b, 0);
                return sum / MA_PERIODS;
            };

            const maValues = {
                inquiries: calcMA('flow_inquiries'),
                reservations: calcMA('flow_reservations'),
                visits: calcMA('flow_visits'),
                payments: calcMA('flow_payments')
            };

            // Calculate Health
            const calcHealth = (current: number, ma: number) => {
                if (ma === 0) return current > 0 ? 100 : 0;
                return Math.round(((current / ma) - 1) * 100);
            };

            const curr = currFlow[0] || {};

            return {
                current: {
                    inquiries: curr.flow_inquiries || 0,
                    reservations: curr.flow_reservations || 0,
                    visits: curr.flow_visits || 0,
                    payments: curr.flow_payments || 0
                },
                health: {
                    inquiries: calcHealth(Number(curr.flow_inquiries) || 0, maValues.inquiries),
                    reservations: calcHealth(Number(curr.flow_reservations) || 0, maValues.reservations),
                    visits: calcHealth(Number(curr.flow_visits) || 0, maValues.visits),
                    payments: calcHealth(Number(curr.flow_payments) || 0, maValues.payments)
                }
            };
        };

        const visitPipeline = await fetchPipelineData(visitQuery);
        const remotePipeline = await fetchPipelineData(remoteQuery);

        const op = opStats[0] || {};

        return new Response(JSON.stringify({
            operational: {
                visits: op.today_visits || 0,
                new_visits: op.today_new_visits || 0,
                reservations: op.today_reservations || 0,
                revenue: op.today_revenue || 0,
                payment_count: op.today_payment_count || 0,
                refunds: op.today_refunds || 0,
                new_leads: op.today_new_leads || 0,
                pending_inquiries: op.pending_inquiries || 0,
                shipping_delayed: shippingDelayed,
                shipping_imminent: shippingImminent
            },
            pipeline: {
                period: `Last ${PERIOD_DAYS} Days`,
                visit: visitPipeline,
                remote: remotePipeline
            },
            meta: {
                updated_at: nowSec
            }
        }), {
            headers: { 'Content-Type': 'application/json' }
        });


    } catch (e: any) {
        console.error('Radiator API Error:', e);
        return new Response(JSON.stringify({
            operational: { visits: 0, new_visits: 0, reservations: 0, revenue: 0, payment_count: 0, refunds: 0, new_leads: 0 },
            pipeline: null,
            error: e.message
        }));
    }
}
