export const prerender = false;

import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    try {
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
        }

        // Parse date range parameters (default: last 30 days)
        const fromParam = url.searchParams.get('from');
        const toParam = url.searchParams.get('to');

        const now = Math.floor(Date.now() / 1000);
        const thirtyDaysAgo = now - (30 * 24 * 60 * 60);

        const fromTimestamp = fromParam
            ? Math.floor(new Date(fromParam).getTime() / 1000)
            : thirtyDaysAgo;
        const toTimestamp = toParam
            ? Math.floor(new Date(toParam).getTime() / 1000)
            : now;

        // 1. New Patients Count (in period)
        const newPatientsResult = await db.prepare(`
            SELECT COUNT(*) as count
            FROM patients
            WHERE deleted_at IS NULL
              AND created_at >= ?
              AND created_at <= ?
        `).bind(fromTimestamp, toTimestamp).first<{ count: number }>();

        // 2. Total Active Patients
        const totalPatientsResult = await db.prepare(`
            SELECT COUNT(*) as count
            FROM patients
            WHERE deleted_at IS NULL
        `).first<{ count: number }>();

        // 3. 30-Day Inactive Patients (no event in last 30 days)
        const inactiveResult = await db.prepare(`
            SELECT COUNT(*) as count
            FROM patient_retention_stats
            WHERE (last_event_date IS NULL OR last_event_date < ?)
        `).bind(thirtyDaysAgo).first<{ count: number }>();

        // 4. 30-Day Retention Rate
        // Patients with first event who had a second event within 30 days
        const retentionResult = await db.prepare(`
            SELECT
                COUNT(CASE WHEN second_event_date IS NOT NULL 
                    AND (second_event_date - first_event_date) <= 2592000 
                    THEN 1 END) as retained,
                COUNT(CASE WHEN first_event_date IS NOT NULL THEN 1 END) as total
            FROM retention_30d_stats
        `).first<{ retained: number; total: number }>();

        const retention30dRate = retentionResult && retentionResult.total > 0
            ? retentionResult.retained / retentionResult.total
            : null;

        // 5. Lead Source Distribution
        const leadSourcesResult = await db.prepare(`
            SELECT source, patient_count
            FROM lead_source_stats
            ORDER BY patient_count DESC
        `).all<{ source: string; patient_count: number }>();

        // 6. Monthly Trend (last 6 months)
        const monthlyTrendResult = await db.prepare(`
            SELECT month, new_patients
            FROM monthly_new_patients
            ORDER BY month DESC
            LIMIT 6
        `).all<{ month: string; new_patients: number }>();

        // 7. Top Referral Sources with retention (bonus insight)
        const topSourcesResult = await db.prepare(`
            SELECT 
                COALESCE(first_source, 'UNKNOWN') as source,
                COUNT(*) as patient_count,
                AVG(visit_count) as avg_visits,
                AVG(retention_days) as avg_retention_days
            FROM patient_retention_stats
            GROUP BY COALESCE(first_source, 'UNKNOWN')
            ORDER BY patient_count DESC
            LIMIT 5
        `).all<{ source: string; patient_count: number; avg_visits: number; avg_retention_days: number }>();

        const response = {
            period: {
                from: new Date(fromTimestamp * 1000).toISOString().split('T')[0],
                to: new Date(toTimestamp * 1000).toISOString().split('T')[0]
            },
            summary: {
                newPatients: newPatientsResult?.count || 0,
                totalPatients: totalPatientsResult?.count || 0,
                inactive30d: inactiveResult?.count || 0,
                retention30dRate: retention30dRate
            },
            leadSources: leadSourcesResult?.results || [],
            monthlyTrend: monthlyTrendResult?.results?.reverse() || [],
            topSources: topSourcesResult?.results || []
        };

        return new Response(JSON.stringify(response), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error: any) {
        console.error('[CRM Overview API Error]', error);
        return new Response(JSON.stringify({
            error: 'Failed to fetch CRM data',
            details: error.message
        }), { status: 500 });
    }
};
