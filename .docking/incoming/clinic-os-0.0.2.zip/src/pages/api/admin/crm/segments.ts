export const prerender = false;

import type { APIRoute } from 'astro';
import { generateSegmentSql } from '../../../../lib/segment-engine';

// GET: List all segments with patient counts
export const GET: APIRoute = async ({ locals, url }) => {
    try {
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
        }

        const segmentId = url.searchParams.get('id');

        if (segmentId) {
            // Get specific segment with patient list
            const segment = await db.prepare(`
                SELECT * FROM segments WHERE id = ? AND is_active = 1
            `).bind(segmentId).first();

            if (!segment) {
                return new Response(JSON.stringify({ error: 'Segment not found' }), { status: 404 });
            }

            // Execute the segment query to get patient list
            try {
                let querySql = segment.query_sql;
                let params: any[] = [];

                if (segment.criteria) {
                    try {
                        const parsed = JSON.parse(segment.criteria);
                        const generated = generateSegmentSql(parsed);
                        querySql = `SELECT id as patient_id FROM patients WHERE ${generated.sql}`;
                        params = generated.params;
                    } catch (e) {
                        console.error('[Segments API] Failed to parse criteria', e);
                    }
                }

                const patientsResult = await db.prepare(querySql).bind(...params).all();
                const patientIds = patientsResult?.results?.map((r: any) => r.patient_id) || [];

                // Get patient details
                let patients = [];
                if (patientIds.length > 0) {
                    const placeholders = patientIds.map(() => '?').join(',');
                    const patientsData = await db.prepare(`
                        SELECT p.id, p.name, p.current_phone, p.first_source,
                               prs.visit_count, prs.retention_days, prs.last_event_date
                        FROM patients p
                        LEFT JOIN patient_retention_stats prs ON prs.patient_id = p.id
                        WHERE p.id IN (${placeholders})
                        ORDER BY p.name
                    `).bind(...patientIds).all();
                    patients = patientsData?.results || [];
                }

                return new Response(JSON.stringify({
                    segment,
                    patients,
                    count: patients.length
                }), {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                });
            } catch (queryError: any) {
                console.error('[Segments API] Query execution error:', queryError);
                return new Response(JSON.stringify({
                    error: 'Segment query failed',
                    details: queryError.message
                }), { status: 500 });
            }
        }

        // List all segments with counts
        const segmentsResult = await db.prepare(`
            SELECT * FROM segments WHERE is_active = 1 ORDER BY id
        `).all();

        const segments = segmentsResult?.results || [];

        // Get patient counts for each segment
        const segmentsWithCounts = await Promise.all(segments.map(async (seg: any) => {
            try {
                let querySql = seg.query_sql;
                let params: any[] = [];

                // Valid 'criteria' means it's a new dynamic segment with placeholders
                if (seg.criteria) {
                    try {
                        const parsed = JSON.parse(seg.criteria);
                        const generated = generateSegmentSql(parsed);
                        // Reconstruct full query matching the one stored in query_sql but now we have params!
                        // Actually, let's just use the WHERE clause generated
                        querySql = `SELECT id FROM patients WHERE ${generated.sql}`;
                        params = generated.params;
                    } catch (e) {
                        // Fallback to stored query_sql (legacy or error)
                        console.error('Failed to parse criteria for segment', seg.id);
                    }
                }

                const countResult = await db.prepare(`
                    SELECT COUNT(*) as count FROM (${querySql})
                `).bind(...params).first();

                return {
                    ...seg,
                    patient_count: countResult?.count || 0
                };
            } catch (e) {
                console.error(`Error counting segment ${seg.id}:`, e);
                return { ...seg, patient_count: 0, error: true };
            }
        }));

        return new Response(JSON.stringify({
            segments: segmentsWithCounts
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error: any) {
        console.error('[Segments API Error]', error);
        return new Response(JSON.stringify({
            error: 'Failed to fetch segments',
            details: error.message
        }), { status: 500 });
    }
};

// POST: Create a new segment
export const POST: APIRoute = async ({ locals, request }) => {
    try {
        const db = locals.runtime?.env?.DB;
        if (!db) return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });

        const body = await request.json();
        const { name, description, criteria } = body;

        if (!name || !criteria) {
            return new Response(JSON.stringify({ error: 'Missing name or criteria' }), { status: 400 });
        }

        let querySql = '';

        // Build SQL based on criteria
        // Simple implementation for Label-based segments
        if (criteria.type === 'label') {
            // criteria: { type: 'label', category: 'program', value: 'diet' }
            querySql = `
                SELECT patient_id 
                FROM patient_labels 
                WHERE category = '${criteria.category}' 
                AND value = '${criteria.value}' 
                AND is_active = 1
            `;
        } else if (criteria.type === 'status') {
            // criteria: { type: 'status', value: 'active' }
            querySql = `
                SELECT id as patient_id
                FROM patients
                WHERE status = '${criteria.value}'
                AND deleted_at IS NULL
            `;
        } else {
            // fallback or logic for other types
            return new Response(JSON.stringify({ error: 'Invalid criteria type' }), { status: 400 });
        }

        // Use a generic logic to avoid SQL injection in a real app, but here we construct fixed queries
        // Ideally we should store the criteria JSON and build query on fly or use parameterized views.
        // For D1/SQLite, we store the SQL string as per existing pattern.

        await db.prepare(`
            INSERT INTO segments (name, description, query_sql) VALUES (?, ?, ?)
        `).bind(name, description || '', querySql).run();

        return new Response(JSON.stringify({ success: true }), { status: 201 });

    } catch (error: any) {
        console.error('[Segments Create Error]', error);
        return new Response(JSON.stringify({
            error: 'Failed to create segment',
            details: error.message
        }), { status: 500 });
    }
};
