
import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
    }

    const url = new URL(request.url);
    const metric = url.searchParams.get('metric');
    const startDate = url.searchParams.get('startDate'); // YYYY-MM-DD
    const endDate = url.searchParams.get('endDate'); // YYYY-MM-DD
    const mode = url.searchParams.get('mode');

    if (!startDate || !endDate || !metric) {
        return new Response(JSON.stringify({ error: 'Missing params' }), { status: 400 });
    }

    const startUnix = Math.floor(new Date(startDate).getTime() / 1000);
    const endUnix = Math.floor(new Date(endDate).getTime() / 1000) + 86399;

    let query = '';
    let binds: any[] = [];
    // Mode filtering is handled per-query below

    try {
        switch (metric) {
            case 'new_patients':
                // Patients created in range
                query = `
                    SELECT p.id, p.name, p.chart_number, p.current_phone as phone, p.created_at,
                           p.first_source as source
                    FROM patients p
                    WHERE p.deleted_at IS NULL
                    AND p.created_at BETWEEN ? AND ?
                    ORDER BY p.created_at DESC
                `;
                binds = [startUnix, endUnix];
                break;

            case 'active_patients':
                // Patients with events in range
                query = `
                    SELECT DISTINCT p.id, p.name, p.chart_number, p.current_phone as phone, p.created_at,
                           MAX(pe.event_date) as last_activity
                    FROM patients p
                    JOIN patient_events pe ON pe.patient_id = p.id
                    WHERE p.deleted_at IS NULL
                    AND pe.event_date BETWEEN ? AND ?
                    ${(mode && mode !== 'ALL') ? 'AND pe.care_mode = ?' : ''}
                    GROUP BY p.id
                    ORDER BY last_activity DESC
                `;
                binds = [startUnix, endUnix];
                if (mode && mode !== 'ALL') binds.push(mode);
                break;

            case 'returning_visits':
                // Active patients excluding newly created ones (approx)
                query = `
                    SELECT DISTINCT p.id, p.name, p.chart_number, p.current_phone as phone, p.created_at,
                           MAX(pe.event_date) as last_activity
                    FROM patients p
                    JOIN patient_events pe ON pe.patient_id = p.id
                    WHERE p.deleted_at IS NULL
                    AND pe.event_date BETWEEN ? AND ?
                    AND p.created_at < ?
                    ${(mode && mode !== 'ALL') ? 'AND pe.care_mode = ?' : ''}
                    GROUP BY p.id
                    ORDER BY last_activity DESC
                `;
                binds = [startUnix, endUnix, startUnix];
                if (mode && mode !== 'ALL') binds.push(mode);
                break;

            case 'cohort_visits':
                // New Patients in range with their visit counts derived directly
                // Replaces missing patient_retention_stats view
                query = `
                    SELECT p.id, p.name, p.chart_number, p.current_phone as phone, p.created_at,
                           COUNT(pe.id) as visit_count,
                           CAST((MAX(pe.event_date) - MIN(pe.event_date)) / 86400 AS INTEGER) as retention_days
                    FROM patients p
                    LEFT JOIN patient_events pe ON pe.patient_id = p.id 
                    WHERE p.deleted_at IS NULL
                    AND p.created_at BETWEEN ? AND ?
                    GROUP BY p.id
                    ORDER BY visit_count DESC
                `;
                binds = [startUnix, endUnix];
                break;

            default:
                return new Response(JSON.stringify({ error: 'Invalid metric' }), { status: 400 });
        }

        const { results } = await db.prepare(query).bind(...binds).all();

        return new Response(JSON.stringify({
            data: results,
            meta: { count: results.length }
        }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Breakdown API Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
