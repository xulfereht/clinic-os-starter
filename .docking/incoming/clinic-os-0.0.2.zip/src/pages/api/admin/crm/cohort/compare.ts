/**
 * CRM 코호트 비교 분석 API
 * GET /api/admin/crm/cohort/compare
 * 
 * Query params:
 * - splitBy: 'provider' | 'care_mode' | 'business_type'
 * - ... (cohort config params)
 */

import type { APIRoute } from 'astro';
import {
    buildCohort,
    calculateCohortMetrics,
    calculateCohortDateRange,
    classifyVisits,
    type CohortConfig,
    type ClassifiedVisit
} from '../../../../../lib/cohort';

interface ComparisonResult {
    splitValue: string;
    label: string;
    cohortSize: number;
    retention: { week4: number; week8: number; week12: number };
    avgRevisits: number;
    medianFirstRevisitDays: number | null;
}

export const GET: APIRoute = async ({ request, locals }) => {
    try {
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'Database not available' }), {
                status: 500,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        const url = new URL(request.url);

        // Parse query params
        const weeksAgo = parseInt(url.searchParams.get('weeksAgo') || '8');
        const windowWeeks = parseInt(url.searchParams.get('windowWeeks') || '4');
        const analysisType = (url.searchParams.get('analysisType') || 'episode_start') as
            'first_ever' | 'episode_start' | 'restart_only';
        const dormantDays = parseInt(url.searchParams.get('dormantDays') || '90');
        const followUpWeeks = parseInt(url.searchParams.get('followUpWeeks') || '12');
        const cutoffDays = parseInt(url.searchParams.get('cutoffDays') || '14');
        const splitBy = url.searchParams.get('splitBy') || 'provider';

        // Config
        const config: CohortConfig = {
            dormantThresholdDays: dormantDays,
            followUpWeeks,
            cutoffBufferDays: cutoffDays,
        };

        // Calculate date range
        const { intakeStart, intakeEnd } = calculateCohortDateRange(
            weeksAgo,
            windowWeeks,
            cutoffDays
        );

        // Build full cohort first
        const cohort = await buildCohort(
            db,
            intakeStart,
            intakeEnd,
            analysisType,
            config
        );

        // Get split labels (provider names, etc.)
        let labelMap: Map<string, string> = new Map();
        if (splitBy === 'provider') {
            const staffResult = await db.prepare(`
        SELECT id, name FROM staff WHERE deleted_at IS NULL
      `).all();
            for (const row of staffResult.results as { id: string; name: string }[]) {
                labelMap.set(row.id, row.name);
            }
        }

        // Group cohort by split value
        const splitGroups = new Map<string, Map<string, ClassifiedVisit[]>>();

        for (const [patientId, visits] of cohort) {
            // Find the episode start visit in range
            const episodeStart = visits.find(v =>
                v.event_date >= intakeStart &&
                v.event_date <= intakeEnd &&
                v.is_episode_start
            );

            if (!episodeStart) continue;

            // Get split value based on splitBy
            let splitValue: string = 'unknown';
            switch (splitBy) {
                case 'provider':
                    splitValue = episodeStart.staff_id || 'unassigned';
                    break;
                case 'care_mode':
                    splitValue = episodeStart.care_mode || 'INPERSON';
                    break;
                case 'business_type':
                    splitValue = episodeStart.business_type || 'INSURED';
                    break;
            }

            if (!splitGroups.has(splitValue)) {
                splitGroups.set(splitValue, new Map());
            }
            splitGroups.get(splitValue)!.set(patientId, visits);
        }

        // Calculate metrics for each group
        const results: ComparisonResult[] = [];

        for (const [splitValue, groupCohort] of splitGroups) {
            const metrics = calculateCohortMetrics(groupCohort, intakeStart, intakeEnd, config);

            let label = splitValue;
            if (splitBy === 'provider') {
                label = labelMap.get(splitValue) || (splitValue === 'unassigned' ? '미배정' : splitValue);
            } else if (splitBy === 'care_mode') {
                label = splitValue === 'INPERSON' ? '대면' : splitValue === 'REMOTE' ? '비대면' : splitValue;
            } else if (splitBy === 'business_type') {
                label = splitValue === 'INSURED' ? '급여' : splitValue === 'UNINSURED' ? '비급여' : splitValue;
            }

            results.push({
                splitValue,
                label,
                cohortSize: metrics.cohortSize,
                retention: metrics.retention,
                avgRevisits: metrics.avgRevisits,
                medianFirstRevisitDays: metrics.medianFirstRevisitDays,
            });
        }

        // Sort by cohort size descending
        results.sort((a, b) => b.cohortSize - a.cohortSize);

        return new Response(JSON.stringify({
            success: true,
            splitBy,
            results,
            totalCohortSize: cohort.size,
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Cohort Compare API error:', error);
        return new Response(JSON.stringify({
            error: 'Failed to calculate comparison',
            details: error instanceof Error ? error.message : 'Unknown error'
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};
