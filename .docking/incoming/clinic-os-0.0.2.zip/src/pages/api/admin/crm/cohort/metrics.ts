/**
 * CRM 코호트 분석 API
 * GET /api/admin/crm/cohort/metrics
 * 
 * Query params:
 * - weeksAgo: 기준점 (기본 4)
 * - windowWeeks: 유입 창 (기본 4)  
 * - analysisType: 'first_ever' | 'episode_start' | 'restart_only'
 * - dormantDays: 휴면 기준 (기본 90)
 * - followUpWeeks: 추적 기간 (기본 12)
 */

import type { APIRoute } from 'astro';
import {
    buildCohort,
    calculateCohortMetrics,
    calculateCohortDateRange,
    type CohortConfig
} from '../../../../../lib/cohort';

export const GET: APIRoute = async ({ request, locals }) => {
    try {
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'Database not available' }), {
                status: 500,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        const url = new URL(request.url);

        // Parse query params
        const weeksAgo = parseInt(url.searchParams.get('weeksAgo') || '4');
        const windowWeeks = parseInt(url.searchParams.get('windowWeeks') || '4');
        const analysisType = (url.searchParams.get('analysisType') || 'episode_start') as
            'first_ever' | 'episode_start' | 'restart_only';
        const dormantDays = parseInt(url.searchParams.get('dormantDays') || '90');
        const followUpWeeks = parseInt(url.searchParams.get('followUpWeeks') || '12');
        const cutoffDays = parseInt(url.searchParams.get('cutoffDays') || '14');

        // Config
        const config: CohortConfig = {
            dormantThresholdDays: dormantDays,
            followUpWeeks,
            cutoffBufferDays: cutoffDays,
        };

        // Calculate date range
        const { intakeStart, intakeEnd, analysisDate } = calculateCohortDateRange(
            weeksAgo,
            windowWeeks,
            cutoffDays
        );

        // Build cohort
        const cohort = await buildCohort(
            db,
            intakeStart,
            intakeEnd,
            analysisType,
            config
        );

        // Calculate metrics
        const metrics = calculateCohortMetrics(cohort, intakeStart, intakeEnd, config);

        // Response
        return new Response(JSON.stringify({
            success: true,
            params: {
                weeksAgo,
                windowWeeks,
                analysisType,
                dormantDays,
                followUpWeeks,
                intakeStart: new Date(intakeStart * 1000).toISOString().split('T')[0],
                intakeEnd: new Date(intakeEnd * 1000).toISOString().split('T')[0],
                analysisDate: new Date(analysisDate * 1000).toISOString().split('T')[0],
            },
            metrics,
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Cohort API error:', error);
        return new Response(JSON.stringify({
            error: 'Failed to calculate cohort metrics',
            details: error instanceof Error ? error.message : 'Unknown error'
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};
