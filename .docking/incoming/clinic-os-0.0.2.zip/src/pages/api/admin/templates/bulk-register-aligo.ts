
import type { APIRoute } from 'astro';
import { getAligoConfig, addAlimTalkTemplate, convertVariablesToAligoFormat } from '../../../../lib/aligo';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const env = locals.runtime?.env;

    if (!db) return new Response('No DB', { status: 500 });

    const config = await getAligoConfig(env, db);
    if (!config || !config.enabled) {
        return new Response('Aligo not configured', { status: 400 });
    }

    // 1. Fetch unregistered templates
    const templates = await db.prepare(`
        SELECT * FROM message_templates WHERE alimtalk_code IS NULL
    `).all();

    // Safe access to results array
    const templateList = templates.results || (Array.isArray(templates) ? templates : []);

    if (templateList.length === 0) {
        return new Response(JSON.stringify({
            message: 'No unregistered templates found.',
            total: 0
        }), {
            headers: { 'Content-Type': 'application/json' }
        });
    }

    const results = [];
    let successCount = 0;

    for (const t of templateList) {
        // Add 100ms delay to prevent rate limiting bursts
        await new Promise(resolve => setTimeout(resolve, 100));

        try {
            // Validate name length (Max 20 chars per Aligo spec)
            let tplName = (t.name as string) || 'Untitled';
            if (tplName.length > 20) {
                tplName = tplName.substring(0, 20);
            }

            const content = convertVariablesToAligoFormat(t.content as string);

            // Buttons handling
            let tplButtons = null;
            if (t.buttons) {
                try {
                    const parsed = JSON.parse(t.buttons as string);
                    if ((parsed as any).button) {
                        tplButtons = t.buttons as string;
                    } else if (Array.isArray(parsed)) {
                        tplButtons = JSON.stringify({ button: parsed });
                    }
                } catch (e) {
                    console.warn(`Invalid buttons for ${t.id}`, e);
                }
            }

            const params = {
                tpl_name: tplName,
                tpl_content: content,
                tpl_button: tplButtons || undefined
            };

            const res = await addAlimTalkTemplate(config, params);

            // Relaxed success check
            if (res.code == 0) {
                const alimtalkCode = res.data?.templtCode ||
                    (res as any).templtCode ||
                    (res as any).info?.templtCode ||
                    null;

                if (alimtalkCode) {
                    await db.prepare(`
                        UPDATE message_templates 
                        SET alimtalk_code = ?, alimtalk_status = 'REG', updated_at = unixepoch()
                        WHERE id = ?
                    `).bind(alimtalkCode, t.id).run();
                    successCount++;
                    results.push({ name: t.name, status: 'OK', code: alimtalkCode });
                } else {
                    results.push({ name: t.name, status: 'OK_BUT_NO_CODE', res });
                }

            } else {
                results.push({ name: t.name, status: 'FAIL', message: res.message, code: res.code });
            }
        } catch (err: any) {
            console.error(`Error processing template ${t.name}:`, err);
            results.push({ name: t.name, status: 'ERROR', error: err.message });
        }
    }

    return new Response(JSON.stringify({
        total: templateList.length,
        success: successCount,
        details: results
    }, null, 2), {
        headers: { 'Content-Type': 'application/json' }
    });
};
