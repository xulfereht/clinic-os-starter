import type { APIRoute } from 'astro';

export const prerender = false;

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const { results } = await db.prepare("SELECT * FROM message_templates ORDER BY created_at DESC").run();
        return new Response(JSON.stringify(results), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Failed to fetch templates:', e);
        return new Response(JSON.stringify({ error: 'Failed to fetch templates' }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { name, content } = body;

        if (!name || !content) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
        }

        const category = body.category || 'general';
        const channel = body.channel || 'SMS';
        const alimtalk_code = body.alimtalk_code || null;
        const segment_id = body.segment_id || null;

        const { results } = await db.prepare(`
            INSERT INTO message_templates (name, content, category, channel, alimtalk_code, segment_id, is_active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)
            RETURNING *
        `).bind(
            name,
            content,
            category,
            channel,
            alimtalk_code,
            segment_id,
            Math.floor(Date.now() / 1000),
            Math.floor(Date.now() / 1000)
        ).run();

        // Assuming RETURNING * returns the inserted row, and we want the first one
        const newTemplate = results && results.length > 0 ? results[0] : null;

        return new Response(JSON.stringify({ success: true, id: newTemplate?.id, template: newTemplate }), {
            status: 201,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Failed to create template:', e);
        return new Response(JSON.stringify({ error: 'Failed to create template' }), { status: 500 });
    }
};
