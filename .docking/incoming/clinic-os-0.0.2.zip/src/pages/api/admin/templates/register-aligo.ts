
import type { APIRoute } from 'astro';
import {
    getAligoConfig,
    addAlimTalkTemplate,
    modifyAlimTalkTemplate,
    requestAlimTalkTemplate,
    convertVariablesToAligoFormat
} from '../../../../lib/aligo';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const env = locals.runtime?.env;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    const config = await getAligoConfig(env, db);
    if (!config || !config.enabled) {
        return new Response(JSON.stringify({ error: 'Aligo configuration missing or disabled' }), { status: 400 });
    }

    try {
        const body = await request.json();
        const { type, template_id, name, content, buttons, request_inspection } = body;

        let tplName = name;
        let tplContent = content;
        let tplButtons = buttons ? JSON.stringify({ button: buttons }) : undefined;
        let tplCode = '';
        let localTemplateId = template_id;

        // CASE 1: EXISTING Template (From Local DB)
        if (type === 'EXISTING' && template_id) {
            const template = await db.prepare("SELECT * FROM message_templates WHERE id = ?").bind(template_id).first();
            if (!template) {
                return new Response(JSON.stringify({ error: 'Template not found' }), { status: 404 });
            }

            tplName = template.name as string;
            // Convert {var} to #{var} for AlimTalk
            tplContent = convertVariablesToAligoFormat(template.content as string);

            // If local template already has buttons, use them if not overridden
            if (!tplButtons && template.buttons) {
                try {
                    // Check if it's already in Aligo format {button: [...]}
                    const parsed = JSON.parse(template.buttons as string) as any;
                    if (parsed.button) {
                        tplButtons = template.buttons as string;
                    } else if (Array.isArray(parsed)) {
                        tplButtons = JSON.stringify({ button: parsed });
                    }
                } catch (e) {
                    console.warn('Invalid buttons JSON in DB', e);
                }
            }

            tplCode = template.alimtalk_code || '';
        }
        // CASE 2: NEW Template (From Payload)
        else if (type === 'NEW') {
            if (!tplName || !tplContent) {
                return new Response(JSON.stringify({ error: 'Name and Content are required for new templates' }), { status: 400 });
            }
            // Ensure content has Aligo format variables
            tplContent = convertVariablesToAligoFormat(tplContent);
        } else {
            return new Response(JSON.stringify({ error: 'Invalid request type' }), { status: 400 });
        }


        // ACTION: Add or Modify
        let resultSource = null;
        let actionParams = {
            tpl_name: tplName,
            tpl_content: tplContent,
            tpl_button: tplButtons,
            tpl_code: tplCode
        };

        console.log('[AlimTalk] Register Payload:', JSON.stringify(actionParams, null, 2));

        // If we have a code, try to modify first
        if (tplCode) {
            console.log('Attempting to MODIFY template:', tplCode);
            resultSource = await modifyAlimTalkTemplate(config, actionParams);

            // If modify fails with "not editable" (e.g. approved), we might need to inform user
            // But if it fails because it doesn't exist, we might want to Add? 
            // Aligo doesn't easily tell "not found" vs "bad request".
            // For now, if modify fails, we return error.
        } else {
            console.log('Attempting to ADD template');
            resultSource = await addAlimTalkTemplate(config, actionParams);
        }

        if (resultSource.code !== 0) {
            return new Response(JSON.stringify({ error: resultSource.message, code: resultSource.code }), { status: 400 });
        }

        // Success - Get new Data
        const newData = resultSource.data || {};
        const newCode = newData.templtCode || tplCode;
        const newStatus = newData.status || 'R'; // R: Ready
        const newInspStatus = newData.inspStatus || 'REG'; // REG: Registered

        // Request Inspection if asked
        if (request_inspection && newCode) {
            console.log('Requesting Inspection for:', newCode);
            await requestAlimTalkTemplate(config, newCode);
            // We can't easily check result of request here without double call, but it usually queues it.
            // We assume it moves to REQ.
        }

        // UPDATE Local DB
        if (type === 'EXISTING' && localTemplateId) {
            await db.prepare(`
                UPDATE message_templates 
                SET alimtalk_code = ?, alimtalk_status = ? 
                WHERE id = ?
            `).bind(newCode, newInspStatus, localTemplateId).run();
        } else if (type === 'NEW') {
            // Convert back to local vars for local storage? Or store as is?
            // User might want to use this for SMS too.
            // Let's store normalized (without #) in content, and # in aligo specific fields if we had them.
            // But we only have one 'content'.
            // Compromise: Store as is (with # if user entered #, or without if converted).
            // Actually, for consistency, local DB usually has {var}. 
            // If we registered #{var}, we should probably strip # for local DB text if we want to share.
            // But for now, let's just save what we sent (converted).

            const localContent = tplContent; // Maybe strip #? convertVariablesToAligoFormat is one way.

            const res = await db.prepare(`
                INSERT INTO message_templates (name, content, buttons, alimtalk_code, alimtalk_status, type)
                VALUES (?, ?, ?, ?, ?, 'ALIMTALK')
                RETURNING id
            `).bind(tplName, localContent, tplButtons || null, newCode, newInspStatus).first();

            localTemplateId = res.id;
        }

        return new Response(JSON.stringify({
            success: true,
            id: localTemplateId,
            alimtalk_code: newCode,
            status: newInspStatus,
            message: resultSource.message
        }), { status: 200 });

    } catch (e) {
        console.error('Registration Error:', e);
        return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
    }
};
