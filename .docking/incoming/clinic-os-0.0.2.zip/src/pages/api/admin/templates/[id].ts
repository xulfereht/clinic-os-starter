import type { APIRoute } from 'astro';

export const prerender = false;

export const PATCH: APIRoute = async ({ params, request, locals }) => {
    const templateId = params.id;

    if (!templateId) {
        return new Response(JSON.stringify({ error: 'Template ID required' }), { status: 400 });
    }

    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { name, content, category } = body;

        let query = "UPDATE message_templates SET updated_at = ?";
        const params: any[] = [Math.floor(Date.now() / 1000)];

        if (name) {
            query += ", name = ?";
            params.push(name);
        }
        if (content) {
            query += ", content = ?";
            params.push(content);
        }
        if (category) {
            query += ", category = ?";
            params.push(category);
        }
        if (body.channel) {
            query += ", channel = ?";
            params.push(body.channel);
        }
        if (body.alimtalk_code !== undefined) { // Allow clearing code with empty string or null
            query += ", alimtalk_code = ?";
            params.push(body.alimtalk_code);
        }
        if (body.segment_id !== undefined) {
            query += ", segment_id = ?";
            params.push(body.segment_id);
        }

        query += " WHERE id = ?";
        params.push(templateId);

        if (params.length === 1) { // Only updated_at and templateId, no other fields to update
            return new Response(JSON.stringify({ error: 'No fields provided for update' }), { status: 400 });
        }

        // Update template
        await db.prepare(query).bind(...params).run();

        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Template update error:', e);
        return new Response(JSON.stringify({ error: 'Failed to update template' }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    const templateId = params.id;
    if (!templateId) return new Response(JSON.stringify({ error: 'ID required' }), { status: 400 });

    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'DB error' }), { status: 500 });

    try {
        await db.prepare("DELETE FROM message_templates WHERE id = ?").bind(templateId).run();
        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Delete error:', e);
        return new Response(JSON.stringify({ error: 'Failed to delete' }), { status: 500 });
    }
};
