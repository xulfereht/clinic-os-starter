import type { APIRoute } from 'astro';
import { getAligoConfig, getAligoTemplates } from '../../../../lib/aligo';

export const GET: APIRoute = async ({ locals, request }) => {
    try {
        const db = locals.runtime.env.DB;
        const env = locals.runtime.env;

        // 1. Get Config
        const config = await getAligoConfig(env, db);
        if (!config || !config.enabled) {
            return new Response(JSON.stringify({ error: '알리고 설정이 누락되었거나 비활성화되었습니다.' }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        console.log('[sync-aligo] Fetching templates from Aligo via:', config.baseUrl);

        // 2. Fetch Templates from Aligo
        const response = await getAligoTemplates(config);

        console.log('[sync-aligo] Aligo response code:', response.code, 'message:', response.message);

        // Aligo returns code 0 for success
        if (response.code !== 0) {
            const msg = response.message || (response as any).message || 'Unknown Error';
            return new Response(JSON.stringify({ error: `알리고 API 오류: ${msg}` }), {
                status: 500,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        const templates = response.list;
        let syncedCount = 0;

        const url = new URL(request.url);
        const dryRun = url.searchParams.get('dryRun') === 'true';
        const diffs = [];

        // 3. Sync Logic (Upsert & Delete)
        const aligoCodes = new Set<string>();

        for (const t of templates) {
            aligoCodes.add(t.templtCode);

            // Find existing template ONLY by alimtalk_code (Strict Separation)
            const existing = await db.prepare(`
                SELECT id, content, buttons FROM message_templates WHERE alimtalk_code = ?
            `).bind(t.templtCode).first<{ id: string, content: string, buttons: string }>();

            // Debug: Log original newline format from Aligo
            console.log(`[sync-aligo] Template ${t.templtCode} newline check:`, {
                has_crlf: t.templtContent.includes('\r\n'),
                has_lf_only: t.templtContent.includes('\n') && !t.templtContent.includes('\r\n'),
                raw_sample: JSON.stringify(t.templtContent.substring(0, 100))
            });

            // CRITICAL: Preserve EXACT Aligo format including \r\n newlines
            // Variable Normalization: #{변수} -> {변수} (for easier usage in app)
            // BUT preserve original newlines (\r\n) from Aligo to ensure exact match during send
            const normalizedContent = t.templtContent.replace(/#\{([^}]+)\}/g, '{$1}');

            // Serialize buttons array to JSON string for storage
            // Aligo API returns 'buttons' array
            const rawButtons = (t as any).buttons;
            const buttonsJson = rawButtons && rawButtons.length > 0 ? JSON.stringify(rawButtons) : null;

            // Map Aligo status to internal alimtalk_status
            const alimtalkStatus = t.inspStatus || 'REG';
            let approvalStatus = 'I';
            if (alimtalkStatus === 'APR') approvalStatus = 'A';
            else if (alimtalkStatus === 'REJ') approvalStatus = 'R';

            if (dryRun) {
                if (existing) {
                    // Compare content and buttons (ignoring null/undefined differences for buttons if empty)
                    const existingButtons = existing.buttons || null;
                    const newButtons = buttonsJson || null;

                    if (existing.content !== normalizedContent || existingButtons !== newButtons) {
                        diffs.push({
                            code: t.templtCode,
                            name: t.templtName,
                            reason: 'Mismatch',
                            db: {
                                content: existing.content,
                                buttons: existingButtons
                            },
                            aligo: {
                                content: normalizedContent,
                                buttons: newButtons,
                                raw: t.templtContent // Show raw from Aligo to check # vs nothing
                            }
                        });
                    }
                } else {
                    diffs.push({
                        code: t.templtCode,
                        name: t.templtName,
                        reason: 'New (Not in DB)',
                        aligo: { content: normalizedContent }
                    });
                }
                continue; // Skip DB update in dryRun
            }

            if (existing) {
                // Update existing: Preserve channel if it was SMS
                await db.prepare(`
                    UPDATE message_templates 
                    SET content = ?, 
                        alimtalk_code = ?,
                        buttons = ?,
                        name = ?, 
                        alimtalk_status = ?,
                        approval_status = ?,
                        updated_at = unixepoch()
                    WHERE id = ?
                `).bind(normalizedContent, t.templtCode, buttonsJson, t.templtName, alimtalkStatus, approvalStatus, existing.id).run();
            } else {
                // New template found in Aligo side: Insert as ALIMTALK channel
                await db.prepare(`
                    INSERT INTO message_templates (name, content, category, channel, alimtalk_code, buttons, alimtalk_status, approval_status, is_active, created_at, updated_at)
                    VALUES (?, ?, 'alimtalk', 'ALIMTALK', ?, ?, ?, ?, 1, unixepoch(), unixepoch())
                `).bind(t.templtName, normalizedContent, t.templtCode, buttonsJson, alimtalkStatus, approvalStatus).run();
            }
            syncedCount++;
        }

        // 4. Handle Deletions (Templates in DB but not in Aligo)
        // Fetch all ALIMTALK templates from DB
        const { results: allDbTemplates } = await db.prepare("SELECT id, alimtalk_code, name FROM message_templates WHERE channel = 'ALIMTALK'").run();
        const orphans = (allDbTemplates || []).filter((dbT: any) => dbT.alimtalk_code && !aligoCodes.has(dbT.alimtalk_code));

        let deletedCount = 0;
        if (orphans.length > 0) {
            if (dryRun) {
                orphans.forEach((o: any) => {
                    diffs.push({
                        code: o.alimtalk_code,
                        name: o.name,
                        reason: 'Orphan (In DB, Not in Aligo)',
                        action: 'Would Delete'
                    });
                });
            } else {
                // Delete orphans
                for (const o of orphans) {
                    try {
                        await db.prepare("DELETE FROM message_templates WHERE id = ?").bind(o.id).run();
                        deletedCount++;
                        console.log(`[sync-aligo] Deleted orphan template: ${o.name} (${o.alimtalk_code})`);
                    } catch (e) {
                        console.error(`[sync-aligo] Failed to delete orphan ${o.name}:`, e);
                        // Optional: Soft delete fallback if FK constraint fails?
                        // await db.prepare("UPDATE message_templates SET is_active = 0 WHERE id = ?").bind(o.id).run();
                    }
                }
            }
        }

        if (dryRun) {
            return new Response(JSON.stringify({
                dryRun: true,
                diffs: diffs,
                totalAligo: templates.length,
                mismatchCount: diffs.filter(d => d.reason === 'Mismatch').length,
                newCount: diffs.filter(d => d.reason.startsWith('New')).length,
                orphanCount: orphans.length
            }), {
                headers: { 'Content-Type': 'application/json' }
            });
        }

        return new Response(JSON.stringify({
            success: true,
            count: syncedCount,
            deleted: deletedCount,
            message: `${syncedCount}개의 템플릿이 동기화(저장/수정)되었으며, ${deletedCount}개의 미존재 템플릿이 삭제되었습니다.`
        }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('[sync-aligo] Error:', error);
        return new Response(JSON.stringify({
            error: '동기화 중 오류가 발생했습니다.',
            details: error instanceof Error ? error.message : String(error)
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};
