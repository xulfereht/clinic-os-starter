import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        const posts = await db.prepare(`
            SELECT title, category 
            FROM posts 
            WHERE title LIKE '%속쓰림%' OR title LIKE '%다이어트 정체기%'
        `).all();
        return new Response(JSON.stringify(posts.results, null, 2));
    } catch (e: any) {
        return new Response(`Check failed: ${e.message}`, { status: 200 });
    }
};
