import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        const types = await db.prepare("SELECT DISTINCT type FROM posts").all();
        const posts = await db.prepare("SELECT id, title, type FROM posts LIMIT 20").all();

        return new Response(JSON.stringify({
            types: types.results,
            sample_posts: posts.results
        }, null, 2));
    } catch (e: any) {
        return new Response(`Check failed: ${e.message}`, { status: 200 });
    }
};
