import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response("DB not found");

    try {
        const programs = await db.prepare("SELECT id, title FROM programs").all();
        return new Response(JSON.stringify(programs.results, null, 2));
    } catch (e: any) {
        return new Response(`Error: ${e.message}`);
    }
};
