import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    const db = locals.runtime.env.DB;

    try {
        // Add lunch_start column
        await db.prepare(`
            ALTER TABLE clinic_weekly_schedules ADD COLUMN lunch_start TEXT DEFAULT '12:00'
        `).run();
    } catch (e) {
        // Column might already exist
    }

    try {
        // Add lunch_end column
        await db.prepare(`
            ALTER TABLE clinic_weekly_schedules ADD COLUMN lunch_end TEXT DEFAULT '13:00'
        `).run();
    } catch (e) {
        // Column might already exist
    }

    return new Response(JSON.stringify({
        success: true,
        message: 'Lunch time columns added to clinic_weekly_schedules table'
    }));
};
