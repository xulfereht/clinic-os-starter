import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response("DB not found");

    try {
        const schema = await db.prepare("PRAGMA table_info(clinic_settings)").all();
        // If clinic_settings doesn't exist, try settings
        if (!schema.results || schema.results.length === 0) {
            const schema2 = await db.prepare("PRAGMA table_info(settings)").all();
            return new Response(JSON.stringify({ table: 'settings', schema: schema2.results }, null, 2));
        }
        return new Response(JSON.stringify({ table: 'clinic_settings', schema: schema.results }, null, 2));
    } catch (e: any) {
        return new Response(`Error: ${e.message}`);
    }
};
