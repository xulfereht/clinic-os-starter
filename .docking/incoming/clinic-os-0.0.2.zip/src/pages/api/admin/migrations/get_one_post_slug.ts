import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        const post = await db.prepare("SELECT slug FROM posts LIMIT 1").first();
        return new Response(post ? post.slug : "No posts found");
    } catch (e: any) {
        return new Response(`Error: ${e.message}`, { status: 200 });
    }
};
