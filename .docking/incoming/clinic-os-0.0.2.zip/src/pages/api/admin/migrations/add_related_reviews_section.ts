import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        const programs = await db.prepare("SELECT id, sections FROM programs").all();
        let updatedCount = 0;

        for (const program of programs.results) {
            let sections = [];
            try {
                sections = JSON.parse(program.sections as string);
            } catch (e) {
                console.error(`Failed to parse sections for program ${program.id}`);
                continue;
            }

            const hasReviews = sections.some((s: any) => s.type === 'RelatedReviews' || s.type === 'related-reviews');

            if (!hasReviews) {
                // Add RelatedReviews section before FAQ or at the end
                const newSection = {
                    type: 'RelatedReviews',
                    data: {
                        title: '치료 후기',
                        subtitle: '실제 치료 사례를 확인해보세요'
                    }
                };

                // Insert before FAQ if exists, otherwise append
                const faqIndex = sections.findIndex((s: any) => s.type === 'FAQ' || s.type === 'faq');
                if (faqIndex !== -1) {
                    sections.splice(faqIndex, 0, newSection);
                } else {
                    sections.push(newSection);
                }

                await db.prepare("UPDATE programs SET sections = ? WHERE id = ?")
                    .bind(JSON.stringify(sections), program.id)
                    .run();
                updatedCount++;
            }
        }

        return new Response(`Migration successful: Updated ${updatedCount} programs with RelatedReviews section.`);
    } catch (e: any) {
        return new Response(`Migration failed: ${e.message}`, { status: 500 });
    }
};
