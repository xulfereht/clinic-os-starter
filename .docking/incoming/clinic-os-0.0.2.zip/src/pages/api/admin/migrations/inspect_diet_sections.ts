import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response("DB not found");

    try {
        const program = await db.prepare("SELECT id, sections FROM programs WHERE id = 'diet'").first();
        return new Response(JSON.stringify(program, null, 2));
    } catch (e: any) {
        return new Response(`Error: ${e.message}`);
    }
};
