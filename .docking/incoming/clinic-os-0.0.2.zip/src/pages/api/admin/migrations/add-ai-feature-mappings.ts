export const prerender = false;

export async function GET({ locals }: { locals: any }) {
    try {
        const db = locals.runtime.env.DB;

        // Check if table exists
        const result = await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='ai_feature_mappings'").first();

        if (result) {
            return new Response("Table 'ai_feature_mappings' already exists", { status: 200 });
        }

        // Create table
        await db.prepare(`
            CREATE TABLE ai_feature_mappings (
                feature_key TEXT PRIMARY KEY,
                provider TEXT NOT NULL,
                model TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `).run();

        // Seed default mappings (optional, but good for UX)
        // We set defaults only if they are not there, but since table is new, we can just insert.
        // Actually, let's leave it empty so UI shows "Select Provider" or implementation uses fallback.
        // But implementation plan said "fallback to default". So empty is fine.

        return new Response("Migration successful: ai_feature_mappings created", { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
