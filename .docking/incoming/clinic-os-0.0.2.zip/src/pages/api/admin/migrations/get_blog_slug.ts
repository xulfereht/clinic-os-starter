import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response("DB not found");

    try {
        const post = await db.prepare("SELECT slug FROM posts WHERE type IN ('blog', 'column') LIMIT 1").first();
        return new Response(JSON.stringify(post), { status: 200 });
    } catch (e: any) {
        return new Response(`Error: ${e.message}`);
    }
};
