export const prerender = false;

export async function GET({ locals }: { locals: any }) {
    try {
        const db = locals.runtime.env.DB;

        // Check if column exists
        try {
            await db.prepare("SELECT lifecycle_stage FROM patients LIMIT 1").run();
            return new Response("Column already exists", { status: 200 });
        } catch (e) {
            // Column doesn't exist, proceed
        }

        // Add column
        await db.prepare("ALTER TABLE patients ADD COLUMN lifecycle_stage TEXT DEFAULT 'potential'").run();

        // Update existing records to 'new_visit' (assuming existing are actual patients)
        await db.prepare("UPDATE patients SET lifecycle_stage = 'new_visit'").run();

        return new Response("Migration successful", { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
