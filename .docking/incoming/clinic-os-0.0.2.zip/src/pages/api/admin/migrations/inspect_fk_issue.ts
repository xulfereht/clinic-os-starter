import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        // Get table info for posts
        const tableInfo = await db.prepare("PRAGMA foreign_key_list(posts)").all();

        // Get the problematic post (one without category)
        const post = await db.prepare("SELECT * FROM posts WHERE category IS NULL LIMIT 1").first();

        return new Response(JSON.stringify({
            foreign_keys: tableInfo.results,
            problem_post: post
        }, null, 2));
    } catch (e: any) {
        return new Response(`Inspection failed: ${e.message}`, { status: 200 });
    }
};
