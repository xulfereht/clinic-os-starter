import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response("DB not found");

    const logs = [];
    try {
        logs.push("Starting enhanced seed v2...");

        const programs = [
            { id: 'diet', name: '다이어트' },
            { id: 'skin', name: '피부질환' },
            { id: 'digestive', name: '소화기' },
            { id: 'pain', name: '통증' },
            { id: 'women', name: '여성질환' },
            { id: 'pediatric', name: '소아청소년' },
            { id: 'neuro', name: '신경정신' },
            { id: 'wellness', name: '보약/웰니스' },
            { id: 'head', name: '두면부' }
        ];

        const reviewTemplates = [
            { title: "{program} 치료 3개월 후기입니다", content: "{program} 치료를 받고 정말 좋아졌습니다. 처음에는 반신반의했지만 꾸준히 치료받으니 효과가 나타나네요. 원장님 감사합니다." },
            { title: "만성적인 문제였는데 {program} 치료로 해결했어요", content: "오랫동안 고생했던 문제였는데 백록담한의원 {program} 프로그램 덕분에 많이 호전되었습니다. 강력 추천합니다." },
            { title: "{program} 프로그램 강력 추천합니다", content: "지인 소개로 방문했는데 {program} 상담부터 치료까지 너무 친절하고 꼼꼼하게 봐주셔서 감동했습니다." }
        ];

        // Ensure patient exists
        try {
            await db.prepare("INSERT OR IGNORE INTO patients (id, name, current_phone) VALUES (?, ?, ?)").bind('patient_seed_1', '홍길동', '010-1234-5678').run();
            logs.push("Patient ensured");
        } catch (e: any) {
            logs.push(`Patient creation failed: ${e.message}`);
        }

        let insertedCount = 0;
        const doctorId = 'doc_choi';
        const patientId = 'patient_seed_1';

        for (const program of programs) {
            for (let i = 0; i < 3; i++) {
                const template = reviewTemplates[i];
                const title = template.title.replace("{program}", program.name);
                const content = template.content.replace("{program}", program.name);
                const slug = `${program.id}-review-${i + 1}-${Date.now()}`;

                try {
                    // Full insert
                    await db.prepare(`
                        INSERT INTO posts (type, title, slug, excerpt, content, category, doctor_id, patient_id, status)
                        VALUES ('review', ?, ?, ?, ?, ?, ?, ?, 'published')
                    `).bind(
                        title,
                        slug,
                        content.substring(0, 50) + '...',
                        content,
                        program.id,
                        doctorId,
                        patientId
                    ).run();
                    insertedCount++;
                } catch (e: any) {
                    logs.push(`Failed to insert review for ${program.name}: ${e.message}`);
                    // Try minimal insert fallback
                    try {
                        await db.prepare(`
                            INSERT INTO posts (type, title, category, status)
                            VALUES ('review', ?, ?, 'published')
                        `).bind(title, program.id).run();
                        logs.push(`Fallback insert success for ${program.name}`);
                        insertedCount++;
                    } catch (e2: any) {
                        logs.push(`Fallback failed: ${e2.message}`);
                    }
                }
            }
        }

        return new Response(`Seeding complete. Inserted: ${insertedCount}\nLogs:\n${logs.join('\n')}`);
    } catch (e: any) {
        return new Response(`Fatal error: ${e.message}\nLogs:\n${logs.join('\n')}`);
    }
};
