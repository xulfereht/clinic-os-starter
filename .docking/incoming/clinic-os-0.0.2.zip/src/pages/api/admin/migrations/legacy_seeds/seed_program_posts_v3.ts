import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        const postId = generateId();
        const title = `Test Post ${Date.now()}`;
        const slug = `test-post-${Date.now()}`;
        const content = `Test content`;
        const doctorId = '1';
        const createdAt = Math.floor(Date.now() / 1000);

        // Try inserting WITHOUT category first
        await db.prepare(`
            INSERT INTO posts (id, type, title, slug, excerpt, content, doctor_id, created_at)
            VALUES (?, 'column', ?, ?, ?, ?, ?, ?)
        `).bind(postId, title, slug, 'excerpt', content, doctorId, createdAt).run();

        return new Response(`Seeding successful: Created test post.`);
    } catch (e: any) {
        return new Response(`Seeding failed: ${e.message}\n${e.stack}`, { status: 200 });
    }
};

function generateId() {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}
