import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        const program = await db.prepare("SELECT sections FROM programs WHERE id = 'diet'").first();
        if (!program) return new Response("Program not found");

        return new Response(program.sections as string);
    } catch (e: any) {
        return new Response(`Inspection failed: ${e.message}`, { status: 200 });
    }
};
