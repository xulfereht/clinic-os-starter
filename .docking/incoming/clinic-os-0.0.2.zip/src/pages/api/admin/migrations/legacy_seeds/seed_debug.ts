import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        // List IDs
        const staff = await db.prepare("SELECT id FROM staff").all();
        const patients = await db.prepare("SELECT id FROM patients").all();

        const staffIds = staff.results.map((s: any) => s.id);
        const patientIds = patients.results.map((p: any) => p.id);

        const validDoctorId = staffIds.includes('doc_choi') ? 'doc_choi' : staffIds[0];
        const validPatientId = patientIds.length > 0 ? patientIds[0] : null;

        // Create patient if needed
        if (!validPatientId) {
            await db.prepare("INSERT INTO patients (id, name, current_phone, created_at) VALUES (?, ?, ?, ?)").bind("patient_seed_1", "홍길동", "010-1234-5678", Math.floor(Date.now() / 1000)).run();
        }
        const finalPatientId = validPatientId || "patient_seed_1";

        // Test Insert
        await db.prepare(`
            INSERT INTO posts (title, type, doctor_id, patient_id, author_id, category, created_at, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            "Final Test Review",
            "review",
            validDoctorId,
            finalPatientId,
            validDoctorId,
            "diet",
            Math.floor(Date.now() / 1000),
            "published"
        ).run();

        return new Response(JSON.stringify({
            success: true,
            used_doctor_id: validDoctorId,
            used_patient_id: finalPatientId,
            available_staff: staffIds,
            available_patients: patientIds
        }, null, 2));
    } catch (e: any) {
        return new Response(JSON.stringify({
            success: false,
            error: e.message,
            available_staff: await db.prepare("SELECT id FROM staff").all().then((r: any) => r.results),
            available_patients: await db.prepare("SELECT id FROM patients").all().then((r: any) => r.results)
        }, null, 2));
    }
};
