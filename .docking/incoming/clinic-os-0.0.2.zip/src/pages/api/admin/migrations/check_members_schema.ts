import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response("DB not found");

    try {
        const info = await db.prepare("PRAGMA table_info(web_members)").all();
        return new Response(JSON.stringify(info.results, null, 2));
    } catch (e: any) {
        return new Response(`Error: ${e.message}`);
    }
};
