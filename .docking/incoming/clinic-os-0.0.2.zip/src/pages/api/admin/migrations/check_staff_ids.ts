import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        const staff = await db.prepare("SELECT id, name FROM staff").all();
        return new Response(JSON.stringify(staff.results, null, 2));
    } catch (e: any) {
        return new Response(`Check failed: ${e.message}`, { status: 200 });
    }
};
