import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        const { results } = await db.prepare("SELECT id, sections FROM programs").all();
        let updatedCount = 0;

        for (const program of results) {
            let sections = [];
            try {
                sections = JSON.parse(program.sections as string);
            } catch (e) {
                continue;
            }

            // Check if RelatedPosts already exists
            const hasRelated = sections.some((s: any) => s.type === 'RelatedPosts' || s.type === 'related-posts');

            if (!hasRelated) {
                // Add RelatedPosts section before DoctorIntro or at the end
                const doctorIndex = sections.findIndex((s: any) => s.type === 'DoctorIntro' || s.type === 'doctor-intro');

                const newSection = {
                    type: 'RelatedPosts',
                    title: '관련 건강 정보',
                    subtitle: '전문가가 알려드리는 건강 지식'
                };

                if (doctorIndex !== -1) {
                    sections.splice(doctorIndex, 0, newSection);
                } else {
                    sections.push(newSection);
                }

                await db.prepare("UPDATE programs SET sections = ? WHERE id = ?")
                    .bind(JSON.stringify(sections), program.id)
                    .run();

                updatedCount++;
            }
        }

        return new Response(`Migration successful: Updated ${updatedCount} programs with RelatedPosts section.`);
    } catch (e: any) {
        return new Response(`Migration failed: ${e.message}\n${e.stack}`, { status: 200 });
    }
};
