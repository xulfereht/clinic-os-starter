import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        // Find duplicates based on title and type='notice'
        // Keep the one with the smallest ID (assuming it's the original)
        const duplicates = await db.prepare(`
            SELECT id, title 
            FROM posts 
            WHERE type = 'notice' 
            AND id NOT IN (
                SELECT MIN(id) 
                FROM posts 
                WHERE type = 'notice' 
                GROUP BY title
            )
        `).all();

        const duplicateIds = duplicates.results.map((p: any) => p.id);

        if (duplicateIds.length > 0) {
            // Delete duplicates
            const placeholders = duplicateIds.map(() => '?').join(',');
            await db.prepare(`DELETE FROM posts WHERE id IN (${placeholders})`)
                .bind(...duplicateIds)
                .run();
        }

        return new Response(`Removed ${duplicateIds.length} duplicate notices.\nIDs: ${duplicateIds.join(', ')}`);
    } catch (e: any) {
        return new Response(`Cleanup failed: ${e.message}`, { status: 200 });
    }
};
