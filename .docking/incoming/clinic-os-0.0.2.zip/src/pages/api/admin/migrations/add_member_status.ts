import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response("DB not found");

    try {
        // Check if column exists
        const info = await db.prepare("PRAGMA table_info(web_members)").all();
        const hasStatus = info.results.some((c: any) => c.name === 'status');

        if (!hasStatus) {
            await db.prepare("ALTER TABLE web_members ADD COLUMN status TEXT DEFAULT 'pending'").run();
            // Update existing members to approved (optional, but good for existing users)
            await db.prepare("UPDATE web_members SET status = 'approved' WHERE status = 'pending'").run();
            return new Response("Added status column and approved existing members.");
        }

        return new Response("Status column already exists.");
    } catch (e: any) {
        return new Response(`Error: ${e.message}`);
    }
};
