import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        const post = await db.prepare("SELECT * FROM posts LIMIT 1").first();
        return new Response(JSON.stringify(post, null, 2));
    } catch (e: any) {
        return new Response(`Inspection failed: ${e.message}\n${e.stack}`, { status: 200 });
    }
};
