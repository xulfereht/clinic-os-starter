import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response("DB not found");

    try {
        const programs = await db.prepare("SELECT id, sections FROM programs").all();
        let updatedCount = 0;

        for (const program of programs.results) {
            let sections = JSON.parse(program.sections as string);
            let modified = false;

            sections = sections.map((section: any) => {
                if (section.type === 'RelatedReviews') {
                    if (!section.data) section.data = {};
                    // Force overwrite
                    section.data.title = "진료 노트";
                    section.data.subtitle = "비슷한 증상의 치료 기록을 확인해보세요";

                    // Explicitly delete root properties if they exist
                    if ('title' in section) delete section.title;
                    if ('subtitle' in section) delete section.subtitle;

                    modified = true;
                }
                return section;
            });

            if (modified) {
                await db.prepare("UPDATE programs SET sections = ? WHERE id = ?")
                    .bind(JSON.stringify(sections), program.id)
                    .run();
                updatedCount++;
            }
        }

        return new Response(`Updated ${updatedCount} programs with new section title.`);
    } catch (e: any) {
        return new Response(`Error: ${e.message}`);
    }
};
