import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    const programs = [
        { id: 'diet', title: '다이어트', topic: '건강한 체중 감량의 핵심' },
        { id: 'skin', title: '피부질환', topic: '만성 피부질환의 원인과 치료' },
        { id: 'digestive', title: '소화기', topic: '속이 편해야 몸이 편하다' },
        { id: 'pain', title: '통증', topic: '지긋지긋한 통증에서 벗어나기' },
        { id: 'women', title: '여성질환', topic: '여성을 위한 한방 치료' },
        { id: 'pediatric', title: '소아청소년', topic: '우리 아이 성장과 면역력' },
        { id: 'neuro', title: '신경정신', topic: '마음의 병, 몸으로 다스리다' },
        { id: 'wellness', title: '보약/웰니스', topic: '내 몸에 맞는 보약 찾기' },
        { id: 'head', title: '두면부', topic: '두통과 어지럼증의 한의학적 접근' }
    ];

    try {
        // Get a doctor ID to assign posts to
        const doctor = await db.prepare("SELECT id FROM staff WHERE type = 'doctor' LIMIT 1").first();
        // Use the doctor ID directly, or fallback to 'doc_choi' if known, or just '1' if we must guess.
        // Based on inspection, doctor_id is string 'doc_choi'.
        const doctorId = doctor ? doctor.id : 'doc_choi';

        let createdCount = 0;

        for (const prog of programs) {
            // Check if post exists for this category
            const existing = await db.prepare("SELECT id FROM posts WHERE category = ? LIMIT 1").bind(prog.id).first();

            if (!existing) {
                const title = `[${prog.title}] ${prog.topic}`;
                const slug = `${prog.id}-sample-post-${Date.now()}`;
                const content = `# ${prog.title} 칼럼\n\n${prog.topic}에 대한 전문적인 칼럼 내용입니다.\n\n## 주요 내용\n1. 원인 분석\n2. 치료 방법\n3. 생활 관리\n\n백록담한의원에서 체계적인 관리를 받아보세요.`;
                const excerpt = `${prog.title} 프로그램과 관련된 ${prog.topic}에 대한 칼럼입니다.`;

                const createdAt = Math.floor(Date.now() / 1000);

                // Omit 'id' to let DB autoincrement
                await db.prepare(`
                    INSERT INTO posts (type, title, slug, excerpt, content, doctor_id, category, created_at)
                    VALUES ('column', ?, ?, ?, ?, ?, ?, ?)
                `).bind(title, slug, excerpt, content, doctorId, prog.id, createdAt).run();

                createdCount++;
            }
        }

        return new Response(`Seeding successful: Created ${createdCount} sample posts.`);
    } catch (e: any) {
        return new Response(`Seeding failed: ${e.message}\n${e.stack}`, { status: 200 });
    }
};
