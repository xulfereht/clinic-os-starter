import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response("DB not found");

    const logs = [];
    try {
        logs.push("Starting realistic review seeding (v3)...");

        // 1. Clear existing reviews to avoid clutter
        await db.prepare("DELETE FROM posts WHERE type = 'review'").run();
        logs.push("Cleared existing reviews");

        // 2. Define realistic templates per category
        const reviewData = {
            diet: [
                { title: "[30대 여성] 출산 후 10kg 감량 성공 - 산후비만 졸업했어요", content: "출산 후 6개월이 지나도 빠지지 않던 살 때문에 우울했는데, 백록감비정 복용 3개월 만에 임신 전 몸무게로 돌아갔습니다. 식욕 조절이 정말 잘 되고, 무엇보다 기운이 빠지지 않아서 육아와 병행하기 좋았어요." },
                { title: "[40대 남성] 고도비만, 3개월 15kg 감량 - 지방간 수치 정상화", content: "건강검진에서 지방간 경고를 받고 다이어트를 결심했습니다. 단순히 굶는 게 아니라 대사를 높여주는 치료 덕분에 요요 없이 감량에 성공했고, 피로감도 많이 줄었습니다." },
                { title: "[20대 여성] 하체비만 탈출 - 허벅지 사이즈 2인치 감소", content: "상체는 말랐는데 하체만 튼실해서 고민이었어요. 순환을 돕는 약침 치료와 한약을 병행하니 부종이 빠지면서 다리 라인이 달라졌습니다." }
            ],
            skin: [
                { title: "[20대 남성] 재발성 여드름 - 6개월 치료 후 깨끗해진 피부", content: "피부과 약을 먹을 때만 좋고 끊으면 다시 올라오는 여드름 때문에 스트레스가 심했습니다. 체질 개선 한약을 먹으면서 속 열을 내리니 여드름이 더 이상 올라오지 않아요." },
                { title: "[30대 여성] 만성 아토피 - 가려움증에서 해방되었습니다", content: "밤마다 긁느라 잠을 못 잤는데, 면역력을 높이는 치료를 받고 나서 피부가 정말 튼튼해졌습니다. 스테로이드 없이도 이렇게 좋아질 수 있다는 게 놀라워요." },
                { title: "[40대 여성] 안면홍조 - 갱년기 증상과 함께 잡았어요", content: "얼굴이 수시로 붉어지고 화끈거려서 대인기피증까지 생길 뻔했습니다. 상열하한을 조절하는 한약 덕분에 홍조는 물론 손발 차가운 것도 좋아졌습니다." }
            ],
            digestive: [
                { title: "[30대 남성] 역류성 식도염 - 목 이물감과 속쓰림 해결", content: "커피와 야근으로 달고 살던 식도염, 양약으로도 해결이 안 됐는데 담적 치료를 받고 속이 정말 편해졌습니다. 목에 걸린 듯한 느낌이 사라지니 살 것 같아요." },
                { title: "[50대 여성] 만성 소화불량 - 20년 묵은 체증이 내려갔습니다", content: "조금만 먹어도 더부룩하고 가스가 차서 고생했습니다. 위장 운동을 돕는 침 치료와 한약으로 이제는 밀가루 음식을 먹어도 소화가 잘 됩니다." },
                { title: "[20대 여성] 과민성 대장 증후군 - 긴장하면 배아픈 증상 호전", content: "시험이나 발표 전에는 화장실을 들락날락했는데, 장을 따뜻하게 하는 치료 덕분에 배가 편안해졌습니다. 일상생활의 질이 달라졌어요." }
            ],
            pain: [
                { title: "[50대 남성] 허리 디스크 - 수술 없이 통증 잡았습니다", content: "디스크 터져서 수술 권유받았는데, 봉침과 추나 치료로 통증이 잡혔습니다. 지금은 가벼운 등산도 가능할 정도로 회복되었습니다." },
                { title: "[30대 직장인] 거북목/일자목 - 만성 두통과 어깨 결림 해결", content: "하루 종일 컴퓨터를 보다 보니 목과 어깨가 돌처럼 굳어있었습니다. 추나 교정으로 목 커브를 되찾으니 두통도 사라지고 눈도 맑아졌어요." },
                { title: "[60대 여성] 무릎 관절염 - 계단 오르내리기가 편해졌어요", content: "무릎이 시리고 아파서 걷기 힘들었는데, 약침 치료 꾸준히 받고 나서 통증이 많이 줄었습니다. 친구들과 여행도 다녀왔네요." }
            ],
            women: [
                { title: "[20대 여성] 심한 생리통 - 진통제 없이 그날을 보냅니다", content: "생리 때마다 응급실 갈 정도로 통증이 심했는데, 자궁을 따뜻하게 하는 한약을 먹고 나서 거짓말처럼 통증이 사라졌습니다." },
                { title: "[30대 여성] 다낭성 난소 증후군 - 생리 주기 정상화 성공", content: "생리를 몇 달씩 건너뛰어서 걱정이 많았습니다. 호르몬제 없이 한방 치료로 자연스럽게 생리가 돌아왔고, 배란도 규칙적으로 되고 있습니다." },
                { title: "[50대 여성] 갱년기 증후군 - 불면증과 안면홍조 극복", content: "갱년기가 오면서 잠도 못 자고 땀이 비 오듯 쏟아졌는데, 부족한 진액을 보충해주는 보약 덕분에 다시 활력을 찾았습니다." }
            ],
            pediatric: [
                { title: "[7세 남아] 잦은 감기/비염 - 면역력 보강 후 감기 졸업", content: "환절기만 되면 감기를 달고 살았는데, 녹용 보약을 먹이고 나서 올겨울은 감기 한 번 안 걸리고 지나갔습니다. 밥도 잘 먹어서 키도 컸어요." },
                { title: "[10세 여아] 성조숙증 - 호르몬 주사 없이 성장 관리 중", content: "가슴 몽우리가 너무 빨리 잡혀서 걱정했는데, 천연 한약재로 성장 속도를 조절하면서 키 성장은 돕는 치료를 받고 있습니다." },
                { title: "[5세 남아] 야제증 - 밤마다 깨서 울던 아이가 통잠 자요", content: "밤에 몇 번씩 깨서 우는 아이 때문에 온 가족이 힘들었는데, 심장 열을 내려주는 증류 한약 먹고 나서부터 푹 잡니다." }
            ],
            neuro: [
                { title: "[30대 직장인] 불면증 - 수면제 없이 7시간 숙면", content: "스트레스로 잠들기 힘들고 자다 깨다를 반복했는데, 심신을 안정시키는 한약 덕분에 눕자마자 잠들고 아침에 개운하게 일어납니다." },
                { title: "[20대 학생] 공황장애 - 가슴 두근거림과 불안감 호전", content: "지하철 타기가 무서울 정도로 불안했는데, 자율신경을 조절하는 치료를 받으면서 마음이 많이 편안해졌습니다. 이제 대중교통도 잘 이용해요." },
                { title: "[40대 여성] 화병 - 가슴 답답함과 홧병이 풀렸어요", content: "가슴이 답답하고 억울한 마음이 들어 힘들었는데, 맺힌 기운을 풀어주는 침 치료와 상담으로 마음의 평화를 찾았습니다." }
            ],
            wellness: [
                { title: "[40대 남성] 만성 피로 - 공진단 복용 후 아침이 달라졌어요", content: "자고 일어나도 피곤하고 무기력했는데, 원장님이 처방해주신 공진단 먹고 나서 체력이 정말 좋아졌습니다. 야근해도 거뜬하네요." },
                { title: "[70대 남성] 기력 저하 - 경옥고로 활력 되찾으셨습니다", content: "아버님이 입맛도 없으시고 기운 없어 하셨는데, 경옥고 꾸준히 드시더니 식사도 잘 하시고 산책도 다니십니다. 효도 선물로 최고예요." },
                { title: "[30대 여성] 수험생 보약 - 집중력 향상과 체력 관리", content: "중요한 시험을 앞두고 체력이 떨어져서 힘들었는데, 총명탕 처방받고 머리가 맑아지고 집중이 잘 돼서 좋은 결과 얻었습니다." }
            ],
            head: [
                { title: "[30대 남성] 만성 두통/편두통 - 진통제 끊었습니다", content: "두통약을 달고 살았는데, 목과 어깨 근육을 풀어주고 머리로 가는 혈류를 개선하는 치료 덕분에 두통이 싹 사라졌습니다." },
                { title: "[50대 여성] 이명/어지럼증 - 귀에서 나는 소리가 줄었어요", content: "삐- 하는 소리 때문에 잠도 못 잤는데, 신장 기운을 보강하는 치료를 받고 나서 소리가 훨씬 작아지고 어지럼증도 좋아졌습니다." },
                { title: "[20대 여성] 안구건조증 - 인공눈물 없이도 눈이 편안해요", content: "눈이 뻑뻑하고 충혈이 심했는데, 간 열을 내리는 한약과 눈 주위 침 치료로 눈이 정말 맑아졌습니다." }
            ]
        };

        // 3. Insert reviews
        let insertedCount = 0;
        const doctorId = 'doc_choi';
        const patientId = 'patient_seed_1';

        // Ensure patient exists
        try {
            await db.prepare("INSERT OR IGNORE INTO patients (id, name, current_phone) VALUES (?, ?, ?)").bind(patientId, '홍길동', '010-1234-5678').run();
        } catch (e) { }

        for (const [category, reviews] of Object.entries(reviewData)) {
            for (let i = 0; i < reviews.length; i++) {
                const review = reviews[i];
                const slug = `${category}-review-${i + 1}-${Date.now()}`;

                try {
                    await db.prepare(`
                        INSERT INTO posts (type, title, slug, excerpt, content, category, doctor_id, patient_id, status, created_at)
                        VALUES ('review', ?, ?, ?, ?, ?, ?, ?, 'published', strftime('%s', 'now'))
                    `).bind(
                        review.title,
                        slug,
                        review.content.substring(0, 50) + '...',
                        review.content,
                        category,
                        doctorId,
                        patientId
                    ).run();
                    insertedCount++;
                } catch (e: any) {
                    logs.push(`Failed to insert review for ${category}: ${e.message}`);
                }
            }
        }

        return new Response(`Seeding v3 complete. Inserted: ${insertedCount}\nLogs:\n${logs.join('\n')}`);
    } catch (e: any) {
        return new Response(`Fatal error: ${e.message}\nLogs:\n${logs.join('\n')}`);
    }
};
