import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    const db = locals.runtime.env.DB;

    try {
        // Add reservation policy columns to settings table
        await db.prepare(`
            ALTER TABLE settings ADD COLUMN reservation_slot_minutes INTEGER DEFAULT 30
        `).run();
    } catch (e) {
        // Column might already exist
    }

    try {
        await db.prepare(`
            ALTER TABLE settings ADD COLUMN max_patients_per_slot INTEGER DEFAULT 3
        `).run();
    } catch (e) {
        // Column might already exist
    }

    try {
        await db.prepare(`
            ALTER TABLE settings ADD COLUMN enforce_clinic_hours INTEGER DEFAULT 1
        `).run();
    } catch (e) {
        // Column might already exist
    }

    return new Response(JSON.stringify({
        success: true,
        message: 'Reservation policy columns added to settings table'
    }));
};
