import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response("DB not found", { status: 500 });
    }

    try {
        // Check if column exists first to avoid error
        const tableInfo = await db.prepare("PRAGMA table_info(posts)").all();
        const hasCategory = tableInfo.results.some((col: any) => col.name === 'category');

        if (!hasCategory) {
            await db.prepare("ALTER TABLE posts ADD COLUMN category TEXT").run();
            return new Response("Migration successful: Added category column to posts table.");
        } else {
            return new Response("Migration skipped: category column already exists.");
        }
    } catch (e: any) {
        return new Response(`Migration failed: ${e.message}`, { status: 500 });
    }
};
