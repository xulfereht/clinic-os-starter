export const prerender = false;

import type { APIRoute } from "astro";


export const GET: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!db) return new Response(JSON.stringify({ error: "DB not found" }), { status: 500 });

    // Fetch all versions for a term
    const versions = await db.prepare(`
        SELECT * FROM terms_versions 
        WHERE term_id = ? 
        ORDER BY created_at DESC
    `).bind(id).all();

    return new Response(JSON.stringify({ versions: versions.results }), {
        status: 200,
        headers: { "Content-Type": "application/json" }
    });
};

export const POST: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id: termId } = params;

    if (!db) return new Response(JSON.stringify({ error: "DB not found" }), { status: 500 });

    try {
        const body = await request.json();
        const { version, content, is_active, locale = 'ko' } = body;

        if (!version || !content) {
            return new Response(JSON.stringify({ error: "Version and Content are required" }), { status: 400 });
        }

        // If setting as active, deactivate other versions for the same locale
        if (is_active) {
            await db.prepare(`UPDATE terms_versions SET is_active = 0 WHERE term_id = ? AND locale = ?`).bind(termId, locale).run();
        }

        const newId = crypto.randomUUID();
        await db.prepare(`
            INSERT INTO terms_versions (id, term_id, version, content, is_active, locale, effective_date, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(newId, termId, version, content, is_active ? 1 : 0, locale, Math.floor(Date.now() / 1000), Math.floor(Date.now() / 1000)).run();

        return new Response(JSON.stringify({ success: true, id: newId }), { status: 201 });
    } catch (e) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
