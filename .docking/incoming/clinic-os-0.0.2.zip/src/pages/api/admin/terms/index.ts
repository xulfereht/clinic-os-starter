export const prerender = false;

import type { APIRoute } from "astro";

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: "DB not found" }), { status: 500 });

    try {
        const terms = await db.prepare(`
            SELECT t.*, v.version as active_version, v.effective_date as active_effective_date
            FROM terms_definitions t
            LEFT JOIN terms_versions v ON t.id = v.term_id AND v.is_active = 1
            ORDER BY t.created_at DESC
        `).all();

        return new Response(JSON.stringify({ terms: terms.results }), {
            status: 200,
            headers: { "Content-Type": "application/json" }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        console.error("DB not found in locals");
        return new Response(JSON.stringify({ error: "DB not found" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { slug, title, description, initialContent } = body;
        console.log("Creating/Init Term:", slug, title);

        if (!slug || !title) {
            return new Response(JSON.stringify({ error: "Slug and Title are required" }), { status: 400 });
        }

        // Check if already exists
        let term = await db.prepare("SELECT id FROM terms_definitions WHERE slug = ?").bind(slug).first();

        if (!term) {
            // Generate UUID for TEXT primary key
            const termId = crypto.randomUUID();
            await db.prepare(`
                INSERT INTO terms_definitions (id, slug, title, description, created_at)
                VALUES (?, ?, ?, ?, strftime('%s', 'now'))
            `).bind(termId, slug, title, description || '').run();

            term = { id: termId };
        }

        if (initialContent && term) {
            console.log("Initializing content for:", slug, "term_id:", term.id);
            // Check if any version exists
            const existing = await db.prepare("SELECT id FROM terms_versions WHERE term_id = ?").bind(term.id).first();

            if (!existing) {
                const versionId = crypto.randomUUID();
                await db.prepare(`
                    INSERT INTO terms_versions (id, term_id, version, content, is_active, effective_date, created_at)
                    VALUES (?, ?, '1.0', ?, 1, strftime('%s', 'now'), strftime('%s', 'now'))
                `).bind(versionId, term.id, initialContent).run();
            }
        }

        return new Response(JSON.stringify({ success: true, id: term?.id }), { status: 201 });
    } catch (e: any) {
        console.error("Terms API Error:", e);
        return new Response(JSON.stringify({ error: e.message || "Unknown error" }), { status: 500 });
    }
};
