import type { APIRoute } from 'astro';

export const prerender = false;

// Get all templates
export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    const { results } = await db.prepare(`
        SELECT * FROM self_diagnosis_templates 
        WHERE status = 'active'
        ORDER BY order_index, created_at DESC
    `).all();

    return new Response(JSON.stringify(results), {
        headers: { 'Content-Type': 'application/json' }
    });
};

// Create new template
export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const data = await request.json();

        const id = crypto.randomUUID();

        // Build questions JSON
        const questions = data.questions || [];

        // Build result templates JSON
        const resultTemplates = data.result_templates || {};

        // Build CTA config JSON
        const ctaConfig = {
            primary: {
                text: data.cta_primary_text || '맞춤 상담 신청하기',
                action: data.cta_primary_action || 'inquiry'
            },
            secondary: data.cta_secondary_text ? {
                text: data.cta_secondary_text,
                action: data.cta_secondary_action || 'program'
            } : null
        };

        await db.prepare(`
            INSERT INTO self_diagnosis_templates (
                id, name, description, type, program_id,
                questions, calculation_script, result_templates_json, cta_config,
                estimated_time, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', strftime('%s', 'now'))
        `).bind(
            id,
            data.name,
            data.description || null,
            data.type || 'custom',
            data.program_id || null,
            JSON.stringify(questions),
            data.calculation_script || null,
            JSON.stringify(resultTemplates),
            JSON.stringify(ctaConfig),
            data.estimated_time || 5
        ).run();

        return new Response(JSON.stringify({ id, success: true }), {
            status: 201,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        console.error('Template creation error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
