import type { APIRoute } from 'astro';

// GET: Fetch single event with its applicants
export const GET: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    const id = params.id;

    try {
        // Get campaign
        const event = await db.prepare("SELECT * FROM event_campaigns WHERE id = ?").bind(id).first();

        if (!event) {
            return new Response(JSON.stringify({ error: 'Event not found' }), { status: 404 });
        }

        // Get applicants (leads with matching channel)
        const campaignChannel = `campaign_${event.slug.replace(/-/g, '_')}`;
        const { results: applicants } = await db.prepare(`
            SELECT id, name, contact, status, intake_data, patient_id, created_at
            FROM leads 
            WHERE channel LIKE ? 
            ORDER BY created_at DESC
        `).bind(campaignChannel + '%').all();

        return new Response(JSON.stringify({
            event,
            applicants: applicants || []
        }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Event GET error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

// DELETE: Delete an event
export const DELETE: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    const id = params.id;

    try {
        await db.prepare("DELETE FROM event_campaigns WHERE id = ?").bind(id).run();
        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Event DELETE error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
