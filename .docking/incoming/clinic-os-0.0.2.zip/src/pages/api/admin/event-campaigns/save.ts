
import type { APIRoute } from 'astro';

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const data = await request.json();
        const { id, title, slug, description, products, is_active } = data;

        if (!title || !slug) {
            return new Response(JSON.stringify({ error: 'Title and Slug are required' }), { status: 400 });
        }

        if (id) {
            // Update
            await db.prepare(`
                UPDATE event_campaigns SET
                    title = ?,
                    slug = ?,
                    description = ?,
                    products = ?,
                    is_active = ?
                WHERE id = ?
            `).bind(
                title, slug, description, products, is_active, id
            ).run();
        } else {
            // Create
            await db.prepare(`
                INSERT INTO event_campaigns (title, slug, description, products, is_active, created_at)
                VALUES (?, ?, ?, ?, ?, unixepoch())
            `).bind(
                title, slug, description, products, is_active
            ).run();
        }

        return new Response(JSON.stringify({ success: true }), { status: 200 });

    } catch (e: any) {
        console.error("Campaign Save Error:", e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
