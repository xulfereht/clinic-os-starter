import type { APIRoute } from 'astro';

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    try {
        const body = await request.json();
        const {
            name, name_en, name_hanja, type, department, position, isActive, orderIndex,
            bio, specialties, education, career, image,
            email, password, role, permissions,
            translations // Add translations
        } = body;

        console.log(`[Staff Update] ID: ${id}, Name: ${name}`);
        console.log(`[Staff Update] Received Permissions (Raw):`, permissions);
        console.log(`[Staff Update] Received Permissions (Type):`, typeof permissions);

        const now = Math.floor(Date.now() / 1000);

        // Build query dynamically based on whether password is provided
        let query = `
            UPDATE staff SET 
                name = ?, name_en = ?, name_hanja = ?, type = ?, department = ?, position = ?, is_active = ?, order_index = ?,
                bio = ?, specialties = ?, education = ?, career = ?, image = ?,
                email = ?, admin_role = ?, permissions = ?, updated_at = ?
        `;

        const bindings = [
            name, name_en || null, name_hanja || null, type, department, position, isActive === '0' ? 0 : 1, parseInt(orderIndex) || 0,
            bio, specialties, education, career, image || null,
            email || null, role || 'staff', permissions || '{}', now
        ];

        if (password) {
            const encoder = new TextEncoder();
            const data = encoder.encode(password);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            const passwordHash = Array.from(new Uint8Array(hashBuffer))
                .map(b => b.toString(16).padStart(2, '0'))
                .join('');

            query += `, password_hash = ?`;
            bindings.push(passwordHash);
        }

        query += ` WHERE id = ?`;
        bindings.push(id);

        await db.prepare(query).bind(...bindings).run();

        // Handle Translations
        if (translations) {
            const stmt = db.prepare(`
                INSERT INTO staff_translations (staff_id, locale, bio, education, career, specialties, status, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, 'published', unixepoch())
                ON CONFLICT(staff_id, locale) DO UPDATE SET
                    bio = excluded.bio,
                    education = excluded.education,
                    career = excluded.career,
                    specialties = excluded.specialties,
                    updated_at = unixepoch()
            `);

            const batch = [];
            for (const [locale, data] of Object.entries(translations)) {
                // @ts-ignore
                if (data && typeof data === 'object') {
                    batch.push(stmt.bind(
                        id,
                        locale,
                        // @ts-ignore
                        data.bio || null,
                        // @ts-ignore
                        data.education || null,
                        // @ts-ignore
                        data.career || null,
                        // @ts-ignore
                        data.specialties || null
                    ));
                }
            }
            if (batch.length > 0) {
                await db.batch(batch);
            }
        }

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    try {
        await db.prepare("UPDATE staff SET deleted_at = unixepoch() WHERE id = ?").bind(id).run();
        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
