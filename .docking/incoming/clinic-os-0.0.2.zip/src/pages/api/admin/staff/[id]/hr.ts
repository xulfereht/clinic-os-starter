import type { APIRoute } from 'astro';

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    try {
        const data = await request.json();

        // Update HR fields
        await locals.runtime.env.DB.prepare(
            `UPDATE staff SET 
             join_date = ?, 
             phone = ?, 
             birth_date = ?, 
             total_leaves = ? 
             WHERE id = ?`
        ).bind(
            data.join_date || null,
            data.phone || null,
            data.birth_date || null,
            data.total_leaves || 15,
            id
        ).run();

        return new Response(JSON.stringify({ message: 'HR info updated' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
