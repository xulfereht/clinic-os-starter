import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    try {
        // Fetch all staff (defensive query)
        const { results: staff } = await db.prepare(`SELECT * FROM staff WHERE deleted_at IS NULL ORDER BY name ASC`).all();

        // Filter active staff manually if column exists, defaulting to true
        // and add isOnline
        const activeStaff = staff.filter((s: any) => s.is_active !== 0 && s.is_active !== false);


        // Fetch active sessions OR check last_seen (within 2 mins)
        const now = Math.floor(Date.now() / 1000);
        const threshold = now - 120;

        const staffWithStatus = activeStaff.map((s: any) => ({
            ...s,
            id: s.id, // Ensure ID exists
            name: s.name || 'Unknown',
            isOnline: (s.last_seen || 0) > threshold
        }));

        return new Response(JSON.stringify({ staff: staffWithStatus }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
