/**
 * Super Admin Management API
 */

import type { APIRoute } from 'astro';

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
        }

        const user = locals.user;

        // Only allow super admin
        if (!user || user.role !== '최고관리자') {
            return new Response(JSON.stringify({ error: '권한이 없습니다.' }), { status: 403 });
        }

        const body = await request.json();
        const { action, id, name, email, password } = body;

        if (action === 'create') {
            if (!name || !email || !password) {
                return new Response(JSON.stringify({ error: '모든 필드를 입력해주세요.' }), { status: 400 });
            }

            // Check if email already exists
            const existing = await db.prepare('SELECT id FROM super_admins WHERE email = ?').bind(email).first();
            if (existing) {
                return new Response(JSON.stringify({ error: '이미 존재하는 이메일입니다.' }), { status: 400 });
            }

            const newId = crypto.randomUUID();
            const passwordHash = await hashPassword(password);

            await db.prepare(
                'INSERT INTO super_admins (id, email, password_hash, name, created_at) VALUES (?, ?, ?, ?, unixepoch())'
            ).bind(newId, email, passwordHash, name).run();

            return new Response(JSON.stringify({ success: true, id: newId }), { status: 200 });

        } else if (action === 'update_password') {
            if (!id || !password) {
                return new Response(JSON.stringify({ error: '비밀번호를 입력해주세요.' }), { status: 400 });
            }

            const passwordHash = await hashPassword(password);

            await db.prepare(
                'UPDATE super_admins SET password_hash = ? WHERE id = ?'
            ).bind(passwordHash, id).run();

            return new Response(JSON.stringify({ success: true }), { status: 200 });

        } else if (action === 'delete') {
            if (!id) {
                return new Response(JSON.stringify({ error: 'ID가 필요합니다.' }), { status: 400 });
            }

            // Don't allow deleting the last super admin
            const count = await db.prepare('SELECT COUNT(*) as cnt FROM super_admins').first();
            if ((count?.cnt as number) <= 1) {
                return new Response(JSON.stringify({ error: '마지막 최고관리자는 삭제할 수 없습니다.' }), { status: 400 });
            }

            await db.prepare('DELETE FROM super_admins WHERE id = ?').bind(id).run();

            return new Response(JSON.stringify({ success: true }), { status: 200 });
        }

        return new Response(JSON.stringify({ error: 'Invalid action' }), { status: 400 });

    } catch (e: any) {
        console.error('[Super Admin API] Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

async function hashPassword(password: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hashBuffer))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}
