import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    try {
        const body = await request.json();
        const {
            name, type, department, position, isActive, orderIndex,
            bio, specialties, education, career, image,
            email, password, role, permissions
        } = body;

        if (!name) {
            return new Response(JSON.stringify({ error: 'Name is required' }), { status: 400 });
        }

        // Hash password if provided
        let passwordHash = null;
        if (password) {
            const encoder = new TextEncoder();
            const data = encoder.encode(password);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            passwordHash = Array.from(new Uint8Array(hashBuffer))
                .map(b => b.toString(16).padStart(2, '0'))
                .join('');
        }

        const id = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        await db.prepare(`
            INSERT INTO staff (
                id, name, type, department, position, is_active, order_index,
                bio, specialties, education, career, image,
                email, password_hash, role, permissions,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            id,
            name,
            type || 'staff',
            department || null,
            position || null,
            isActive === '0' ? 0 : 1,
            parseInt(orderIndex) || 0,
            bio || null,
            specialties || '[]',
            education || null,
            career || null,
            image || null,
            email || null,
            passwordHash,
            role || 'staff',
            permissions || '{}',
            now,
            now
        ).run();

        return new Response(JSON.stringify({ success: true, id }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
