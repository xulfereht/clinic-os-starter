import type { APIRoute } from 'astro';

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    try {
        const body = await request.json();
        const { adminId } = body;

        if (!adminId) {
            return new Response(JSON.stringify({ error: 'Admin ID required' }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);

        // Update last_seen
        await db.prepare("UPDATE staff SET last_seen = ? WHERE id = ?").bind(now, adminId).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    try {
        const now = Math.floor(Date.now() / 1000);
        const threshold = now - 120; // Active within last 2 minutes

        const { results } = await db.prepare(`
            SELECT id, name, image, last_seen 
            FROM staff 
            WHERE last_seen > ?
            ORDER BY last_seen DESC
        `).bind(threshold).all();

        return new Response(JSON.stringify({ users: results }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
