
export const prerender = false;

export async function GET({ locals }) {
    const db = locals.runtime.env.DB;

    const sqls = [
        // 1. Ensure Tables Exist
        `CREATE TABLE IF NOT EXISTS faq_translations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            faq_id INTEGER NOT NULL,
            locale TEXT NOT NULL,
            question TEXT NOT NULL,
            answer_short TEXT,
            answer_detail TEXT,
            status TEXT DEFAULT 'draft',
            priority INTEGER DEFAULT 5,
            translator_id TEXT,
            reviewer_id TEXT,
            created_at INTEGER DEFAULT (unixepoch()),
            updated_at INTEGER DEFAULT (unixepoch()),
            UNIQUE(faq_id, locale)
            -- Removed FK constraint for safety in this script
        );`,
        `CREATE TABLE IF NOT EXISTS topic_translations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            topic_id INTEGER NOT NULL,
            locale TEXT NOT NULL,
            title TEXT NOT NULL,
            summary TEXT,
            status TEXT DEFAULT 'draft',
            created_at INTEGER DEFAULT (unixepoch()),
            updated_at INTEGER DEFAULT (unixepoch()),
            UNIQUE(topic_id, locale)
        );`,

        // 2. Add Columns (Try/Catch implemented via individual execution)

        // 3. Seed Topic Translations for Gambi Diet
        `INSERT OR REPLACE INTO topic_translations (topic_id, locale, title, summary, status)
        SELECT id, 'zh-hans', '减肥韩药（减肥丸·减肥片）处方前必读', '减肥丸和减肥片的区别、效果与副作用，以及服用时的注意事项。医疗团队为您详细解答关于减肥韩药的一切。', 'published'
        FROM topics WHERE slug = 'gambi-diet-herbal';`,

        `INSERT OR REPLACE INTO topic_translations (topic_id, locale, title, summary, status)
        SELECT id, 'ja', 'ダイエット韓方薬（減肥丸・減肥錠）処方前に必ず知っておくべきこと', '減肥丸と減肥錠の違い、効果と副作用、そして服用時の注意事項まで。医療陣が直接教えるダイエット韓方薬のすべて。', 'published'
        FROM topics WHERE slug = 'gambi-diet-herbal';`,

        // 4. Seed FAQ #1 (Tags + Content) - Schema update for tags is needed first
    ];

    const results = [];

    // Execute Base Tables
    for (const sql of sqls) {
        try {
            await db.prepare(sql).run();
            results.push({ success: true, sql: sql.substring(0, 50) + "..." });
        } catch (e: any) {
            results.push({ success: false, error: e.message, sql: sql.substring(0, 50) + "..." });
        }
    }

    // Add Columns individually
    try {
        await db.prepare("ALTER TABLE topic_translations ADD COLUMN seo_title TEXT").run();
        results.push({ success: true, msg: "Added seo_title to topic_translations" });
    } catch (e: any) {
        results.push({ success: false, msg: "seo_title column might already exist", error: e.message });
    }

    try {
        await db.prepare("ALTER TABLE faq_translations ADD COLUMN tags TEXT").run();
        results.push({ success: true, msg: "Added tags to faq_translations" });
    } catch (e: any) {
        results.push({ success: false, msg: "tags column might already exist", error: e.message });
    }

    // Update FAQ #1 Content
    const faqUpdateSqlZh = `
    INSERT OR REPLACE INTO faq_translations (faq_id, locale, question, answer_short, answer_detail, tags, status, created_at, updated_at)
    VALUES (
        1, 
        'zh-hans', 
        '减肥丸和减肥片有什么区别?', 
        '减肥丸是小颗粒的丸剂，减肥片是将药效浓缩的片剂。白鹿潭韩医院以服用方便的减肥片（每天2次，每次2片）作为基本处方。',
        '<p><strong>减肥丸和减肥片的区别</strong></p><table><tr><th>区分</th><th>减肥丸</th><th>减肥片 ✅</th></tr><tr><td>形态</td><td>小颗粒(丸)</td><td>片剂(Tablet)</td></tr><tr><td>服用量</td><td>一次多粒</td><td><strong>每天2次，2片</strong></td></tr><tr><td>特征</td><td>传统方式</td><td><strong>汤药效果浓缩</strong></td></tr><tr><td>便携性</td><td>普通</td><td><strong>简便</strong></td></tr></table><p><strong>白鹿潭韩医院的选择：</strong> 以保留汤药治疗效果同时提高服用便利性的<strong>减肥片</strong>作为基本处方。每天2次，每次2片，繁忙的现代人也能坚持服用。</p>',
        '["剂型", "差异", "效果"]',
        'published',
        strftime('%s', 'now'),
        strftime('%s', 'now')
    );`;

    const faqUpdateSqlJa = `
    INSERT OR REPLACE INTO faq_translations (faq_id, locale, question, answer_short, answer_detail, tags, status, created_at, updated_at)
    VALUES (
        1, 
        'ja', 
        '減肥丸と減肥錠は何が違いますか？', 
        '減肥丸は小さな粒状の丸剤で、減肥錠は薬効を濃縮した錠剤です。白鹿潭韓医院では、服用の利便性が高い減肥錠（1日2回、2錠）を基本処方としています。',
        '<p><strong>減肥丸と減肥錠の違い</strong></p><table><tr><th>区分</th><th>減肥丸</th><th>減肥錠 ✅</th></tr><tr><td>形態</td><td>小さな粒(丸)</td><td>錠剤(タブレット)</td></tr><tr><td>服用量</td><td>一度に多数</td><td><strong>1日2回、2錠</strong></td></tr><tr><td>特徴</td><td>伝統方式</td><td><strong>湯薬の効果を濃縮</strong></td></tr><tr><td>携帯性</td><td>普通</td><td><strong>簡便</strong></td></tr></table><p><strong>白鹿潭韓医院の選択：</strong> 湯薬の治療効果はそのままに、服用の利便性を高めた<strong>減肥錠</strong>を基本処方としています。1日2回、2錠で多忙な現代人も着実に服用できます。</p>',
        '["剤形", "違い", "効果"]',
        'published',
        strftime('%s', 'now'),
        strftime('%s', 'now')
    );`;

    try {
        await db.prepare(faqUpdateSqlZh).run();
        results.push({ success: true, msg: "Updated FAQ #1 ZH" });
    } catch (e: any) {
        results.push({ success: false, error: e.message, msg: "FAQ #1 ZH Update Failed" });
    }

    try {
        await db.prepare(faqUpdateSqlJa).run();
        results.push({ success: true, msg: "Updated FAQ #1 JA" });
    } catch (e: any) {
        results.push({ success: false, error: e.message, msg: "FAQ #1 JA Update Failed" });
    }

    return new Response(JSON.stringify(results, null, 2), {
        headers: { 'Content-Type': 'application/json' }
    });
}
