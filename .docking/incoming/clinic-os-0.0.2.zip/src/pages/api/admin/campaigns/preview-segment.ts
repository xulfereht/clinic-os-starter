export const prerender = false;

import type { APIRoute } from 'astro';
import { generateSegmentSql } from '../../../../lib/segment-engine';

export const GET: APIRoute = async ({ url, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'DB not available' }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    const segmentId = url.searchParams.get('segment_id');

    if (!segmentId) {
        return new Response(JSON.stringify({ error: 'segment_id is required' }), {
            status: 400,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    try {
        // Fetch segment
        interface FullSegment {
            id: number;
            query_sql: string;
            criteria: string | null;
        }

        const segment = await db.prepare("SELECT id, query_sql, criteria FROM segments WHERE id = ?")
            .bind(segmentId)
            .first() as FullSegment | null;

        if (!segment) {
            return new Response(JSON.stringify({ error: 'Segment not found', count: 0 }), {
                status: 404,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Regenerate SQL from criteria (same as cron logic)
        let segmentSql = segment.query_sql;
        let segmentParams: any[] = [];

        if (segment.criteria) {
            try {
                const criteria = JSON.parse(segment.criteria);
                const generated = generateSegmentSql(criteria);
                // Build full query for counting
                segmentSql = `SELECT id, name, current_phone FROM patients WHERE deleted_at IS NULL AND (${generated.sql})`;
                segmentParams = generated.params;
            } catch (e: any) {
                console.error(`[Segment Preview] Failed to parse criteria for segment ${segment.id}: ${e.message}`);
                // Fallback to stored query_sql
            }
        }

        // Count patients
        const countQuery = `SELECT COUNT(*) as count FROM (${segmentSql})`;
        const countResult = await db.prepare(countQuery)
            .bind(...segmentParams)
            .first() as { count: number } | null;

        const count = countResult?.count || 0;

        return new Response(JSON.stringify({ count }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('[Segment Preview] Error:', e);
        return new Response(JSON.stringify({
            error: e.message,
            count: 0
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};
