
import type { APIRoute } from 'astro';
import { getAligoConfig, sendAligoMessage, sendAlimTalk } from '../../../../../lib/aligo';
import { getCampaignData, getClinicInfo, getPatientVariables, substituteVariables } from '../../../../../lib/campaign-validation';
import { getSurveyLink } from '../../../../../lib/survey-registry';

export const POST: APIRoute = async ({ params, locals }) => {
    // 1. Auth Check
    const user = locals.user;
    if (!user) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    const { id: campaignId } = params;
    if (!campaignId) {
        return new Response(JSON.stringify({ error: 'Campaign ID is required' }), { status: 400 });
    }

    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const env = locals.runtime?.env;

    const config = await getAligoConfig(env, db);
    if (!config) {
        return new Response(JSON.stringify({ error: 'SMS Configuration Missing' }), { status: 500 });
    }

    try {
        const now = Math.floor(Date.now() / 1000);

        // 2. Fetch Campaign Details via Shared Lib
        let campaignData;
        try {
            campaignData = await getCampaignData(db, campaignId);
        } catch (e: any) {
            return new Response(JSON.stringify({ error: e.message }), { status: 400 });
        }

        const { campaign, template, patients } = campaignData;

        if (patients.length === 0) {
            return new Response(JSON.stringify({ error: 'No patients found in this segment' }), { status: 400 });
        }

        // 6. Create Run History
        const runId = crypto.randomUUID();
        await db.prepare(`
            INSERT INTO campaign_runs (id, campaign_id, started_at, status, trigger_type) 
            VALUES (?, ?, ?, 'running', 'MANUAL')
        `).bind(runId, campaignId, now).run();

        // Update Campaign Status with Optimistic Locking
        // Only proceed if status is 'draft' OR 'manual_sending' (retry)
        const updateResult = await db.prepare("UPDATE campaigns SET status = 'manual_sending', sent_at = ? WHERE id = ? AND (status = 'draft' OR status = 'failed' OR status = 'manual_sending')")
            .bind(now, campaignId).run();

        if (updateResult.meta.changes === 0) {
            return new Response(JSON.stringify({ error: 'Campaign is already being processed or sent' }), { status: 409 });
        }

        // Fetch Clinic Info
        const clinicInfo = await getClinicInfo(db);
        const clinicName = clinicInfo.name;
        const clinicPhone = clinicInfo.phone;
        const baseUrl = clinicInfo.url || 'https://www.example.com';

        // 7. Send Batch
        let successCount = 0;
        let failCount = 0;

        for (const p of patients) {

            // Get Variables (handles survey url, reservation calculation)
            const variables = await getPatientVariables(db, p, clinicInfo);
            const surveyUrl = variables.url; // Need this for legacy variable replacement if any left? No, all handled.

            // Variable Substitution
            let content = substituteVariables(template.content || '', variables);

            let result;
            let msgType = '';

            try {
                if (template.channel === 'ALIMTALK' || template.channel === 'BOTH') {
                    if (template.alimtalk_code) {
                        msgType = 'ALIMTALK';
                        let userButtonJson = template.buttons;
                        if (userButtonJson) {
                            try {
                                // 1. Substitute variables in the raw string first
                                const substitutedString = substituteVariables(userButtonJson, variables);

                                // 2. Parse to ensure valid JSON
                                const buttons = JSON.parse(substitutedString);

                                // 3. Wrap in Aligo-expected structure: { "button": [...] }
                                userButtonJson = JSON.stringify({ button: buttons });
                            } catch (e) {
                                console.error('Failed to process buttons', e);
                                // If fail, send original? Or undefined? 
                                // Sending original raw array might fail, but better than crashing.
                                // Actually, if we fail to parse, it's safer not to send buttons or send as is.
                                userButtonJson = substituteVariables(userButtonJson, variables);
                            }
                        }

                        // Failover logic: Always 'Y' if we have fallback content
                        const failoverYn = 'Y';

                        // Substitute variables in title for failover
                        let failoverTitle = '#{clinic_name} 알림';
                        failoverTitle = substituteVariables(failoverTitle, variables);

                        result = await sendAlimTalk(config, {
                            receiver: p.current_phone,
                            tpl_code: template.alimtalk_code,
                            senderkey: config.senderKey || '',
                            message_1: content, // Fallback message content
                            message: content,   // AlimTalk message content
                            subject_1: failoverTitle,
                            failover: failoverYn,
                            button_1: userButtonJson || undefined
                        });
                    } else {
                        // Fallback to SMS if no code?
                        msgType = 'SMS';

                        // Substitute variables in title for SMS
                        let smsTitle = '#{clinic_name} 알림';
                        smsTitle = substituteVariables(smsTitle, variables);

                        result = await sendAligoMessage(config, {
                            receiver: p.current_phone,
                            msg: content,
                            destination: `${p.current_phone}|${p.name}`,
                            title: smsTitle
                        });
                    }
                } else {
                    msgType = 'SMS';
                    // Substitute variables in title for SMS
                    let smsTitle = '#{clinic_name} 알림';
                    smsTitle = substituteVariables(smsTitle, variables);

                    result = await sendAligoMessage(config, {
                        receiver: p.current_phone,
                        msg: content,
                        destination: `${p.current_phone}|${p.name}`,
                        title: smsTitle
                    });
                }

                const rawResult = result as any;
                const isSuccess = (String(result.result_code) === '1') || (rawResult.code !== undefined && Number(rawResult.code) === 0);

                if (isSuccess) successCount++;
                else failCount++;

                // Log
                let errorMsg = result.message;
                if (result.msg_id) {
                    errorMsg = `[MsgID: ${result.msg_id}] ${result.message}`;
                }

                await db.prepare(`
                    INSERT INTO message_logs (
                        campaign_id, patient_id, patient_name, phone, 
                        message_type, content, status, sent_at, type,
                        result_code, error_message
                    ) VALUES (
                        ?, ?, ?, ?, 
                        ?, ?, ?, ?, 'campaign',
                        ?, ?
                    )
                `).bind(
                    campaignId, p.id, p.name, p.current_phone,
                    msgType, content, isSuccess ? 'sent' : 'failed', now,
                    result.result_code, errorMsg
                ).run();

            } catch (err: any) {
                console.error(`Failed to send to ${p.name}`, err);
                failCount++;
                try {
                    await db.prepare(`
                        INSERT INTO message_logs (
                            campaign_id, patient_id, patient_name, phone, 
                            message_type, content, status, sent_at, type,
                            error_message
                        ) VALUES (
                            ?, ?, ?, ?, 
                            ?, ?, 'failed', ?, 'campaign',
                            ?
                        )
                    `).bind(
                        campaignId, p.id, p.name || 'Unknown', p.current_phone || '',
                        msgType || 'UNKNOWN', content || '', now,
                        err.message || 'Unknown Error'
                    ).run();
                } catch (e) {
                    console.error('Failed to log error', e);
                }
            }
        }

        // 8. Update Final Status
        const endTime = Math.floor(Date.now() / 1000);

        await db.prepare(`
            UPDATE campaigns 
            SET status = 'sent', 
                sent_count = sent_count + ?, 
                failed_count = failed_count + ?,
                total_count = ?
            WHERE id = ?
        `).bind(successCount, failCount, patients.length, campaignId).run();

        await db.prepare(`
            UPDATE campaign_runs
            SET status = 'completed', 
                completed_at = ?,
                sent_count = ?,
                failed_count = ?,
                total_count = ?
            WHERE id = ?
        `).bind(endTime, successCount, failCount, patients.length, runId).run();

        return new Response(JSON.stringify({
            success: true,
            processed: patients.length,
            successCount,
            failCount,
            runId
        }), { status: 200 });

    } catch (error: any) {
        console.error('Campaign Send Error:', error);
        return new Response(JSON.stringify({
            error: 'Internal Server Error',
            details: error.message
        }), { status: 500 });
    }
};
