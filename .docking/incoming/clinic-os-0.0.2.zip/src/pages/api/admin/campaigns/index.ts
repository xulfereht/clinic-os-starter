export const prerender = false;

import type { APIRoute } from 'astro';

// POST: Create a new campaign
export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
        }

        const data = await request.json();
        const { name, template_id, segment_id, type, trigger_config, scheduled_at, trigger_event } = data;

        if (!name || !template_id) {
            return new Response(JSON.stringify({ error: 'Name and template_id required' }), { status: 400 });
        }

        // Get patient count for segment
        let totalCount = 0;
        if (segment_id) {
            // Fetch segment with criteria
            interface FullSegment {
                id: number;
                query_sql: string;
                criteria: string | null;
            }
            const segment = await db.prepare(`SELECT id, query_sql, criteria FROM segments WHERE id = ?`)
                .bind(segment_id)
                .first() as FullSegment | null;

            if (segment) {
                // Regenerate SQL from criteria (same as preview API and cron)
                let segmentSql = segment.query_sql;
                let segmentParams: any[] = [];

                if (segment.criteria) {
                    try {
                        const { generateSegmentSql } = await import('../../../../lib/segment-engine');
                        const criteria = JSON.parse(segment.criteria);
                        const generated = generateSegmentSql(criteria);
                        // Build full query for counting
                        segmentSql = `SELECT id, name, current_phone FROM patients WHERE deleted_at IS NULL AND (${generated.sql})`;
                        segmentParams = generated.params;
                    } catch (e) {
                        console.error('[Campaigns API] Failed to parse criteria:', e);
                        // Fallback to stored query_sql
                    }
                }

                try {
                    const countQuery = `SELECT COUNT(*) as count FROM (${segmentSql})`;
                    const countResult = await db.prepare(countQuery)
                        .bind(...segmentParams)
                        .first() as { count: number } | null;
                    totalCount = countResult?.count || 0;
                } catch (e) {
                    console.error('[Campaigns API] Segment query error:', e);
                }
            }
        }

        const id = Date.now();
        const now = Math.floor(Date.now() / 1000);

        // Determine initial status
        // - ONE_TIME without scheduled_at: 'draft' (manual send later)
        // - ONE_TIME with scheduled_at: 'scheduled' (will run at scheduled time)
        // - RECURRING: 'active' (managed by next_run_at, not scheduled_at)
        let status = 'scheduled'; // default
        if (type === 'ONE_TIME' && !scheduled_at) {
            status = 'draft';
        } else if (type === 'RECURRING') {
            status = 'active'; // RECURRING campaigns are always active
        }

        let nextRunAt = null;
        if (type === 'RECURRING' && trigger_config) {
            try {
                const { calculateNextRun } = await import('../../../../lib/scheduler');
                // Parse trigger_config to find scheduled time
                const config = typeof trigger_config === 'string' ? JSON.parse(trigger_config) : trigger_config;
                nextRunAt = calculateNextRun(config, now);
            } catch (e) {
                console.error("Failed to calculate initial next run:", e);
            }
        }

        await db.prepare(`
            INSERT INTO campaigns (id, name, template_id, segment_id, status, total_count, created_at, type, trigger_config, scheduled_at, trigger_type, next_run_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            id,
            name,
            template_id,
            segment_id || null,
            status,
            totalCount,
            now,
            type || 'ONE_TIME',
            trigger_config || null,
            scheduled_at || null,
            trigger_event || null,
            nextRunAt // Initial next_run_at
        ).run();

        return new Response(JSON.stringify({
            success: true,
            campaign_id: id,
            total_count: totalCount
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error: any) {
        console.error('[Campaigns API] Error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};

// GET: List campaigns
export const GET: APIRoute = async ({ locals }) => {
    try {
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
        }

        const result = await db.prepare(`
            SELECT c.*, t.name as template_name, s.name as segment_name,
                (SELECT started_at FROM campaign_runs WHERE campaign_id = c.id ORDER BY started_at DESC LIMIT 1) as last_run_at,
                (SELECT sent_count FROM campaign_runs WHERE campaign_id = c.id ORDER BY started_at DESC LIMIT 1) as last_run_sent_count,
                (SELECT total_count FROM campaign_runs WHERE campaign_id = c.id ORDER BY started_at DESC LIMIT 1) as last_run_total_count
            FROM campaigns c
            LEFT JOIN message_templates t ON t.id = c.template_id
            LEFT JOIN segments s ON s.id = c.segment_id
            ORDER BY c.created_at DESC
            LIMIT 50
        `).all();

        return new Response(JSON.stringify({ campaigns: result?.results || [] }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error: any) {
        console.error('[Campaigns API] Error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};
