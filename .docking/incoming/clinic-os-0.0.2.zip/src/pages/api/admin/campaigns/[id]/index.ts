export const prerender = false;

import type { APIRoute } from 'astro';

export const DELETE: APIRoute = async ({ params, locals }) => {
    try {
        const db = locals.runtime?.env?.DB;
        const { id } = params;

        if (!db) return new Response('DB not available', { status: 500 });
        if (!id) return new Response('ID required', { status: 400 });

        // Check if exists
        const campaign = await db.prepare("SELECT * FROM campaigns WHERE id = ?").bind(id).first();
        if (!campaign) {
            return new Response('Campaign not found', { status: 404 });
        }

        // Allow delete if not 'sending' (or maybe allow force delete?)
        // Safer to prevent deleting if currently sending
        // if (campaign.status === 'sending') {
        //    return new Response(JSON.stringify({ error: 'Cannot delete a campaign while it is sending.' }), { status: 400 });
        // }

        // Delete (Cascade should handle logs/runs if defined, otherwise we might leave orphans. 
        // Assuming simple delete is requested. Better to delete logs too if no cascade.)
        // Let's assume SQLite constraints or just delete main row.
        // Delete dependent records first to avoid Foreign Key constraints
        await db.prepare("DELETE FROM message_logs WHERE campaign_id = ?").bind(id).run();
        await db.prepare("DELETE FROM campaign_runs WHERE campaign_id = ?").bind(id).run();

        // Then delete the campaign
        await db.prepare("DELETE FROM campaigns WHERE id = ?").bind(id).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const PATCH: APIRoute = async ({ params, request, locals }) => {
    try {
        const db = locals.runtime?.env?.DB;
        const { id } = params;

        if (!db) return new Response('DB not available', { status: 500 });

        const body = await request.json();

        // Check if just status update or full edit
        const keys = Object.keys(body);
        const isStatusOnly = keys.length === 1 && keys[0] === 'status';

        const campaign = await db.prepare("SELECT * FROM campaigns WHERE id = ?").bind(id).first();
        if (!campaign) return new Response('Campaign not found', { status: 404 });

        if (isStatusOnly) {
            const { status } = body;
            if (!status) return new Response('Status required', { status: 400 });

            await db.prepare("UPDATE campaigns SET status = ? WHERE id = ?").bind(status, id).run();
            return new Response(JSON.stringify({ success: true, status }), { status: 200 });
        } else {
            // Full Edit
            // Fields: name, template_id, segment_id, type, trigger_config, trigger_event, scheduled_at
            const { name, template_id, segment_id, type, trigger_config, trigger_event, scheduled_at } = body;

            // Recalculate next_run_at if RECURRING
            let nextRunAt = campaign.next_run_at;
            if (type === 'RECURRING' && trigger_config) {
                try {
                    const { calculateNextRun } = await import('../../../../../lib/scheduler');
                    const config = typeof trigger_config === 'string' ? JSON.parse(trigger_config) : trigger_config;
                    // Calculate from NOW
                    nextRunAt = calculateNextRun(config, Math.floor(Date.now() / 1000));
                } catch (e) {
                    console.error("Failed to calculate next run:", e);
                }
            }

            // Recalculate total_count if segment_id is provided
            let totalCount = campaign.total_count; // Keep existing if not recalculating
            if (segment_id) {
                interface FullSegment {
                    id: number;
                    query_sql: string;
                    criteria: string | null;
                }
                const segment = await db.prepare(`SELECT id, query_sql, criteria FROM segments WHERE id = ?`)
                    .bind(segment_id)
                    .first() as FullSegment | null;

                if (segment) {
                    let segmentSql = segment.query_sql;
                    let segmentParams: any[] = [];

                    if (segment.criteria) {
                        try {
                            const { generateSegmentSql } = await import('../../../../../lib/segment-engine');
                            const criteria = JSON.parse(segment.criteria);
                            const generated = generateSegmentSql(criteria);
                            segmentSql = `SELECT id, name, current_phone FROM patients WHERE deleted_at IS NULL AND (${generated.sql})`;
                            segmentParams = generated.params;
                        } catch (e) {
                            console.error('[Campaign PATCH] Failed to parse criteria:', e);
                        }
                    }

                    try {
                        const countQuery = `SELECT COUNT(*) as count FROM (${segmentSql})`;
                        const countResult = await db.prepare(countQuery)
                            .bind(...segmentParams)
                            .first() as { count: number } | null;
                        totalCount = countResult?.count || 0;
                    } catch (e) {
                        console.error('[Campaign PATCH] Segment query error:', e);
                    }
                }
            }

            // Update Query
            // Note: status is NOT updated here automatically, assumed to remain as-is or handled separately. 
            // If user edits a 'scheduled' campaign, it remains 'scheduled' (with new time).
            // If editing a 'draft', remains 'draft'.

            await db.prepare(`
                UPDATE campaigns 
                SET name = ?, template_id = ?, segment_id = ?, type = ?, 
                    trigger_config = ?, trigger_event = ?, scheduled_at = ?, next_run_at = ?, total_count = ?
                WHERE id = ?
            `).bind(
                name,
                template_id,
                segment_id || null,
                type || 'ONE_TIME',
                trigger_config || null,
                trigger_event || null,
                scheduled_at || null,
                nextRunAt,
                totalCount,
                id
            ).run();

            return new Response(JSON.stringify({ success: true }), { status: 200 });
        }

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
