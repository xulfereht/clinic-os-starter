export const prerender = false;
import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
    }

    const { runId } = params;
    if (!runId) {
        return new Response(JSON.stringify({ error: 'Run ID required' }), { status: 400 });
    }

    try {
        // 1. Get Run Details
        const run: any = await db.prepare('SELECT * FROM campaign_runs WHERE id = ?').bind(runId).first();
        if (!run) {
            return new Response(JSON.stringify({ error: 'Run not found' }), { status: 404 });
        }

        // 2. Get Logs
        // Use started_at and completed_at (or now) to filter logs belonging to this run
        // We add a small buffer or just strict equality >= started_at works if logic is sound.
        const startTime = run.started_at;
        const endTime = run.completed_at || (Math.floor(Date.now() / 1000) + 86400);

        const logs = await db.prepare(`
            SELECT * FROM message_logs 
            WHERE campaign_id = ? 
            AND sent_at >= ? 
            AND sent_at <= ?
            ORDER BY sent_at DESC
        `).bind(run.campaign_id, startTime, endTime).all();

        return new Response(JSON.stringify({
            run,
            logs: logs?.results || []
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
