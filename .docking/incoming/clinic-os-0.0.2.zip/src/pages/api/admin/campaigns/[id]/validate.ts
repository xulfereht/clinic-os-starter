
import type { APIRoute } from 'astro';
import { getCampaignData, getClinicInfo, getPatientVariables, validateMessageContent } from '../../../../../lib/campaign-validation';

export const GET: APIRoute = async ({ params, locals }) => {
    // 1. Auth Check
    const user = locals.user;
    if (!user) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    const { id: campaignId } = params;
    if (!campaignId) {
        return new Response(JSON.stringify({ error: 'Campaign ID is required' }), { status: 400 });
    }

    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const env = locals.runtime?.env;

    try {
        // Fetch Data
        const { campaign, template, patients } = await getCampaignData(db, campaignId);

        if (patients.length === 0) {
            return new Response(JSON.stringify({
                total: 0,
                valid: 0,
                invalid: 0,
                issues: []
            }), { status: 200 });
        }

        const clinicInfo = await getClinicInfo(db);

        let validCount = 0;
        let invalidCount = 0;
        const issues: any[] = [];
        const MAX_ISSUES = 20; // Only return first 20 issues

        // Check each patient
        for (const p of patients) {
            const vars = await getPatientVariables(db, p, clinicInfo);
            const missing = validateMessageContent(template.content, vars);

            // Check buttons too if they exist
            // (Buttons might have variables like URL)
            // Ideally we should check template.buttons string too
            if (template.buttons) {
                const buttonMissing = validateMessageContent(template.buttons, vars);
                // merge unique
                for (const m of buttonMissing) {
                    if (!missing.includes(m)) missing.push(m);
                }
            }

            if (missing.length > 0) {
                invalidCount++;
                if (issues.length < MAX_ISSUES) {
                    issues.push({
                        patient_name: p.name,
                        missing_variables: missing
                    });
                }
            } else {
                validCount++;
            }
        }

        return new Response(JSON.stringify({
            total: patients.length,
            valid: validCount,
            invalid: invalidCount,
            issues: issues,
            sample_issue: issues.length > 0 ? issues[0] : null
        }), { status: 200 });

    } catch (error: any) {
        console.error('Validation Error:', error);
        return new Response(JSON.stringify({
            error: 'Validation failed',
            details: error.message
        }), { status: 500 });
    }
};
