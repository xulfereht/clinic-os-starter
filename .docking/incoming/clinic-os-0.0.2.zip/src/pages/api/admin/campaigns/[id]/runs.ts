export const prerender = false;

import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
    }

    const { id } = params;
    if (!id) {
        return new Response(JSON.stringify({ error: 'Campaign ID required' }), { status: 400 });
    }

    try {
        const result = await db.prepare(`
            SELECT * FROM campaign_runs 
            WHERE campaign_id = ? 
            ORDER BY started_at DESC 
            LIMIT 50
        `).bind(id).all();

        return new Response(JSON.stringify({ runs: result?.results || [] }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
