import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // Use a single SQL query to update all patients at once
        // This avoids "Too many API requests" error from Cloudflare Workers
        const result = await db.prepare(`
            UPDATE patients
            SET visit_count = (
                SELECT COUNT(*) 
                FROM patient_events 
                WHERE patient_events.patient_id = patients.id 
                AND patient_events.type = 'visit'
            )
            WHERE deleted_at IS NULL
        `).run();

        return new Response(JSON.stringify({
            success: true,
            message: `Batch update completed successfully`,
            result
        }), { status: 200 });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
