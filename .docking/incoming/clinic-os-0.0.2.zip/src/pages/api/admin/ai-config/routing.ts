import type { APIRoute } from 'astro';

export const prerender = false;

// GET: Fetch all feature mappings
export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    try {
        const mappings = await db.prepare("SELECT * FROM ai_feature_mappings").all();

        // Convert array of rows to a Map-like object { feature_key: { provider, model, ... } }
        // or just return array and let frontend handle it.
        // Let's return object for easier lookup by key.
        const mappingObj: Record<string, any> = {};
        mappings.results.forEach((m: any) => {
            mappingObj[m.feature_key] = m;
        });

        return new Response(JSON.stringify(mappingObj), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

// POST: Update a specific feature mapping
export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    try {
        const body = await request.json();
        const { feature_key, provider, model } = body;

        if (!feature_key || !provider) {
            return new Response(JSON.stringify({ error: 'Feature Key and Provider are required' }), { status: 400 });
        }

        // UPSERT logic
        // Check existence
        const existing = await db.prepare("SELECT feature_key FROM ai_feature_mappings WHERE feature_key = ?").bind(feature_key).first();

        if (existing) {
            await db.prepare(
                "UPDATE ai_feature_mappings SET provider = ?, model = ?, updated_at = CURRENT_TIMESTAMP WHERE feature_key = ?"
            ).bind(provider, model || null, feature_key).run();
        } else {
            await db.prepare(
                "INSERT INTO ai_feature_mappings (feature_key, provider, model) VALUES (?, ?, ?)"
            ).bind(feature_key, provider, model || null).run();
        }

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
