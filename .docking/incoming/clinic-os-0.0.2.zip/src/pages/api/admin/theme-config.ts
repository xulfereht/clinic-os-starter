import type { APIRoute } from 'astro';
import { getClinicSettings } from '../../../lib/clinic';

export const POST: APIRoute = async ({ request, locals }) => {
    // TODO: Add auth check here if needed (assuming middleware handles it or we trust internal for now)

    try {
        const data = await request.json();
        const { themeConfig } = data;

        if (!themeConfig) {
            return new Response(JSON.stringify({ error: 'Missing themeConfig' }), { status: 400 });
        }

        // Get DB Binding
        const db = locals.runtime?.env?.DB;

        if (!db) {
            console.error("Database binding not found");
            return new Response(JSON.stringify({ error: 'Database connection failed' }), { status: 500 });
        }

        // Get Clinic ID (Pass DB to fetch actual ID)
        const clinic = await getClinicSettings(db);
        const clinicId = clinic.id || 1; // Default to 1 if not found (though it should be)

        // 1. Try UPDATE
        let result = await db.prepare(
            "UPDATE clinics SET theme_config = ? WHERE id = ?"
        ).bind(JSON.stringify(themeConfig), 1).run();

        // 2. If no rows updated, INSERT (UPSERT)
        if (result.meta.changes === 0) {
            result = await db.prepare(
                "INSERT INTO clinics (id, name, theme_config) VALUES (?, ?, ?)"
            ).bind(1, '백록담한의원', JSON.stringify(themeConfig)).run();
        }

        return new Response(JSON.stringify({
            success: true,
            changes: result.meta.changes,
            saved: themeConfig
        }), { status: 200 });

    } catch (e) {
        console.error('Error saving theme config:', e);
        return new Response(JSON.stringify({ error: 'Internal Server Error', details: String(e) }), { status: 500 });
    }
};

export const GET: APIRoute = async ({ locals }) => {
    try {
        const db = locals.runtime?.env?.DB;
        if (!db) {
            return new Response(JSON.stringify({ error: 'Database connection failed' }), { status: 500 });
        }

        const clinic = await getClinicSettings(db);
        // console.log("API GET Theme Config:", clinic.theme);
        return new Response(JSON.stringify(clinic.theme), { status: 200 });
    } catch (e) {
        console.error("API GET Error:", e);
        return new Response(JSON.stringify({ error: 'Failed to fetch config' }), { status: 500 });
    }
};
