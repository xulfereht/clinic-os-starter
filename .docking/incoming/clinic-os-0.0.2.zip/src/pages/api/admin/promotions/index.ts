import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    const { results } = await db.prepare("SELECT * FROM promotions WHERE deleted_at IS NULL ORDER BY created_at DESC").run();
    return new Response(JSON.stringify({ promotions: results }), { status: 200 });
};

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });

    try {
        const body = await request.json();
        const { name, type, value } = body;

        if (!name || !type || value === undefined) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
        }

        const id = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        await db.prepare(
            "INSERT INTO promotions (id, name, type, value, created_at) VALUES (?, ?, ?, ?, ?)"
        ).bind(id, name, type, parseInt(value), now).run();

        return new Response(JSON.stringify({ success: true, id }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
