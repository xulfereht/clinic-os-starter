import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const user = locals.user;

    if (!db || !user) {
        return new Response(JSON.stringify({ error: 'Unauthorized or DB unavailable' }), { status: 401 });
    }

    try {
        const { path, label, icon } = await request.json();

        if (!path || !label) {
            return new Response(JSON.stringify({ error: 'Path and Label are required' }), { status: 400 });
        }

        // Check if exists
        const existing = await db.prepare("SELECT id FROM admin_favorites WHERE admin_id = ? AND path = ?")
            .bind(user.id, path)
            .first();

        if (existing) {
            // Remove
            await db.prepare("DELETE FROM admin_favorites WHERE id = ?").bind(existing.id).run();
            return new Response(JSON.stringify({ success: true, action: 'removed' }), { status: 200 });
        } else {
            // Add
            const id = crypto.randomUUID();
            const now = Math.floor(Date.now() / 1000);
            await db.prepare("INSERT INTO admin_favorites (id, admin_id, path, label, icon, created_at) VALUES (?, ?, ?, ?, ?, ?)")
                .bind(id, user.id, path, label, icon || '⭐', now)
                .run();
            return new Response(JSON.stringify({ success: true, action: 'added' }), { status: 200 });
        }
    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
