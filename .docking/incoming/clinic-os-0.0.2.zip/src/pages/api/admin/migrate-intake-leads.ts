/**
 * Migration script to convert existing intake leads to patients
 * Run this once to migrate data from leads table to patients + intake_submissions
 */

export const prerender = false;

export async function POST({ request, locals }: { request: Request; locals: any }) {
    try {
        const db = locals.runtime.env.DB;

        // Check authentication (optional - add your auth check here)
        // const auth = request.headers.get('authorization');
        // if (auth !== 'YOUR_SECRET_KEY') {
        //     return new Response('Unauthorized', { status: 401 });
        // }

        // Get all intake leads that haven't been migrated to intake_submissions yet
        const { results: intakeLeads } = await db.prepare(`
            SELECT l.* 
            FROM leads l
            LEFT JOIN intake_submissions i ON l.patient_id = i.patient_id
            WHERE l.channel = 'intake_form' 
            AND l.intake_data IS NOT NULL
            AND i.id IS NULL
        `).run();

        let converted = 0;
        let skipped = 0;
        let errors: string[] = [];

        for (const lead of intakeLeads) {
            try {
                const intakeData = JSON.parse(lead.intake_data);
                let patientId = lead.patient_id;

                // If patient_id is null, we need to find or create the patient
                if (!patientId) {
                    // Check if patient already exists (by phone)
                    const existing = await db.prepare("SELECT id FROM patients WHERE current_phone = ?")
                        .bind(lead.contact)
                        .first();

                    if (existing) {
                        patientId = existing.id;
                        // Link the lead to existing patient
                        await db.prepare("UPDATE leads SET patient_id = ? WHERE id = ?")
                            .bind(patientId, lead.id)
                            .run();
                    } else {
                        // Create new patient
                        patientId = crypto.randomUUID();
                        const now = Math.floor(Date.now() / 1000);

                        // Gender conversion
                        let gender = intakeData.gender || '';
                        if (gender === 'male') gender = 'M';
                        else if (gender === 'female') gender = 'F';
                        else gender = '';

                        const smsConsent = intakeData.consentMetadata?.marketing_consent || intakeData.marketing_consent || false;
                        const emailConsent = intakeData.consentMetadata?.marketing_consent || intakeData.marketing_consent || false;

                        // Build notes
                        let notes = `[초진 접수 정보]\n`;
                        notes += `방문 목적: ${intakeData.visit_category || '-'}\n`;
                        notes += `주요 증상: ${intakeData.main_symptom || '-'}\n`;
                        notes += `증상 기간: ${intakeData.duration || '-'}\n`;
                        if (intakeData.herbal_consent) {
                            notes += `한약 치료: ${intakeData.herbal_consent === 'yes' ? '고려 중' : '침 치료만 희망'}\n`;
                        }
                        notes += `내원 경로: ${intakeData.referral?.join(', ') || '-'}\n`;
                        notes += `접수 일시: ${intakeData.submittedAt || new Date(lead.created_at * 1000).toISOString()}\n`;

                        await db.prepare(`
                            INSERT INTO patients (
                                id, name, current_phone, birth_date, gender, address,
                                status, sms_consent, email_consent, notes,
                                created_at, updated_at, source, channel
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        `).bind(
                            patientId,
                            lead.name,
                            lead.contact,
                            intakeData.birthdate || null,
                            gender,
                            intakeData.address || null,
                            'inquiry',
                            smsConsent ? 1 : 0,
                            emailConsent ? 1 : 0,
                            notes,
                            lead.created_at,
                            now,
                            'online',
                            'intake_form'
                        ).run();

                        // Link lead to patient
                        await db.prepare("UPDATE leads SET patient_id = ? WHERE id = ?")
                            .bind(patientId, lead.id)
                            .run();
                    }
                }

                // Create intake_submission record (Backfill)
                const intakeId = crypto.randomUUID();
                await db.prepare(`
                    INSERT INTO intake_submissions (
                        id, patient_id, intake_data, submitted_at, status, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?)
                `).bind(
                    intakeId,
                    patientId,
                    lead.intake_data,
                    lead.created_at,
                    'pending',
                    lead.created_at
                ).run();

                // Create timeline event if it doesn't exist (optional check, but good for safety)
                // For simplicity, we'll assume if we are backfilling intake_submissions, we might want to ensure the event exists too.
                // But let's just add it. Duplicate events are less critical than missing ones, or we can skip if patient was already existing.
                // Actually, if we are just backfilling the submission record for the admin view, we might not want to duplicate the event if it was already created during manual conversion.
                // Let's check if an intake event exists.

                const existingEvent = await db.prepare("SELECT id FROM patient_events WHERE patient_id = ? AND type = 'intake'").bind(patientId).first();

                if (!existingEvent) {
                    const eventId = crypto.randomUUID();
                    let eventContent = `방문 목적: ${intakeData.visit_category || '-'}\n`;
                    eventContent += `주요 증상: ${intakeData.main_symptom || '-'}\n`;
                    eventContent += `증상 기간: ${intakeData.duration || '-'}\n`;

                    if (intakeData.herbal_consent) {
                        eventContent += `\n[한약 치료 의사]\n`;
                        eventContent += intakeData.herbal_consent === 'yes' ? '✓ 한약 치료 고려 중\n' : '침 치료만 희망\n';
                    }

                    if (intakeData.referral && intakeData.referral.length > 0) {
                        eventContent += `\n[내원 경로]\n${intakeData.referral.join(', ')}\n`;
                    }

                    if (intakeData.consentMetadata) {
                        eventContent += `\n[동의 내역]\n`;
                        eventContent += `개인정보: ${intakeData.consentMetadata.privacy_consent ? '✓ 동의' : '✗ 미동의'}\n`;
                        eventContent += `마케팅: ${intakeData.consentMetadata.marketing_consent ? '✓ 동의' : '✗ 미동의'}\n`;
                        eventContent += `IP: ${intakeData.consentMetadata.ip}\n`;
                        eventContent += `시각: ${intakeData.consentMetadata.timestamp}`;
                    }

                    await db.prepare(`
                        INSERT INTO patient_events (
                            id, patient_id, type, title, content, event_date, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    `).bind(
                        eventId,
                        patientId,
                        'intake',
                        '초진 접수 문진표',
                        eventContent,
                        lead.created_at,
                        lead.created_at
                    ).run();
                }

                converted++;

            } catch (err: any) {
                errors.push(`Lead ${lead.id}: ${err.message}`);
            }
        }

        return new Response(JSON.stringify({
            success: true,
            total: intakeLeads.length,
            converted,
            skipped,
            errors: errors.length > 0 ? errors : undefined
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Migration Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
