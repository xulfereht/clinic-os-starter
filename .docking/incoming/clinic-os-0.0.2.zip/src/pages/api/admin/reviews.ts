import type { APIRoute } from 'astro';

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const formData = await request.formData();
        const patientId = formData.get('patient_id') as string;
        const doctorId = formData.get('doctor_id') as string;
        const title = formData.get('title') as string;
        let slug = formData.get('slug') as string;
        const excerpt = formData.get('excerpt') as string || null;
        const content = formData.get('content') as string;
        const featuredImage = formData.get('featured_image') as string || null;
        const category = formData.get('category') as string || null;
        const safeCategory = category === "" ? null : category;

        // Generate slug if not provided
        if (!slug) {
            slug = title
                .toLowerCase()
                .replace(/[^a-z0-9가-힣]/g, '-')
                .replace(/-+/g, '-')
                .replace(/^-|-$/g, '')
                + '-' + Date.now();
        }

        // Get Patient's is_sample status
        const patient = await db.prepare("SELECT is_sample FROM patients WHERE id = ?").bind(patientId).first();
        const isSample = patient?.is_sample || 0;

        // Insert review
        const reviewId = crypto.randomUUID();
        await db.prepare(`
            INSERT INTO posts (id, type, title, slug, excerpt, content, doctor_id, patient_id, featured_image, category, created_at, is_sample)
            VALUES (?, 'review', ?, ?, ?, ?, ?, ?, ?, ?, strftime('%s', 'now'), ?)
        `).bind(reviewId, title, slug, excerpt, content, doctorId, patientId, featuredImage, safeCategory, isSample).run();

        return Response.redirect('/admin/reviews?success=review_created', 302);
    } catch (e: any) {
        console.error('Review creation error:', e);
        return Response.redirect('/admin/reviews/new?error=' + encodeURIComponent('후기 생성 중 오류가 발생했습니다'), 302);
    }
};
