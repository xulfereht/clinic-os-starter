import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { leadId, status, consultType, patientType, holdReason, holdMemo } = body;

        if (!leadId || !status) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
        }

        const { staffId } = body; // Optional staffId for tracking

        const now = Math.floor(Date.now() / 1000);
        let query = "UPDATE leads SET status = ?";
        const params: any[] = [status];

        // Also update type if consultType is provided
        if (consultType !== undefined && consultType !== null && consultType !== '') {
            query += ", type = ?";
            params.push(consultType);
        }

        // Also update patient_type if patientType is provided
        if (patientType !== undefined && patientType !== null && patientType !== '') {
            query += ", patient_type = ?";
            params.push(patientType);
        }

        // Store hold reason and memo if provided (for hold statuses)
        if (holdReason) {
            // Get current intake_data and merge hold info
            const currentLead = await db.prepare("SELECT intake_data FROM leads WHERE id = ?").bind(leadId).first();
            let intakeData: any = {};
            try {
                if (currentLead?.intake_data) {
                    intakeData = JSON.parse(currentLead.intake_data as string);
                }
            } catch (e) {
                intakeData = {};
            }
            intakeData.hold_reason = holdReason;
            intakeData.hold_memo = holdMemo || '';
            intakeData.hold_at = now;

            query += ", intake_data = ?";
            params.push(JSON.stringify(intakeData));
        }

        // Status specific timestamp updates
        const closedStatuses = [
            'closed', 'hold', 'cancelled',
            'first_visit_reservation', 'remote_reservation', 'first_visit_hold', 'remote_hold',
            'return_visit_reservation', 'return_visit_payment', 'return_visit_inquiry'
        ];

        if (status === 'consulting') {
            // When moving to processing/consulting
            query += ", consulting_at = CASE WHEN consulting_at IS NULL THEN ? ELSE consulting_at END";
            params.push(now);

            // If moving back from closed, clear closed_at
            query += ", closed_at = NULL";
        } else if (closedStatuses.includes(status)) {
            // When moving to any closed/outcome state
            query += ", closed_at = ?";
            params.push(now);
        } else if (status === 'pending' || status === 'new') {
            // If moving back to pending
            query += ", closed_at = NULL";
        }

        query += " WHERE id = ?";
        params.push(leadId);

        await db.prepare(query).bind(...params).run();

        // Log Event
        if (staffId) {
            try {
                const statusLabels: Record<string, string> = {
                    'new': '신규', 'pending': '대기', 'consulting': '상담중',
                    'closed': '종료(일반)', 'hold': '보류', 'cancelled': '취소',
                    'first_visit_reservation': '초진내원예약',
                    'remote_reservation': '초진비대면예약',
                    'first_visit_hold': '초진보류',
                    'remote_hold': '초진비대면보류',
                    'return_visit_reservation': '재진내원예약',
                    'return_visit_payment': '재진비대면결제',
                    'return_visit_inquiry': '재진단순문의'
                };
                const label = statusLabels[status] || status;

                await db.prepare(`
                    INSERT INTO lead_events (id, lead_id, type, content, staff_id, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                `).bind(
                    crypto.randomUUID(),
                    leadId,
                    'status_change',
                    `상태 변경: ${label}`,
                    staffId,
                    now
                ).run();
            } catch (logErr) {
                console.warn('Failed to log lead event:', logErr);
            }
        }

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        console.error("Update status error:", e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
