
import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;
    const { id } = params;

    try {
        const body = await request.json();
        const { patient_type } = body;

        // Validate
        if (!['new', 'existing_customer'].includes(patient_type)) {
            return new Response(JSON.stringify({ error: 'Invalid patient type' }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);

        // Update
        const { meta } = await db.prepare("UPDATE leads SET patient_type = ?, updated_at = ? WHERE id = ?")
            .bind(patient_type, now, id)
            .run();

        if (meta.changes === 0) {
            return new Response(JSON.stringify({ error: 'Lead not found or no change' }), { status: 404 });
        }

        return new Response(JSON.stringify({ success: true, patient_type }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Update Type Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
