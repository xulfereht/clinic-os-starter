import type { APIRoute } from 'astro';

export const DELETE: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    if (!id) {
        return new Response(JSON.stringify({ error: 'Lead ID is required' }), { status: 400 });
    }

    try {
        // Soft Delete: Mark lead as deleted, preserve event history
        await db.prepare("UPDATE leads SET deleted_at = unixepoch() WHERE id = ?").bind(id).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
