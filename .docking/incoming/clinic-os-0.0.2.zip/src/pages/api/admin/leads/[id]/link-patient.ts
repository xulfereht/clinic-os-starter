export const prerender = false;

export async function POST({ params, request, locals }: { params: any; request: Request; locals: any }) {
    const { id } = params;

    try {
        const { patientId } = await request.json();
        const db = locals.runtime.env.DB;
        const now = Math.floor(Date.now() / 1000);

        if (!patientId) {
            return new Response(JSON.stringify({ error: 'Patient ID is required' }), { status: 400 });
        }

        // Verify patient exists
        const patient = await db.prepare("SELECT name FROM patients WHERE id = ?").bind(patientId).first();
        if (!patient) {
            return new Response(JSON.stringify({ error: 'Patient not found' }), { status: 404 });
        }

        // Update Lead
        await db.prepare("UPDATE leads SET patient_id = ?, updated_at = ? WHERE id = ?")
            .bind(patientId, now, id)
            .run();



        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
