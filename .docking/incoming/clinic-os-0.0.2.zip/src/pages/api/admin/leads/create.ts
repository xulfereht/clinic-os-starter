import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { phone, name, channel, notes, consultType } = body;

        if (!phone) {
            return new Response(JSON.stringify({ error: 'Phone number is required' }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);
        let patientId: string | null = null;
        let isNewPatient = false;

        // 1. Check if patient exists
        const existingPatient = await db.prepare("SELECT * FROM patients WHERE current_phone = ?").bind(phone).first();

        if (existingPatient) {
            patientId = (existingPatient as any).id;
            // Optional: Update name if provided and existing is empty?
            // For now, we just link to the existing patient.
        } else {
            // 2. Do NOT create new patient (Keep DB clean)
            patientId = null;
        }

        // 3. Create Lead
        const leadId = crypto.randomUUID();
        const intakeJson = JSON.stringify({ notes: notes || '', initial_inquiry: true });

        // Auto-detect: existing customer or new lead
        const patientType = existingPatient ? 'existing_customer' : 'new_lead';

        await db.prepare(`
            INSERT INTO leads (
                id, patient_id, type, status, channel, intake_data, name, contact, created_at, updated_at, patient_type, tags, summary
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            leadId,
            patientId, // Can be null
            consultType || 'visit', // Use consultType if provided, default to 'visit'
            'new', // Status: New (Fresh)
            channel || 'phone',
            intakeJson,
            name || '미입력',
            phone,
            now,
            now,
            patientType,  // Auto-detected based on patient DB
            body.tags ? JSON.stringify(body.tags) : null,
            notes || null
        ).run();

        // Get Current Admin
        const adminSessionId = request.headers.get('Cookie')?.match(/admin_session=([^;]+)/)?.[1];
        let staffId = null;
        if (adminSessionId) {
            const session = await db.prepare("SELECT staff_id FROM sessions WHERE id = ? AND expires_at > strftime('%s', 'now')").bind(adminSessionId).first();
            if (session) staffId = session.staff_id;
        }

        // 3.5. Update Patient Tags if provided and patient exists
        if (patientId && body.tags) {
            let newTags: string[] = [];
            if (Array.isArray(body.tags)) newTags = body.tags;
            else if (typeof body.tags === 'string') newTags = [body.tags];

            if (newTags.length > 0) {
                // Parse existing segments
                let currentSegments: string[] = [];
                try {
                    const raw = (existingPatient as any).segments;
                    if (raw) currentSegments = JSON.parse(raw);
                    if (!Array.isArray(currentSegments)) currentSegments = [];
                } catch (e) {
                    currentSegments = [];
                }

                // Merge tags (avoid duplicates)
                const mergedTags = [...new Set([...currentSegments, ...newTags])];

                await db.prepare(`
                    UPDATE patients 
                    SET segments = ?, updated_at = ?, last_activity_at = ? 
                    WHERE id = ?
                `).bind(
                    JSON.stringify(mergedTags),
                    now,
                    now,
                    patientId
                ).run();
            }
        }

        // 4. Create Timeline Event (Only if patient exists)
        if (patientId) {
            const eventId = crypto.randomUUID();
            await db.prepare(`
                INSERT INTO patient_events (
                    id, patient_id, type, summary, description, created_at, created_by, staff_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `).bind(
                eventId,
                patientId,
                'inquiry',
                '추가 문의 등록',
                `경로: ${channel === 'walk_in' ? '내원(워크인)' : '전화'}\n내용: ${notes || '-'}`,
                now,
                'admin',
                staffId
            ).run();
        }

        return new Response(JSON.stringify({
            success: true,
            leadId,
            patientId,
            message: patientId ? '기존 환자에 문의가 등록되었습니다.' : '새로운 문의가 등록되었습니다. 환자 연결이 필요합니다.'
        }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
