export const prerender = false;

export async function POST({ params, request, locals }: { params: any; request: Request; locals: any }) {
    const { id } = params;

    try {
        const db = locals.runtime.env.DB;
        const now = Math.floor(Date.now() / 1000);

        // Update Lead - Set patient_id to NULL
        await db.prepare("UPDATE leads SET patient_id = NULL, updated_at = ? WHERE id = ?")
            .bind(now, id)
            .run();

        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
