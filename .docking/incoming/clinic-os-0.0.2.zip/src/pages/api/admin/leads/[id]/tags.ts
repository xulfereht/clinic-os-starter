import type { APIRoute } from 'astro';

export const PATCH: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    const { id } = params;

    try {
        const body = await request.json();
        const { tags } = body;

        if (!Array.isArray(tags)) {
            return new Response(JSON.stringify({ error: 'Tags must be an array' }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);

        await db.prepare(`
            UPDATE leads 
            SET tags = ?, updated_at = ?
            WHERE id = ?
        `).bind(
            JSON.stringify(tags),
            now,
            id
        ).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });

    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
