import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const { results } = await db.prepare(
            "SELECT * FROM lead_events WHERE lead_id = ? ORDER BY created_at DESC"
        ).bind(id).run();

        return new Response(JSON.stringify({ events: results }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { type, content } = body;

        if (!type) {
            return new Response(JSON.stringify({ error: 'Type is required' }), { status: 400 });
        }

        const eventId = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        // Get Current Admin
        const adminSessionId = request.headers.get('Cookie')?.match(/admin_session=([^;]+)/)?.[1];
        let staffId = null;

        // Handle legacy super admin session
        if (adminSessionId === 'legacy_super_admin') {
            staffId = 'super_admin'; // Use a special ID for legacy admin
        } else if (adminSessionId) {
            const session = await db.prepare("SELECT staff_id FROM sessions WHERE id = ? AND expires_at > strftime('%s', 'now')").bind(adminSessionId).first();
            if (session) staffId = session.staff_id;
        }

        await db.prepare(
            "INSERT INTO lead_events (id, lead_id, type, content, created_at, staff_id) VALUES (?, ?, ?, ?, ?, ?)"
        ).bind(eventId, id, type, content || '', now, staffId).run();

        // Sync to Patient Events if linked
        const lead = await db.prepare("SELECT patient_id FROM leads WHERE id = ?").bind(id).first();
        if (lead && lead.patient_id) {
            await db.prepare(
                `INSERT INTO patient_events (id, patient_id, type, title, content, event_date, created_at, staff_id)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
            ).bind(
                crypto.randomUUID(),
                lead.patient_id,
                'lead_log',
                `상담 기록 (${type === 'call' ? '전화' : type === 'message' ? '문자' : '메모'})`,
                content || '',
                now,
                now,
                staffId
            ).run();
        }

        return new Response(JSON.stringify({
            success: true,
            event: { id: eventId, lead_id: id, type, content, created_at: now }
        }), { status: 200 });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
