export const prerender = false;

export async function POST({ params, request, locals }: { params: any; request: Request; locals: any }) {
    const { id } = params;

    try {
        // Parse body ONCE
        const body = await request.json();
        const { name, contact, birthDate, gender, chartNumber, tags, isWalkIn, reservationData, status: requestedStatus } = body;

        const db = locals.runtime.env.DB;
        const now = Math.floor(Date.now() / 1000);
        const createdBy = locals.user?.id || null;

        // Normalize contact for lookup
        const normalizedContact = contact?.replace(/[^0-9]/g, '') || '';

        // Check if patient exists by phone
        const existing = await db.prepare(
            "SELECT id FROM patients WHERE REPLACE(REPLACE(current_phone, '-', ''), ' ', '') = ?"
        ).bind(normalizedContact).first();

        let patientId = existing?.id;
        let action = 'linked';

        // If patient doesn't exist, create one
        if (!patientId) {
            // Check for duplicate chart number
            if (chartNumber) {
                const existingChart = await db.prepare("SELECT id FROM patients WHERE chart_number = ?").bind(chartNumber).first();
                if (existingChart) {
                    return new Response(JSON.stringify({ error: '이미 존재하는 차트 번호입니다.' }), { status: 409 });
                }
            }

            patientId = crypto.randomUUID();
            const patientStatus = chartNumber ? 'active' : 'inquiry';
            const lifecycle = chartNumber ? 'new_visit' : 'potential';
            const tagsJson = tags && tags.length > 0 ? JSON.stringify(tags) : null;

            await db.prepare(`
                INSERT INTO patients (id, name, current_phone, gender, birth_date, lifecycle_stage, status, chart_number, segments, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).bind(
                patientId,
                name,
                contact,
                gender || null,
                birthDate || null,
                lifecycle,
                patientStatus,
                chartNumber || null,
                tagsJson,
                now,
                now
            ).run();

            action = 'created';
        }

        // ----------------------------------------------------
        // Handle Reservation/Walk-in
        // ----------------------------------------------------
        let reservationId = null;

        if (isWalkIn) {
            // Walk-in: Create reservation with status 'completed' (immediate visit)
            reservationId = crypto.randomUUID();
            await db.prepare(`
                INSERT INTO reservations (id, patient_id, doctor_id, reserved_at, status, notes, created_at, updated_at, created_by)
                VALUES (?, ?, ?, ?, 'completed', '비예약 워크인 내원', ?, ?, ?)
            `).bind(
                reservationId,
                patientId,
                null, // Doctor can be null for walk-ins
                now,  // reserved_at = now (current time)
                now,
                now,
                createdBy
            ).run();
        } else if (reservationData && reservationData.date && reservationData.time) {
            // Normal Reservation
            reservationId = crypto.randomUUID();
            const doctorId = reservationData.doctorId || null;
            const dateTimeStr = `${reservationData.date}T${reservationData.time}:00+09:00`;
            const reservedAt = Math.floor(new Date(dateTimeStr).getTime() / 1000);

            await db.prepare(`
                INSERT INTO reservations (id, patient_id, doctor_id, reserved_at, status, created_at, updated_at, created_by)
                VALUES (?, ?, ?, ?, 'scheduled', ?, ?, ?)
            `).bind(
                reservationId,
                patientId,
                doctorId,
                reservedAt,
                now,
                now,
                createdBy
            ).run();
        }

        // ----------------------------------------------------
        // Update Lead Status & Link
        // ----------------------------------------------------
        const updateStatus = requestedStatus || (reservationId ? 'first_visit_reservation' : 'consulting');

        const closedStatuses = [
            'closed', 'hold', 'cancelled',
            'first_visit_reservation', 'remote_reservation', 'first_visit_hold', 'remote_hold',
            'return_visit_reservation', 'return_visit_payment', 'return_visit_inquiry'
        ];

        let leadUpdateQuery = "UPDATE leads SET patient_id = ?, status = ?, updated_at = ?";
        const leadUpdateParams: any[] = [patientId, updateStatus, now];

        if (closedStatuses.includes(updateStatus)) {
            leadUpdateQuery += ", closed_at = ?";
            leadUpdateParams.push(now);
        }

        leadUpdateQuery += " WHERE id = ?";
        leadUpdateParams.push(id);

        await db.prepare(leadUpdateQuery).bind(...leadUpdateParams).run();

        // ----------------------------------------------------
        // Log Event
        // ----------------------------------------------------
        const eventId = crypto.randomUUID();
        let actionText = action === 'created' ? '환자 차트 생성' : '기존 환자 연동';
        if (reservationId) {
            actionText += isWalkIn ? ' 및 바로 내원 처리' : ' 및 예약 확정';
        }

        await db.prepare(`
            INSERT INTO lead_events (id, lead_id, type, content, staff_id, created_at)
            VALUES (?, ?, 'status_change', ?, ?, ?)
        `).bind(
            eventId,
            id,
            `${actionText}: ${name} (${updateStatus})`,
            createdBy,
            now
        ).run();

        return new Response(JSON.stringify({ success: true, action, patientId, reservationId }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('[convert.ts] Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
