import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // 1. Try to add the column if it doesn't exist
        try {
            await db.prepare("ALTER TABLE patients ADD COLUMN last_shipping_date TEXT").run();
        } catch (e) {
            console.log("Column last_shipping_date likely exists:", e);
        }

        // 2. Backfill last_shipping_date from shipments
        // We find the MAX(shipped_at) for each patient via shipping_orders
        // And update the patient's last_shipping_date

        const result = await db.prepare(`
            UPDATE patients
            SET last_shipping_date = (
                SELECT date(MAX(s.shipped_at), 'unixepoch', 'localtime')
                FROM shipments s
                JOIN shipping_orders so ON s.shipping_order_id = so.id
                WHERE so.patient_id = patients.id
                AND s.status = 'shipped'
            )
            WHERE deleted_at IS NULL
        `).run();

        return new Response(JSON.stringify({
            success: true,
            message: `Schema updated & Last Shipping Dates backfilled`,
            result
        }), { status: 200 });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
