import type { APIRoute } from 'astro';

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response('Database not available', { status: 500 });
    }

    try {
        const { is_visible } = await request.json();

        await db.prepare("UPDATE programs SET is_visible = ? WHERE id = ?")
            .bind(is_visible ? 1 : 0, id)
            .run();

        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
