import type { APIRoute } from 'astro';

export const PATCH: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { title, content, eventType, event_date } = body;

        const updates: string[] = [];
        const queryParams: any[] = [];

        if (title !== undefined) {
            updates.push("title = ?");
            queryParams.push(title);
        }
        if (content !== undefined) {
            updates.push("content = ?");
            queryParams.push(content);
        }
        if (eventType !== undefined) {
            updates.push("type = ?");
            queryParams.push(eventType);
        }
        if (event_date) {
            const timestamp = Math.floor(new Date(event_date).getTime() / 1000);
            updates.push("event_date = ?");
            queryParams.push(timestamp);
        }

        if (updates.length === 0) {
            return new Response(JSON.stringify({ error: 'No fields to update' }), { status: 400 });
        }

        const query = `UPDATE patient_events SET ${updates.join(", ")} WHERE id = ?`;
        queryParams.push(id);

        const res = await db.prepare(query).bind(...queryParams).run();

        if (res.meta.changes === 0) {
            return new Response(JSON.stringify({ error: 'Event not found' }), { status: 404 });
        }

        return new Response(JSON.stringify({ success: true }));
    } catch (e: any) {
        console.error('Update event error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    const { id } = params;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // Soft delete
        const res = await db.prepare("UPDATE patient_events SET deleted_at = unixepoch() WHERE id = ?").bind(id).run();

        if (res.meta.changes === 0) {
            return new Response(JSON.stringify({ error: 'Event not found' }), { status: 404 });
        }

        return new Response(JSON.stringify({ success: true }));
    } catch (e: any) {
        console.error('Delete event error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
