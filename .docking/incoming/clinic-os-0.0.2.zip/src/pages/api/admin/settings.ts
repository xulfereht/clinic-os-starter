export const prerender = false;

import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    const category = url.searchParams.get('category');

    let query = 'SELECT category, key, value, updated_at FROM site_settings';
    const params: string[] = [];

    if (category) {
        query += ' WHERE category = ?';
        params.push(category);
    }

    query += ' ORDER BY category, key';

    const { results } = await db.prepare(query).bind(...params).run();

    return new Response(JSON.stringify(results), {
        headers: { 'Content-Type': 'application/json' }
    });
};

export const PUT: APIRoute = async ({ locals, request }) => {
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const { category, key, value } = await request.json();

        if (!category || !key) {
            return new Response(JSON.stringify({ error: 'Category and key are required' }), { status: 400 });
        }

        // Upsert: Update if exists, insert if not
        await db.prepare(`
            INSERT INTO site_settings (category, key, value, updated_at)
            VALUES (?, ?, ?, unixepoch())
            ON CONFLICT(category, key) 
            DO UPDATE SET value = excluded.value, updated_at = unixepoch()
        `).bind(category, key, value || '').run();

        const updated = await db.prepare(
            'SELECT category, key, value, updated_at FROM site_settings WHERE category = ? AND key = ?'
        ).bind(category, key).first();

        return new Response(JSON.stringify(updated), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Error updating setting:', error);
        return new Response(JSON.stringify({ error: 'Failed to update setting' }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ locals, request }) => {
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const { settings } = await request.json();

        if (!Array.isArray(settings)) {
            return new Response(JSON.stringify({ error: 'Settings must be an array' }), { status: 400 });
        }

        // Bulk update
        for (const { category, key, value } of settings) {
            if (!category || !key) continue;

            await db.prepare(`
                INSERT INTO site_settings (category, key, value, updated_at)
                VALUES (?, ?, ?, unixepoch())
                ON CONFLICT(category, key) 
                DO UPDATE SET value = excluded.value, updated_at = unixepoch()
            `).bind(category, key, value || '').run();
        }

        return new Response(JSON.stringify({ success: true, updated: settings.length }), {
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Error bulk updating settings:', error);
        return new Response(JSON.stringify({ error: 'Failed to bulk update settings' }), { status: 500 });
    }
};
