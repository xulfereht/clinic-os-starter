import type { APIRoute } from 'astro';

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const formData = await request.formData();
        const type = formData.get('type') as string; // 'blog', 'column', 'notice'
        const doctorIdRaw = formData.get('doctor_id') as string;
        const doctorId = doctorIdRaw && doctorIdRaw.trim() !== '' ? doctorIdRaw : null; // Convert empty to null
        const title = formData.get('title') as string;
        let slug = formData.get('slug') as string;
        const excerpt = formData.get('excerpt') as string || null;
        const content = formData.get('content') as string;
        const featuredImage = formData.get('featured_image') as string || null;

        const category = formData.get('category') as string || null;

        // Generate slug if not provided
        if (!slug) {
            slug = title
                .toLowerCase()
                .replace(/[^a-z0-9가-힣]/g, '-')
                .replace(/-+/g, '-')
                .replace(/^-|-$/g, '')
                + '-' + Date.now();
        }

        // Insert post - let SQLite auto-generate INTEGER PRIMARY KEY
        const status = formData.get('status') as string || 'published'; // Default to published
        const result = await db.prepare(`
            INSERT INTO posts (type, title, slug, excerpt, content, doctor_id, featured_image, category, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, strftime('%s', 'now'))
        `).bind(type, title, slug, excerpt, content, doctorId, featuredImage, category, status).run();

        // Return JSON for API calls, redirect for form submissions
        const acceptHeader = request.headers.get('Accept') || '';
        if (acceptHeader.includes('application/json')) {
            return new Response(JSON.stringify({ success: true, id: result.meta.last_row_id }), {
                status: 201,
                headers: { 'Content-Type': 'application/json' }
            });
        }
        return Response.redirect('/admin/posts?success=post_created', 302);
    } catch (e: any) {
        console.error('Post creation error:', e);

        const acceptHeader = request.headers.get('Accept') || '';
        if (acceptHeader.includes('application/json')) {
            return new Response(JSON.stringify({ error: e.message || '글 생성 중 오류가 발생했습니다' }), { status: 500 });
        }
        return Response.redirect('/admin/posts/new?error=' + encodeURIComponent('글 생성 중 오류가 발생했습니다'), 302);
    }
};
