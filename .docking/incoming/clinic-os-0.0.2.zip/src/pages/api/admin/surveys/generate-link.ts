import type { APIRoute } from 'astro';
import { SURVEY_LIBRARY, SURVEY_PANELS } from '../../../../lib/survey-registry';
import { generateSignedUrl } from '../../../../lib/crypto';

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const body = await request.json();
        const { patientId, surveyId } = body;

        if (!patientId || !surveyId) {
            return new Response(JSON.stringify({ error: 'Missing parameters' }), { status: 400 });
        }

        // Find Survey
        let pathTemplate = '';
        const libItem = SURVEY_LIBRARY.find(s => s.id === surveyId);
        if (libItem) {
            pathTemplate = libItem.pathTemplate;
        } else if (SURVEY_PANELS[surveyId]) {
            pathTemplate = `/surveys/[patient_id]/panel/${surveyId}`;
        }

        if (!pathTemplate) {
            return new Response(JSON.stringify({ error: 'Survey not found' }), { status: 404 });
        }

        const path = pathTemplate.replace('[patient_id]', patientId);
        const origin = new URL(request.url).origin;
        const fullUrl = origin + path;

        // Use secret from env or fallback
        // @ts-ignore
        const secret = locals.runtime?.env?.JWT_SECRET || 'clinic-survey-secret-key-2025';

        // Generate Signed URL (24 hours expiration)
        const signedUrl = await generateSignedUrl(fullUrl, secret, 24 * 60);

        return new Response(JSON.stringify({ url: signedUrl }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        console.error('Error generating signed link:', e);
        return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
    }
};
