export const prerender = false;

import type { APIRoute } from "astro";

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), {
            status: 500,
            headers: { "Content-Type": "application/json" },
        });
    }

    try {
        const data = await request.json();

        // Basic validation
        if (!data.name || !data.questions || !data.result_templates_json) {
            return new Response(JSON.stringify({ error: "Missing required fields" }), {
                status: 400,
                headers: { "Content-Type": "application/json" },
            });
        }

        const id = data.id || crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);

        // Prepare the insert statement
        const stmt = db.prepare(`
      INSERT INTO self_diagnosis_templates (
        id, name, description, type, program_id,
        questions, calculation_script, result_templates_json, cta_config,
        estimated_time, status, created_at, updated_at
      ) VALUES (
        ?, ?, ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?, ?, ?
      )
    `);

        // Execute insert
        await stmt.bind(
            id,
            data.name,
            data.description || "",
            data.type || "custom",
            data.program_id || null,
            JSON.stringify(data.questions),
            data.calculation_script || "",
            JSON.stringify(data.result_templates_json),
            JSON.stringify(data.cta_config || {}),
            data.estimated_time || 5,
            data.status || "active",
            now,
            now
        ).run();

        return new Response(JSON.stringify({ success: true, id }), {
            status: 200,
            headers: { "Content-Type": "application/json" },
        });

    } catch (e: any) {
        console.error("Error creating diagnosis template:", e);
        return new Response(JSON.stringify({ error: e.message }), {
            status: 500,
            headers: { "Content-Type": "application/json" },
        });
    }
};
