import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT * FROM clinic_holidays WHERE date >= date('now') ORDER BY date ASC`
        ).run();

        return new Response(JSON.stringify(results), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const data = await request.json();

        // Import Action
        if (data.action === 'import') {
            const year = data.year || new Date().getFullYear();

            // Year-specific holidays (음력 기반 명절은 매년 다름)
            const holidaysByYear: Record<number, Array<{ date: string; description: string }>> = {
                2025: [
                    { date: '2025-01-01', description: '신정' },
                    { date: '2025-01-28', description: '설날 연휴' },
                    { date: '2025-01-29', description: '설날' },
                    { date: '2025-01-30', description: '설날 연휴' },
                    { date: '2025-03-01', description: '삼일절' },
                    { date: '2025-03-03', description: '대체공휴일(삼일절)' },
                    { date: '2025-05-05', description: '어린이날' },
                    { date: '2025-05-06', description: '대체공휴일(어린이날)' },
                    { date: '2025-06-06', description: '현충일' },
                    { date: '2025-08-15', description: '광복절' },
                    { date: '2025-10-03', description: '개천절' },
                    { date: '2025-10-05', description: '추석 연휴' },
                    { date: '2025-10-06', description: '추석' },
                    { date: '2025-10-07', description: '추석 연휴' },
                    { date: '2025-10-08', description: '대체공휴일(추석)' },
                    { date: '2025-10-09', description: '한글날' },
                    { date: '2025-12-25', description: '성탄절' },
                ],
                2026: [
                    { date: '2026-01-01', description: '신정' },
                    { date: '2026-02-16', description: '설날 연휴' },
                    { date: '2026-02-17', description: '설날' },
                    { date: '2026-02-18', description: '설날 연휴' },
                    { date: '2026-03-01', description: '삼일절' },
                    { date: '2026-03-02', description: '대체공휴일(삼일절)' },
                    { date: '2026-05-05', description: '어린이날' },
                    { date: '2026-05-24', description: '석가탄신일' },
                    { date: '2026-05-25', description: '대체공휴일(석가탄신일)' },
                    { date: '2026-06-06', description: '현충일' },
                    { date: '2026-08-15', description: '광복절' },
                    { date: '2026-08-17', description: '대체공휴일(광복절)' },
                    { date: '2026-09-24', description: '추석 연휴' },
                    { date: '2026-09-25', description: '추석' },
                    { date: '2026-09-26', description: '추석 연휴' },
                    { date: '2026-10-03', description: '개천절' },
                    { date: '2026-10-05', description: '대체공휴일(개천절)' },
                    { date: '2026-10-09', description: '한글날' },
                    { date: '2026-12-25', description: '성탄절' },
                ],
            };

            const holidays = holidaysByYear[year];
            if (!holidays) {
                return new Response(JSON.stringify({
                    error: `${year}년 공휴일 데이터가 없습니다. 수동으로 추가해주세요.`
                }), { status: 400 });
            }

            const batch = holidays.map(h =>
                locals.runtime.env.DB.prepare(
                    `INSERT INTO clinic_holidays (date, description) VALUES (?, ?)
                     ON CONFLICT(date) DO UPDATE SET description = excluded.description`
                ).bind(h.date, h.description)
            );

            await locals.runtime.env.DB.batch(batch);
            return new Response(JSON.stringify({ message: `${year}년 공휴일 ${holidays.length}개 가져오기 완료` }), { status: 200 });
        }

        // Normal Add Action
        const { date, description } = data;
        await locals.runtime.env.DB.prepare(
            `INSERT INTO clinic_holidays (date, description) VALUES (?, ?)
             ON CONFLICT(date) DO UPDATE SET description = excluded.description`
        ).bind(date, description).run();

        return new Response(JSON.stringify({ message: 'Added' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ request, locals }) => {
    try {
        const url = new URL(request.url);
        const id = url.searchParams.get('id');

        if (!id) {
            return new Response(JSON.stringify({ error: 'ID is required' }), { status: 400 });
        }

        await locals.runtime.env.DB.prepare(
            `DELETE FROM clinic_holidays WHERE id = ?`
        ).bind(id).run();

        return new Response(JSON.stringify({ message: 'Holiday deleted' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
