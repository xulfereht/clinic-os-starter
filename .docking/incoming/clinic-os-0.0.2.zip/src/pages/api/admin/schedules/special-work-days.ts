import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT * FROM clinic_special_work_days ORDER BY date ASC`
        ).run();
        return new Response(JSON.stringify(results), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const { date, description } = await request.json();
        await locals.runtime.env.DB.prepare(
            `INSERT INTO clinic_special_work_days (date, description) VALUES (?, ?)
             ON CONFLICT(date) DO UPDATE SET description = excluded.description`
        ).bind(date, description).run();

        return new Response(JSON.stringify({ message: 'Added' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ url, locals }) => {
    try {
        const id = url.searchParams.get('id');
        if (!id) return new Response('ID required', { status: 400 });

        await locals.runtime.env.DB.prepare(
            `DELETE FROM clinic_special_work_days WHERE id = ?`
        ).bind(id).run();

        return new Response(JSON.stringify({ message: 'Deleted' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
