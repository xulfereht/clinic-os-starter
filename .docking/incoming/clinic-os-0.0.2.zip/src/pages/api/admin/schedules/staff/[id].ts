import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT * FROM staff_schedules WHERE staff_id = ? ORDER BY day_of_week ASC`
        ).bind(id).run();

        // If no schedule exists, return default (Mon-Fri 9-6)
        if (results.length === 0) {
            const defaultSchedule = Array.from({ length: 7 }, (_, i) => ({
                day_of_week: i,
                start_time: '09:00',
                end_time: '18:00',
                is_working: i >= 1 && i <= 5 // Mon-Fri
            }));
            return new Response(JSON.stringify(defaultSchedule), { status: 200 });
        }

        return new Response(JSON.stringify(results), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    try {
        const schedules = await request.json(); // Array of schedule objects

        const batch = schedules.map((s: any) =>
            locals.runtime.env.DB.prepare(
                `INSERT INTO staff_schedules (staff_id, day_of_week, start_time, end_time, is_working)
                 VALUES (?, ?, ?, ?, ?)
                 ON CONFLICT(staff_id, day_of_week) DO UPDATE SET
                 start_time = excluded.start_time,
                 end_time = excluded.end_time,
                 is_working = excluded.is_working`
            ).bind(id, s.day_of_week, s.start_time, s.end_time, s.is_working)
        );

        await locals.runtime.env.DB.batch(batch);

        return new Response(JSON.stringify({ message: 'Schedule updated' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
