import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT * FROM clinic_weekly_schedules ORDER BY day_of_week ASC`
        ).run();
        return new Response(JSON.stringify(results), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const PUT: APIRoute = async ({ request, locals }) => {
    const db = locals.runtime.env.DB;

    try {
        const schedules = await request.json();

        // Try to add lunch columns if they don't exist (idempotent)
        try {
            await db.prepare(`ALTER TABLE clinic_weekly_schedules ADD COLUMN lunch_start TEXT DEFAULT '13:00'`).run();
        } catch (e) { /* column exists */ }

        try {
            await db.prepare(`ALTER TABLE clinic_weekly_schedules ADD COLUMN lunch_end TEXT DEFAULT '14:00'`).run();
        } catch (e) { /* column exists */ }

        // Now update with all fields
        const batch = schedules.map((s: any) =>
            db.prepare(
                `UPDATE clinic_weekly_schedules 
                 SET is_closed = ?, open_time = ?, close_time = ?, lunch_start = ?, lunch_end = ?, updated_at = unixepoch()
                 WHERE day_of_week = ?`
            ).bind(
                s.is_closed ? 1 : 0,
                s.open_time || '09:00',
                s.close_time || '18:00',
                s.lunch_start || '13:00',
                s.lunch_end || '14:00',
                s.day_of_week
            )
        );

        await db.batch(batch);
        return new Response(JSON.stringify({ message: 'Updated' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
