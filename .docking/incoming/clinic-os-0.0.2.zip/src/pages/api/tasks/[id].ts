import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT t.*, s.name as assignee_name 
       FROM tasks t 
       LEFT JOIN staff s ON t.assignee_id = s.id 
       WHERE t.id = ?`
        ).bind(id).run();

        if (!results.length) {
            return new Response(JSON.stringify({ error: 'Task not found' }), { status: 404 });
        }

        return new Response(JSON.stringify(results[0]), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    try {
        const data = await request.json();
        const allowedFields = ['title', 'description', 'content', 'status', 'assignee_id', 'due_date', 'frequency', 'subtasks'];
        const updates: string[] = [];
        const values: any[] = [];

        for (const key of Object.keys(data)) {
            if (allowedFields.includes(key)) {
                updates.push(`${key} = ?`);
                values.push(data[key]);
            }
        }

        if (updates.length === 0) {
            return new Response(JSON.stringify({ message: 'No valid fields to update' }), { status: 400 });
        }

        if (data.frequency) {
            updates.push('last_generated = ?');
            values.push(data.frequency !== 'once' ? Math.floor(Date.now() / 1000) : null);
        }

        updates.push('updated_at = unixepoch()');
        values.push(id);

        const query = `UPDATE tasks SET ${updates.join(', ')} WHERE id = ?`;

        await locals.runtime.env.DB.prepare(query).bind(...values).run();

        return new Response(JSON.stringify({ message: 'Task updated' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    try {
        await locals.runtime.env.DB.prepare(
            `UPDATE tasks SET deleted_at = unixepoch() WHERE id = ?`
        ).bind(id).run();

        return new Response(JSON.stringify({ message: 'Task deleted' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
