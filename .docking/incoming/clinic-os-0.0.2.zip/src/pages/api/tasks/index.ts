import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT t.*, s.name as assignee_name 
       FROM tasks t 
       LEFT JOIN staff s ON t.assignee_id = s.id 
       ORDER BY t.status, t.due_date`
        ).run();

        return new Response(JSON.stringify(results), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const data = await request.json();
        const { title, description, content, assignee_id, due_date, created_by, frequency, subtasks } = data;
        const id = crypto.randomUUID();
        const isRecurring = frequency && frequency !== 'once';

        await locals.runtime.env.DB.prepare(
            `INSERT INTO tasks (id, title, description, content, assignee_id, due_date, created_by, frequency, subtasks, last_generated) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).bind(
            id, title, description, content, assignee_id, due_date, created_by,
            frequency || 'once', subtasks || '[]',
            isRecurring ? Math.floor(Date.now() / 1000) : null
        ).run();

        return new Response(JSON.stringify({ id, message: 'Task created' }), { status: 201 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
