import type { APIRoute } from 'astro';
export const prerender = false;
import type { IntakePayload, IntakeResponse } from '../../lib/intake-schema';

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        let payload: any;
        try {
            payload = await request.json();
        } catch (e) {
            return new Response(JSON.stringify({ status: "error", message: "Invalid JSON" }), { status: 400 });
        }

        console.log("Received Payload:", JSON.stringify(payload, null, 2));

        const { patient, meta, chiefComplaints, context, channel: explicitChannel } = payload;
        const leadType = meta?.leadType || "unknown";
        const summary = chiefComplaints?.[0]?.description || "";
        const id = crypto.randomUUID();

        // Determine channel: Explicit > Meta > Default
        const channel = explicitChannel || meta?.channel || 'intake_form';

        // Insert into leads table
        // @ts-ignore
        if (locals.runtime?.env?.DB) {
            const db = locals.runtime.env.DB;

            // Map fields to leads table
            // Table schema: id, name, contact, type, patient_type, symptoms, visit_date, status, created_at
            const name = patient?.name || "Anonymous";
            const contact = patient?.contact?.phone || "";
            const type = meta?.serviceType || "visit";
            const patientType = meta?.patientType || "new";
            const visitDate = context?.preferredTime || null;

            // Normalize contact for matching (remove hyphens and spaces)
            const normalizedContact = contact.replace(/[^0-9]/g, '');

            // Check for existing patient using normalized phone match
            let patientId = null;

            // Try precise match first, then normalized match
            // SQLite REPLACE(col, '-', '') helps matching formatted numbers in DB against unformatted input
            const existingPatient = await db.prepare(`
                SELECT id FROM patients 
                WHERE REPLACE(REPLACE(current_phone, '-', ''), ' ', '') = ?
            `).bind(normalizedContact).first();

            if (existingPatient) {
                console.log(`[Intake] Found existing patient: ${existingPatient.id} for contact ${normalizedContact}`);
                patientId = existingPatient.id;
            } else {
                console.log(`[Intake] No existing patient found for contact: ${contact} (normalized: ${normalizedContact})`);
            }

            await db.prepare(
                `INSERT INTO leads (id, name, contact, type, patient_type, symptoms, visit_date, summary, status, created_at, patient_id, intake_data, channel) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
            ).bind(
                id,
                name,
                contact,
                type,
                patientType,
                JSON.stringify([]), // symptoms
                visitDate,
                summary, // summary
                "new",
                Math.floor(Date.now() / 1000),
                patientId,
                JSON.stringify({
                    first_message: summary,
                    visit_category: type === 'refund' ? '환불/취소' : type,
                    patient_type: patientType === 'returning' ? '재진' : '초진'
                }),
                channel
            ).run();

            // Sync to Patient Events if linked
            if (patientId) {
                await db.prepare(
                    `INSERT INTO patient_events (id, patient_id, type, title, content, event_date, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?)`
                ).bind(
                    crypto.randomUUID(),
                    patientId,
                    'lead_created',
                    '상담 접수',
                    summary || '신규 상담이 접수되었습니다.',
                    Math.floor(Date.now() / 1000),
                    Math.floor(Date.now() / 1000)
                ).run();
                console.log(`[Intake] Synced to patient_events for patient: ${patientId}`);
            }
        }

        return new Response(JSON.stringify({
            status: "ok",
            message: "Lead created",
            leadId: id
        }), { status: 200 });

    } catch (err: any) {
        console.error("API Error:", err);
        return new Response(JSON.stringify({ status: "error", message: err.message }), { status: 500 });
    }
};
