import type { APIRoute } from 'astro';

/**
 * 카카오 i 오픈빌더 스킬 웹훅 핸들러
 * 
 * 카카오톡 채널로 들어온 메시지를 받아서:
 * 1. 리드로 저장
 * 2. 자동 응답 메시지 반환 (5초 이내)
 * 
 * 실제 상담은 카카오톡 채널 관리자에서 진행
 */
export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({
            version: "2.0",
            template: { outputs: [{ simpleText: { text: "시스템 오류가 발생했습니다." } }] }
        }), {
            status: 200,  // 카카오는 200 응답 필요
            headers: { 'Content-Type': 'application/json' }
        });
    }

    // Check if Kakao integration is enabled
    try {
        const clinicResult = await db.prepare("SELECT integrations FROM clinics WHERE id = 1").first();
        if (clinicResult?.integrations) {
            const integrations = JSON.parse(clinicResult.integrations as string);
            if (!integrations.kakao?.enabled) {
                console.log('[Kakao Webhook] Integration not enabled');
                return new Response(JSON.stringify({
                    version: "2.0",
                    template: { outputs: [{ simpleText: { text: "현재 카카오톡 상담 서비스를 준비 중입니다." } }] }
                }), {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
        }
    } catch (e) {
        console.error('[Kakao Webhook] Failed to check integration status:', e);
    }

    try {
        const body = await request.json();

        // 카카오 i 오픈빌더 payload 파싱
        const userRequest = body.userRequest || {};
        const user = userRequest.user || {};
        const utterance = userRequest.utterance || '';  // 사용자가 입력한 메시지
        const kakaoUserId = user.id || '';  // 카카오 user_key

        // 추가 정보 (있으면)
        const params = body.action?.params || {};
        const clientExtra = body.action?.clientExtra || {};

        const now = Math.floor(Date.now() / 1000);

        // 1. 기존 카카오 사용자인지 확인
        let existingKakaoUser = await db.prepare(
            "SELECT * FROM kakao_users WHERE kakao_user_id = ?"
        ).bind(kakaoUserId).first();

        let kakaoUserDbId: string;

        if (!existingKakaoUser) {
            // 새 카카오 사용자 등록
            kakaoUserDbId = crypto.randomUUID();
            await db.prepare(`
                INSERT INTO kakao_users (id, kakao_user_id, first_message_at, last_message_at, message_count)
                VALUES (?, ?, ?, ?, 1)
            `).bind(kakaoUserDbId, kakaoUserId, now, now).run();
        } else {
            kakaoUserDbId = (existingKakaoUser as any).id;
            // 메시지 횟수 업데이트
            await db.prepare(`
                UPDATE kakao_users SET last_message_at = ?, message_count = message_count + 1 WHERE id = ?
            `).bind(now, kakaoUserDbId).run();
        }

        // 2. 메시지 저장
        const messageId = crypto.randomUUID();
        await db.prepare(`
            INSERT INTO kakao_messages (id, kakao_user_id, direction, content, created_at)
            VALUES (?, ?, 'inbound', ?, ?)
        `).bind(messageId, kakaoUserDbId, utterance, now).run();

        // 3. 리드 생성 (첫 메시지이거나 마지막 메시지로부터 24시간 이상 지났으면)
        const lastLead = await db.prepare(`
            SELECT * FROM leads WHERE channel = 'kakao' AND contact = ? 
            ORDER BY created_at DESC LIMIT 1
        `).bind(kakaoUserId).first();

        const shouldCreateNewLead = !lastLead ||
            (now - ((lastLead as any).created_at || 0)) > 86400;  // 24시간

        if (shouldCreateNewLead) {
            const leadId = crypto.randomUUID();
            const intakeData = JSON.stringify({
                kakao_user_id: kakaoUserId,
                first_message: utterance,
                source: 'kakao_channel'
            });

            await db.prepare(`
                INSERT INTO leads (
                    id, type, status, channel, intake_data, name, contact, created_at, updated_at, patient_type
                ) VALUES (?, 'chat', 'new', 'kakao', ?, ?, ?, ?, ?, 'new')
            `).bind(
                leadId,
                intakeData,
                '카카오톡 문의',  // 이름 대신 채널 표시
                kakaoUserId,  // 카카오 user_id를 contact로
                now,
                now
            ).run();

            // 리드 이벤트 로깅
            await db.prepare(`
                INSERT INTO lead_events (id, lead_id, event_type, data, created_at)
                VALUES (?, ?, 'created', ?, ?)
            `).bind(
                crypto.randomUUID(),
                leadId,
                JSON.stringify({ source: 'kakao_webhook', message: utterance }),
                now
            ).run();
        } else {
            // 기존 리드에 메시지 추가 기록
            const leadId = (lastLead as any).id;
            await db.prepare(`
                INSERT INTO lead_events (id, lead_id, event_type, data, created_at)
                VALUES (?, ?, 'message_received', ?, ?)
            `).bind(
                crypto.randomUUID(),
                leadId,
                JSON.stringify({ message: utterance }),
                now
            ).run();

            // 리드 업데이트 시간 갱신
            await db.prepare(`
                UPDATE leads SET updated_at = ? WHERE id = ?
            `).bind(now, leadId).run();
        }

        // 4. 카카오 응답 (5초 이내 필수)
        return new Response(JSON.stringify({
            version: "2.0",
            template: {
                outputs: [
                    {
                        simpleText: {
                            text: "문의가 접수되었습니다.\n잠시 후 상담원이 카카오톡으로 답변 드리겠습니다. 😊"
                        }
                    }
                ]
            }
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Kakao webhook error:', e);

        // 에러 시에도 응답은 해야 함
        return new Response(JSON.stringify({
            version: "2.0",
            template: {
                outputs: [
                    {
                        simpleText: {
                            text: "문의가 접수되었습니다. 곧 연락드리겠습니다."
                        }
                    }
                ]
            }
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};

// GET: 웹훅 테스트용
export const GET: APIRoute = async () => {
    return new Response(JSON.stringify({
        status: 'ok',
        message: 'Kakao webhook endpoint is ready'
    }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
    });
};
