import type { APIRoute } from 'astro';

export const prerender = false;

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { title, slug, content, author_id, type, status, category, doctor_id, patient_id } = body;

        // Convert empty strings and undefined to null for FKs and nullable fields
        const safeAuthorId = author_id || null;
        const safeCategory = category || null;
        const safeDoctorId = doctor_id || null;
        const safePatientId = patient_id || null;

        await db.prepare(
            "UPDATE posts SET title = ?, slug = ?, content = ?, author_id = ?, type = ?, status = ?, category = ?, doctor_id = ?, patient_id = ?, updated_at = strftime('%s', 'now') WHERE id = ?"
        ).bind(title, slug, content, safeAuthorId, type, status, safeCategory, safeDoctorId, safePatientId, id).run();

        return new Response(JSON.stringify({ status: "ok" }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        await db.prepare("DELETE FROM posts WHERE id = ?").bind(id).run();
        return new Response(JSON.stringify({ status: "ok" }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
