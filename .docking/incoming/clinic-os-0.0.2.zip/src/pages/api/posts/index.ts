import type { APIRoute } from 'astro';

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { title, slug, content, author_id, type, status, category } = body;

        // Convert empty strings to null for FKs and nullable fields
        const safeAuthorId = author_id === "" ? null : author_id;
        const safeCategory = category === "" ? null : category;

        await db.prepare(
            "INSERT INTO posts (title, slug, content, author_id, type, status, category) VALUES (?, ?, ?, ?, ?, ?, ?)"
        ).bind(title, slug, content, safeAuthorId, type, status, safeCategory).run();

        return new Response(JSON.stringify({ status: "ok" }), { status: 201 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
