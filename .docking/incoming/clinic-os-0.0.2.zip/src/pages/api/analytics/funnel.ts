import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
  const db = locals.runtime.env.DB;
  const startDate = url.searchParams.get('startDate') || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
  const endDate = url.searchParams.get('endDate') || new Date().toISOString();

  // 1. Inquiry Count (Leads + Patients created in range)
  const inquiryQuery = `
    SELECT COUNT(*) as count 
    FROM leads 
    WHERE created_at BETWEEN ? AND ?
  `;
  // Simplify: Assuming leads timestamp is unix epoch in seconds or ms? Schema says unixepoch() so seconds.
  // JavaScript Date / 1000 for seconds.
  const startSec = Math.floor(new Date(startDate).getTime() / 1000);
  const endSec = Math.floor(new Date(endDate).getTime() / 1000);

  const { results: inquiryKey } = await db.prepare(`SELECT COUNT(*) as count FROM leads WHERE created_at BETWEEN ? AND ? AND deleted_at IS NULL`).bind(startSec, endSec).run();
  const inquiryCount = inquiryKey[0].count as number;

  // 2. Reservation Count (First reservations in range)
  const reservationQuery = `
    SELECT COUNT(*) as count 
    FROM reservations 
    WHERE reserved_at BETWEEN ? AND ? 
    AND status != 'cancelled'
    AND deleted_at IS NULL
  `;
  const { results: resKey } = await db.prepare(reservationQuery).bind(startSec, endSec).run();
  const reservationCount = resKey[0].count as number;

  // 3. Visit Count (Completed reservations or Visits in event log)
  // We can count 'completed' reservations
  const visitQuery = `
    SELECT COUNT(*) as count 
    FROM reservations 
    WHERE reserved_at BETWEEN ? AND ? 
    AND status = 'completed'
    AND deleted_at IS NULL
  `;
  const { results: visitKey } = await db.prepare(visitQuery).bind(startSec, endSec).run();
  const visitCount = visitKey[0].count as number;

  // 4. Payment Count
  const paymentQuery = `
    SELECT COUNT(DISTINCT patient_id) as count, SUM(amount) as total_revenue
    FROM payments 
    WHERE paid_at BETWEEN ? AND ? 
    AND status = 'completed'
    AND deleted_at IS NULL
  `;
  const { results: payKey } = await db.prepare(paymentQuery).bind(startSec, endSec).run();
  const paymentCount = payKey[0].count as number;
  const totalRevenue = payKey[0].total_revenue as number;

  // Calculate Rates
  const rates = {
    inquiry_to_reservation: inquiryCount > 0 ? (reservationCount / inquiryCount) * 100 : 0,
    reservation_to_visit: reservationCount > 0 ? (visitCount / reservationCount) * 100 : 0,
    visit_to_payment: visitCount > 0 ? (paymentCount / visitCount) * 100 : 0,
  };

  return new Response(JSON.stringify({
    counts: {
      inquiries: inquiryCount,
      reservations: reservationCount,
      visits: visitCount,
      payments: paymentCount,
      revenue: totalRevenue || 0
    },
    rates
  }), {
    status: 200,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};
