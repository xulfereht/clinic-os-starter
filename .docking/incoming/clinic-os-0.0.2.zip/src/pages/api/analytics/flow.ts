import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;

    // Date Range Params (Default: Today)
    const now = new Date();
    const startParam = url.searchParams.get('startDate'); // YYYY-MM-DD
    const endParam = url.searchParams.get('endDate');     // YYYY-MM-DD

    // Maturity Window: Days to wait before considering a lead "mature" for conversion analysis
    // Default: 7 days (based on p90 conversion time analysis)
    const maturityWindowDays = parseInt(url.searchParams.get('maturityWindow') || '7', 10);

    // Helper: Parse YYYY-MM-DD to Unix Timestamp
    const parseDateToUnix = (dateStr: string | null, isEnd = false) => {
        if (!dateStr) {
            const d = new Date();
            d.setHours(isEnd ? 23 : 0, isEnd ? 59 : 0, 0, 0);
            return Math.floor(d.getTime() / 1000);
        }
        const d = new Date(dateStr);
        if (isEnd) d.setHours(23, 59, 59, 999);
        else d.setHours(0, 0, 0, 0);
        return Math.floor(d.getTime() / 1000);
    };

    const startTs = parseDateToUnix(startParam);
    const endTs = parseDateToUnix(endParam, true);

    // Calculate mature cohort cutoff: endTs - maturityWindowDays
    // Only leads created BEFORE this cutoff are considered "mature" for conversion analysis
    const matureCutoffTs = endTs - (maturityWindowDays * 86400);

    try {
        // 1. Total Inquiries (Leads) - ALL leads in range (includes fresh)
        const { results: inquiryStats } = await db.prepare(`
            SELECT l.channel, COUNT(*) as count 
            FROM leads l
            LEFT JOIN patients p ON l.patient_id = p.id
            WHERE l.created_at BETWEEN ? AND ?
            AND l.deleted_at IS NULL
            AND (l.channel_id IS NOT NULL OR (l.channel IS NOT NULL AND l.channel != '') OR COALESCE(p.name, l.name) IS NOT NULL)
            GROUP BY l.channel
        `).bind(startTs, endTs).run();

        // Count of "fresh" leads (created within maturity window, not yet mature)
        const { results: freshLeadResult } = await db.prepare(`
            SELECT COUNT(*) as count
            FROM leads l
            LEFT JOIN patients p ON l.patient_id = p.id
            WHERE l.created_at > ? AND l.created_at <= ?
            AND l.deleted_at IS NULL
            AND (l.channel_id IS NOT NULL OR (l.channel IS NOT NULL AND l.channel != '') OR COALESCE(p.name, l.name) IS NOT NULL)
        `).bind(matureCutoffTs, endTs).run();
        const freshLeadCount = freshLeadResult[0]?.count || 0;

        // 2. Marketing Attribution (First Source)
        // From Patients table (Created in range)
        const { results: sourceStats } = await db.prepare(`
            SELECT 
                CASE 
                    WHEN first_source IS NOT NULL AND first_source != '' THEN first_source 
                    ELSE '미확인' -- 'Unknown'
                END as source_name,
                COUNT(*) as count
            FROM patients
            WHERE created_at BETWEEN ? AND ?
            AND deleted_at IS NULL
            GROUP BY source_name
            ORDER BY count DESC
        `).bind(startTs, endTs).run();

        // 3. Funnel Steps (MATURE COHORT ONLY - excludes leads created within maturity window)
        // Step 1: Mature Inquiries (Total Leads created before cutoff)
        const { results: matureInquiryResult } = await db.prepare(`
            SELECT COUNT(*) as count
            FROM leads l
            LEFT JOIN patients p ON l.patient_id = p.id
            WHERE l.created_at BETWEEN ? AND ?
            AND l.deleted_at IS NULL
            AND (l.channel_id IS NOT NULL OR (l.channel IS NOT NULL AND l.channel != '') OR COALESCE(p.name, l.name) IS NOT NULL)
        `).bind(startTs, matureCutoffTs).run();
        const matureInquiries = matureInquiryResult[0]?.count || 0;

        const totalInquiries = (inquiryStats as any[]).reduce((sum: number, r: any) => sum + r.count, 0);

        // Step 2: Reservations (Mature Cohort patients who made a reservation)
        const { results: reservationCountResult } = await db.prepare(`
            SELECT COUNT(DISTINCT p.id) as count
            FROM patients p
            JOIN reservations r ON p.id = r.patient_id
            WHERE p.created_at BETWEEN ? AND ?
            AND p.deleted_at IS NULL
            AND r.deleted_at IS NULL
        `).bind(startTs, matureCutoffTs).run();
        const convertedToReservation = reservationCountResult[0]?.count || 0;

        // Step 3: Visits (Checked-in / Completed)
        const { results: visitCountResult } = await db.prepare(`
            SELECT COUNT(DISTINCT p.id) as count
            FROM patients p
            JOIN reservations r ON p.id = r.patient_id
            WHERE p.created_at BETWEEN ? AND ?
            AND r.status = 'completed'
            AND p.deleted_at IS NULL
            AND r.deleted_at IS NULL
        `).bind(startTs, matureCutoffTs).run();
        const convertedToVisit = visitCountResult[0]?.count || 0;

        // Step 4: Payments (Paid)
        // Mature Cohort: Patients created before cutoff who eventually paid
        const { results: paymentCountResult } = await db.prepare(`
            SELECT COUNT(DISTINCT p.id) as count
            FROM patients p
            JOIN payments pay ON p.id = pay.patient_id
            WHERE p.created_at BETWEEN ? AND ?
            AND (pay.status = 'completed' OR pay.status = 'paid')
            AND pay.amount > 0
            AND pay.deleted_at IS NULL
            AND p.deleted_at IS NULL
        `).bind(startTs, matureCutoffTs).run();
        const convertedToPayment = paymentCountResult[0]?.count || 0;

        // Web Specific Drilldown (Web Channel Only)
        // Requires analytics_events table (from web.astro logic)
        // "inquiry_view" -> "inquiry_submit"
        const { results: webFunnel } = await db.prepare(`
            SELECT 
                SUM(CASE WHEN event_type = 'inquiry_view' THEN 1 ELSE 0 END) as views,
                SUM(CASE WHEN event_type = 'inquiry_submit' THEN 1 ELSE 0 END) as submits
            FROM analytics_events
            WHERE created_at BETWEEN ? AND ? -- timestamp text comparison might need care if string vs int
            -- Assuming analytics_events uses ISO string created_at based on web.astro. 
            -- But checking schema 0065_create_analytics.sql or 0128...
            -- Let's check web.astro: date(created_at) >= date(?). It treats it as string.
            -- We need to convert TS to ISO string for this table perhaps?
            -- Actually, let's verify schema. Assuming ISO string for now based on previous files.
        `).bind(
            new Date(startTs * 1000).toISOString(),
            new Date(endTs * 1000).toISOString()
        ).run();

        const webViews = Number(webFunnel[0]?.views) || 0;
        const webSubmits = Number(webFunnel[0]?.submits) || 0;

        return new Response(JSON.stringify({
            range: { start: startParam, end: endParam },
            maturityWindow: maturityWindowDays,
            cohort: {
                // Total leads in range (ALL leads, including fresh)
                totalInquiries: totalInquiries,
                // Leads still considered "fresh" (too new for conversion analysis)
                freshLeads: freshLeadCount,
                // Mature leads (ready for conversion analysis)
                matureInquiries: matureInquiries
            },
            funnel: {
                // These are based on MATURE cohort only
                inquiries: matureInquiries,
                reservations: convertedToReservation,
                visits: convertedToVisit,
                payments: convertedToPayment
            },
            channels: inquiryStats,
            sources: sourceStats,
            webSpecific: {
                views: webViews,
                submits: webSubmits,
                conversionRate: webViews > 0 ? ((webSubmits / webViews) * 100).toFixed(1) : 0
            }
        }));

    } catch (e: any) {
        console.error('Flow Analytics Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
