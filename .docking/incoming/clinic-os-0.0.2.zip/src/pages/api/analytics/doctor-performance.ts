import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;

    // Date Range Params
    const startParam = url.searchParams.get('startDate');
    const endParam = url.searchParams.get('endDate');

    // Parse dates (Unix Timestamp)
    const now = new Date();
    let startDate = startParam ? new Date(startParam) : new Date(now.getFullYear(), now.getMonth(), 1);
    let endDate = endParam ? new Date(endParam) : new Date(now.getFullYear(), now.getMonth() + 1, 0);

    // Set times to start/end of day
    startDate.setHours(0, 0, 0, 0);
    if (endParam) {
        endDate.setHours(23, 59, 59, 999);
    } else {
        endDate.setHours(23, 59, 59, 999); // Ensure end date covers full day
    }

    const startTs = Math.floor(startDate.getTime() / 1000);
    const endTs = Math.floor(endDate.getTime() / 1000);

    try {
        // Core Query: Doctor Performance based on COMPLETED reservations (Visits)
        // We define "New Visit" as linked to a 'new'/'new_lead' patient type.
        // Everything else is "Returning".
        // Daily Average = Total Visits / Working Days

        const { results } = await db.prepare(`
            SELECT 
                COALESCE(s.name, '미지정') as doctor_name,
                e.staff_id as doctor_id,
                e.staff_id,
                COUNT(e.id) as total_visits,
                COUNT(DISTINCT e.patient_id) as unique_patients,
                SUM(CASE WHEN e.title = '초진 내원' THEN 1 ELSE 0 END) as new_visits,
                SUM(CASE WHEN e.title != '초진 내원' THEN 1 ELSE 0 END) as returning_visits,
                COUNT(DISTINCT date(CAST(e.event_date AS INTEGER), 'unixepoch', '+9 hours')) as working_days
            FROM patient_events e
            LEFT JOIN staff s ON e.staff_id = s.id
            WHERE e.type = 'visit'
            AND e.event_date >= ? AND e.event_date <= ?
            AND (e.deleted_at IS NULL OR e.deleted_at = '')
            GROUP BY e.staff_id
            ORDER BY total_visits DESC
        `).bind(startTs, endTs).run();

        // Post-process for averages
        const processed = (results || []).map((row: any) => ({
            ...row,
            daily_avg: row.working_days > 0 ? (row.total_visits / row.working_days).toFixed(1) : '0.0',
            new_ratio: row.total_visits > 0 ? ((row.new_visits / row.total_visits) * 100).toFixed(1) : '0.0'
        }));

        return new Response(JSON.stringify({
            data: processed,
            range: { start: startDate, end: endDate }
        }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Doctor Performance API Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
