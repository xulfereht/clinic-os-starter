import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        return new Response(JSON.stringify({ error: 'DB not available' }), { status: 500 });
    }

    const url = new URL(request.url);
    const type = url.searchParams.get('type'); // 'inquiries' | 'reservations' | 'visits' | 'payments'
    const startDate = url.searchParams.get('startDate');
    const endDate = url.searchParams.get('endDate');
    const consultType = url.searchParams.get('consultType') || 'all'; // 'all' | 'visit' | 'remote'

    // Maturity Window: Days to wait before considering a lead "mature" for conversion analysis
    const maturityWindowDays = parseInt(url.searchParams.get('maturityWindow') || '7', 10);

    const page = parseInt(url.searchParams.get('page') || '1', 10);
    const limit = parseInt(url.searchParams.get('limit') || '50', 10);
    const offset = (page - 1) * limit;

    if (!type || !startDate || !endDate) {
        return new Response(JSON.stringify({ error: 'Missing required parameters' }), { status: 400 });
    }

    // Convert dates to timestamps (start of day / end of day)
    const startTimestamp = Math.floor(new Date(startDate).getTime() / 1000);
    const endTimestamp = Math.floor(new Date(endDate).setHours(23, 59, 59, 999) / 1000);

    // Calculate mature cohort cutoff for payments (same logic as flow.ts)
    const matureCutoffTs = endTimestamp - (maturityWindowDays * 86400);

    // Build type condition based on consultType
    let typeCondition = '';
    if (consultType === 'visit') {
        typeCondition = " AND (l.type = 'visit' OR l.status LIKE '%first_visit%')";
    } else if (consultType === 'remote') {
        typeCondition = " AND (l.type = 'remote' OR l.status LIKE '%remote%')";
    }

    try {
        let query = '';
        let countQuery = ''; // New: Count Calculation
        let results = [];
        let total = 0;
        let totalRevenue = 0; // Optional, for types that support it

        if (type === 'inquiries') {
            // Fetch NEW patient leads within date range (초진 only) + consultType filter
            query = `
                SELECT 
                    l.id,
                    l.created_at,
                    l.channel_id,
                    l.channel,
                    l.status,
                    l.type,
                    COALESCE(p.name, l.name) as patient_name,
                    COALESCE(p.current_phone, l.contact) as patient_phone
                FROM leads l
                LEFT JOIN patients p ON l.patient_id = p.id
                WHERE l.created_at >= ? AND l.created_at <= ?
                AND l.patient_type IN ('new', 'new_lead')
                AND (l.channel_id IS NOT NULL OR (l.channel IS NOT NULL AND l.channel != '') OR COALESCE(p.name, l.name) IS NOT NULL)
                AND (l.deleted_at IS NULL)
                ${typeCondition}
                ORDER BY l.created_at DESC
                LIMIT ? OFFSET ?
            `;

            // Count
            countQuery = `
                SELECT COUNT(*) as total 
                FROM leads l
                LEFT JOIN patients p ON l.patient_id = p.id
                WHERE l.created_at >= ? AND l.created_at <= ?
                AND l.patient_type IN ('new', 'new_lead')
                AND (l.channel_id IS NOT NULL OR (l.channel IS NOT NULL AND l.channel != '') OR COALESCE(p.name, l.name) IS NOT NULL)
                AND (l.deleted_at IS NULL)
                ${typeCondition}
            `;
            const countResult = await db.prepare(countQuery).bind(startTimestamp, endTimestamp).first();
            total = Number(countResult?.total || 0);

            const { results: leads } = await db.prepare(query).bind(startTimestamp, endTimestamp, limit, offset).all();
            results = leads;

        } else if (type === 'payments') {
            // Match journey.ts cohort logic: Payments from NEW leads created in range
            query = `
                SELECT 
                    pay.id,
                    pay.paid_at as created_at,
                    pay.amount,
                    p.name as patient_name,
                    l.type as consult_type
                FROM payments pay
                INNER JOIN leads l ON pay.patient_id = l.patient_id
                INNER JOIN patients p ON pay.patient_id = p.id
                WHERE l.created_at >= ? AND l.created_at <= ?
                AND l.patient_type IN ('new', 'new_lead')
                AND pay.status = 'completed'
                AND pay.amount > 0
                AND (pay.deleted_at IS NULL OR pay.deleted_at = '')
                AND (l.deleted_at IS NULL OR l.deleted_at = '')
                AND (p.deleted_at IS NULL OR p.deleted_at = '')
                ${typeCondition}
                ORDER BY pay.paid_at DESC
                LIMIT ? OFFSET ?
            `;

            countQuery = `
                SELECT COUNT(*) as total
                FROM payments pay
                INNER JOIN leads l ON pay.patient_id = l.patient_id
                INNER JOIN patients p ON pay.patient_id = p.id
                WHERE l.created_at >= ? AND l.created_at <= ?
                AND l.patient_type IN ('new', 'new_lead')
                AND pay.status = 'completed'
                AND pay.amount > 0
                AND (pay.deleted_at IS NULL OR pay.deleted_at = '')
                AND (l.deleted_at IS NULL OR l.deleted_at = '')
                AND (p.deleted_at IS NULL OR p.deleted_at = '')
                ${typeCondition}
            `;
            const countResult = await db.prepare(countQuery).bind(startTimestamp, endTimestamp).first();
            total = Number(countResult?.total || 0);

            const { results: payments } = await db.prepare(query).bind(startTimestamp, endTimestamp, limit, offset).all();
            results = payments;

        } else if (type === 'payments_orphan') {
            // Orphan New Payments: New Patients (created in range) but NO Lead (in range)
            query = `
                SELECT 
                    pay.id,
                    pay.paid_at as created_at,
                    pay.amount,
                    p.name as patient_name,
                    'visit' as consult_type
                FROM payments pay
                INNER JOIN patients p ON pay.patient_id = p.id
                WHERE pay.paid_at >= ? AND pay.paid_at <= ?
                AND p.created_at >= ? AND p.created_at <= ?
                AND pay.status = 'completed' AND pay.amount > 0
                AND (pay.deleted_at IS NULL OR pay.deleted_at = '')
                AND (p.deleted_at IS NULL OR p.deleted_at = '')
                AND NOT EXISTS (
                    SELECT 1 FROM leads l 
                    WHERE l.patient_id = p.id 
                    AND l.created_at >= ? AND l.created_at <= ? 
                    AND l.patient_type IN ('new', 'new_lead') 
                    AND (l.deleted_at IS NULL OR l.deleted_at = '')
                )
                ORDER BY pay.paid_at DESC
                LIMIT 100
            `;
            const { results: orphan } = await db.prepare(query).bind(startTimestamp, endTimestamp, startTimestamp, endTimestamp, startTimestamp, endTimestamp).all();
            results = orphan;

        } else if (type === 'payments_returning') {
            // Returning Payments: Patients created BEFORE start range
            query = `
                SELECT 
                    pay.id,
                    pay.paid_at as created_at,
                    pay.amount,
                    p.name as patient_name,
                    '' as consult_type
                FROM payments pay
                INNER JOIN patients p ON pay.patient_id = p.id
                WHERE pay.paid_at >= ? AND pay.paid_at <= ?
                AND p.created_at < ?
                AND pay.status = 'completed' AND pay.amount > 0
                AND (pay.deleted_at IS NULL OR pay.deleted_at = '')
                AND (p.deleted_at IS NULL OR p.deleted_at = '')
                ORDER BY pay.paid_at DESC
                LIMIT ? OFFSET ?
            `;

            countQuery = `
                SELECT COUNT(*) as total
                FROM payments pay
                INNER JOIN patients p ON pay.patient_id = p.id
                WHERE pay.paid_at >= ? AND pay.paid_at <= ?
                AND p.created_at < ?
                AND pay.status = 'completed' AND pay.amount > 0
                AND (pay.deleted_at IS NULL OR pay.deleted_at = '')
                AND (p.deleted_at IS NULL OR p.deleted_at = '')
            `;
            const countResult = await db.prepare(countQuery).bind(startTimestamp, endTimestamp, startTimestamp).first();
            total = Number(countResult?.total || 0);

            const { results: returning } = await db.prepare(query).bind(startTimestamp, endTimestamp, startTimestamp, limit, offset).all();
            results = returning;

        } else if (type === 'staff_payment') {
            const staffId = url.searchParams.get('staffId');
            let staffCondition = 'AND pay.created_by IS NULL';
            let params: any[] = [startTimestamp, endTimestamp];

            if (staffId && staffId !== 'null' && staffId !== 'unknown' && staffId !== '') {
                staffCondition = 'AND pay.created_by = ?';
                params.push(staffId);
            }

            // Calculate Totals first
            const summaryQuery = `
                SELECT 
                    COUNT(pay.id) as total,
                    SUM(pay.amount) as total_revenue
                FROM payments pay
                INNER JOIN patients p ON pay.patient_id = p.id
                WHERE pay.paid_at >= ? AND pay.paid_at <= ?
                AND pay.status = 'completed' AND pay.amount > 0
                AND (pay.deleted_at IS NULL OR pay.deleted_at = '')
                AND (p.deleted_at IS NULL OR p.deleted_at = '')
                ${staffCondition}
            `;
            const summaryResult = await db.prepare(summaryQuery).bind(...params).first();
            const total = Number(summaryResult?.total) || 0;
            const totalRevenue = Number(summaryResult?.total_revenue) || 0;

            query = `
                SELECT 
                    pay.id,
                    pay.paid_at as created_at,
                    pay.amount,
                    p.name as patient_name,
                    pay.notes,
                    '' as consult_type
                FROM payments pay
                INNER JOIN patients p ON pay.patient_id = p.id
                WHERE pay.paid_at >= ? AND pay.paid_at <= ?
                AND pay.status = 'completed' AND pay.amount > 0
                AND (pay.deleted_at IS NULL OR pay.deleted_at = '')
                AND (p.deleted_at IS NULL OR p.deleted_at = '')
                ${staffCondition}
                ORDER BY pay.paid_at DESC
                LIMIT ? OFFSET ?
            `;
            const { results: staffPayments } = await db.prepare(query).bind(...params, limit, offset).all();
            results = staffPayments;

            // Return with totals (wrapped in a way we can extract later, or just change final response structure)
            // Ideally we change the outer scope let variables to hold these.
            // But 'results' is typed as array.
            // I'll attach totals to the results array or change the response logic below.
            // Let's modify the final return to include 'total' and 'totalRevenue' variables declared in outer scope.

            return new Response(JSON.stringify({
                data: results,
                total,
                totalRevenue
            }), {
                headers: { 'Content-Type': 'application/json' }
            });


        } else if (type === 'reservations') {
            // Match journey.ts: Show only FIRST reservation per patient (unique patients)
            // Uses subquery to get earliest reservation per patient_id
            query = `
                SELECT 
                    r.id,
                    r.reserved_at,
                    r.created_at,
                    r.status,
                    COALESCE(l.name, '') as patient_name,
                    COALESCE(l.contact, '') as patient_phone,
                    COALESCE(s.name, '') as doctor_name,
                    COALESCE(l.channel, '') as channel,
                    COALESCE(l.type, '') as consult_type
                FROM reservations r
                INNER JOIN (
                    SELECT patient_id, MIN(created_at) as first_created
                    FROM reservations
                    WHERE (deleted_at IS NULL OR deleted_at = '')
                    GROUP BY patient_id
                ) first_r ON r.patient_id = first_r.patient_id AND r.created_at = first_r.first_created
                INNER JOIN leads l ON r.patient_id = l.patient_id AND l.patient_type IN ('new', 'new_lead') AND (l.deleted_at IS NULL OR l.deleted_at = '')
                LEFT JOIN staff s ON r.doctor_id = s.id
                WHERE (r.deleted_at IS NULL OR r.deleted_at = '')
                AND l.created_at >= ? AND l.created_at <= ?
                ${typeCondition}
                ORDER BY r.reserved_at DESC
                LIMIT 100
            `;
            const { results: reservations } = await db.prepare(query).bind(startTimestamp, endTimestamp).all();
            results = reservations;

        } else if (type === 'visits') {
            // Match journey.ts: Show only FIRST visit per patient (unique patients)
            // Uses subquery to get earliest visit per patient_id
            query = `
                SELECT 
                    e.id,
                    e.created_at as visit_date,
                    COALESCE(l.name, '') as patient_name,
                    COALESCE(l.contact, '') as patient_phone,
                    COALESCE(l.channel, '') as channel,
                    COALESCE(l.type, '') as consult_type
                FROM patient_events e
                INNER JOIN (
                    SELECT patient_id, MIN(created_at) as first_created
                    FROM patient_events
                    WHERE type = 'visit'
                    AND (deleted_at IS NULL OR deleted_at = '')
                    GROUP BY patient_id
                ) first_e ON e.patient_id = first_e.patient_id AND e.created_at = first_e.first_created
                INNER JOIN leads l ON e.patient_id = l.patient_id AND l.patient_type IN ('new', 'new_lead') AND (l.deleted_at IS NULL OR l.deleted_at = '')
                WHERE e.type = 'visit'
                AND (e.deleted_at IS NULL OR e.deleted_at = '')
                AND l.created_at >= ? AND l.created_at <= ?
                ${typeCondition}
                ORDER BY e.created_at DESC
                LIMIT 100
            `;
            const { results: visits } = await db.prepare(query).bind(startTimestamp, endTimestamp).all();
            results = visits;

        } else if (type === 'channel') {
            // Fetch leads by specific channel
            const channelName = url.searchParams.get('channel');
            if (!channelName) {
                return new Response(JSON.stringify({ error: 'Missing channel parameter' }), { status: 400 });
            }

            const patientType = url.searchParams.get('patientType') || 'all';
            let typeCondition = '';
            if (patientType === 'new') {
                typeCondition = " AND l.patient_type IN ('new', 'new_lead')";
            } else if (patientType === 'returning') {
                typeCondition = " AND l.patient_type IN ('existing_customer', 'returning')";
            }

            const tag = url.searchParams.get('tag');
            let tagCondition = '';
            let tagParam: string[] = [];
            if (tag) {
                tagCondition = " AND l.tags LIKE ?";
                tagParam = [`%"${tag}"%`];
            }

            query = `
                SELECT 
                    l.id,
                    l.created_at,
                    l.channel,
                    l.status,
                    COALESCE(p.name, l.name) as patient_name,
                    COALESCE(p.current_phone, l.contact) as patient_phone,
                    p.id as patient_id
                FROM leads l
                LEFT JOIN patients p ON l.patient_id = p.id
                WHERE l.created_at >= ? AND l.created_at <= ?
                AND l.channel = ?
                AND l.deleted_at IS NULL
                ${typeCondition}
                ${tagCondition}
                ORDER BY l.created_at DESC
                LIMIT 100
            `;
            const { results: channelLeads } = await db.prepare(query).bind(startTimestamp, endTimestamp, channelName, ...tagParam).all();
            results = channelLeads;

        } else if (type === 'doctor_daily') {
            const doctorId = url.searchParams.get('staffId'); // Reusing staffId param
            if (!doctorId) return new Response(JSON.stringify({ error: 'Missing staffId' }), { status: 400 });

            // Daily Stats for specific doctor
            // Using patient_events.title for 초진/재진 classification (same as intake/index.astro)
            query = `
                SELECT 
                    date(CAST(e.event_date AS INTEGER), 'unixepoch', '+9 hours') as visit_date,
                    COUNT(e.id) as total_count,
                    SUM(CASE WHEN e.title = '초진 내원' THEN 1 ELSE 0 END) as new_count,
                    SUM(CASE WHEN e.title != '초진 내원' THEN 1 ELSE 0 END) as returning_count
                FROM patient_events e
                WHERE e.staff_id = ?
                AND e.type = 'visit'
                AND e.event_date >= ? AND e.event_date <= ?
                AND (e.deleted_at IS NULL OR e.deleted_at = '')
                GROUP BY date(CAST(e.event_date AS INTEGER), 'unixepoch', '+9 hours')
                ORDER BY visit_date DESC
            `;
            const { results: dailyStats } = await db.prepare(query).bind(doctorId, startTimestamp, endTimestamp).all();
            results = dailyStats;

        } else if (type === 'source') {
            const sourceName = url.searchParams.get('sourceName');
            if (!sourceName) {
                return new Response(JSON.stringify({ error: 'Missing sourceName parameter' }), { status: 400 });
            }

            // Fetch details for Verified Source
            // Must match journey.ts logic: INNER JOIN leads + patient_type filter

            // first_visit_date is TEXT YYYY-MM-DD
            const startDateStr = new Date(startTimestamp * 1000).toISOString().split('T')[0];
            const endDateStr = new Date(endTimestamp * 1000).toISOString().split('T')[0];

            // Handle "미지정" (unspecified) - search for NULL or empty first_source
            const isUnspecified = sourceName === '미지정';
            const sourceCondition = isUnspecified
                ? "(p.first_source IS NULL OR p.first_source = '')"
                : "p.first_source = ?";

            query = `
            SELECT
                p.id,
                p.first_visit_date as visit_date,
                p.name as patient_name,
                p.current_phone as patient_phone,
                COALESCE(NULLIF(p.first_source, ''), '미지정') as channel,
                CASE WHEN l.type = 'remote' THEN 'remote' ELSE 'visit' END as consult_type,
                (SELECT SUM(amount) FROM payments pay WHERE pay.patient_id = p.id AND pay.paid_at >= ? AND pay.paid_at <= ? AND pay.deleted_at IS NULL) as total_revenue
            FROM patients p
            INNER JOIN leads l ON l.patient_id = p.id
            WHERE ${sourceCondition}
            AND p.first_visit_date >= ? AND p.first_visit_date <= ?
            AND l.patient_type IN('new', 'new_lead')
            AND (p.deleted_at IS NULL OR p.deleted_at = '')
            AND (l.deleted_at IS NULL OR l.deleted_at = '')
            ORDER BY p.first_visit_date DESC
            LIMIT ? OFFSET ?
            `;

            countQuery = `
                SELECT COUNT(*) as total
                FROM patients p
                INNER JOIN leads l ON l.patient_id = p.id
                WHERE ${sourceCondition}
                AND p.first_visit_date >= ? AND p.first_visit_date <= ?
                AND l.patient_type IN('new', 'new_lead')
                AND (p.deleted_at IS NULL OR p.deleted_at = '')
                AND (l.deleted_at IS NULL OR l.deleted_at = '')
            `;

            // Bind parameters differently based on source type
            if (isUnspecified) {
                const countResult = await db.prepare(countQuery).bind(startDateStr, endDateStr).first();
                total = Number(countResult?.total || 0);
                const { results: sourcePatients } = await db.prepare(query).bind(startTimestamp, endTimestamp, startDateStr, endDateStr, limit, offset).all();
                results = sourcePatients;
            } else {
                const countResult = await db.prepare(countQuery).bind(sourceName, startDateStr, endDateStr).first();
                total = Number(countResult?.total || 0);
                const { results: sourcePatients } = await db.prepare(query).bind(startTimestamp, endTimestamp, sourceName, startDateStr, endDateStr, limit, offset).all();
                results = sourcePatients;
            }

        } else {
            return new Response(JSON.stringify({ error: 'Invalid type' }), { status: 400 });
        }

        return new Response(JSON.stringify({
            data: results,
            total,
            totalRevenue,
            page,
            limit
        }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Error fetching analytics details:', e);
        return new Response(JSON.stringify({ error: 'Internal Server Error', message: e?.message || String(e) }), { status: 500 });
    }
};
