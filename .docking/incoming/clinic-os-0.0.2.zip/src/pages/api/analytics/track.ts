import type { APIRoute } from 'astro';
import { hashIP, isBot } from '../../../lib/analytics-utils';
import { getClinicSettings } from '../../../lib/clinic';

export const POST: APIRoute = async ({ request, locals }) => {
    const db = locals.runtime.env.DB;

    try {
        const data = await request.json();
        const { type, sessionId, visitorId, path, referrer, userAgent, eventType, eventData } = data;

        // 0. Check for Bots -> Skip Tracking
        if (userAgent && isBot(userAgent)) {
            return new Response(JSON.stringify({ success: true, skipped: true, reason: 'bot' }), {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Get Client IP
        const clientIP = request.headers.get('cf-connecting-ip') || request.headers.get('x-forwarded-for') || '';

        // 1. Check for Internal IP -> Skip Tracking
        // Optimization: Fetch only analytics_config column
        const configResult = await db.prepare("SELECT analytics_config FROM clinics WHERE id = 1").first();
        let blockedIps: string[] = [];

        if (configResult?.analytics_config) {
            try {
                const parsed = JSON.parse(configResult.analytics_config as string);
                if (Array.isArray(parsed.blockedIps)) {
                    blockedIps = parsed.blockedIps;
                }
            } catch (e) {/* ignore parsing error */ }
        }

        if (clientIP && blockedIps.includes(clientIP)) {
            // Silently ignore internal traffic
            return new Response(JSON.stringify({ success: true, skipped: true }), {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Hash IP for privacy (we don't store raw IPs)
        const ipHash = clientIP ? await hashIP(clientIP) : null;

        // Detect device type from user agent
        const deviceType = detectDeviceType(userAgent || '');

        // Get country from Cloudflare headers
        const country = request.headers.get('cf-ipcountry') || null;

        if (type === 'pageview') {
            await db.prepare(`
                INSERT INTO page_views (session_id, visitor_id, path, referrer, user_agent, ip_hash, country, device_type)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `).bind(sessionId, visitorId || null, path, referrer || null, userAgent || null, ipHash, country, deviceType).run();
        } else if (type === 'event') {
            await db.prepare(`
                INSERT INTO analytics_events (session_id, visitor_id, event_type, event_data, path)
                VALUES (?, ?, ?, ?, ?)
            `).bind(sessionId, visitorId || null, eventType, JSON.stringify(eventData || {}), path || null).run();
        }

        return new Response(JSON.stringify({ success: true }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Analytics tracking error:', error);
        // Return 200 even on error to not block the client
        return new Response(JSON.stringify({ success: false }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};

// Removed local hashIP function in favor of shared utility

function detectDeviceType(userAgent: string): string {
    const ua = userAgent.toLowerCase();
    if (/mobile|android|iphone|ipod|blackberry|windows phone/i.test(ua)) {
        return 'mobile';
    }
    if (/ipad|tablet/i.test(ua)) {
        return 'tablet';
    }
    return 'desktop';
}

// Also support GET for beacon fallback
export const GET: APIRoute = async ({ url, locals }) => {
    const db = locals.runtime.env.DB;

    try {
        const sessionId = url.searchParams.get('sid');
        const path = url.searchParams.get('p');
        const referrer = url.searchParams.get('r');

        if (sessionId && path) {
            await db.prepare(`
                INSERT INTO page_views (session_id, path, referrer)
                VALUES (?, ?, ?)
            `).bind(sessionId, path, referrer || null).run();
        }

        // Return 1x1 transparent GIF
        const gif = new Uint8Array([
            0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00, 0x01, 0x00,
            0x80, 0x00, 0x00, 0xff, 0xff, 0xff, 0x00, 0x00, 0x00, 0x21,
            0xf9, 0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0x2c, 0x00, 0x00,
            0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x02, 0x02, 0x44,
            0x01, 0x00, 0x3b
        ]);

        return new Response(gif, {
            status: 200,
            headers: {
                'Content-Type': 'image/gif',
                'Cache-Control': 'no-store, no-cache, must-revalidate'
            }
        });
    } catch (error) {
        console.error('Analytics GET error:', error);
        return new Response('', { status: 200 });
    }
};
