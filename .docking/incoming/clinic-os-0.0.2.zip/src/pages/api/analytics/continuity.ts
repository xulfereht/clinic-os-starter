import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;

    // Date Range logic
    const parseDateToUnix = (dateStr: string | null, isEnd = false) => {
        if (!dateStr) {
            const d = new Date();
            d.setHours(isEnd ? 23 : 0, isEnd ? 59 : 0, 0, 0);
            return Math.floor(d.getTime() / 1000);
        }
        const d = new Date(dateStr);
        if (isEnd) d.setHours(23, 59, 59, 999);
        else d.setHours(0, 0, 0, 0);
        return Math.floor(d.getTime() / 1000);
    };

    const startParam = url.searchParams.get('startDate');
    const endParam = url.searchParams.get('endDate');
    const startTs = parseDateToUnix(startParam);
    const endTs = parseDateToUnix(endParam, true);

    try {
        // 1. New vs Returning Visits
        // Define New Patient Visit: A visit where the patient was CREATED in the same month/period?
        // OR standard med definition: First visit ever.
        // Let's use: Visit where patient.created_at is within specific window close to visit? 
        // Simplest: Patient created within the selected range = New Patient (for this context).
        // Patient created before selected range = Returning Patient.

        const { results: visitStats } = await db.prepare(`
            SELECT 
                CASE 
                    WHEN p.created_at BETWEEN ? AND ? THEN 'new'
                    ELSE 'returning'
                END as patient_type,
                COUNT(*) as visit_count
            FROM reservations r
            JOIN patients p ON r.patient_id = p.id
            WHERE r.reserved_at BETWEEN ? AND ?
            AND r.status = 'completed'
            GROUP BY patient_type
        `).bind(startTs, endTs, startTs, endTs).run();

        // 2. Retention Rate (Cohort)
        // Of patients engaged (visited) in the Previous Period, how many visited in Current Period?
        // Or simple: Returning / Total.
        // Let's do simple Returning Ratio for the trend chart.
        // And maybe a discrete "Revisit Rate": % of New Patients from [Start-30d] who visited again in [Start-Now].

        // 2a. Revisit Interval (Avg days between visits for returning patients visited in range)
        // Complex query. Approximate:
        // For patients visiting in this range, find their previous visit, calc diff.
        // SQLite window functions support LAG.
        /*
        SELECT AVG(diff) FROM (
            SELECT (r.reserved_at - LAG(r.reserved_at) OVER (PARTITION BY r.patient_id ORDER BY r.reserved_at)) / 86400 as diff
            FROM reservations r
            WHERE r.status = 'completed'
        ) WHERE diff IS NOT NULL
        */
        // We can scope this generally or just for active patients.
        const { results: intervalResult } = await db.prepare(`
            SELECT AVG(diff) as avg_days
            FROM (
                SELECT (r.reserved_at - LAG(r.reserved_at) OVER (PARTITION BY r.patient_id ORDER BY r.reserved_at)) / 86400.0 as diff
                FROM reservations r
                WHERE r.status = 'completed'
            ) 
            WHERE diff IS NOT NULL AND diff < 365 -- Filter outliers > 1 year
        `).run();

        const avgRevisitInterval = intervalResult[0]?.avg_days || 0;

        return new Response(JSON.stringify({
            visitStats,
            metrics: {
                avgRevisitInterval: Math.round(avgRevisitInterval * 10) / 10
            }
        }));

    } catch (e: any) {
        console.error('Continuity Analytics Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
