import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
  const db = locals.runtime.env.DB;
  const startDate = url.searchParams.get('startDate') || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
  const endDate = url.searchParams.get('endDate') || new Date().toISOString();

  const startSec = Math.floor(new Date(startDate).getTime() / 1000);
  const endSec = Math.floor(new Date(endDate).getTime() / 1000);

  // 1. Doctor Performance (Revisit Count & Rate)
  // We need to define "Revisit". Simplified: Visits by patients with > 1 visit count?
  // Or better: Count completed reservations grouped by doctor.

  const doctorStatsQuery = `
    SELECT 
      d.name as doctor_name,
      COUNT(r.id) as total_visits,
      COUNT(CASE WHEN r.status = 'cancelled' THEN 1 END) as cancel_count
    FROM staff d
    LEFT JOIN reservations r ON r.doctor_id = d.id
    WHERE d.type = 'doctor' AND r.reserved_at BETWEEN ? AND ?
    GROUP BY d.id
  `;

  const { results: doctorStats } = await db.prepare(doctorStatsQuery).bind(startSec, endSec).run();

  // 2. Program Performance (Revenue & Volume)
  // Join payments with products (programs)
  const programStatsQuery = `
    SELECT 
      p.name as program_name,
      COUNT(pay.id) as payment_count,
      SUM(pay.amount) as total_revenue
    FROM products p
    JOIN payments pay ON pay.product_id = p.id
    WHERE pay.paid_at BETWEEN ? AND ?
    AND pay.status = 'completed'
    GROUP BY p.id
    ORDER BY total_revenue DESC
  `;

  const { results: programStats } = await db.prepare(programStatsQuery).bind(startSec, endSec).run();

  return new Response(JSON.stringify({
    doctor_performance: doctorStats,
    program_performance: programStats
  }), {
    status: 200,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};
