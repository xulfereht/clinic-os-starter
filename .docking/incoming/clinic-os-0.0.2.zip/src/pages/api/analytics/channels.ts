import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;

    const startParam = url.searchParams.get('startDate');
    const endParam = url.searchParams.get('endDate');

    const parseDateToUnix = (dateStr: string | null, isEnd = false) => {
        if (!dateStr) {
            const d = new Date();
            d.setHours(isEnd ? 23 : 0, isEnd ? 59 : 0, 0, 0);
            return Math.floor(d.getTime() / 1000);
        }
        const d = new Date(dateStr);
        if (isEnd) d.setHours(23, 59, 59, 999);
        else d.setHours(0, 0, 0, 0);
        return Math.floor(d.getTime() / 1000);
    };

    const startTs = parseDateToUnix(startParam);
    const endTs = parseDateToUnix(endParam, true);

    // Patient Type Filter
    const patientType = url.searchParams.get('patientType') || 'all';
    let typeCondition = '';
    if (patientType === 'new') {
        typeCondition = " AND leads.patient_type IN ('new', 'new_lead')";
    } else if (patientType === 'returning') {
        typeCondition = " AND leads.patient_type IN ('existing_customer', 'returning')";
    }

    // Tag Filter
    const tag = url.searchParams.get('tag');
    let tagCondition = '';
    let tagParam: string[] = [];
    if (tag) {
        tagCondition = " AND leads.tags LIKE ?";
        tagParam = [`%"${tag}"%`];
    }

    try {
        // 1. Channel Mix (Leads)
        // Get leads by channel
        const { results: channelLeads } = await db.prepare(`
            SELECT channel, COUNT(*) as leads
            FROM leads
            WHERE created_at BETWEEN ? AND ?
            AND deleted_at IS NULL
            AND channel IS NOT NULL AND channel != ''
            ${typeCondition.replace('leads.', '')}
            ${tagCondition.replace('leads.', '')}
            GROUP BY channel
        `).bind(startTs, endTs, ...tagParam).run();

        // 2. Visit Attribution (Patients who visited)
        // Count patients where first_visit_at is in range
        // Join with leads to get channel info if needed, but here we use first_source from patients table usually?
        // Actually, the requirement is "Marketing Performance" -> usually based on leads source or patient survey
        // Let's use leads channel for consistency with the tab
        const { results: visitAttribution } = await db.prepare(`
            SELECT leads.channel as source, COUNT(DISTINCT patients.id) as count
            FROM patients
            JOIN leads ON patients.lead_id = leads.id
            WHERE patients.first_visit_at BETWEEN ? AND ?
            AND patients.deleted_at IS NULL
            AND leads.channel IS NOT NULL
            ${typeCondition}
            ${tagCondition}
            GROUP BY leads.channel
        `).bind(startTs, endTs, ...tagParam).run();

        // 3. Channel Funnel Data
        // We need to aggregate stats per channel: Leads -> Patients -> Visits -> Payments
        // This is complex to do in one query efficiently without window functions or complex joins
        // We will fetch stats separately and combine in JS

        // Leads per channel (already got channelLeads)

        // Patients per channel (created in range)
        const { results: channelPatients } = await db.prepare(`
            SELECT leads.channel, COUNT(DISTINCT patients.id) as count
            FROM patients
            JOIN leads ON patients.lead_id = leads.id
            WHERE leads.created_at BETWEEN ? AND ?
            AND patients.created_at IS NOT NULL
            AND patients.deleted_at IS NULL
            ${typeCondition}
            ${tagCondition}
            GROUP BY leads.channel
        `).bind(startTs, endTs, ...tagParam).run();

        // Visits per channel (first visit in range OR just visited in range? Funnel usually implies cohort)
        // For funnel: Leads created in range -> did they visit?
        const { results: channelVisits } = await db.prepare(`
            SELECT leads.channel, COUNT(DISTINCT patients.id) as count
            FROM patients
            JOIN leads ON patients.lead_id = leads.id
            WHERE leads.created_at BETWEEN ? AND ?
            AND patients.first_visit_at IS NOT NULL
            AND patients.deleted_at IS NULL
            ${typeCondition}
            ${tagCondition}
            GROUP BY leads.channel
        `).bind(startTs, endTs, ...tagParam).run();

        // Payments per channel (paid in range? OR leads created in range -> paid?)
        // Funnel: Leads created in range -> paid
        const { results: channelPayments } = await db.prepare(`
            SELECT leads.channel, COUNT(DISTINCT payments.id) as count
            FROM payments
            JOIN patients ON payments.patient_id = patients.id
            JOIN leads ON patients.lead_id = leads.id
            WHERE leads.created_at BETWEEN ? AND ?
            AND payments.amount > 0
            AND payments.deleted_at IS NULL
            ${typeCondition}
            ${tagCondition}
            GROUP BY leads.channel
        `).bind(startTs, endTs, ...tagParam).run();

        // Merge into conversion funnel by channel
        const channelMap = new Map<string, any>();

        for (const row of channelLeads as any[]) {
            channelMap.set(row.channel, {
                channel: row.channel,
                leads: row.leads,
                patients: 0,
                visits: 0,
                payments: 0
            });
        }
        for (const row of channelPatients as any[]) {
            if (channelMap.has(row.channel)) {
                channelMap.get(row.channel).patients = row.count;
            }
        }
        for (const row of channelVisits as any[]) {
            if (channelMap.has(row.channel)) {
                channelMap.get(row.channel).visits = row.count;
            }
        }
        for (const row of channelPayments as any[]) {
            if (channelMap.has(row.channel)) {
                channelMap.get(row.channel).payments = row.count;
            }
        }

        // Calculate conversion rates
        const channelFunnel = Array.from(channelMap.values()).map(c => ({
            ...c,
            leadToPatient: c.leads > 0 ? Math.round((c.patients / c.leads) * 100) : 0,
            patientToVisit: c.patients > 0 ? Math.round((c.visits / c.patients) * 100) : 0,
            visitToPayment: c.visits > 0 ? Math.round((c.payments / c.visits) * 100) : 0,
            overall: c.leads > 0 ? Math.round((c.payments / c.leads) * 100) : 0
        }));

        // Sort by leads descending
        channelFunnel.sort((a, b) => b.leads - a.leads);

        return new Response(JSON.stringify({
            range: { start: startParam, end: endParam },
            reservationAttribution: [], // Deprecated in favor of channel funnel
            visitAttribution: visitAttribution,
            channelFunnel: channelFunnel
        }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Channel Analytics Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
