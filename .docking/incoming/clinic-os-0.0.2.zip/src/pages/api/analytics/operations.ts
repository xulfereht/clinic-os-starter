import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;

    // Date Range logic
    const parseDateToUnix = (dateStr: string | null, isEnd = false) => {
        if (!dateStr) {
            const d = new Date();
            d.setHours(isEnd ? 23 : 0, isEnd ? 59 : 0, 0, 0);
            return Math.floor(d.getTime() / 1000);
        }
        const d = new Date(dateStr);
        if (isEnd) d.setHours(23, 59, 59, 999);
        else d.setHours(0, 0, 0, 0);
        return Math.floor(d.getTime() / 1000);
    };

    const startParam = url.searchParams.get('startDate');
    const endParam = url.searchParams.get('endDate');
    const startTs = parseDateToUnix(startParam);
    const endTs = parseDateToUnix(endParam, true);

    try {
        // 1. Revenue by Category (Product/Program)
        // Join payments with products (if product_id exists) OR just aggregate raw.
        // Assuming products table exists (checked earlier).
        const { results: revenueMix } = await db.prepare(`
            SELECT 
                COALESCE(prod.category, '기타') as category,
                SUM(pay.amount) as revenue,
                COUNT(*) as count
            FROM payments pay
            LEFT JOIN products prod ON pay.product_id = prod.id
            WHERE pay.paid_at BETWEEN ? AND ?
            AND (pay.status = 'completed' OR pay.status = 'paid')
            AND pay.amount > 0
            GROUP BY category
            ORDER BY revenue DESC
        `).bind(startTs, endTs).run();

        // 2. Doctor Productivity (Visits & Revenue)
        // Appointments completed by doctor
        const { results: doctorStats } = await db.prepare(`
            SELECT 
                s.name as doctor_name,
                COUNT(*) as visit_count
            FROM reservations r
            JOIN staff s ON r.doctor_id = s.id
            WHERE r.reserved_at BETWEEN ? AND ?
            AND r.status = 'completed'
            GROUP BY s.name
            ORDER BY visit_count DESC
        `).bind(startTs, endTs).run();

        // 3. Hourly Traffic Heatmap (Operations optimization)
        const { results: hourlyTraffic } = await db.prepare(`
            SELECT 
                strftime('%w', datetime(reserved_at, 'unixepoch', '+09:00')) as day_of_week, -- 0=Sun, 1=Mon...
                strftime('%H', datetime(reserved_at, 'unixepoch', '+09:00')) as hour,
                COUNT(*) as count
            FROM reservations
            WHERE reserved_at BETWEEN ? AND ?
            AND status = 'completed'
            GROUP BY day_of_week, hour
        `).bind(startTs, endTs).run();

        return new Response(JSON.stringify({
            revenueMix,
            doctorStats,
            hourlyTraffic
        }));

    } catch (e: any) {
        console.error('Operations Analytics Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
