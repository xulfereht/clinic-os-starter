import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;

    // Date Range Params (Default: This Month)
    const now = new Date();
    const startParam = url.searchParams.get('startDate');
    const endParam = url.searchParams.get('endDate');
    const consultType = url.searchParams.get('consultType') || 'all'; // visit, remote, all

    // Parse dates or default to 1st of month
    let startDate = startParam ? new Date(startParam) : new Date(now.getFullYear(), now.getMonth(), 1);
    let endDate;

    if (endParam) {
        endDate = new Date(endParam);
        // Ensure we cover the full end date
        endDate.setHours(23, 59, 59, 999);
    } else {
        endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
    }

    const startTs = Math.floor(startDate.getTime() / 1000);
    const endTs = Math.floor(endDate.getTime() / 1000);

    // Build type condition based on consultType
    let typeCondition = '';
    if (consultType === 'visit') {
        typeCondition = " AND (l.type = 'visit' OR l.status LIKE '%first_visit%')";
    } else if (consultType === 'remote') {
        typeCondition = " AND (l.type = 'remote' OR l.status LIKE '%remote%')";
    }

    try {
        // --- CONNECTED PIPELINE (New Patient Focus) ---
        // 1. Inquiries (New Patient Leads Created in Period)
        const { results: leadStats } = await db.prepare(`
            SELECT channel, COUNT(*) as count 
            FROM leads l
            WHERE created_at BETWEEN ? AND ?
            AND patient_type IN ('new', 'new_lead')
            AND deleted_at IS NULL
            ${typeCondition}
            GROUP BY channel
        `).bind(startTs, endTs).run();

        // 2. Reservations (Linked to New Patient Leads)
        // Count reservations created in period linked to NEW leads
        const { results: reservationStats } = await db.prepare(`
            SELECT l.channel, COUNT(DISTINCT r.patient_id) as count 
            FROM reservations r
            JOIN leads l ON r.patient_id = l.patient_id
            WHERE l.created_at BETWEEN ? AND ? 
            AND l.patient_type IN ('new', 'new_lead') AND l.deleted_at IS NULL
            AND r.deleted_at IS NULL
            ${typeCondition}
            GROUP BY l.channel
        `).bind(startTs, endTs).run();

        // 3. Visits (Linked to New Patient Leads) - Skip for remote consultType
        let visitStats: any[] = [];
        if (consultType !== 'remote') {
            const visitResult = await db.prepare(`
                SELECT l.channel, COUNT(DISTINCT e.patient_id) as count
                FROM patient_events e
                JOIN leads l ON e.patient_id = l.patient_id
                WHERE e.type = 'visit'
                AND l.created_at BETWEEN ? AND ?
                AND l.patient_type IN ('new', 'new_lead') AND l.deleted_at IS NULL
                AND e.deleted_at IS NULL
                ${typeCondition}
                GROUP BY l.channel
            `).bind(startTs, endTs).run();
            visitStats = visitResult.results || [];
        }

        // 4. Payments (Revenue) (Linked to New Patient Leads)
        const { results: paymentStats } = await db.prepare(`
            SELECT l.channel, 
                   COUNT(DISTINCT p.id) as count,
                   SUM(p.amount) as total_revenue
            FROM payments p
            JOIN leads l ON p.patient_id = l.patient_id
            WHERE p.status = 'completed'
            AND l.created_at BETWEEN ? AND ?
            AND l.patient_type IN ('new', 'new_lead') AND l.deleted_at IS NULL
            AND p.deleted_at IS NULL
            ${typeCondition}
            GROUP BY l.channel
        `).bind(startTs, endTs).run();

        // 4-b. Orphan New Payments (New Patients in range, Paid in range, No Lead in range)
        // Note: Using paid_at for revenue timing, but patient creation for cohort definition
        const { results: orphanStats } = await db.prepare(`
            SELECT 
                COUNT(DISTINCT p.id) as count,
                SUM(pay.amount) as total_revenue
            FROM payments pay
            JOIN patients p ON pay.patient_id = p.id
            WHERE pay.paid_at BETWEEN ? AND ?
            AND p.created_at BETWEEN ? AND ?
            AND pay.status = 'completed' AND pay.amount > 0
            AND (pay.deleted_at IS NULL OR pay.deleted_at = '')
            AND (p.deleted_at IS NULL OR p.deleted_at = '')
            AND NOT EXISTS (
                SELECT 1 FROM leads l 
                WHERE l.patient_id = p.id 
                AND l.created_at BETWEEN ? AND ? 
                AND l.patient_type IN ('new', 'new_lead') 
                AND (l.deleted_at IS NULL OR l.deleted_at = '')
            )
        `).bind(startTs, endTs, startTs, endTs, startTs, endTs).run();

        // 4-c. Returning Payments (Existing Patients created before start, Paid in range)
        const { results: returningStats } = await db.prepare(`
            SELECT 
                COUNT(DISTINCT p.id) as count,
                SUM(pay.amount) as total_revenue
            FROM payments pay
            JOIN patients p ON pay.patient_id = p.id
            WHERE pay.paid_at BETWEEN ? AND ?
            AND p.created_at < ?
            AND pay.status = 'completed' AND pay.amount > 0
            AND (pay.deleted_at IS NULL OR pay.deleted_at = '')
            AND (p.deleted_at IS NULL OR p.deleted_at = '')
        `).bind(startTs, endTs, startTs).run();


        // --- Staff Performance ---

        // Payment Creator Performance (결제 담당자별 성과)
        // created_by can be a staff_id OR a super_admin_id
        const consultantsResult = await db.prepare(`
            SELECT 
                COALESCE(s.name, sa.name, '알 수 없음') as name,
                pay.created_by as staff_id,
                COUNT(DISTINCT pay.patient_id) as patient_count,
                COUNT(pay.id) as payment_count,
                SUM(pay.amount) as total_revenue,
                ROUND(AVG(pay.amount), 0) as avg_payment
            FROM payments pay
            LEFT JOIN staff s ON pay.created_by = s.id
            LEFT JOIN super_admins sa ON pay.created_by = sa.id
            WHERE pay.paid_at >= ? AND pay.paid_at <= ? 
            AND pay.deleted_at IS NULL
            AND pay.amount > 0
            GROUP BY pay.created_by
            ORDER BY total_revenue DESC
        `).bind(startTs, endTs).run();
        const consultants = consultantsResult.results || [];

        // Doctor Performance with detailed breakdown
        // Using patient_events.title for 초진/재진 classification (same as intake/index.astro)
        // Shows all doctors separately + "미지정" for visits without staff_id
        const { results: doctorStats } = await db.prepare(`
            SELECT
                pe.staff_id,
                COALESCE(s.name, '미지정') as doctor_name,
                COUNT(pe.id) as total_count,
                SUM(CASE WHEN pe.title = '초진 내원' THEN 1 ELSE 0 END) as new_visit_count,
                SUM(CASE WHEN pe.title != '초진 내원' THEN 1 ELSE 0 END) as returning_count,
                0 as remote_count
            FROM patient_events pe
            LEFT JOIN staff s ON pe.staff_id = s.id
            WHERE pe.type = 'visit'
            AND pe.event_date BETWEEN ? AND ?
            AND (pe.deleted_at IS NULL OR pe.deleted_at = '')
            GROUP BY pe.staff_id, COALESCE(s.name, '미지정')
            ORDER BY total_count DESC
        `).bind(startTs, endTs).run();

        // Verified Source - For 초진 patients who actually had visits (first_source is set)
        // first_source is recorded at visit check-in (내원) or remote intake completion (비대면)
        // Separates data by visit type (내원 vs 비대면)
        const startDateStr = startDate.toISOString().split('T')[0];
        const endDateStr = endDate.toISOString().split('T')[0];
        const verifiedSourcesResult = await db.prepare(`
            SELECT
                COALESCE(NULLIF(p.first_source, ''), '미지정') as source_name,
                CASE 
                    WHEN l.type = 'remote' THEN 'remote'
                    ELSE 'visit'
                END as visit_type,
                COUNT(DISTINCT p.id) as count,
                COALESCE(SUM((SELECT SUM(amount) FROM payments pay WHERE pay.patient_id = p.id AND pay.paid_at >= ? AND pay.paid_at <= ? AND pay.deleted_at IS NULL)), 0) as revenue
            FROM patients p
            INNER JOIN leads l ON l.patient_id = p.id
            WHERE p.first_visit_date >= ?
            AND p.first_visit_date <= ?
            AND l.patient_type IN ('new', 'new_lead')
            AND (p.deleted_at IS NULL OR p.deleted_at = '')
            AND (l.deleted_at IS NULL OR l.deleted_at = '')
            GROUP BY source_name, visit_type
            ORDER BY count DESC
        `).bind(startTs, endTs, startDateStr, endDateStr).run();
        const verifiedSources = verifiedSourcesResult.results || [];

        // --- Tag Stats (Revenue by Tag) ---
        // Fetch active patients (paid in range) and their active segments
        // Note: Using active segments (p.segments) rather than legacy leads.tags
        const { results: tagRawData } = await db.prepare(`
            SELECT 
                p.segments,
                SUM(pay.amount) as revenue
            FROM payments pay
            JOIN patients p ON pay.patient_id = p.id
            WHERE pay.paid_at BETWEEN ? AND ?
            AND pay.status = 'completed' AND pay.amount > 0
            AND pay.deleted_at IS NULL
            GROUP BY p.id
        `).bind(startTs, endTs).run();

        // Tags to exclude from Analysis (Operational/Status tags)
        const EXCLUDED_TAGS = ['주2회침치료'];

        const tagStats: Record<string, number> = {};
        (tagRawData || []).forEach((row: any) => {
            try {
                if (row.segments) {
                    const tags = JSON.parse(row.segments);
                    if (Array.isArray(tags) && tags.length > 0) {
                        // 1. Normalize & Filter
                        const validTags = tags
                            .filter(t => t && typeof t === 'string')
                            .map(t => t.replace(/\s+/g, '')) // Remove spaces for checking matches
                            .filter(t => !EXCLUDED_TAGS.some(ex => t.includes(ex))); // Exclude specific keywords

                        // 2. Select Primary Tag (First valid one)
                        // This prevents double-counting revenue for one patient
                        if (validTags.length > 0) {
                            const primaryTag = validTags[0];
                            tagStats[primaryTag] = (tagStats[primaryTag] || 0) + (row.revenue || 0);
                        } else {
                            // Valid tags were filtered out (only had excluded tags)
                            tagStats['기타 (Excluded)'] = (tagStats['기타 (Excluded)'] || 0) + (row.revenue || 0);
                        }
                    } else {
                        tagStats['태그 없음'] = (tagStats['태그 없음'] || 0) + (row.revenue || 0);
                    }
                } else {
                    tagStats['태그 없음'] = (tagStats['태그 없음'] || 0) + (row.revenue || 0);
                }
            } catch (e) { }
        });

        // Sort by Revenue DESC
        const tagRevenueStats = Object.entries(tagStats)
            .sort(([, a], [, b]) => b - a)
            .reduce((r, [k, v]) => ({ ...r, [k]: v }), {});

        // --- Aggregation ---
        const channels = new Set([
            ...(leadStats as any[]).map(r => r.channel),
            ...(reservationStats as any[]).map(r => r.channel),
            ...(visitStats as any[]).map(r => r.channel),
            ...(paymentStats as any[]).map(r => r.channel)
        ]);

        const byChannel = Array.from(channels).map(channel => {
            const inqCount = (leadStats as any[]).find(r => r.channel === channel)?.count || 0;
            const resCount = (reservationStats as any[]).find(r => r.channel === channel)?.count || 0;
            const visitCount = (visitStats as any[]).find(r => r.channel === channel)?.count || 0;

            const payStat = (paymentStats as any[]).find(r => r.channel === channel);
            const payCount = payStat?.count || 0;
            const revenue = payStat?.total_revenue || 0;

            return {
                channel: channel || 'Direct/Unknown',
                inquiries: inqCount,
                reservations: resCount,
                visits: visitCount,
                payments: payCount,
                revenue: revenue,
                conversion_rate: inqCount > 0 ? ((resCount / inqCount) * 100).toFixed(1) : 0,
                revenue_per_patient: payCount > 0 ? Math.round(revenue / payCount) : 0
            };
        });

        // Totals
        const summary = {
            total_inquiries: byChannel.reduce((sum, c) => sum + c.inquiries, 0),
            total_reservations: byChannel.reduce((sum, c) => sum + c.reservations, 0),
            total_visits: byChannel.reduce((sum, c) => sum + c.visits, 0),
            total_payments: byChannel.reduce((sum, c) => sum + c.payments, 0),
            total_revenue: byChannel.reduce((sum, c) => sum + c.revenue, 0),
            orphan_payment_count: (orphanStats as any[])[0]?.count || 0,
            orphan_revenue: (orphanStats as any[])[0]?.total_revenue || 0,
            returning_payment_count: (returningStats as any[])[0]?.count || 0,
            returning_revenue: (returningStats as any[])[0]?.total_revenue || 0,
            conversion_rate: 0
        };
        // Conversion Rate: Inquiries -> Reservations
        summary.conversion_rate = summary.total_inquiries > 0
            ? parseFloat(((summary.total_reservations / summary.total_inquiries) * 100).toFixed(1))
            : 0;

        // Pie Chart Data
        const pie_charts = {
            patient_type: {
                new: (summary.total_revenue || 0) + (summary.orphan_revenue || 0),
                returning: summary.returning_revenue || 0
            },
            consult_type: {
                // Derived from Doctor Stats (Completed Reservations)
                visit: doctorStats.reduce((acc: number, cur: any) => acc + (cur.new_visit_count || 0) + (cur.returning_count || 0), 0),
                remote: doctorStats.reduce((acc: number, cur: any) => acc + (cur.remote_count || 0), 0)
            },
            by_tag: tagRevenueStats
        };

        return new Response(JSON.stringify({
            consultType,
            isRemote: consultType === 'remote',
            summary,
            pie_charts,
            byChannel: byChannel.sort((a, b) => b.inquiries - a.inquiries),
            byStaff: { consultants, doctors: doctorStats },
            verifiedSources,
            range: { start: startDate, end: endDate }
        }));

    } catch (e: any) {
        console.error('Analytics Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
