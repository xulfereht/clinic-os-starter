import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;

    // Date Range logic (Same as flow.ts)
    const now = new Date();
    const parseDateToUnix = (dateStr: string | null, isEnd = false) => {
        if (!dateStr) {
            const d = new Date();
            d.setHours(isEnd ? 23 : 0, isEnd ? 59 : 0, 0, 0);
            return Math.floor(d.getTime() / 1000);
        }
        const d = new Date(dateStr);
        if (isEnd) d.setHours(23, 59, 59, 999);
        else d.setHours(0, 0, 0, 0);
        return Math.floor(d.getTime() / 1000);
    };

    const startParam = url.searchParams.get('startDate');
    const endParam = url.searchParams.get('endDate');
    const startTs = parseDateToUnix(startParam);
    const endTs = parseDateToUnix(endParam, true);

    try {
        // 1. Overall No-Show/Cancel Counts
        const { results: statusCounts } = await db.prepare(`
            SELECT status, COUNT(*) as count 
            FROM reservations 
            WHERE reserved_at BETWEEN ? AND ?
            AND status IN ('no_show', 'cancelled', 'completed', 'scheduled')
            GROUP BY status
        `).bind(startTs, endTs).run();

        // 2. Cancellation Reasons (Top 5)
        const { results: reasons } = await db.prepare(`
            SELECT cancel_reason as reason, COUNT(*) as count
            FROM reservations
            WHERE reserved_at BETWEEN ? AND ?
            AND status IN ('cancelled', 'no_show')
            AND cancel_reason IS NOT NULL AND cancel_reason != ''
            GROUP BY cancel_reason
            ORDER BY count DESC
            LIMIT 5
        `).bind(startTs, endTs).run();

        // 3. Leakage by Time of Day (Hourly)
        // "reserved_at" is Unix TS. We need to extract hour.
        // SQLite: strftime('%H', datetime(reserved_at, 'unixepoch', 'localtime')) 
        // Note: 'localtime' depends on server timezone. 
        // Safest is to assume UTC+9 if we control environment, or just use +09:00 modifier
        const { results: hourlyLeakage } = await db.prepare(`
            SELECT 
                strftime('%H', datetime(reserved_at, 'unixepoch', '+09:00')) as hour,
                COUNT(*) as count
            FROM reservations
            WHERE reserved_at BETWEEN ? AND ?
            AND status IN ('no_show', 'cancelled')
            GROUP BY hour
            ORDER BY hour
        `).bind(startTs, endTs).run();

        // 4. Stale Leads (Ghosting)
        // Leads created > 3 days ago but still in 'new' or 'pending' status
        // AND created within the selected range (to keep context) OR just current snapshot?
        // Usually snapshot is more useful for "Actionable", but for analytics we might want "Leads created in this period that became stale".
        // Let's do: Leads created in range that are NOW still 'new'/'pending' and created > 3 days ago (which is implied if range is past)
        const threeDaysAgo = Math.floor(Date.now() / 1000) - (3 * 24 * 60 * 60);
        // We only care about leads created in the requested window that failed to launch.
        const { results: staleLeads } = await db.prepare(`
            SELECT COUNT(*) as count
            FROM leads
            WHERE created_at BETWEEN ? AND ?
            AND status IN ('new', 'pending')
            AND created_at < ?
        `).bind(startTs, endTs, threeDaysAgo).run();

        const staleCount = staleLeads[0]?.count || 0;

        return new Response(JSON.stringify({
            statusCounts,
            reasons,
            hourlyLeakage,
            staleLeads: staleCount
        }));

    } catch (e: any) {
        console.error('Leakage Analytics Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
