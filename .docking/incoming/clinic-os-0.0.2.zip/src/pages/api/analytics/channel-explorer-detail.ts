import type { APIRoute } from 'astro';
import {
    CHANNEL_LABELS,
    PATIENT_TYPE_LABELS,
    CONSULT_TYPE_LABELS,
    STATUS_LABELS,
    getLabel
} from './channel-explorer';

// Date parsing helper
const parseDateToUnix = (dateStr: string | null, isEnd = false): number => {
    if (!dateStr) {
        const d = new Date();
        d.setHours(isEnd ? 23 : 0, isEnd ? 59 : 0, 0, 0);
        return Math.floor(d.getTime() / 1000);
    }
    const d = new Date(dateStr);
    if (isEnd) d.setHours(23, 59, 59, 999);
    else d.setHours(0, 0, 0, 0);
    return Math.floor(d.getTime() / 1000);
};

// Mask phone number for privacy
const maskPhone = (phone: string | null): string => {
    if (!phone) return '-';
    // Keep first 3 and last 4 digits
    const digits = phone.replace(/\D/g, '');
    if (digits.length < 7) return phone;
    return `${digits.slice(0, 3)}-****-${digits.slice(-4)}`;
};

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;

    // Parse parameters
    const startParam = url.searchParams.get('startDate');
    const endParam = url.searchParams.get('endDate');
    const startTs = parseDateToUnix(startParam);
    const endTs = parseDateToUnix(endParam, true);

    const channelFilter = url.searchParams.get('channel');
    const patientTypeFilter = url.searchParams.get('patientType');
    const consultTypeFilter = url.searchParams.get('consultType');
    const tagFilter = url.searchParams.get('tag');
    const statusFilter = url.searchParams.get('status');
    const scope = url.searchParams.get('scope');
    const source = url.searchParams.get('source') || 'leads'; // leads, reservations, payments

    const page = parseInt(url.searchParams.get('page') || '1', 10);
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '50', 10), 100);
    const offset = (page - 1) * limit;

    try {
        let countSql = '';
        let dataSql = '';
        let params: any[] = [startTs, endTs];
        let whereClause = '';
        const conditions: string[] = [];

        let postFilterResults = false;
        let excludeTags: string[] = [];
        let queryParams: any[] = [];

        // 1. DATA SOURCE STRATEGY
        if (source === 'reservations') {
            // ... existing reservation logic (omitted for brevity, assume unchanged if not targeting)
            // simplified for this tool call to strictly target what matches.
            // (Assuming I should provide the surrounding context or just the relevant block modification? the file is large)
            // Better to target specific blocks. 
            // I will replace the logic in source='payments' block first.

            // Context: Consult Type Chart (Visit vs Remote) & Verified Lists
            // Filter: reservations.reserved_at
            conditions.push('r.reserved_at BETWEEN ? AND ?');
            conditions.push("r.status = 'completed'");
            conditions.push('r.deleted_at IS NULL');

            if (consultTypeFilter) {
                // Approximate mapping: check lead type or if we recorded type in reservation in future
                conditions.push('l.type = ?');
                params.push(consultTypeFilter);
            }
            if (patientTypeFilter) {
                if (patientTypeFilter === 'new') conditions.push("l.patient_type IN ('new', 'new_lead')");
                else if (patientTypeFilter === 'returning') conditions.push("l.patient_type IN ('existing_customer', 'returning')");
            }
            if (channelFilter) {
                conditions.push('l.channel = ?');
                params.push(channelFilter);
            }

            whereClause = conditions.join(' AND ');

            countSql = `
                SELECT COUNT(*) as total, 0 as total_revenue
                FROM reservations r
                LEFT JOIN leads l ON r.patient_id = l.patient_id
                WHERE ${whereClause}
            `;

            dataSql = `
                SELECT 
                    r.id as id, 
                    COALESCE(p.name, l.name) as name,
                    COALESCE(p.current_phone, l.contact) as phone,
                    l.channel,
                    l.patient_type,
                    l.type as consult_type,
                    l.tags,
                    p.segments,
                    l.status,
                    r.reserved_at as main_date,
                    l.patient_id,
                    p.first_visit_date,
                    1 as payment_count, 
                    0 as total_revenue
                FROM reservations r
                LEFT JOIN leads l ON r.patient_id = l.patient_id
                LEFT JOIN patients p ON r.patient_id = p.id
                WHERE ${whereClause}
                ORDER BY r.reserved_at DESC
                LIMIT ? OFFSET ?
            `;
            queryParams = [...params, limit, offset];

        } else if (source === 'payments') {
            // Context: Patient Type Chart (Revenue)
            // Filter: payments.paid_at
            conditions.push('pay.paid_at BETWEEN ? AND ?');
            conditions.push("pay.status = 'completed'");
            conditions.push('pay.amount > 0');
            conditions.push('pay.deleted_at IS NULL');

            if (patientTypeFilter) {
                if (patientTypeFilter === 'new') {
                    // New: Leads marked 'new' OR Orphans (No lead, Patient created in range)
                    conditions.push(`(
                        l.patient_type IN ('new', 'new_lead') 
                        OR (l.id IS NULL AND p.created_at BETWEEN ${startTs} AND ${endTs})
                     )`);
                } else if (patientTypeFilter === 'returning') {
                    // Returning: Patients created BEFORE the period (Cohort)
                    // Matches journey.ts logic to ensure counts align (e.g. 37 vs 22)
                    conditions.push(`p.created_at < ${startTs}`);
                }
            }
            if (channelFilter) {
                conditions.push('l.channel = ?');
                params.push(channelFilter);
            }
            if (tagFilter) {
                if (tagFilter === 'NO_TAG') {
                    // Filter for empty tags
                    conditions.push(`(
                        (l.tags IS NULL OR l.tags = '' OR l.tags = '[]') 
                        AND 
                        (p.segments IS NULL OR p.segments = '' OR p.segments = '[]')
                    )`);
                } else if (tagFilter === 'OTHERS') {
                    const excludeTagsStr = url.searchParams.get('excludeTags');
                    if (excludeTagsStr) {
                        try {
                            const parsed = JSON.parse(excludeTagsStr);
                            if (Array.isArray(parsed) && parsed.length > 0) {
                                excludeTags = parsed;
                                // Must match a tag that is NOT in the exclude list
                                // AND must not be empty (that's NO_TAG)

                                // Since we can't easily query "contains ANY tag NOT IN list" with simple LIKE,
                                // we will Filter OUT all known Top Tags. 
                                // But a patient might have a Top Tag AND an Other Tag. Prioritization (Journey.ts) says First Valid Tag wins.
                                // So we need to ensure their *Primary Tag* is not in the list.
                                // Journey.ts logic: First valid tag = Primary.

                                // SQL Logic: For each excluded tag T, the JSON string must NOT start with T (roughly).
                                // OR: Simpler toggle: NOT LIKE %Tag1% AND NOT LIKE %Tag2% ...
                                // This works because Journey.ts logic is strictly "First valid tag wins".
                                // If we exclude Top Tags, we are left with rows where NO Top Tag is present? 
                                // Use iteration for negation.

                                // Enable Post-Processing
                                postFilterResults = true;
                                excludeTags = excludeTags.map(t => t.replace(/\s+/g, ''));
                                // Also ignore empty
                                conditions.push(`(
                                    (l.tags IS NOT NULL AND l.tags != '' AND l.tags != '[]') 
                                    OR 
                                    (p.segments IS NOT NULL AND p.segments != '' AND p.segments != '[]')
                                )`);
                            }
                        } catch (e) { }
                    }
                } else {
                    // Ignore spaces when filtering
                    conditions.push("(REPLACE(l.tags, ' ', '') LIKE ? OR REPLACE(p.segments, ' ', '') LIKE ?)");
                    const normalizedTag = tagFilter.replace(/\s+/g, '');
                    params.push(`%"${normalizedTag}"%`, `%"${normalizedTag}"%`);
                }
            }

            whereClause = conditions.join(' AND ');

            countSql = `
                SELECT COUNT(DISTINCT pay.id) as total, SUM(pay.amount) as total_revenue
                FROM payments pay
                LEFT JOIN leads l ON pay.patient_id = l.patient_id
                LEFT JOIN patients p ON pay.patient_id = p.id
                WHERE ${whereClause}
            `;

            // If Post-Filtering, we must fetch ALL matching rows to filter in JS
            // Limit/Offset will be applied after filtering
            const limitClause = postFilterResults ? '' : 'LIMIT ? OFFSET ?';
            queryParams = postFilterResults ? params : [...params, limit, offset];

            dataSql = `
                SELECT 
                    pay.id as id,
                    COALESCE(p.name, l.name) as name,
                    COALESCE(p.current_phone, l.contact) as phone,
                    l.channel,
                    l.patient_type,
                    l.type as consult_type,
                    l.tags,
                    p.segments,
                    l.status,
                    pay.paid_at as main_date,
                    l.patient_id,
                    p.first_visit_date,
                    1 as payment_count,
                    pay.amount as total_revenue
                FROM payments pay
                LEFT JOIN leads l ON pay.patient_id = l.patient_id
                LEFT JOIN patients p ON pay.patient_id = p.id
                WHERE ${whereClause}
                ORDER BY pay.paid_at DESC
                ${limitClause}
            `;

        } else {
            // Default: Leads (Funnel)
            conditions.push('l.created_at BETWEEN ? AND ?');
            conditions.push('l.deleted_at IS NULL');

            if (scope === 'visited') {
                conditions.push("(l.status = 'converted' OR p.first_visit_date IS NOT NULL)");
            }
            if (channelFilter) {
                conditions.push('l.channel = ?');
                params.push(channelFilter);
            }
            if (patientTypeFilter) {
                if (patientTypeFilter === 'new') conditions.push("l.patient_type IN ('new', 'new_lead')");
                else if (patientTypeFilter === 'returning') conditions.push("l.patient_type IN ('existing_customer', 'returning')");
            }
            if (consultTypeFilter) {
                conditions.push('l.type = ?');
                params.push(consultTypeFilter);
            }
            if (tagFilter) {
                // Ignore spaces when filtering
                conditions.push("(REPLACE(l.tags, ' ', '') LIKE ?)");
                const normalizedTag = tagFilter.replace(/\s+/g, '');
                params.push(`%"${normalizedTag}"%`);
            }
            if (statusFilter) {
                conditions.push('l.status = ?');
                params.push(statusFilter);
            }

            whereClause = conditions.join(' AND ');

            countSql = `
                SELECT 
                    COUNT(DISTINCT l.id) as total,
                    COALESCE(SUM(pay.amount), 0) as total_revenue
                FROM leads l
                LEFT JOIN patients p ON l.patient_id = p.id
                LEFT JOIN payments pay ON p.id = pay.patient_id AND pay.deleted_at IS NULL AND pay.amount > 0
                WHERE ${whereClause}
            `;

            dataSql = `
                SELECT 
                    l.id,
                    COALESCE(p.name, l.name) as name,
                    COALESCE(p.current_phone, l.contact) as phone,
                    l.channel,
                    l.patient_type,
                    l.type as consult_type,
                    l.tags,
                    p.segments,
                    l.status,
                    l.intake_data,
                    l.created_at as main_date,
                    l.patient_id,
                    p.first_visit_date,
                    (SELECT COUNT(*) FROM payments pay WHERE pay.patient_id = p.id AND pay.deleted_at IS NULL AND pay.amount > 0) as payment_count,
                    (SELECT COALESCE(SUM(amount), 0) FROM payments pay WHERE pay.patient_id = p.id AND pay.deleted_at IS NULL AND pay.amount > 0) as total_revenue
                FROM leads l
                LEFT JOIN patients p ON l.patient_id = p.id
                WHERE ${whereClause}
                ORDER BY l.created_at DESC
                LIMIT ? OFFSET ?
            `;
            queryParams = [...params, limit, offset];
        }

        // Execute Count
        const summaryResult = await db.prepare(countSql).bind(...params).first();
        let total = Number(summaryResult?.total) || 0;
        let totalRevenue = Number(summaryResult?.total_revenue) || 0;

        // Execute Data
        const { results } = await db.prepare(dataSql).bind(...queryParams).run();

        let filteredResults = results as any[];

        // POST-PROCESSING FILTER (For OTHERS drill-down)
        if (postFilterResults && excludeTags.length > 0) {
            const EXCLUDED_KEYWORDS = ['주2회침치료']; // Must match journey.ts

            filteredResults = filteredResults.filter(row => {
                let tags: string[] = [];
                // Priority: Patient Segments > Lead Tags
                if (row.segments) {
                    try { tags = JSON.parse(row.segments); } catch { }
                } else if (row.tags) {
                    try { tags = JSON.parse(row.tags); } catch { }
                }

                if (!tags || !Array.isArray(tags) || tags.length === 0) return false;

                // 1. Normalize & Filter Excluded Keywords
                const validTags = tags
                    .filter(t => t && typeof t === 'string')
                    .map(t => t.replace(/\s+/g, ''))
                    .filter(t => !EXCLUDED_KEYWORDS.some(ex => t.includes(ex)));

                // 2. Determine Primary Tag
                if (validTags.length > 0) {
                    const primaryTag = validTags[0];
                    // KEEP if Primary Tag is NOT in the exclude list (Top 6)
                    return !excludeTags.includes(primaryTag);
                } else {
                    // Only had excluded tags (e.g. 주2회침치료) -> treated as '기타 (Excluded)' which is likely separate or part of Others?
                    // journey.ts puts them in '기타 (Excluded)' bucket.
                    // If '기타 (Excluded)' is NOT in top 6, then it IS an Other.
                    // So we should KEEP it.
                    // excludeTags contains keys like '다이어트', '피부', etc.
                    // It likely does NOT contain '기타 (Excluded)'.
                    // So we should keep these rows.
                    return true;
                }
            });

            // Re-calculate pagination for filtered list
            total = filteredResults.length;
            totalRevenue = filteredResults.reduce((acc, row) => acc + (row.total_revenue || 0), 0);
            filteredResults = filteredResults.slice(offset, offset + limit);
        }

        // Transform results with Korean labels
        const data = filteredResults.map(row => {
            let tags: string[] = [];
            try {
                // Priority: Patient Segments (Active) > Lead Tags (Legacy)
                if (row.segments) {
                    tags = JSON.parse(row.segments);
                } else if (row.tags) {
                    tags = JSON.parse(row.tags);
                }
            } catch { }

            let intakeData: any = null;
            try {
                if (row.intake_data) intakeData = JSON.parse(row.intake_data);
            } catch { }

            // Determine conversion status
            let conversionStatus = 'pending';
            if (row.payment_count > 0) {
                conversionStatus = 'converted';
            } else if (row.first_visit_date) {
                conversionStatus = 'visited';
            } else if (row.patient_id) {
                conversionStatus = 'patient_created';
            }

            return {
                id: row.id,
                name: row.name || '미입력',
                phone: maskPhone(row.phone),
                phoneRaw: row.phone, // For staff use, consider access control
                channel: row.channel,
                channelLabel: getLabel(row.channel, CHANNEL_LABELS),
                patientType: row.patient_type,
                patientTypeLabel: getLabel(row.patient_type, PATIENT_TYPE_LABELS),
                consultType: row.consult_type,
                consultTypeLabel: getLabel(row.consult_type, CONSULT_TYPE_LABELS),
                tags,
                status: row.status,
                statusLabel: getLabel(row.status, STATUS_LABELS),
                createdAt: row.main_date,
                patientId: row.patient_id,
                hasVisited: !!row.first_visit_date,
                paymentCount: row.payment_count || 0,
                totalRevenue: row.total_revenue || 0,
                conversionStatus,
                conversionStatusLabel: conversionStatus === 'converted' ? '결제 완료' :
                    conversionStatus === 'visited' ? '내원 완료' :
                        conversionStatus === 'patient_created' ? '환자 등록' : '진행 중',
                // Optional: extract key info from intake_data
                mainSymptom: intakeData?.main_symptom || intakeData?.symptoms?.[0] || null,
                source: intakeData?.referral_source || intakeData?.source || null
            };
        });

        return new Response(JSON.stringify({
            data,
            total,
            totalRevenue,
            page,
            limit,
            totalPages: Math.ceil(total / limit),
            meta: {
                startDate: startParam,
                endDate: endParam,
                appliedFilters: {
                    channel: channelFilter,
                    patientType: patientTypeFilter,
                    consultType: consultTypeFilter,
                    tag: tagFilter,
                    status: statusFilter
                }
            }
        }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Channel Explorer Detail Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
