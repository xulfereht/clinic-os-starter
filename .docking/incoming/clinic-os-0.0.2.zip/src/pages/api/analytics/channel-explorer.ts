import type { APIRoute } from 'astro';

// Korean Label Mappings
export const CHANNEL_LABELS: Record<string, string> = {
    'naver_talk': '네이버 톡톡',
    'naver_talktalk': '네이버 톡톡',
    'kakao': '카카오톡 채널',
    'kakaotalk': '카카오톡 채널',
    'web': '홈페이지 문의',
    'intake_form': '예약 폼',
    'phone': '전화 문의',
    'chatgpt_app': 'AI 상담',
    'admin': '직접 등록',
    'direct': '직접 방문',
    'referral': '지인 소개',
    '': '미지정',
};

export const PATIENT_TYPE_LABELS: Record<string, string> = {
    'new': '초진',
    'new_lead': '초진',
    'existing_customer': '재진',
    'returning': '재진',
    '': '미지정',
};

export const CONSULT_TYPE_LABELS: Record<string, string> = {
    'remote': '비대면',
    'visit': '내원',
    '': '미지정',
};

export const STATUS_LABELS: Record<string, string> = {
    'new': '신규',
    'pending': '대기 중',
    'contacted': '연락 완료',
    'consulting': '상담 중',
    'reserved': '예약 확정',
    'visited': '내원 완료',
    'converted': '전환 완료',
    'closed': '종료',
    'lost': '이탈',
    '': '미지정',
};

// Helper to get label
export const getLabel = (value: string | null | undefined, map: Record<string, string>): string => {
    if (!value) return map[''] || value || '미지정';
    return map[value] || value;
};

// Date parsing helper
const parseDateToUnix = (dateStr: string | null, isEnd = false): number => {
    if (!dateStr) {
        const d = new Date();
        d.setHours(isEnd ? 23 : 0, isEnd ? 59 : 0, 0, 0);
        return Math.floor(d.getTime() / 1000);
    }
    const d = new Date(dateStr);
    if (isEnd) d.setHours(23, 59, 59, 999);
    else d.setHours(0, 0, 0, 0);
    return Math.floor(d.getTime() / 1000);
};

export const GET: APIRoute = async ({ locals, url }) => {
    // @ts-ignore
    const db = locals.runtime.env.DB;

    // Parse parameters
    const startParam = url.searchParams.get('startDate');
    const endParam = url.searchParams.get('endDate');
    const startTs = parseDateToUnix(startParam);
    const endTs = parseDateToUnix(endParam, true);

    const groupBy = url.searchParams.get('groupBy') || 'channel'; // channel, patient_type, type, tag
    const channelFilter = url.searchParams.get('channel');
    const patientTypeFilter = url.searchParams.get('patientType');
    const consultTypeFilter = url.searchParams.get('consultType');
    const tagFilter = url.searchParams.get('tag');

    try {
        // Build WHERE conditions
        const conditions: string[] = [
            'l.created_at BETWEEN ? AND ?',
            'l.deleted_at IS NULL'
        ];
        const params: any[] = [startTs, endTs];

        if (channelFilter) {
            conditions.push('l.channel = ?');
            params.push(channelFilter);
        }
        if (patientTypeFilter) {
            if (patientTypeFilter === 'new') {
                conditions.push("l.patient_type IN ('new', 'new_lead')");
            } else if (patientTypeFilter === 'returning') {
                conditions.push("l.patient_type IN ('existing_customer', 'returning')");
            }
        }
        if (consultTypeFilter) {
            conditions.push('l.type = ?');
            params.push(consultTypeFilter);
        }
        if (tagFilter) {
            conditions.push('l.tags LIKE ?');
            params.push(`%"${tagFilter}"%`);
        }

        const whereClause = conditions.join(' AND ');

        // Determine GROUP BY column
        let groupColumn: string;
        let labelMap: Record<string, string>;

        switch (groupBy) {
            case 'patient_type':
                groupColumn = 'l.patient_type';
                labelMap = PATIENT_TYPE_LABELS;
                break;
            case 'type':
                groupColumn = 'l.type';
                labelMap = CONSULT_TYPE_LABELS;
                break;
            case 'tag':
                // For tags, we need special handling since it's JSON array
                // We'll extract and aggregate later
                groupColumn = 'l.channel'; // fallback for now
                labelMap = CHANNEL_LABELS;
                break;
            case 'gender':
                groupColumn = 'p.gender';
                labelMap = { 'male': '남성', 'female': '여성', 'M': '남성', 'F': '여성', '': '미지정' };
                break;
            default:
                groupColumn = 'l.channel';
                labelMap = CHANNEL_LABELS;
        }

        // Main aggregation query
        const { results: leadStats } = await db.prepare(`
            SELECT 
                ${groupColumn} as group_key,
                COUNT(*) as leads,
                COUNT(DISTINCT CASE WHEN l.patient_id IS NOT NULL THEN l.patient_id END) as patients
            FROM leads l
            LEFT JOIN patients p ON l.patient_id = p.id
            WHERE ${whereClause}
            GROUP BY ${groupColumn}
            ORDER BY leads DESC
        `).bind(...params).run();

        // Get visit and payment stats per group
        const { results: visitStats } = await db.prepare(`
            SELECT 
                ${groupColumn} as group_key,
                COUNT(DISTINCT CASE WHEN p.first_visit_date IS NOT NULL AND p.first_visit_date != '' THEN p.id END) as visits
            FROM leads l
            LEFT JOIN patients p ON l.patient_id = p.id
            WHERE ${whereClause}
            GROUP BY ${groupColumn}
        `).bind(...params).run();

        const { results: paymentStats } = await db.prepare(`
            SELECT 
                ${groupColumn} as group_key,
                COUNT(DISTINCT pay.id) as payments,
                COALESCE(SUM(pay.amount), 0) as revenue
            FROM leads l
            LEFT JOIN patients p ON l.patient_id = p.id
            LEFT JOIN payments pay ON p.id = pay.patient_id AND pay.deleted_at IS NULL AND pay.amount > 0
            WHERE ${whereClause}
            GROUP BY ${groupColumn}
        `).bind(...params).run();

        // Merge results
        const visitMap = new Map((visitStats as any[]).map(v => [v.group_key, v]));
        const paymentMap = new Map((paymentStats as any[]).map(p => [p.group_key, p]));

        const data = (leadStats as any[]).map(row => {
            const key = row.group_key || '';
            const visits = visitMap.get(key)?.visits || 0;
            const payInfo = paymentMap.get(key) || { payments: 0, revenue: 0 };
            const leads = row.leads || 0;

            return {
                key,
                label: getLabel(key, labelMap),
                leads,
                patients: row.patients || 0,
                visits,
                payments: payInfo.payments || 0,
                revenue: payInfo.revenue || 0,
                conversionRate: leads > 0 ? Math.round((payInfo.payments / leads) * 100 * 10) / 10 : 0
            };
        });

        // Calculate Totals & Shares
        const totalLeads = data.reduce((sum, item) => sum + item.leads, 0);
        const totalVisits = data.reduce((sum, item) => sum + item.visits, 0);
        const totalRevenue = data.reduce((sum, item) => sum + item.revenue, 0);

        const enhancedData = data.map(item => ({
            ...item,
            share: {
                leads: totalLeads > 0 ? (item.leads / totalLeads * 100).toFixed(1) : 0,
                visits: totalVisits > 0 ? (item.visits / totalVisits * 100).toFixed(1) : 0,
                revenue: totalRevenue > 0 ? (item.revenue / totalRevenue * 100).toFixed(1) : 0,
            }
        }));

        // Get available filter options
        const { results: channelOptions } = await db.prepare(`
            SELECT DISTINCT channel FROM leads 
            WHERE created_at BETWEEN ? AND ? AND deleted_at IS NULL AND channel IS NOT NULL AND channel != ''
            ORDER BY channel
        `).bind(startTs, endTs).run();

        const { results: tagResults } = await db.prepare(`
            SELECT tags FROM leads 
            WHERE created_at BETWEEN ? AND ? AND deleted_at IS NULL AND tags IS NOT NULL AND tags != ''
        `).bind(startTs, endTs).run();

        // Extract unique tags from JSON arrays
        const allTags = new Set<string>();
        for (const row of tagResults as any[]) {
            try {
                const tags = JSON.parse(row.tags);
                if (Array.isArray(tags)) {
                    tags.forEach((t: string) => allTags.add(t));
                }
            } catch { }
        }

        return new Response(JSON.stringify({
            data: enhancedData,
            totals: {
                leads: totalLeads,
                visits: totalVisits,
                revenue: totalRevenue
            },
            filters: {
                availableChannels: (channelOptions as any[]).map(c => ({
                    value: c.channel,
                    label: getLabel(c.channel, CHANNEL_LABELS)
                })),
                availableTags: Array.from(allTags).sort(),
                patientTypes: [
                    { value: 'new', label: '초진' },
                    { value: 'returning', label: '재진' }
                ],
                consultTypes: [
                    { value: 'remote', label: '비대면' },
                    { value: 'visit', label: '내원' }
                ]
            },
            labels: {
                channels: CHANNEL_LABELS,
                patientTypes: PATIENT_TYPE_LABELS,
                consultTypes: CONSULT_TYPE_LABELS,
                statuses: STATUS_LABELS
            },
            meta: {
                startDate: startParam,
                endDate: endParam,
                groupBy,
                appliedFilters: {
                    channel: channelFilter,
                    patientType: patientTypeFilter,
                    consultType: consultTypeFilter,
                    tag: tagFilter
                }
            }
        }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        console.error('Channel Explorer Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
