import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    const db = locals.runtime.env.DB;
    const query = url.searchParams.get('q');

    if (!query || query.length < 2) {
        return new Response(JSON.stringify([]));
    }

    try {
        const { results } = await db.prepare(`
            SELECT id, name, current_phone, birth_date, gender
            FROM patients 
            WHERE name LIKE ? OR current_phone LIKE ? 
            LIMIT 5
        `).bind(`%${query}%`, `%${query}%`).run();

        return new Response(JSON.stringify(results));
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message || 'Unknown error' }), { status: 500 });
    }
};
