import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    const db = locals.runtime.env.DB;
    const date = url.searchParams.get('date');
    const doctorId = url.searchParams.get('doctorId');
    const status = url.searchParams.get('status');

    // Fetch Sample Mode
    const settingsRes = await db.prepare("SELECT value FROM site_settings WHERE category='features' AND key='sample_mode'").first();
    const isSampleMode = settingsRes?.value === 'true' || settingsRes?.value === '1';

    // Exclude walk-in records (those with notes containing '비예약' or created with completed status directly)
    let query = `
        SELECT r.*, p.name as patient_name, p.current_phone, s.name as doctor_name
        FROM reservations r
        JOIN patients p ON r.patient_id = p.id
        LEFT JOIN staff s ON r.doctor_id = s.id
        WHERE r.deleted_at IS NULL
        AND (r.notes IS NULL OR r.notes NOT LIKE '%비예약%')
    `;
    const params: any[] = [];

    // Sample Mode Filter
    if (isSampleMode) {
        query += ` AND (r.is_sample = 1 OR r.is_sample IS NULL)`;
    } else {
        query += ` AND (r.is_sample = 0 OR r.is_sample IS NULL)`;
    }

    if (date) {
        // Filter by specific day (start of day to end of day)
        const start = Math.floor(new Date(date).setHours(0, 0, 0, 0) / 1000);
        const end = Math.floor(new Date(date).setHours(23, 59, 59, 999) / 1000);
        query += ` AND r.reserved_at BETWEEN ? AND ?`;
        params.push(start, end);
    } else {
        query += ` ORDER BY r.reserved_at DESC LIMIT 100`;
        const { results } = await db.prepare(query).bind(...params).run();
        return new Response(JSON.stringify(results));
    }

    if (doctorId) {
        query += ` AND r.doctor_id = ?`;
        params.push(doctorId);
    }

    if (status) {
        query += ` AND r.status = ?`;
        params.push(status);
    }

    query += ` ORDER BY r.reserved_at ASC`;

    try {
        const { results } = await db.prepare(query).bind(...params).run();
        return new Response(JSON.stringify(results));
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message || 'Unknown error' }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ locals, request }) => {
    const db = locals.runtime.env.DB;
    const body = await request.json();
    const { patient_id, doctor_id, reserved_at, notes, status: requestStatus } = body;

    // Validate required fields
    if (!patient_id || !reserved_at) {
        return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
    }

    // For walk-ins (status: 'completed'), skip clinic hours validation
    const isWalkIn = requestStatus === 'completed';

    const reservationDate = new Date(reserved_at);
    const ts = Math.floor(reservationDate.getTime() / 1000);

    // Use KST timezone for day/time extraction (Korea Standard Time, UTC+9)
    const kstOptions: Intl.DateTimeFormatOptions = { timeZone: 'Asia/Seoul' };
    const dayOfWeek = new Date(reservationDate.toLocaleString('en-US', kstOptions)).getDay(); // 0=Sun, 1=Mon...
    const timeStr = reservationDate.toLocaleTimeString('en-US', {
        ...kstOptions,
        hour12: false,
        hour: '2-digit',
        minute: '2-digit'
    });

    // Fetch settings
    const settings = await db.prepare(`SELECT * FROM settings LIMIT 1`).first() as any;
    const slotMinutes = settings?.reservation_slot_minutes || 30;
    const maxPerSlot = settings?.max_patients_per_slot || 3;
    const enforceHours = settings?.enforce_clinic_hours !== 0; // Default true

    // Validate against clinic hours if enforcement is enabled (skip for walk-ins)
    if (enforceHours && !isWalkIn) {
        const schedule = await db.prepare(`
            SELECT * FROM clinic_weekly_schedules WHERE day_of_week = ?
        `).bind(dayOfWeek).first() as any;

        if (!schedule || schedule.is_closed) {
            return new Response(JSON.stringify({
                error: '해당 요일은 휴진일입니다.',
                code: 'CLOSED_DAY'
            }), { status: 400 });
        }

        // Check if time is within operating hours
        const openTime = schedule.open_time || '09:00';
        const closeTime = schedule.close_time || '18:00';

        if (timeStr < openTime || timeStr >= closeTime) {
            return new Response(JSON.stringify({
                error: `예약 가능 시간은 ${openTime} ~ ${closeTime} 입니다.`,
                code: 'OUTSIDE_HOURS'
            }), { status: 400 });
        }

        // Check lunch break - use defaults if not set (1pm-2pm)
        const lunchStart = schedule.lunch_start || '13:00';
        const lunchEnd = schedule.lunch_end || '14:00';
        if (timeStr >= lunchStart && timeStr < lunchEnd) {
            return new Response(JSON.stringify({
                error: `점심시간(${lunchStart} ~ ${lunchEnd})에는 예약할 수 없습니다.`,
                code: 'LUNCH_BREAK'
            }), { status: 400 });
        }
    }

    // Calculate slot boundaries for capacity check (skip for walk-ins)
    if (!isWalkIn) {
        const slotStart = Math.floor(ts / (slotMinutes * 60)) * (slotMinutes * 60);
        const slotEnd = slotStart + (slotMinutes * 60);

        // Count existing reservations in this slot
        const existing = await db.prepare(`
            SELECT COUNT(*) as count FROM reservations 
            WHERE reserved_at >= ? AND reserved_at < ? 
            AND status = 'scheduled'
        `).bind(slotStart, slotEnd).first() as any;

        if (existing && existing.count >= maxPerSlot) {
            return new Response(JSON.stringify({
                error: `해당 시간대(${slotMinutes}분 단위)는 이미 ${maxPerSlot}건의 예약이 있습니다.`,
                code: 'SLOT_FULL'
            }), { status: 400 });
        }
    }

    // Create reservation
    const id = crypto.randomUUID();

    try {
        const finalStatus = isWalkIn ? 'completed' : 'scheduled';
        const doctorIdValue = doctor_id || null;
        const notesValue = notes || null;
        const nowTs = Math.floor(Date.now() / 1000);
        const createdBy = locals.user?.id || null;

        // Get Patient's is_sample status
        const patient = await db.prepare("SELECT is_sample FROM patients WHERE id = ?").bind(patient_id).first();
        const isSample = patient?.is_sample || 0;

        await db.prepare(`
            INSERT INTO reservations (id, patient_id, doctor_id, reserved_at, status, notes, created_at, updated_at, created_by, is_sample)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(id, patient_id, doctorIdValue, ts, finalStatus, notesValue, nowTs, nowTs, createdBy, isSample).run();

        // Update patient's last activity time
        await db.prepare(`
            UPDATE patients SET last_activity_at = unixepoch(), updated_at = unixepoch() WHERE id = ?
            `).bind(patient_id).run();

        return new Response(JSON.stringify({ id, success: true }), { status: 201 });
    } catch (e: any) {
        console.error('Reservation creation error:', e);
        return new Response(JSON.stringify({ error: e.message || 'Unknown error' }), { status: 500 });
    }
};
