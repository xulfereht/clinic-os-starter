import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals, url }) => {
    const db = locals.runtime.env.DB;
    const date = url.searchParams.get('date');
    const doctorId = url.searchParams.get('doctorId');

    if (!date) {
        return new Response(JSON.stringify({ error: 'Date is required' }), { status: 400 });
    }

    // Parse date and get day of week in KST
    const dateObj = new Date(date);
    const kstOptions: Intl.DateTimeFormatOptions = { timeZone: 'Asia/Seoul' };
    const dayOfWeek = new Date(dateObj.toLocaleString('en-US', kstOptions)).getDay();

    // Get settings
    const settings = await db.prepare(`SELECT * FROM settings LIMIT 1`).first() as any;
    const slotMinutes = settings?.reservation_slot_minutes || 30;
    const maxPerSlot = settings?.max_patients_per_slot || 3;

    // Get schedule for this day
    const schedule = await db.prepare(`
        SELECT * FROM clinic_weekly_schedules WHERE day_of_week = ?
    `).bind(dayOfWeek).first() as any;

    if (!schedule || schedule.is_closed) {
        return new Response(JSON.stringify({
            closed: true,
            message: '해당 요일은 휴진일입니다.',
            slots: []
        }));
    }

    const openTime = schedule.open_time || '09:00';
    const closeTime = schedule.close_time || '18:00';
    // Default lunch times if not set in database (1pm-2pm)
    const lunchStart = schedule.lunch_start || '13:00';
    const lunchEnd = schedule.lunch_end || '14:00';

    // Generate slots
    const slots: { time: string; available: boolean; remaining: number; isLunch: boolean }[] = [];

    const [openHour, openMin] = openTime.split(':').map(Number);
    const [closeHour, closeMin] = closeTime.split(':').map(Number);

    let currentTime = openHour * 60 + openMin; // Convert to minutes
    const endTime = closeHour * 60 + closeMin;

    // Get start/end of day as timestamps for querying reservations
    const dayStart = Math.floor(new Date(`${date}T00:00:00`).getTime() / 1000);
    const dayEnd = Math.floor(new Date(`${date}T23:59:59`).getTime() / 1000);

    // Get all scheduled reservations for this day
    let reservationsQuery = `
        SELECT reserved_at FROM reservations 
        WHERE reserved_at >= ? AND reserved_at <= ? 
        AND status = 'scheduled'
    `;
    const params: any[] = [dayStart, dayEnd];

    if (doctorId) {
        reservationsQuery += ` AND doctor_id = ?`;
        params.push(doctorId);
    }

    const { results: reservations } = await db.prepare(reservationsQuery).bind(...params).run();

    // Count reservations per slot
    const reservationCounts = new Map<string, number>();
    reservations.forEach((r: any) => {
        const resDate = new Date(r.reserved_at * 1000);
        // Extract hours and minutes in KST
        const resHour = parseInt(resDate.toLocaleTimeString('en-US', { timeZone: 'Asia/Seoul', hour: '2-digit', hour12: false }), 10);
        const resMin = parseInt(resDate.toLocaleTimeString('en-US', { timeZone: 'Asia/Seoul', minute: '2-digit' }), 10);
        // Round to slot
        const slotKey = `${String(resHour).padStart(2, '0')}:${String(Math.floor(resMin / slotMinutes) * slotMinutes).padStart(2, '0')}`;
        reservationCounts.set(slotKey, (reservationCounts.get(slotKey) || 0) + 1);
    });

    // Generate slot list
    while (currentTime < endTime) {
        const hour = Math.floor(currentTime / 60);
        const min = currentTime % 60;
        const timeStr = `${String(hour).padStart(2, '0')}:${String(min).padStart(2, '0')}`;

        // Check if this is lunch time
        let isLunch = false;
        if (lunchStart && lunchEnd) {
            const [lunchStartHour, lunchStartMin] = lunchStart.split(':').map(Number);
            const [lunchEndHour, lunchEndMin] = lunchEnd.split(':').map(Number);
            const lunchStartMins = lunchStartHour * 60 + lunchStartMin;
            const lunchEndMins = lunchEndHour * 60 + lunchEndMin;
            isLunch = currentTime >= lunchStartMins && currentTime < lunchEndMins;
        }

        const booked = reservationCounts.get(timeStr) || 0;
        const remaining = maxPerSlot - booked;

        slots.push({
            time: timeStr,
            available: !isLunch && remaining > 0,
            remaining: isLunch ? 0 : remaining,
            isLunch
        });

        currentTime += slotMinutes;
    }

    return new Response(JSON.stringify({
        closed: false,
        openTime,
        closeTime,
        lunchStart,
        lunchEnd,
        slotMinutes,
        maxPerSlot,
        slots
    }));
};
