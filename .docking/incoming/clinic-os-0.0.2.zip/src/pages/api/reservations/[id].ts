import type { APIRoute } from 'astro';
import { PatientStatusService } from '../../../lib/patient-status';

export const GET: APIRoute = async ({ locals, params }) => {
    const db = locals.runtime.env.DB;
    const { id } = params;

    try {
        const reservation = await db.prepare(`
            SELECT r.*, s.name as doctor_name, p.name as patient_name
            FROM reservations r
            LEFT JOIN staff s ON r.doctor_id = s.id
            LEFT JOIN patients p ON r.patient_id = p.id
            WHERE r.id = ?
        `).bind(id).first();

        if (!reservation) {
            return new Response(JSON.stringify({ error: 'Reservation not found' }), { status: 404 });
        }

        return new Response(JSON.stringify({ reservation }));
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message || 'Unknown error' }), { status: 500 });
    }
};

export const PATCH: APIRoute = async ({ locals, params, request }) => {
    const db = locals.runtime.env.DB;
    const { id } = params;
    const body = await request.json();
    const { status, doctor_id, notes, reserved_at } = body;

    try {
        // 1. Fetch Request: Get current state BEFORE update
        const oldRes = await db.prepare(`
            SELECT r.*, s.name as doctor_name, p.name as patient_name
            FROM reservations r
            LEFT JOIN staff s ON r.doctor_id = s.id
            LEFT JOIN patients p ON r.patient_id = p.id
            WHERE r.id = ?
        `).bind(id).first();

        if (!oldRes) {
            return new Response(JSON.stringify({ error: 'Reservation not found' }), { status: 404 });
        }

        // 2. Prepare Update Query
        let query = `UPDATE reservations SET updated_at = unixepoch()`;
        const sqlParams: any[] = [];
        const changes: string[] = [];

        // Helper to format date
        const formatDate = (ts: number) => {
            const d = new Date(ts * 1000);
            return d.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false });
        };

        // Check for changes and build query
        if (status && status !== oldRes.status) {
            query += `, status = ?`;
            sqlParams.push(status);

            const statusMap: Record<string, string> = {
                'pending': '대기', 'scheduled': '예약됨', 'confirmed': '확정',
                'completed': '진료완료', 'cancelled': '취소', 'no_show': '노쇼'
            };
            changes.push(`상태: ${statusMap[oldRes.status as string] || oldRes.status} → ${statusMap[status] || status}`);
        }

        if (doctor_id !== undefined && doctor_id !== oldRes.doctor_id) {
            query += `, doctor_id = ?`;
            sqlParams.push(doctor_id);

            // Need to fetch new doctor name if changed
            if (doctor_id) {
                const newDoc = await db.prepare('SELECT name FROM staff WHERE id = ?').bind(doctor_id).first<{ name: string }>();
                changes.push(`담당의: ${oldRes.doctor_name || '미지정'} → ${newDoc?.name || '미지정'}`);
            } else {
                changes.push(`담당의: ${oldRes.doctor_name} → 미지정`);
            }
        }

        if (notes !== undefined && notes !== oldRes.notes) {
            query += `, notes = ?`;
            sqlParams.push(notes);
            if (!oldRes.notes && notes) changes.push(`메모 추가`);
            else if (oldRes.notes && !notes) changes.push(`메모 삭제`);
            else changes.push(`메모 수정`);
        }

        if (reserved_at) {
            const newTs = Math.floor(new Date(reserved_at).getTime() / 1000);
            if (newTs !== oldRes.reserved_at) {
                query += `, reserved_at = ?`;
                sqlParams.push(newTs);
                changes.push(`일시: ${formatDate(oldRes.reserved_at as number)} → ${formatDate(newTs)}`);
            }
        }

        query += ` WHERE id = ?`;
        sqlParams.push(id);

        // 3. Execute Update
        if (sqlParams.length > 1) { // id is always in params, so > 1 means updates exist
            await db.prepare(query).bind(...sqlParams).run();

            // 4. Log Changes to Timeline
            if (changes.length > 0) {
                const logs = changes.join(' | ');
                const eventId = crypto.randomUUID();

                // If status is cancelled/no_show, use more specific title
                let title = '예약 정보 변경';
                if (status === 'cancelled') title = '예약 취소';
                else if (status === 'no_show') title = '예약 노쇼';
                else if (status === 'rescheduled') title = '예약 변경';
                // Note: 'rescheduled' isn't a DB status usually, but we can infer from reserved_at change
                if (reserved_at && !status) title = '예약 시간 변경';

                await db.prepare(`
                    INSERT INTO patient_events (id, patient_id, type, title, content, event_date, created_at, staff_id)
                    VALUES (?, ?, 'reservation_update', ?, ?, ?, unixepoch(), ?)
                `).bind(
                    eventId,
                    oldRes.patient_id,
                    title,
                    logs,
                    Math.floor(Date.now() / 1000),
                    locals.user?.id || null // Log who made the change if possible
                ).run();
            }

            // Update patient last activity
            if (oldRes.patient_id && status) {
                await db.prepare(`
                    UPDATE patients SET last_activity_at = unixepoch(), updated_at = unixepoch() WHERE id = ?
                `).bind(oldRes.patient_id).run();
            }

            // 5. Special Logic for 'completed' (Visit Creation)
            // This logic is kept separate as adds a 'visit' event, distinct from the 'reservation_update' log
            if (status === 'completed' && oldRes.status !== 'completed') {
                const reservedAt = oldRes.reserved_at as number; // Use old time or new? DB is updated, but let's use the actual reservation time
                // If time changed too, we should use the NEW time.
                const finalReservedAt = reserved_at ? Math.floor(new Date(reserved_at).getTime() / 1000) : reservedAt;

                const prevVisits = await db.prepare(`
                    SELECT COUNT(*) as count FROM patient_events 
                    WHERE patient_id = ? AND type = 'visit'
                `).bind(oldRes.patient_id).first<{ count: number }>();

                const isFirstVisit = !prevVisits || prevVisits.count === 0;
                const visitTitle = isFirstVisit ? '초진 내원' : '재진 내원';

                const visitDate = new Date(finalReservedAt * 1000);
                const visitTimeStr = visitDate.toLocaleTimeString('ko-KR', {
                    timeZone: 'Asia/Seoul', hour: '2-digit', minute: '2-digit', hour12: false
                });
                const visitContent = `예약시간 ${visitTimeStr} / 내원확인 완료`;

                const visitEventId = crypto.randomUUID();
                const now = Math.floor(Date.now() / 1000);

                await db.prepare(`
                    INSERT INTO patient_events (id, patient_id, type, title, content, event_date, created_at, staff_id)
                    VALUES (?, ?, 'visit', ?, ?, ?, ?, ?)
                `).bind(visitEventId, oldRes.patient_id, visitTitle, visitContent, now, now, oldRes.doctor_id).run(); // Use doctor from reservation

                const service = new PatientStatusService(db);
                await service.updatePatientStatus(oldRes.patient_id as string);

                // Update last visit date
                const kstOffset = 9 * 60 * 60 * 1000;
                const localVisitTime = new Date(visitDate.getTime() + kstOffset);
                const visitDateStr = localVisitTime.toISOString().split('T')[0];

                await db.prepare(`
                    UPDATE patients SET last_visit_date = ?, updated_at = unixepoch() WHERE id = ?
                `).bind(visitDateStr, oldRes.patient_id).run();
            }

            // Update status service for other status changes
            if (status && status !== oldRes.status) {
                const service = new PatientStatusService(db);
                await service.updatePatientStatus(oldRes.patient_id as string);
            }
        }

        return new Response(JSON.stringify({ success: true }));
    } catch (e: any) {
        console.error('PATCH Error:', e);
        return new Response(JSON.stringify({ error: e.message || 'Unknown error' }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ locals, params }) => {
    const db = locals.runtime.env.DB;
    const { id } = params;

    try {
        await db.prepare(`UPDATE reservations SET deleted_at = unixepoch() WHERE id = ?`).bind(id).run();
        return new Response(JSON.stringify({ success: true }));
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
