
import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response('No DB', { status: 500 });
    }

    try {
        // 1. Drop the WRONG campaigns table (the one I created for events)
        // Check schema first to be safe? No, just drop.
        await db.prepare("DROP TABLE IF EXISTS campaigns").run();

        // 2. Restore the ORIGINAL campaigns table (for SMS)
        // Schema inferred from campaigns.astro
        await db.prepare(`
            CREATE TABLE IF NOT EXISTS campaigns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                template_id INTEGER,
                segment_id INTEGER,
                status TEXT DEFAULT 'draft',
                sent_count INTEGER DEFAULT 0,
                total_count INTEGER DEFAULT 0,
                created_at INTEGER
            )
        `).run();

        // 3. Create the NEW event_campaigns table (for Forms)
        await db.prepare(`
            CREATE TABLE IF NOT EXISTS event_campaigns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slug TEXT UNIQUE,
                title TEXT,
                description TEXT,
                products TEXT, -- JSON array of strings or objects {label, value}
                is_active INTEGER DEFAULT 1,
                created_at INTEGER
            )
        `).run();

        // 4. Seed '2025-year-end' into event_campaigns
        const existing = await db.prepare("SELECT * FROM event_campaigns WHERE slug = ?").bind('2025-year-end').first();

        if (!existing) {
            const defaultProducts = [
                { label: '백록감비정 (다이어트)', value: '감비정', desc: '체지방 감소, 식욕 억제' },
                { label: '녹용 보약', value: '녹용보약', desc: '기력 회복, 면역력 강화' },
                { label: '원방공진단 (사향)', value: '원방공진단', desc: '황제의 보약, 만성 피로' },
                { label: '경옥고', value: '경옥고', desc: '호흡기 강화, 자양 강장' }
            ];

            await db.prepare(`
                INSERT INTO event_campaigns (slug, title, description, products, is_active, created_at)
                VALUES (?, ?, ?, ?, ?, unixepoch())
            `).bind(
                '2025-year-end',
                '2025 연말 감사제',
                '기존 고객님들을 위해 준비한 특별 혜택입니다. 원하시는 항목을 선택해주시면 혜택을 적용해드립니다.',
                JSON.stringify(defaultProducts),
                1
            ).run();
        }

        return new Response('Schema restored. SMS campaigns table recreated (empty). Event campaigns table created and seeded.', { status: 200 });

    } catch (e: any) {
        return new Response('Error: ' + e.message, { status: 500 });
    }
};
