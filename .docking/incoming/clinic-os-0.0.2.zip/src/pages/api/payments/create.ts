import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { patient_id, amount, product_id, method, notes, paid_at, quantity } = body;

        if (!patient_id || !amount) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
        }

        const id = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);
        // Default paid_at to now if not provided, ensuring we handle ISO string or timestamp
        let paidAtTs = now;
        if (paid_at) {
            // Handle YYYY-MM-DD format explicitly as KST
            if (typeof paid_at === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(paid_at)) {
                // Determine if the selected date is "today" in KST
                // Determine if the selected date is "today" in KST
                const dateKstStr = paid_at;
                const todayKstStr = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Seoul' });

                if (dateKstStr === todayKstStr) {
                    // If selected date is TODAY, use current time (preserve HH:MM:SS)
                    paidAtTs = now;
                } else {
                    // If selected date is NOT today (historical), default to 00:00 KST
                    // Append T00:00:00+09:00 to treat as KST midnight
                    const kstDate = new Date(`${paid_at}T00:00:00+09:00`);
                    if (!isNaN(kstDate.getTime())) {
                        paidAtTs = Math.floor(kstDate.getTime() / 1000);
                    }
                }
            } else {
                // ISO string or other format
                const date = new Date(paid_at);
                if (!isNaN(date.getTime())) {
                    paidAtTs = Math.floor(date.getTime() / 1000);
                }
            }
        }

        const createdBy = locals.user?.id || null;

        // Get Patient's is_sample status
        const patient = await db.prepare("SELECT is_sample FROM patients WHERE id = ?").bind(patient_id).first();
        const isSample = patient?.is_sample || 0;

        await db.prepare(`
            INSERT INTO payments (id, patient_id, product_id, amount, method, status, notes, quantity, paid_at, created_at, updated_at, created_by, is_sample)
            VALUES (?, ?, ?, ?, ?, 'paid', ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            id,
            patient_id,
            product_id || null,
            amount,
            method || 'card',
            notes || '',
            quantity || 1,
            paidAtTs,
            now,
            now,
            createdBy,
            isSample
        ).run();

        // If product is linked, we should optionally update remaining quantity in shipping_orders if this was a subscription payment.
        // But for now, we just record the payment as requested. Simple record.

        // Update patient's last activity time
        await db.prepare(`
            UPDATE patients SET last_activity_at = unixepoch(), updated_at = unixepoch() WHERE id = ?
        `).bind(patient_id).run();

        return new Response(JSON.stringify({ success: true, id }), { status: 200 });

    } catch (e: any) {
        console.error('Error creating payment:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
