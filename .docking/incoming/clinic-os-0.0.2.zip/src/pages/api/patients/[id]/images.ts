import type { APIRoute } from 'astro';

// HMAC Signature for permanent access
async function generateSignature(key: string, secret: string): Promise<string> {
    const enc = new TextEncoder();
    const algorithm = { name: 'HMAC', hash: 'SHA-256' };
    const keyData = await crypto.subtle.importKey('raw', enc.encode(secret), algorithm, false, ['sign']);
    const signature = await crypto.subtle.sign(algorithm.name, keyData, enc.encode(key));
    return Array.from(new Uint8Array(signature))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}

export const POST: APIRoute = async ({ params, request, locals }) => {
    const { id: patientId } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const bucket = locals.runtime?.env?.BUCKET;
    // @ts-ignore
    const secret = (locals.runtime?.env?.ADMIN_PASSWORD || 'clinic-admin') as string;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    if (!bucket) {
        return new Response(JSON.stringify({ error: 'Storage not available' }), { status: 500 });
    }

    try {
        const formData = await request.formData();
        const file = formData.get('file') as File;
        const description = formData.get('description') as string || '';

        if (!file) {
            return new Response(JSON.stringify({ error: 'No file provided' }), { status: 400 });
        }

        // Validate file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
            return new Response(JSON.stringify({ error: 'File size exceeds 5MB limit' }), { status: 400 });
        }

        const imageId = crypto.randomUUID();
        const now = Math.floor(Date.now() / 1000);
        const ext = file.name.split('.').pop() || 'jpg';

        // Store in R2: patients/{patientId}/images/{uuid}.{ext}
        const filename = `patients/${patientId}/images/${imageId}.${ext}`;

        const arrayBuffer = await file.arrayBuffer();
        await bucket.put(filename, arrayBuffer, {
            httpMetadata: { contentType: file.type },
        });

        // Generate signed URL for permanent access
        const signature = await generateSignature(filename, secret);
        const signedUrl = `/api/files/${filename}?sig=${signature}`;

        // Store URL reference in D1 (not base64 data)
        await db.prepare(`
            INSERT INTO patient_images (id, patient_id, file_name, mime_type, data, size, uploaded_at, description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
            imageId,
            patientId,
            file.name,
            file.type,
            signedUrl,  // Store signed URL instead of base64
            file.size,
            now,
            description
        ).run();

        return new Response(JSON.stringify({
            success: true,
            id: imageId,
            url: signedUrl,
            file_name: file.name,
            uploaded_at: now,
            description: description
        }), { status: 200 });

    } catch (error) {
        console.error('Upload error:', error);
        return new Response(JSON.stringify({ error: 'Failed to upload image' }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, request, locals }) => {
    const { id: patientId } = params; // patientId from URL
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const url = new URL(request.url);
        const imageId = url.searchParams.get('imageId');

        if (!imageId) {
            return new Response(JSON.stringify({ error: 'Image ID required' }), { status: 400 });
        }

        // Verify ownership
        const image = await db.prepare("SELECT * FROM patient_images WHERE id = ? AND patient_id = ?").bind(imageId, patientId).first();
        if (!image) {
            return new Response(JSON.stringify({ error: 'Image not found' }), { status: 404 });
        }

        await db.prepare("DELETE FROM patient_images WHERE id = ?").bind(imageId).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (error) {
        console.error('Delete error:', error);
        return new Response(JSON.stringify({ error: 'Failed to delete image' }), { status: 500 });
    }
};
