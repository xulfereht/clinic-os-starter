import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const data = await request.json();
        const { item_id, quantity_change, reason, created_by, transaction_date, type, new_stock } = data;
        const id = crypto.randomUUID();

        // Use provided date or current timestamp
        const txDate = transaction_date || Math.floor(Date.now() / 1000);
        const txType = type || (quantity_change >= 0 ? 'restock' : 'usage');

        // For adjustments, we set stock_level directly; otherwise we add/subtract
        let updateItem;
        if (type === 'adjustment' && new_stock !== undefined) {
            // Direct stock level setting
            updateItem = locals.runtime.env.DB.prepare(
                `UPDATE inventory_items SET stock_level = ?, updated_at = unixepoch() WHERE id = ?`
            ).bind(new_stock, item_id);
        } else {
            // Regular add/subtract
            updateItem = locals.runtime.env.DB.prepare(
                `UPDATE inventory_items SET stock_level = stock_level + ?, updated_at = unixepoch() WHERE id = ?`
            ).bind(quantity_change, item_id);
        }

        // Log Transaction with type
        const logTransaction = locals.runtime.env.DB.prepare(
            `INSERT INTO inventory_transactions (id, item_id, quantity_change, reason, created_by, transaction_date, type) 
             VALUES (?, ?, ?, ?, ?, ?, ?)`
        ).bind(id, item_id, quantity_change, reason, created_by, txDate, txType);

        // Execute as batch
        await locals.runtime.env.DB.batch([updateItem, logTransaction]);

        return new Response(JSON.stringify({ id, message: 'Transaction recorded' }), { status: 201 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
