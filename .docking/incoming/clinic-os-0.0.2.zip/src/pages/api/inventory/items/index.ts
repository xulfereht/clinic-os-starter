import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT i.*, v.name as vendor_name 
       FROM inventory_items i 
       LEFT JOIN vendors v ON i.vendor_id = v.id 
       ORDER BY i.category, i.name`
        ).run();

        return new Response(JSON.stringify(results), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    try {
        const data = await request.json();
        const { name, category, vendor_id, stock_level, min_stock_level, unit, location, memo } = data;
        const id = crypto.randomUUID();

        await locals.runtime.env.DB.prepare(
            `INSERT INTO inventory_items (id, name, category, vendor_id, stock_level, min_stock_level, unit, location, memo) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).bind(id, name, category, vendor_id, stock_level || 0, min_stock_level || 5, unit || 'ea', location, memo).run();

        return new Response(JSON.stringify({ id, message: 'Item created' }), { status: 201 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
