import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT i.*, v.name as vendor_name 
       FROM inventory_items i 
       LEFT JOIN vendors v ON i.vendor_id = v.id 
       WHERE i.id = ?`
        ).bind(id).run();

        if (!results.length) {
            return new Response(JSON.stringify({ error: 'Item not found' }), { status: 404 });
        }

        return new Response(JSON.stringify(results[0]), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    try {
        const data = await request.json();
        const { name, category, vendor_id, min_stock_level, unit, location, memo } = data;

        await locals.runtime.env.DB.prepare(
            `UPDATE inventory_items 
       SET name = ?, category = ?, vendor_id = ?, min_stock_level = ?, unit = ?, location = ?, memo = ?, updated_at = unixepoch() 
       WHERE id = ?`
        ).bind(name, category, vendor_id, min_stock_level, unit, location, memo, id).run();

        return new Response(JSON.stringify({ message: 'Item updated' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    try {
        await locals.runtime.env.DB.prepare(
            `UPDATE inventory_items SET deleted_at = unixepoch() WHERE id = ?`
        ).bind(id).run();

        return new Response(JSON.stringify({ message: 'Item deleted' }), { status: 200 });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
