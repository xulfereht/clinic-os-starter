import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    try {
        const { results } = await locals.runtime.env.DB.prepare(
            `SELECT t.*, s.name as created_by_name 
             FROM inventory_transactions t
             LEFT JOIN staff s ON t.created_by = s.id
             WHERE t.item_id = ?
             ORDER BY t.transaction_date DESC, t.created_at DESC
             LIMIT 50`
        ).bind(id).run();

        return new Response(JSON.stringify(results), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        return new Response(JSON.stringify({ error: (error as Error).message }), { status: 500 });
    }
};
