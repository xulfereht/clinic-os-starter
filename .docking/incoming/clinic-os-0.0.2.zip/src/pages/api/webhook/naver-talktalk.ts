/**
 * Naver TalkTalk Webhook Receiver
 * 
 * Receives messages from Naver TalkTalk and stores them in the messenger system.
 * 
 * Required Header: Authorization (must match stored token)
 */

import type { APIRoute } from 'astro';
import { getNaverTalkConfig } from '../../../lib/integrations/naver-talktalk';

export const prerender = false;

interface NaverTalkEvent {
    event: 'open' | 'send' | 'leave' | 'friend' | 'echo';
    user: string;
    textContent?: {
        text: string;
        inputType?: string;
        code?: string;
    };
    imageContent?: {
        imageUrl: string;
    };
    options?: any;
}

export const POST: APIRoute = async ({ request, locals }) => {
    console.log('[NaverTalk Webhook] Received request');

    try {
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (!db) {
            console.error('[NaverTalk Webhook] DB not available');
            return new Response(JSON.stringify({ success: false, resultCode: '99', resultMessage: 'DB not available' }), {
                status: 500,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Get stored config and validate authorization
        const config = await getNaverTalkConfig(db);
        if (!config || !config.enabled) {
            console.log('[NaverTalk Webhook] Integration not enabled');
            return new Response(JSON.stringify({ success: false, resultCode: '99', resultMessage: 'Integration not enabled' }), {
                status: 403,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Parse event
        const event: NaverTalkEvent = await request.json();
        console.log('[NaverTalk Webhook] Event:', event.event, 'User:', event.user);

        // Handle different event types
        switch (event.event) {
            case 'open':
                // User started a chat - create or activate channel
                await handleOpenEvent(db, event);
                break;

            case 'send':
                // User sent a message - store it
                await handleSendEvent(db, event);
                break;

            case 'leave':
                // User left chat - mark channel as inactive
                await handleLeaveEvent(db, event);
                break;

            case 'echo':
                // Echo of our own message - ignore
                break;

            default:
                console.log('[NaverTalk Webhook] Unknown event type:', event.event);
        }

        // Always return success to Naver
        return new Response(JSON.stringify({ success: true, resultCode: '00' }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (error: any) {
        console.error('[NaverTalk Webhook] Error:', error);
        return new Response(JSON.stringify({ success: false, resultCode: '99', resultMessage: error.message }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
};

/**
 * Handle 'open' event - user started a chat
 */
async function handleOpenEvent(db: any, event: NaverTalkEvent) {
    const channelId = `naver_${event.user}`;

    // Check if channel exists
    const existing = await db.prepare('SELECT id FROM channels WHERE id = ?').bind(channelId).first();

    if (!existing) {
        // Create new channel
        const now = Math.floor(Date.now() / 1000);
        await db.prepare(`
            INSERT INTO channels (id, type, name, source, status, created_at, last_message_at)
            VALUES (?, 'customer', '네이버 톡톡 고객', 'naver_talktalk', 'active', ?, ?)
        `).bind(channelId, now, now).run();

        console.log('[NaverTalk Webhook] Created channel:', channelId);
    } else {
        // Update status to active
        await db.prepare('UPDATE channels SET status = ? WHERE id = ?').bind('active', channelId).run();
    }
}

/**
 * Handle 'send' event - user sent a message
 */
async function handleSendEvent(db: any, event: NaverTalkEvent) {
    const channelId = `naver_${event.user}`;
    const now = Math.floor(Date.now() / 1000);
    const msgId = crypto.randomUUID();

    // Ensure channel exists
    const channelExists = await db.prepare('SELECT id, lead_id FROM channels WHERE id = ?').bind(channelId).first();
    if (!channelExists) {
        await handleOpenEvent(db, event);
    }

    // Determine content
    let content = '';
    let fileUrl = null;
    let fileType = null;

    if (event.textContent) {
        content = event.textContent.text;
    } else if (event.imageContent) {
        content = '[이미지]';
        fileUrl = event.imageContent.imageUrl;
        fileType = 'image';
    }

    // Insert message
    await db.prepare(`
        INSERT INTO admin_messages (id, channel_id, sender_id, content, file_url, file_type, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(msgId, channelId, `naver:${event.user}`, content, fileUrl, fileType, now).run();

    // Update channel last_message
    await db.prepare(`
        UPDATE channels SET last_message = ?, last_message_at = ?, status = 'active' WHERE id = ?
    `).bind(content.substring(0, 100), now, channelId).run();

    console.log('[NaverTalk Webhook] Saved message:', msgId, 'Content:', content.substring(0, 50));

    // Create lead if not exists or 24h passed since last lead
    const lastLead = await db.prepare(`
        SELECT * FROM leads WHERE channel = 'naver_talk' AND contact = ? 
        ORDER BY created_at DESC LIMIT 1
    `).bind(event.user).first();

    const shouldCreateNewLead = !lastLead ||
        (now - ((lastLead as any).created_at || 0)) > 86400;  // 24시간

    if (shouldCreateNewLead) {
        const leadId = crypto.randomUUID();
        const intakeData = JSON.stringify({
            naver_user_id: event.user,
            first_message: content,
            source: 'naver_talktalk'
        });

        await db.prepare(`
            INSERT INTO leads (
                id, type, status, channel, intake_data, name, contact, created_at, updated_at, patient_type
            ) VALUES (?, 'inquiry', 'new', 'naver_talk', ?, ?, ?, ?, ?, 'new_lead')
        `).bind(
            leadId,
            intakeData,
            '네이버 톡톡 문의',
            event.user,
            now,
            now
        ).run();

        // Link channel to lead
        await db.prepare(`
            UPDATE channels SET lead_id = ? WHERE id = ?
        `).bind(leadId, channelId).run();

        // Log lead event
        await db.prepare(`
            INSERT INTO lead_events (id, lead_id, type, content, created_at)
            VALUES (?, ?, 'created', ?, ?)
        `).bind(
            crypto.randomUUID(),
            leadId,
            JSON.stringify({ source: 'naver_talktalk', first_message: content }),
            now
        ).run();

        console.log('[NaverTalk Webhook] Created lead:', leadId, 'for user:', event.user);
    } else {
        // Update existing lead's updated_at
        await db.prepare(`
            UPDATE leads SET updated_at = ? WHERE id = ?
        `).bind(now, (lastLead as any).id).run();

        // Link channel to existing lead if not linked
        if (!channelExists?.lead_id) {
            await db.prepare(`
                UPDATE channels SET lead_id = ? WHERE id = ?
            `).bind((lastLead as any).id, channelId).run();
        }

        console.log('[NaverTalk Webhook] Updated existing lead:', (lastLead as any).id);
    }
}

/**
 * Handle 'leave' event - user left the chat
 */
async function handleLeaveEvent(db: any, event: NaverTalkEvent) {
    const channelId = `naver_${event.user}`;

    await db.prepare('UPDATE channels SET status = ? WHERE id = ?').bind('closed', channelId).run();

    console.log('[NaverTalk Webhook] Closed channel:', channelId);
}
