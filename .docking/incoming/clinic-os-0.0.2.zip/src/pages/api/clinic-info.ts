import type { APIRoute } from 'astro';
import { getClinicSettings } from '../../lib/clinic';

export const GET: APIRoute = async (context) => {
    // @ts-ignore
    const db = context.locals.runtime?.env?.DB;
    const settings = await getClinicSettings(db);

    const info = {
        name: settings.name,
        description: settings.description,
        contact: settings.contact,
        hours: settings.hours,
        bookingUrl: settings.contact.bookingUrl
    };

    return new Response(JSON.stringify(info), {
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    });
};
