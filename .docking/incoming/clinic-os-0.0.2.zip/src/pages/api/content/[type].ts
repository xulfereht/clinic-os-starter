import type { APIRoute } from 'astro';

export const prerender = false;

export const POST: APIRoute = async ({ request, params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });

    const { type } = params;
    if (!['blog', 'column', 'notice', 'review'].includes(type || '')) {
        return new Response(JSON.stringify({ error: "Invalid content type" }), { status: 400 });
    }

    try {
        const data = await request.json();
        const {
            title,
            slug: providedSlug,
            content,
            excerpt,
            featured_image,
            status = 'draft',
            category,
            doctor_id,
            patient_id,
            patient_name,
            is_pinned,
            is_new = true,
            id: providedId
        } = data;

        if (!title) return new Response(JSON.stringify({ error: "Title is required" }), { status: 400 });

        // Convert undefined to null for D1 compatibility
        const safeExcerpt = excerpt ?? null;
        const safeFeaturedImage = featured_image ?? null;
        const safeCategory = category ?? null;
        const safeDoctorId = doctor_id ?? null;
        const safePatientId = patient_id ?? null;
        const safePatientName = patient_name ?? null;
        const safeIsPinned = is_pinned ?? 0;

        // Generate slug
        let slug = providedSlug;
        if (!slug) {
            slug = title.toLowerCase()
                .replace(/[^a-z0-9가-힣]/g, '-')
                .replace(/-+/g, '-')
                .replace(/^-|-$/g, '')
                + '-' + Date.now();
        }

        const now = Math.floor(Date.now() / 1000);
        const postId = is_new ? (providedId || crypto.randomUUID()) : providedId;

        const safeTranslations = data.translations || '{}';

        if (is_new) {
            // For notices, include is_pinned
            if (type === 'notice') {
                await db.prepare(`
                    INSERT INTO posts (
                        id, type, title, slug, excerpt, content, 
                        featured_image, status, category, 
                        doctor_id, patient_id, is_pinned,
                        translations,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `).bind(
                    postId, type, title, slug, safeExcerpt, content,
                    safeFeaturedImage, status, safeCategory,
                    safeDoctorId, safePatientId, safeIsPinned,
                    safeTranslations,
                    now, now
                ).run();
            } else {
                await db.prepare(`
                    INSERT INTO posts (
                        id, type, title, slug, excerpt, content, 
                        featured_image, status, category, 
                        doctor_id, patient_id, patient_name,
                        translations,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `).bind(
                    postId, type, title, slug, safeExcerpt, content,
                    safeFeaturedImage, status, safeCategory,
                    safeDoctorId, safePatientId, safePatientName,
                    safeTranslations,
                    now, now
                ).run();
            }
        } else {
            // Update - handle is_pinned for notices
            if (type === 'notice') {
                await db.prepare(`
                    UPDATE posts SET 
                        title = ?, slug = ?, excerpt = ?, content = ?, 
                        featured_image = ?, status = ?, category = ?, 
                        doctor_id = ?, patient_id = ?, is_pinned = ?,
                        translations = ?,
                        updated_at = ?
                    WHERE id = ?
                `).bind(
                    title, slug, safeExcerpt, content,
                    safeFeaturedImage, status, safeCategory,
                    safeDoctorId, safePatientId, safeIsPinned,
                    safeTranslations,
                    now, postId
                ).run();
            } else {
                await db.prepare(`
                    UPDATE posts SET 
                        title = ?, slug = ?, excerpt = ?, content = ?, 
                        featured_image = ?, status = ?, category = ?, 
                        doctor_id = ?, patient_id = ?, patient_name = ?,
                        translations = ?,
                        updated_at = ?
                    WHERE id = ?
                `).bind(
                    title, slug, safeExcerpt, content,
                    safeFeaturedImage, status, safeCategory,
                    safeDoctorId, safePatientId, safePatientName,
                    safeTranslations,
                    now, postId
                ).run();
            }
        }

        // Save translations to post_translations table (separate from JSON field)
        if (data.translations && typeof data.translations === 'object') {
            const locales = ['en', 'ja', 'zh-hans'];
            for (const locale of locales) {
                const trans = data.translations[locale];
                if (trans && (trans.title || trans.content)) {
                    // Check if translation exists
                    const existing = await db.prepare(
                        "SELECT id FROM post_translations WHERE post_id = ? AND locale = ?"
                    ).bind(postId, locale).first();

                    if (existing) {
                        // Update existing translation
                        await db.prepare(`
                            UPDATE post_translations SET 
                                title = ?, content = ?, excerpt = ?, 
                                status = 'published', updated_at = ?
                            WHERE post_id = ? AND locale = ?
                        `).bind(
                            trans.title || '',
                            trans.content || '',
                            trans.excerpt || '',
                            now,
                            postId, locale
                        ).run();
                    } else {
                        // Insert new translation
                        await db.prepare(`
                            INSERT INTO post_translations (
                                post_id, locale, title, content, excerpt, 
                                status, created_at, updated_at
                            ) VALUES (?, ?, ?, ?, ?, 'published', ?, ?)
                        `).bind(
                            postId, locale,
                            trans.title || '',
                            trans.content || '',
                            trans.excerpt || '',
                            now, now
                        ).run();
                    }
                }
            }
        }

        return new Response(JSON.stringify({ success: true, id: postId, slug }), { status: 200 });
    } catch (e: any) {
        console.error(`Content API Error (${type}):`, e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });

    const url = new URL(request.url);
    const id = url.searchParams.get('id');

    if (!id) return new Response(JSON.stringify({ error: "ID is required" }), { status: 400 });

    try {
        await db.prepare("DELETE FROM posts WHERE id = ?").bind(id).run();
        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
