import type { APIRoute } from 'astro';

export const prerender = false;

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { name, role, bio, education, career, image, specialties, assignedPrograms } = body;

        // Update doctor details
        await db.prepare(
            "UPDATE doctors SET name = ?, role = ?, bio = ?, education = ?, career = ?, image = ?, specialties = ?, updated_at = strftime('%s', 'now') WHERE id = ?"
        ).bind(name, role, bio, education || '', career || '', image, JSON.stringify(specialties), id).run();

        // Handle program assignments if provided
        if (assignedPrograms !== undefined) {
            // First, unassign all programs from this doctor
            await db.prepare("UPDATE programs SET doctor_id = NULL WHERE doctor_id = ?").bind(id).run();

            // Then, assign selected programs
            if (assignedPrograms.length > 0) {
                for (const programId of assignedPrograms) {
                    await db.prepare("UPDATE programs SET doctor_id = ? WHERE id = ?").bind(id, programId).run();
                }
            }
        }

        return new Response(JSON.stringify({ status: "ok" }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const DELETE: APIRoute = async ({ params, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        // Unassign all programs from this doctor before deleting
        await db.prepare("UPDATE programs SET doctor_id = NULL WHERE doctor_id = ?").bind(id).run();

        // Delete the doctor
        await db.prepare("DELETE FROM staff WHERE id = ?").bind(id).run();

        return new Response(JSON.stringify({ status: "ok" }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
