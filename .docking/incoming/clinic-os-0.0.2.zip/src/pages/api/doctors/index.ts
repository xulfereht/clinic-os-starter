import type { APIRoute } from 'astro';

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { name, role, bio, education, career, image, specialties, assignedPrograms } = body;
        const id = `doc_${crypto.randomUUID().split('-')[0]}`;

        await db.prepare(
            "INSERT INTO doctors (id, name, role, bio, education, career, image, specialties) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        ).bind(id, name, role, bio, education || '', career || '', image, JSON.stringify(specialties)).run();

        // Handle program assignments if provided
        if (assignedPrograms && assignedPrograms.length > 0) {
            for (const programId of assignedPrograms) {
                await db.prepare("UPDATE programs SET doctor_id = ? WHERE id = ?").bind(id, programId).run();
            }
        }

        return new Response(JSON.stringify({ status: "ok", id }), { status: 201 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
