import type { APIRoute } from 'astro';

export const prerender = false;

export const PUT: APIRoute = async ({ params, request, locals }) => {
    const { id } = params;
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: "Database not available" }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { status, notes, symptoms, summary } = body;

        // Build dynamic query
        let query = "UPDATE leads SET ";
        const params = [];

        const updates = [];
        if (status !== undefined) {
            updates.push("status = ?");
            params.push(status);

            // Update closed_at logic
            if (status === 'closed' || status === 'cancelled') {
                updates.push("closed_at = ?");
                params.push(Math.floor(Date.now() / 1000));
            } else {
                updates.push("closed_at = NULL");
            }
        }
        if (notes !== undefined) {
            updates.push("notes = ?");
            params.push(notes);
        }
        if (symptoms !== undefined) {
            updates.push("symptoms = ?");
            params.push(JSON.stringify(symptoms));
        }
        if (summary !== undefined) {
            updates.push("summary = ?");
            params.push(summary);
        }
        if (body.visit_date !== undefined) {
            updates.push("visit_date = ?");
            params.push(body.visit_date);
        }

        if (updates.length === 0) {
            return new Response(JSON.stringify({ status: "ok", message: "No changes" }), { status: 200 });
        }

        query += updates.join(", ");
        query += " WHERE id = ?";
        params.push(id);

        await db.prepare(query).bind(...params).run();

        return new Response(JSON.stringify({ status: "ok", message: "Lead updated" }), { status: 200 });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
