import type { APIRoute } from "astro";

export const prerender = false;

export const DELETE: APIRoute = async ({ request, locals }) => {
    // Auth check
    const cookie = request.headers.get("cookie");
    if (!cookie || !cookie.includes("admin_session=true")) {
        return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });
    }

    try {
        // @ts-ignore
        if (!locals.runtime?.env?.DB) {
            return new Response(JSON.stringify({ error: "DB not found" }), { status: 500 });
        }
        // @ts-ignore
        const db = locals.runtime.env.DB;

        const body = await request.json();
        const { id } = body;

        if (!id) {
            return new Response(JSON.stringify({ error: "ID required" }), { status: 400 });
        }

        // Soft delete: set deleted_at timestamp
        await db.prepare(`
      UPDATE intakes 
      SET deleted_at = strftime('%s', 'now') 
      WHERE id = ? AND deleted_at IS NULL
    `).bind(id).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

export const POST: APIRoute = async ({ request, locals }) => {
    // Restore endpoint
    const cookie = request.headers.get("cookie");
    if (!cookie || !cookie.includes("admin_session=true")) {
        return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });
    }

    try {
        // @ts-ignore
        if (!locals.runtime?.env?.DB) {
            return new Response(JSON.stringify({ error: "DB not found" }), { status: 500 });
        }
        // @ts-ignore
        const db = locals.runtime.env.DB;

        const body = await request.json();
        const { id } = body;

        if (!id) {
            return new Response(JSON.stringify({ error: "ID required" }), { status: 400 });
        }

        // Restore: clear deleted_at timestamp
        await db.prepare(`
      UPDATE intakes 
      SET deleted_at = NULL 
      WHERE id = ?
    `).bind(id).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
