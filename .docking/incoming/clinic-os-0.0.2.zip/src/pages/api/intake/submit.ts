export const prerender = false;

import { sendSlackNotification, type SlackConfig } from "../../../lib/integrations/slack";
import { getClinicSettings } from "../../../lib/clinic";

// Inline formatters to avoid import issues
const DURATION_MAP: Record<string, string> = {
    '1week': '1주일 이내',
    '1month': '1주일 ~ 1개월',
    '6months': '1개월 ~ 6개월',
    '1year': '6개월 ~ 1년',
    'chronic': '1년 이상'
};

const HERBAL_CONSENT_MAP: Record<string, string> = {
    'yes': '한약 치료 상담 희망',
    'no': '침 치료만 희망'
};

function formatDuration(value: string | undefined): string {
    if (!value) return '-';
    // If usage of 'value' as index is problematic (e.g. dynamic key), ensure it's string
    return DURATION_MAP[String(value)] || String(value);
}

function formatHerbalConsent(value: string | undefined): string {
    if (!value) return '';
    return HERBAL_CONSENT_MAP[String(value)] || (value === 'yes' ? '희망함' : '희망 안 함');
}

export async function POST({ request, locals, clientAddress }: { request: Request; locals: any; clientAddress: string }) {
    try {
        console.log('[Intake API] Request received');

        let data;
        try {
            data = await request.json();
            console.log('[Intake API] Payload:', JSON.stringify(data, null, 2));
        } catch (e) {
            console.error('[Intake API] Failed to parse JSON body:', e);
            return new Response(JSON.stringify({ error: 'Invalid JSON body' }), { status: 400 });
        }

        if (!locals.runtime) {
            console.error('[Intake API] locals.runtime is missing. Are you running with the correct adapter?');
            return new Response(JSON.stringify({ error: 'Server configuration error: Runtime missing' }), { status: 500 });
        }

        const db = locals.runtime.env.DB;
        if (!db) {
            console.error('[Intake API] DB binding is missing in locals.runtime.env');
            return new Response(JSON.stringify({ error: 'Server configuration error: DB binding missing' }), { status: 500 });
        }

        const now = Math.floor(Date.now() / 1000);

        // Check Feature Flag
        const settings = await getClinicSettings(db);
        const isRemoteRequest = ['remote', 'remote_integrated'].includes(data.type) || data.visit_method === '비대면진료';

        if (isRemoteRequest && !settings.features?.remoteConsultation) {
            return new Response(JSON.stringify({ error: '비대면 진료 접수가 현재 중단되었습니다.' }), { status: 403 });
        }

        // Determine if this is a simple lead (public intake) or detailed intake
        const isPublicIntake = data.type === 'general';

        if (isPublicIntake) {
            // For public intake, we only create a Lead record
            const leadId = crypto.randomUUID();

            // Determine consult type from visit_method
            // visit_method: '비대면진료' → type = 'remote', else 'visit'
            let consultType = 'visit'; // default
            if (data.visit_method === '비대면진료') {
                consultType = 'remote';
            }

            // Map form data to lead structure
            const leadData = {
                id: leadId,
                name: data.name,
                contact: data.phone,
                type: consultType, // Now properly set based on visit_method
                status: 'new',
                channel: 'intake_form',
                patient_type: data.patient_type || 'new', // Default to new if not specified
                intake_data: JSON.stringify({
                    locale: data.locale || 'ko',
                    visit_category: data.visit_category,
                    visit_method: data.visit_method, // Store original selection
                    main_symptom: data.main_symptom,
                    patient_type: data.patient_type,
                    privacy_consent: data.privacy_consent
                }),
                created_at: now,
                updated_at: now
            };

            console.log('[Intake API] Inserting into leads table...');
            try {
                await db.prepare(`
                    INSERT INTO leads (
                        id, name, contact, type, status, channel, patient_type, intake_data, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `).bind(
                    leadData.id,
                    leadData.name,
                    leadData.contact,
                    leadData.type,
                    leadData.status,
                    leadData.channel,
                    leadData.patient_type,
                    leadData.intake_data,
                    leadData.created_at,
                    leadData.updated_at
                ).run();
                console.log('[Intake API] Insert successful');
            } catch (dbError: any) {
                console.error('[Intake API] DB Insert Error:', dbError);
                throw new Error(`DB Insert Failed: ${dbError.message}`);
            }

            // Send Slack notification (async, don't block response)
            try {
                const clinicResult = await db.prepare("SELECT integrations FROM clinics WHERE id = 1").first();
                if (clinicResult?.integrations) {
                    const integrations = JSON.parse(clinicResult.integrations);
                    if (integrations.slack?.enabled && integrations.slack?.webhookUrl) {
                        // Fire and forget - don't await
                        sendSlackNotification(integrations.slack as SlackConfig, {
                            name: data.name,
                            phone: data.phone,
                            visitCategory: data.visit_category,
                            patientType: data.patient_type,
                            mainSymptom: data.main_symptom,
                            submittedAt: new Date().toLocaleString('ko-KR')
                        }).then(result => {
                            if (result.success) {
                                console.log('[Intake API] Slack notification sent');
                            } else {
                                console.error('[Intake API] Slack notification failed:', result.error);
                            }
                        }).catch(e => {
                            console.error('[Intake API] Slack notification error:', e);
                        });
                    }
                }
            } catch (slackError) {
                console.error('[Intake API] Slack integration error:', slackError);
                // Don't fail the request if Slack fails
            }

            return new Response(JSON.stringify({
                success: true,
                message: '상담 신청이 접수되었습니다.'
            }), { status: 200 });
        }

        // --- Detailed Intake Logic (Admin/Remote) ---

        // Basic Validation for Detailed Intake
        if (data.type !== 'remote_integrated') {
            if (!data.name || !data.phone || !data.rrn_front || !data.rrn_back) {
                return new Response(JSON.stringify({ error: '필수 정보가 누락되었습니다.' }), { status: 400 });
            }
        } else {
            if (!data.patient_id) {
                return new Response(JSON.stringify({ error: '환자 ID가 필요합니다.' }), { status: 400 });
            }
        }

        // Derive Birthdate and Gender from RRN
        let birthdate = '';
        let gender = '';

        const rrnFront = data.rrn_front;
        const rrnBack = data.rrn_back;

        if (data.type !== 'remote_integrated' && rrnFront && rrnBack) {
            const backFirst = parseInt(rrnBack);
            if (rrnFront.length === 6 && !isNaN(backFirst)) {
                const yy = parseInt(rrnFront.substring(0, 2));
                const mm = rrnFront.substring(2, 4);
                const dd = rrnFront.substring(4, 6);

                let yearPrefix = '';
                if ([1, 2, 5, 6].includes(backFirst)) {
                    yearPrefix = '19';
                } else if ([3, 4, 7, 8].includes(backFirst)) {
                    yearPrefix = '20';
                } else {
                    yearPrefix = '19'; // Default fallback
                }

                birthdate = `${yearPrefix}${yy}-${mm}-${dd}`;

                if ([1, 3, 5, 7].includes(backFirst)) {
                    gender = 'M';
                } else {
                    gender = 'F';
                }
            }
        }

        // Allow direct input if RRN is not provided (for remote integrated)
        if (!birthdate && data.birth_date) birthdate = data.birth_date;
        if (!gender && data.gender) {
            // Normalize to M/F for internal consistency
            if (data.gender === 'male' || data.gender === 'M') gender = 'M';
            else if (data.gender === 'female' || data.gender === 'F') gender = 'F';
        }

        // Get client metadata for consent verification
        let clientIP = clientAddress;

        if (!clientIP) {
            const xForwardedFor = request.headers.get('x-forwarded-for');
            if (xForwardedFor) {
                clientIP = xForwardedFor.split(',')[0].trim();
            } else {
                clientIP = request.headers.get('cf-connecting-ip') ||
                    request.headers.get('x-real-ip') ||
                    'unknown';
            }
        }
        const userAgent = request.headers.get('user-agent') || 'unknown';

        // Construct Intake Data with consent verification metadata
        const intakeData = {
            ...data,
            birthdate, // Derived YYYY-MM-DD
            gender: gender === 'M' ? 'male' : 'female',    // Keep original format for display
            submittedAt: new Date().toISOString(),
            // Consent verification metadata
            consentMetadata: {
                ip: clientIP,
                userAgent: userAgent,
                timestamp: new Date().toISOString(),
                privacy_consent: data.privacy_consent || false,
                marketing_consent: data.marketing_consent || false,
                herbal_consent: data.herbal_consent || null,
                remote_consent: data.remote_consent || null
            }
        };

        const smsConsent = intakeData.consentMetadata?.marketing_consent || intakeData.marketing_consent || false;
        const emailConsent = intakeData.consentMetadata?.marketing_consent || intakeData.marketing_consent || false;

        let existingPatient = null;

        // Check for existing patient
        if (data.patient_id) {
            existingPatient = await db.prepare("SELECT * FROM patients WHERE id = ?").bind(data.patient_id).first();
            if (!existingPatient && data.type === 'remote_integrated') {
                return new Response(JSON.stringify({ error: '환자 정보를 찾을 수 없습니다.' }), { status: 404 });
            }
        }

        if (!existingPatient && data.phone) {
            // Normalize phone number (strip all non-digits) for consistent matching
            const normalizedInputPhone = data.phone.replace(/\D/g, '');

            existingPatient = await db.prepare(`
                SELECT * FROM patients 
                WHERE REPLACE(REPLACE(current_phone, '-', ''), ' ', '') = ?
            `).bind(normalizedInputPhone).first();
        }

        let patientId = '';
        let notes = '';

        // Determine new status based on intake type
        const newStatus = ['remote', 'remote_integrated'].includes(data.type) ? 'remote_first_visit' : 'visit_first_visit';

        if (existingPatient) {
            // STRICT VERIFICATION: Check Name and Birthdate (Only for non-ID match)
            if (!data.patient_id) {
                // Allow update if existing patient has no birth_date (e.g. simple inquiry)
                const isNameMismatch = existingPatient.name !== data.name;
                const isBirthDateMismatch = existingPatient.birth_date && existingPatient.birth_date !== birthdate;

                if (isNameMismatch || isBirthDateMismatch) {
                    return new Response(JSON.stringify({
                        error: '입력하신 전화번호는 이미 다른 환자 정보로 등록되어 있습니다.',
                        details: '기존 환자 정보와 이름 또는 생년월일이 일치하지 않습니다. 병원으로 문의해 주세요.'
                    }), { status: 409 });
                }
            } else if (data.type === 'remote_integrated') {
                // Backfill data for update query
                if (!data.name) data.name = existingPatient.name;
                if (!birthdate) birthdate = existingPatient.birth_date;
                if (!gender) gender = existingPatient.gender;
            }

            patientId = existingPatient.id;

            // Updated existing patient logic (Reverted Auto-Lead for returning patients)

            // Update existing patient info
            const existingNotes = existingPatient.notes || '';
            const newNoteHeader = `\n\n--- [${new Date().toLocaleDateString()} 추가 접수] ---\n`;

            // Prepare new notes content
            let newNotes = '';
            if (data.type === 'remote' || data.type === 'remote_integrated') {
                newNotes += `구분: 비대면 진료 접수${data.type === 'remote_integrated' ? ' (통합)' : ''}\n`;
                if (data.type === 'remote_integrated') {
                    newNotes += `신체정보: ${data.height || '?'}cm / ${data.current_weight || '?'}kg (목표: ${data.target_weight || '?'}kg)\n`;
                }
                newNotes += `배송지: ${data.shipping_address || '-'}\n`;
                if (data.shipping_request) newNotes += `배송요청: ${data.shipping_request}\n`;
                newNotes += `현금영수증: ${data.cash_receipt_number || '-'}\n`;
            } else {
                newNotes += `방문 목적: ${data.visit_category || '-'}\n`;
                newNotes += `주요 증상: ${data.main_symptom || '-'}\n`;
                newNotes += `증상 기간: ${formatDuration(data.duration)}\n`;
                if (data.herbal_consent) {
                    newNotes += `한약 치료: ${formatHerbalConsent(data.herbal_consent)}\n`;
                }
                newNotes += `내원 경로: ${data.referral?.join(', ') || '-'}\n`;
            }
            newNotes += `접수 일시: ${intakeData.submittedAt}\n`;

            // Update patient record
            await db.prepare(`
                UPDATE patients 
                SET name = ?, 
                    birth_date = ?, 
                    gender = ?, 
                    address = COALESCE(?, address), 
                    status = ?,
                    sms_consent = ?, 
                    email_consent = ?, 
                    notes = ?, 
                    updated_at = ?,
                    last_activity_at = ?
                WHERE id = ?
            `).bind(
                data.name,
                birthdate,
                gender,
                data.address || data.shipping_address || null, // Map shipping_address to address column for remote intakes
                newStatus, // Update status to reflect new intake
                smsConsent ? 1 : 0,
                emailConsent ? 1 : 0,
                existingNotes + newNoteHeader + newNotes,
                now,
                now,
                patientId
            ).run();

            // [Patch] Ensure first_source is populated if missing
            if (data.referral) {
                const sourceVal = Array.isArray(data.referral) ? data.referral.join(', ') : data.referral;
                if (sourceVal) {
                    await db.prepare(`
                        UPDATE patients 
                        SET first_source = ? 
                        WHERE id = ? AND (first_source IS NULL OR first_source = '')
                    `).bind(sourceVal, patientId).run();
                }
            }

        } else {
            // [Auto-Lead] Check for existing Lead. If none, create one for "Walk-in"
            if (data.phone) {
                const normalizedLeadPhone = data.phone.replace(/\D/g, '');
                const existingLead = await db.prepare("SELECT id FROM leads WHERE replace(replace(contact, '-', ''), ' ', '') = ?").bind(normalizedLeadPhone).first();

                if (!existingLead) {
                    console.log('[Intake API] No lead found for walk-in. Creating Auto-Lead.');
                    const autoLeadId = crypto.randomUUID();
                    await db.prepare(`
                        INSERT INTO leads (
                            id, name, contact, type, status, channel, patient_type, intake_data, created_at, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    `).bind(
                        autoLeadId,
                        data.name,
                        data.phone,
                        'visit',
                        'first_visit_walkin', // SKIPPED 'new', directly to 'walkin'
                        'walk-in', // Channel 'walk-in'
                        'new',
                        JSON.stringify(data), // Save full intake data
                        now,
                        now
                    ).run();
                }
            }

            // Create new patient record
            patientId = crypto.randomUUID();

            notes = `[초진 접수 정보]\n`;
            if (data.type === 'remote') {
                notes += `구분: 비대면 진료 접수\n`;
                notes += `배송지: ${data.shipping_address || '-'}\n`;
                if (data.shipping_request) notes += `배송요청: ${data.shipping_request}\n`;
                notes += `현금영수증: ${data.cash_receipt_number || '-'}\n`;
            } else {
                notes += `방문 목적: ${data.visit_category || '-'}\n`;
                notes += `주요 증상: ${data.main_symptom || '-'}\n`;
                notes += `증상 기간: ${formatDuration(data.duration)}\n`;
                if (data.herbal_consent) {
                    notes += `한약 치료: ${formatHerbalConsent(data.herbal_consent)}\n`;
                }
                notes += `내원 경로: ${data.referral?.join(', ') || '-'}\n`;
            }
            notes += `접수 일시: ${intakeData.submittedAt}\n`;

            // Add consent info to notes for new patients
            if (intakeData.consentMetadata) {
                notes += `\n[동의 정보]\n`;
                notes += `개인정보 동의: ${intakeData.consentMetadata.privacy_consent ? '✓' : '✗'}\n`;
                if (data.type === 'remote') {
                    notes += `비대면 진료 동의: ${intakeData.consentMetadata.remote_consent ? '✓' : '✗'}\n`;
                } else {
                    notes += `마케팅 동의: ${intakeData.consentMetadata.marketing_consent ? '✓' : '✗'}\n`;
                }
                notes += `IP: ${intakeData.consentMetadata.ip}\n`;
                notes += `시각: ${intakeData.consentMetadata.timestamp}\n`;
            }

            await db.prepare(`
                INSERT INTO patients (
                    id, name, current_phone, birth_date, gender, address,
                    status, sms_consent, email_consent, notes,
                    created_at, updated_at, source, channel, first_source, last_activity_at, first_visit_date
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).bind(
                patientId,
                data.name,
                data.phone,
                birthdate,
                gender,
                data.address || data.shipping_address || null,
                newStatus, // Set initial status
                smsConsent ? 1 : 0,
                emailConsent ? 1 : 0,
                notes,
                now,
                now,
                'online',
                'intake_form',
                Array.isArray(data.referral) ? data.referral.join(', ') : (data.referral || null),
                now, // last_activity_at
                ['remote', 'remote_integrated'].includes(data.type) ? new Date().toISOString().split('T')[0] : null // first_visit_date
            ).run();
        }

        // --- SHARED: Store Submission ---
        // Store intake submission record
        const intakeId = crypto.randomUUID();
        await db.prepare(`
            INSERT INTO intake_submissions (
                id, patient_id, intake_data, submitted_at, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?)
        `).bind(
            intakeId,
            patientId,
            JSON.stringify(intakeData),
            now,
            'pending',
            now
        ).run();

        // --- SHARED: Create Timeline Event ---
        const eventId = crypto.randomUUID();

        let eventContent = '';

        if (data.type === 'remote' || data.type === 'remote_integrated') {
            eventContent += `[비대면 진료 접수${data.type === 'remote_integrated' ? ' (통합)' : ''}]\n`;
            if (data.type === 'remote_integrated') {
                eventContent += `신체정보: ${data.height || '?'}cm / ${data.current_weight || '?'}kg (목표: ${data.target_weight || '?'}kg)\n`;

                // Diet survey responses
                const dietLabels: Record<string, string> = {
                    'diet_history': '다이어트 경험',
                    'meal_regularity': '식사 규칙성',
                    'snack_habit': '간식 습관',
                    'alcohol_habit': '음주 습관',
                    'activity_vigorous': '고강도 운동',
                    'activity_moderate': '중강도 운동',
                    'activity_walking': '걷기 시간',
                    'nrs_stress': '스트레스 (NRS)',
                    'nrs_body_image': '체형 스트레스 (NRS)'
                };

                const surveyResponses: string[] = [];
                for (const [key, label] of Object.entries(dietLabels)) {
                    if (data[key] !== undefined && data[key] !== '') {
                        surveyResponses.push(`${label}: ${data[key]}`);
                    }
                }
                if (surveyResponses.length > 0) {
                    eventContent += `\n[설문 응답]\n${surveyResponses.join('\n')}\n`;
                }
            }
            eventContent += `\n배송지: ${data.shipping_address || '-'}\n`;
            if (data.shipping_request) eventContent += `배송요청: ${data.shipping_request}\n`;
            eventContent += `현금영수증: ${data.cash_receipt_number || '-'}\n`;
        } else {
            eventContent += `[문진표 접수 항목]\n`; // Unified Header
            eventContent += `방문 목적: ${data.visit_category || '-'}\n`;
            eventContent += `주요 증상: ${data.main_symptom || '-'}\n`;
            eventContent += `증상 기간: ${formatDuration(data.duration)}\n`;

            if (data.herbal_consent) {
                eventContent += `\n[한약 치료 의사]\n`;
                eventContent += `✓ ${formatHerbalConsent(data.herbal_consent)}\n`;
            }

            if (data.referral && data.referral.length > 0) {
                eventContent += `\n[내원 경로]\n${data.referral.join(', ')}\n`;
            }
        }

        if (intakeData.consentMetadata) {
            eventContent += `\n[동의 내역]\n`;
            eventContent += `개인정보: ${intakeData.consentMetadata.privacy_consent ? '✓ 동의' : '✗ 미동의'}\n`;
            if (data.type === 'remote') {
                eventContent += `비대면 진료 동의: ${intakeData.consentMetadata.remote_consent ? '✓ 동의' : '✗ 미동의'}\n`;
            } else {
                eventContent += `마케팅: ${intakeData.consentMetadata.marketing_consent ? '✓ 동의' : '✗ 미동의'}\n`;
            }
            eventContent += `IP: ${intakeData.consentMetadata.ip}\n`;
            eventContent += `시각: ${intakeData.consentMetadata.timestamp}`;
        }

        await db.prepare(`
            INSERT INTO patient_events (
                id, patient_id, type, title, content, event_date, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `).bind(
            eventId,
            patientId,
            'intake',
            ['remote', 'remote_integrated'].includes(data.type) ? '비대면 진료 접수' : '문진표 접수 확인',
            eventContent,
            now,
            now
        ).run();

        // [Auto-Visit] Create explicit 'visit' event for Reception Dashboard (Only for NEW patients)
        // Reverted for existing patients as per user request.
        if (!existingPatient && !['remote', 'remote_integrated'].includes(data.type)) {
            const visitEventId = crypto.randomUUID();
            await db.prepare(`
                INSERT INTO patient_events (
                    id, patient_id, type, title, content, event_date, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            `).bind(
                visitEventId,
                patientId,
                'visit',
                '초진 내원 접수',
                '모바일 문진표 접수 확인 (자동 내원 등록)',
                now,
                now
            ).run();
        }

        // ... existing code ...
        // Hook for Campaign Trigger
        try {
            // @ts-ignore
            const env = locals.runtime?.env;
            if (env) {
                const { CampaignTriggerService } = await import('../../../lib/events/campaign-trigger');
                const triggerService = new CampaignTriggerService(db, env);

                // Use waitUntil if available to avoid blocking response
                // @ts-ignore
                const ctx = locals.runtime?.ctx;

                const triggerTask = triggerService.emit('patient_created', {
                    patient_id: patientId,
                    patient_name: data.name,
                    patient_phone: data.phone
                });

                if (ctx && ctx.waitUntil) {
                    ctx.waitUntil(triggerTask);
                } else {
                    // Fallback: don't await, just let it run (might be killed but better than blocking 2s)
                    // Or await if reliability is critical. Let's await for 500ms race? No.
                    // Just fire and forget logging.
                    triggerTask.catch(e => console.error('Background Trigger Failed', e));
                }
            }
        } catch (e) {
            console.error('[Intake API] Trigger Hook Error:', e);
        }


        // --- SHARED: Log All Consents to Unified consent_log Table ---
        const consentSource = data.type === 'remote' || data.type === 'remote_integrated' ? 'remote-intake' : 'web-intake';
        const consentIP = intakeData.consentMetadata?.ip || null;
        const consentUA = intakeData.consentMetadata?.userAgent || null;

        try {
            // 1. Privacy Consent (Required for all intakes)
            const privacyConsent = intakeData.consentMetadata?.privacy_consent || false;
            await db.prepare(`
                INSERT INTO consent_log (id, patient_id, consent_type, consent, consent_version, consent_text_snapshot, source, ip_address, user_agent, created_at)
                VALUES (?, ?, 'privacy', ?, 'v1.0', ?, ?, ?, ?, ?)
            `).bind(
                crypto.randomUUID(),
                patientId,
                privacyConsent ? 1 : 0,
                '[개인정보 수집·이용 동의]\n수집 항목: 성명, 생년월일, 연락처, 주소, 진료 정보\n이용 목적: 진료 및 상담 서비스 제공, 처방약 배송, 진료 기록 관리\n보유 기간: 의료법 등 관련 법령에서 정한 기간',
                consentSource,
                consentIP,
                consentUA,
                now
            ).run();

            // 2. Marketing Consent (Optional)
            const marketingConsent = intakeData.consentMetadata?.marketing_consent || intakeData.marketing_consent || false;
            const consentChannels = marketingConsent ? JSON.stringify(["kakao", "sms", "email"]) : null;
            await db.prepare(`
                INSERT INTO consent_log (id, patient_id, consent_type, consent, channels, consent_version, consent_text_snapshot, source, ip_address, user_agent, created_at)
                VALUES (?, ?, 'marketing', ?, ?, 'v1.0', ?, ?, ?, ?, ?)
            `).bind(
                crypto.randomUUID(),
                patientId,
                marketingConsent ? 1 : 0,
                consentChannels,
                '[마케팅 정보 수신 동의]\n수집 항목: 성명, 연락처, 이메일, 이용 기록\n이용 목적: 혜택, 이벤트, 프로모션 정보 제공\n발송 수단: 문자, 카카오톡, 이메일\n보유 기간: 동의 철회 시까지',
                consentSource,
                consentIP,
                consentUA,
                now
            ).run();

            // 3. Remote Consent (Only for remote intakes)
            if (data.type === 'remote' || data.type === 'remote_integrated') {
                const remoteConsent = intakeData.consentMetadata?.remote_consent || false;
                await db.prepare(`
                    INSERT INTO consent_log (id, patient_id, consent_type, consent, consent_version, consent_text_snapshot, source, ip_address, user_agent, created_at)
                    VALUES (?, ?, 'remote', ?, 'v1.0', ?, ?, ?, ?, ?)
                `).bind(
                    crypto.randomUUID(),
                    patientId,
                    remoteConsent ? 1 : 0,
                    '[비대면 진료 동의]\n비대면 진료의 특성과 제한사항을 이해하고 동의합니다.\n대면 진료가 필요할 수 있으며, 이상 증상 시 즉시 복용 중단 필요.',
                    consentSource,
                    consentIP,
                    consentUA,
                    now
                ).run();
            }

            console.log(`[Intake API] Consents Logged: privacy=${privacyConsent}, marketing=${marketingConsent}, remote=${data.type?.includes('remote') ? intakeData.consentMetadata?.remote_consent : 'N/A'}`);
        } catch (logError) {
            console.error('[Intake API] Failed to log consents:', logError);
            // Don't fail the entire request, but log critical error
        }

        return new Response(JSON.stringify({
            success: true,
            patientId,
            message: '초진 접수가 완료되었습니다.'
        }), { status: 200 });

    } catch (e: any) {
        console.error('[Intake API] Critical Error:', e);
        console.error('[Intake API] Stack:', e.stack);
        return new Response(JSON.stringify({
            error: '서버 오류가 발생했습니다.',
            details: e.message,
            stack: import.meta.env.DEV ? e.stack : undefined
        }), { status: 500 });
    }
}
