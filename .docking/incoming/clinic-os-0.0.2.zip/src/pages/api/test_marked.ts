import type { APIRoute } from 'astro';
import { marked } from 'marked';

export const GET: APIRoute = async () => {
    try {
        const content = "# Hello World";
        const html = await marked.parse(content);
        return new Response(JSON.stringify({
            html,
            markedType: typeof marked,
            hasParse: typeof marked.parse === 'function'
        }, null, 2));
    } catch (e: any) {
        return new Response(`Error: ${e.message}\nStack: ${e.stack}`);
    }
};
