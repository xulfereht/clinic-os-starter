export const prerender = false;

export async function POST({ request, locals }: { request: Request; locals: any }) {
    const db = locals.runtime.env.DB;

    try {
        const data = await request.json();
        const { id, action, ...payload } = data; // action: 'ship', 'deliver', 'happy_call'

        if (!id || !action) {
            return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
        }

        const now = Math.floor(Date.now() / 1000);
        let query = '';
        let params: any[] = [];

        if (action === 'ship') {
            query = `
                UPDATE payments 
                SET shipping_status = 'shipped',
                    shipping_courier = ?,
                    shipping_tracking_number = ?,
                    shipped_at = ?
                WHERE id = ?
            `;
            params = [payload.courier, payload.tracking_number, now, id];
        } else if (action === 'deliver') {
            query = `
                UPDATE payments 
                SET shipping_status = 'delivered',
                    delivered_at = ?
                WHERE id = ?
            `;
            params = [now, id];
        } else if (action === 'schedule_happy_call') {
            query = `
                UPDATE payments 
                SET happy_call_status = 'scheduled',
                    happy_call_scheduled_at = ?
                WHERE id = ?
            `;
            params = [payload.scheduled_at, id];
        } else if (action === 'complete_happy_call') {
            query = `
                UPDATE payments 
                SET happy_call_status = 'completed',
                    happy_call_completed_at = ?,
                    happy_call_notes = ?
                WHERE id = ?
            `;
            params = [now, payload.notes, id];
        } else if (action === 'update_due_date') {
            query = `
                UPDATE payments 
                SET shipping_due_date = ?
                WHERE id = ?
            `;
            params = [payload.due_date, id];
        } else if (action === 'pickup') {
            query = `
                UPDATE payments 
                SET shipping_status = 'picked_up',
                    delivered_at = ?
                WHERE id = ?
            `;
            params = [now, id];
        } else {
            return new Response(JSON.stringify({ error: 'Invalid action' }), { status: 400 });
        }

        await db.prepare(query).bind(...params).run();

        return new Response(JSON.stringify({ success: true }), { status: 200 });
    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
