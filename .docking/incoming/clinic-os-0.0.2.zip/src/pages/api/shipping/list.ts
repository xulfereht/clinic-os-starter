export const prerender = false;

export async function GET({ request, locals }: { request: Request; locals: any }) {
    const db = locals.runtime.env.DB;
    const url = new URL(request.url);
    const status = url.searchParams.get('status') || 'pending'; // pending, shipped, happy_call
    const search = url.searchParams.get('search') || '';

    try {
        let query = `
            SELECT 
                p.*,
                pt.name as patient_name,
                pt.current_phone as patient_phone,
                pt.address as patient_address,
                pr.name as product_name
            FROM payments p
            LEFT JOIN patients pt ON p.patient_id = pt.id
            LEFT JOIN products pr ON p.product_id = pr.id
            WHERE 1=1
        `;

        const params: any[] = [];

        if (status === 'pending') {
            query += ` AND (p.shipping_status = 'pending' OR p.shipping_status IS NULL) AND p.status = 'completed'`;
        } else if (status === 'shipped') {
            query += ` AND p.shipping_status = 'shipped'`;
        } else if (status === 'happy_call') {
            query += ` AND p.shipping_status IN ('shipped', 'delivered') AND p.happy_call_status != 'completed'`;
            // Logic for happy call timing can be added here (e.g., shipped > 2 weeks ago)
        }

        if (search) {
            query += ` AND (pt.name LIKE ? OR pt.current_phone LIKE ?)`;
            params.push(`%${search}%`, `%${search}%`);
        }

        query += ` ORDER BY p.paid_at DESC`;

        const { results } = await db.prepare(query).bind(...params).run();

        return new Response(JSON.stringify({ results }), { status: 200 });
    } catch (e: any) {
        console.error(e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
}
