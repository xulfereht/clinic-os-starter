import type { APIRoute } from 'astro';

async function generateSignature(key: string, secret: string): Promise<string> {
    const enc = new TextEncoder();
    const algorithm = { name: 'HMAC', hash: 'SHA-256' };
    const keyData = await crypto.subtle.importKey('raw', enc.encode(secret), algorithm, false, ['sign']);
    const signature = await crypto.subtle.sign(algorithm.name, keyData, enc.encode(key));

    // Convert to hex string
    return Array.from(new Uint8Array(signature))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}

export const prerender = false;

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const bucket = locals.runtime?.env?.BUCKET;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }
    if (!bucket) {
        return new Response(JSON.stringify({ error: 'R2 Bucket not configured' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { prompt, width, height, path } = body;

        if (!prompt) {
            return new Response(JSON.stringify({ error: 'Prompt is required' }), { status: 400 });
        }

        // 1. Get Active Provider
        // @ts-ignore
        let config = await db.prepare("SELECT * FROM ai_configs WHERE is_active = 1 LIMIT 1").first();

        // Fallback to Environment Variables if no DB config
        if (!config) {
            // @ts-ignore
            const env = locals.runtime?.env || {};
            // Prioritize OpenAI (DALL-E 3) as per user request for "Nanobanana Pro" equivalent
            if (env.OPENAI_API_KEY) {
                config = {
                    provider: 'openai',
                    api_key: env.OPENAI_API_KEY,
                    model: 'dall-e-3'
                };
            } else if (env.GEMINI_API_KEY) {
                config = {
                    provider: 'gemini',
                    api_key: env.GEMINI_API_KEY,
                    model: 'imagen-3.0-generate-001'
                };
            }
        }

        if (!config) {
            return new Response(JSON.stringify({ error: 'No active AI provider found. Please configure in Settings > AI or set GEMINI_API_KEY/OPENAI_API_KEY environment variables.' }), { status: 400 });
        }

        let imageUrl: string | null = null;
        let imageBuffer: Buffer | null = null;

        // 2. Call Provider API
        if (config.provider === 'openai') {
            const res = await fetch('https://api.openai.com/v1/images/generations', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${config.api_key}`
                },
                body: JSON.stringify({
                    model: config.model || 'dall-e-3',
                    prompt: prompt,
                    n: 1,
                    size: "1024x1024",
                    response_format: "b64_json"
                })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.error?.message || 'OpenAI API Error');

            imageBuffer = Buffer.from(data.data[0].b64_json, 'base64');

        } else if (config.provider === 'gemini') {
            // Note: Gemini Image Generation API (Imagen) endpoint
            const model = config.model || 'imagen-3.0-generate-001';
            const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:predict?key=${config.api_key}`;

            const res = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    instances: [{ prompt: prompt }],
                    parameters: { sampleCount: 1, aspectRatio: "1:1" }
                })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.error?.message || JSON.stringify(data.error) || 'Gemini API Error');

            const b64 = data.predictions?.[0]?.bytesBase64Encoded || data.predictions?.[0]?.bytes;
            if (!b64) throw new Error('No image data returned from Gemini');

            imageBuffer = Buffer.from(b64, 'base64');
        } else {
            return new Response(JSON.stringify({ error: `Provider ${config.provider} not supported for image generation yet.` }), { status: 400 });
        }

        // 3. Save Image to R2
        if (imageBuffer) {
            const uuid = crypto.randomUUID().split('-')[0];
            let key = `generated/${uuid}.png`;

            // If a specific path is requested
            if (path && path.startsWith('/images/programs/')) {
                // Map public path to R2 key (e.g. /images/programs/foo.png -> programs/foo.png)
                // But usually 'path' intent was to overwrite a local file. 
                // For R2, we can just use the path as key (stripping leading slash)
                key = path.startsWith('/') ? path.slice(1) : path;
            }

            // Upload to R2
            await bucket.put(key, imageBuffer, {
                httpMetadata: {
                    contentType: 'image/png',
                },
            });

            // Generate Signed URL
            // @ts-ignore
            const secret = (locals.runtime?.env?.ADMIN_PASSWORD as string) || 'clinic-admin';
            const signature = await generateSignature(key, secret);
            imageUrl = `/api/files/${key}?sig=${signature}`;
        }

        return new Response(JSON.stringify({
            success: true,
            url: imageUrl,
            provider: config.provider
        }), { status: 200 });

    } catch (e: any) {
        console.error('AI Gen Error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
