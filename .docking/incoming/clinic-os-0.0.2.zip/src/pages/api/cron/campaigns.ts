import type { APIRoute } from 'astro';
import { getAligoConfig, sendAligoMessage, sendAlimTalk } from '../../../lib/aligo';
import { getSurveyLink } from '../../../lib/survey-registry';
import { getClinicSettings } from '../../../lib/clinic';

export const prerender = false;

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const env = locals.runtime?.env;

    if (!db) {
        return new Response('Database not available', { status: 500 });
    }

    const now = Math.floor(Date.now() / 1000);

    // Define types for DB results
    interface Campaign {
        id: number;
        name: string;
        status: string;
        template_id: number;
        segment_id: number;
        type: string;
        trigger_config: string | null;
        scheduled_at: number | null;
        next_run_at: number | null;
        last_processed_id: number;
        batch_size: number;
        is_active: number;
    }

    interface Template {
        id: number;
        name: string;
        content: string;
        channel: string;
        alimtalk_code: string | null;
        buttons: string | null;
    }

    interface Segment {
        query_sql: string;
    }

    interface Patient {
        id: number;
        name: string;
        current_phone: string;
    }

    try {
        // 1. Find a candidate campaign
        // Priority:
        // 1. Already sending (continue batch)
        // 2. Scheduled and time has come
        // 3. Recurring and time has come
        const campaign = await db.prepare(`
            SELECT * FROM campaigns 
            WHERE 1=1 
            AND status != 'paused'
            AND (
                (status = 'sending') OR 
                (status = 'scheduled' AND scheduled_at <= ?) OR 
                (type = 'RECURRING' AND next_run_at <= ?)
            )
            ORDER BY status DESC, scheduled_at ASC 
            LIMIT 1
        `).bind(now, now).first() as Campaign | null;

        if (!campaign) {
            console.log(`[Cron] Checked at ${now} (Unix). No due campaigns found.`);
            // Debug: Check if any are scheduled in the future
            const future = await db.prepare("SELECT count(*) as c FROM campaigns WHERE status='scheduled'").first();
            if (future && (future as any).c > 0) {
                const next = await db.prepare("SELECT scheduled_at FROM campaigns WHERE status='scheduled' ORDER BY scheduled_at ASC LIMIT 1").first();
                console.log(`[Cron] Next campaign is scheduled for: ${(next as any).scheduled_at} (Diff: ${(next as any).scheduled_at - now}s)`);
            }

            return new Response(JSON.stringify({ processed: 0, message: 'No active campaigns' }), {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        console.log(`[Cron] Processing campaign: ${campaign.name}(${campaign.id}) - Status: ${campaign.status}`);

        // 2. Lock / Update Status to 'sending' if not already
        if (campaign.status !== 'sending') {
            await db.prepare("UPDATE campaigns SET status = 'sending' WHERE id = ?").bind(campaign.id).run();
        }

        // 3. Get Template & Segment
        const template = await db.prepare("SELECT * FROM message_templates WHERE id = ?").bind(campaign.template_id).first() as Template | null;
        if (!template) {
            console.error(`Template not found for campaign ${campaign.id}`);
            await db.prepare("UPDATE campaigns SET status = 'failed' WHERE id = ?").bind(campaign.id).run();
            return new Response('Template not found', { status: 500 });
        }

        // Fetch full segment including criteria JSON
        interface FullSegment {
            id: number;
            query_sql: string;
            criteria: string | null;
        }
        const segment = await db.prepare("SELECT id, query_sql, criteria FROM segments WHERE id = ?").bind(campaign.segment_id).first() as FullSegment | null;
        if (!segment) {
            console.error(`Segment not found for campaign ${campaign.id}`);
            await db.prepare("UPDATE campaigns SET status = 'failed' WHERE id = ?").bind(campaign.id).run();
            return new Response('Segment not found', { status: 500 });
        }

        // Regenerate SQL from criteria at runtime (if criteria exists)
        // This ensures we always use the correct, up-to-date conditions
        let segmentSql = segment.query_sql;
        let segmentParams: any[] = [];

        if (segment.criteria) {
            try {
                const { generateSegmentSql } = await import('../../../lib/segment-engine');
                const criteria = JSON.parse(segment.criteria);
                const generated = generateSegmentSql(criteria);
                // Build full query with id, name, current_phone for compatibility
                segmentSql = `SELECT id, name, current_phone FROM patients WHERE deleted_at IS NULL AND (${generated.sql})`;
                segmentParams = generated.params;
                console.log(`[Cron] Regenerated SQL for segment ${segment.id}: ${segmentSql.substring(0, 100)}...`);
            } catch (e: any) {
                console.error(`[Cron] Failed to parse criteria for segment ${segment.id}: ${e.message}`);
                // Fallback to stored query_sql if criteria parsing fails
                // But this shouldn't happen with valid segments
            }
        }

        if (!segmentSql) {
            console.error(`Segment has no valid SQL for campaign ${campaign.id}`);
            await db.prepare("UPDATE campaigns SET status = 'failed' WHERE id = ?").bind(campaign.id).run();
            return new Response('Segment SQL not available', { status: 500 });
        }

        // 4. Batch Select Targets
        const batchSize = campaign.batch_size || 50;
        const lastId = campaign.last_processed_id || 0;

        // -- HISTORY RUN LOGIC START --
        let runId = '';
        if (campaign.type === 'RECURRING') {
            if (lastId > 0) {
                // Continuation: Find latest active run
                const activeRun = await db.prepare("SELECT id FROM campaign_runs WHERE campaign_id = ? AND status = 'running' ORDER BY started_at DESC LIMIT 1").bind(campaign.id).first();
                if (activeRun) {
                    runId = (activeRun as any).id;
                } else {
                    // Fallback
                    runId = crypto.randomUUID();
                    await db.prepare("INSERT INTO campaign_runs (id, campaign_id, started_at, status, trigger_type) VALUES (?, ?, ?, 'running', 'SCHEDULED')")
                        .bind(runId, campaign.id, now).run();
                }
            } else {
                // New Run
                runId = crypto.randomUUID();
                await db.prepare("INSERT INTO campaign_runs (id, campaign_id, started_at, status, trigger_type) VALUES (?, ?, ?, 'running', 'SCHEDULED')")
                    .bind(runId, campaign.id, now).run();
            }
        } else {
            // ONE_TIME
            const activeRun = await db.prepare("SELECT id FROM campaign_runs WHERE campaign_id = ? LIMIT 1").bind(campaign.id).first();
            if (activeRun) {
                runId = (activeRun as any).id;
            } else {
                runId = crypto.randomUUID();
                await db.prepare("INSERT INTO campaign_runs (id, campaign_id, started_at, status, trigger_type) VALUES (?, ?, ?, 'running', 'MANUAL')")
                    .bind(runId, campaign.id, now).run();
            }
        }
        // -- HISTORY RUN LOGIC END --

        // Construct query to get next batch of patients
        // We use the segment's SQL as a subquery (CTEs might be safer but subquery is standard)
        // IMPORTANT: segmentSql must select 'id', 'name', 'current_phone'
        // segmentParams contains parameters from criteria-based SQL
        const targetQuery = `
            SELECT * FROM(${segmentSql})
            WHERE id > ?
            ORDER BY id ASC
            LIMIT ?
            `;

        // Bind segment params first, then lastId and batchSize
        const allParams = [...segmentParams, lastId, batchSize];
        const { results } = await db.prepare(targetQuery).bind(...allParams).all();
        const rawResults = results as unknown as Patient[];

        // De-duplicate in this batch
        // Note: Cross-batch deduplication is harder with simple ID paging if duplicates have different IDs.
        // But preventing sending to same number within a batch is a good start.
        // Ideally, we should order by distinct phone? Use a different strategy?
        // For now, let's filter the current batch.

        // BETTER: Filter out IDs that have same phone as already processed?
        // Limitations: Simple batching by ID might pick up a duplicate later.
        // However, for immediate fix: deduplicate current batch. 
        // Real fix for duplicate records: Users should merge patients.
        // API Fix: Keep track of sent phones in a run? Hard with stateless cron.
        // Compromise: Deduplicate within batch + Log warnings.

        const patients: Patient[] = [];
        const thisBatchPhones = new Set<string>();

        for (const p of rawResults) {
            const normalized = p.current_phone?.replace(/-/g, '') || '';
            if (normalized && !thisBatchPhones.has(normalized)) {
                thisBatchPhones.add(normalized);
                patients.push(p);
            }
        }


        // 5. Send Messages Iteratively
        const config = await getAligoConfig(env, db);
        if (!config) {
            console.error('Aligo config missing');
            return new Response('SMS Config missing', { status: 500 });
        }

        let sentCount = 0;
        let failCount = 0;
        let lastProcessedId = lastId;

        // Fetch Clinic Info for Variables
        const clinicSettings = await getClinicSettings(db);
        const clinicName = clinicSettings.name;
        const clinicPhone = clinicSettings.contact.phone;
        // Base URL for survey links
        const baseUrl = clinicSettings.url || 'https://www.example.com';

        for (const p of patients) {
            lastProcessedId = p.id;

            // Skip if no phone
            if (!p.current_phone) {
                failCount++;
                continue;
            }

            // Generate Survey Link (Default: diagnosis_weighted_v2)
            const surveyUrl = getSurveyLink('diagnosis_weighted_v2', String(p.id), baseUrl);

            // Fetch Next Reservation
            const nowSeconds = Math.floor(Date.now() / 1000);
            const reservation = await db.prepare(`
                SELECT reserved_at FROM reservations 
                WHERE patient_id = ? 
                AND status NOT IN ('cancelled', 'no_show', 'completed')
                AND (
                    (typeof(reserved_at) = 'integer' AND reserved_at > ?)
                    OR 
                    (typeof(reserved_at) = 'text' AND reserved_at > ?)
                )
                ORDER BY reserved_at ASC LIMIT 1
            `).bind(p.id, nowSeconds, new Date().toISOString()).first() as { reserved_at: number | string } | null;

            let resDate = '';
            let resTime = '';
            let resDateTime = '';

            if (reservation && reservation.reserved_at) {
                let rDate: Date;
                if (typeof reservation.reserved_at === 'number') {
                    rDate = new Date(reservation.reserved_at * 1000);
                } else {
                    rDate = new Date(reservation.reserved_at);
                }

                const kstOffset = 9 * 60 * 60 * 1000;
                const kstDate = new Date(rDate.getTime() + kstOffset);

                const month = kstDate.getUTCMonth() + 1;
                const day = kstDate.getUTCDate();
                const hour = kstDate.getUTCHours();
                const minute = kstDate.getUTCMinutes();
                const year = kstDate.getUTCFullYear();

                const pad = (n: number) => n.toString().padStart(2, '0');

                resDate = `${year}-${pad(month)}-${pad(day)}`;
                resTime = `${pad(hour)}:${pad(minute)}`;
                resDateTime = `${month}월 ${day}일 ${pad(hour)}:${pad(minute)}`;
            }

            // Variable Substitution
            // CRITICAL: Use DB template content as base (synced from Aligo, preserves proper format)
            let content = template.content || '';
            const originalContent = content;

            // CRITICAL FIX: Aligo templates use \r\n (CRLF) - we must match EXACTLY
            // Normalize first (\r\n and \r to \n), then convert to \r\n for Aligo
            content = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
            content = content.replace(/\n/g, '\r\n');

            // Check for required variables BEFORE substitution
            const hasReservationVars = /#{reservation_date}|{reservation_date}|#{예약일}|#{reservation_time}|{reservation_time}|#{예약시간}|#{reservation_datetime}|{reservation_datetime}|#{예약일시}/.test(originalContent);

            // Skip this patient if template requires reservation data but patient has none
            if (hasReservationVars && !resDateTime) {
                console.log(`[Cron] Skipping patient ${p.id}: Template requires reservation data but patient has none`);
                failCount++;
                await db.prepare(`
                    INSERT INTO message_logs(campaign_id, patient_id, patient_name, phone, message_type, content, status, sent_at, type, error_message)
                    VALUES(?, ?, ?, ?, 'SKIPPED', ?, 'skipped', ?, 'campaign', ?)
                `).bind(
                    campaign.id, p.id, p.name, p.current_phone,
                    '[변수 누락] 예약 정보 없음',
                    now,
                    `Template requires reservation data but patient ${p.id} has no reservations`
                ).run();
                continue;
            }

            // Proceed with variable substitution
            // Clinic Variables
            content = content.replace(/#{clinic_name}|{clinic_name}/g, clinicName);
            content = content.replace(/#{clinic_phone}|{clinic_phone}/g, clinicPhone);
            content = content.replace(/#{url}|{url}/g, surveyUrl);

            // Reservation Variables
            content = content.replace(/#{reservation_date}|{reservation_date}|#{예약일}/g, resDate);
            content = content.replace(/#{reservation_time}|{reservation_time}|#{예약시간}/g, resTime);
            content = content.replace(/#{reservation_datetime}|{reservation_datetime}|#{예약일시}/g, resDateTime);

            // Patient Variables
            content = content.replace(/#{이름}|{이름}|#{name}|{name}|#{patient_name}|{patient_name}/g, p.name || '');
            content = content.replace(/#{휴대폰}|{휴대폰}/g, p.current_phone);
            content = content.replace(/#{tracking_number}|{tracking_number}/g, ''); // Clear unknown variables

            // Final validation: Check if any unsubstituted variables remain
            const remainingVars = content.match(/#{[^}]+}|{[^}]+}/g);
            if (remainingVars && remainingVars.length > 0) {
                console.log(`[Cron] Skipping patient ${p.id}: Unsubstituted variables found: ${remainingVars.join(', ')}`);
                failCount++;
                await db.prepare(`
                    INSERT INTO message_logs(campaign_id, patient_id, patient_name, phone, message_type, content, status, sent_at, type, error_message)
                    VALUES(?, ?, ?, ?, 'SKIPPED', ?, 'skipped', ?, 'campaign', ?)
                `).bind(
                    campaign.id, p.id, p.name, p.current_phone,
                    `[변수 누락] ${remainingVars.join(', ')}`,
                    now,
                    `Unsubstituted variables: ${remainingVars.join(', ')}`
                ).run();
                continue;
            }

            // Send Logic
            let result;
            let msgType = '';

            try {
                if ((template.channel === 'ALIMTALK' || template.channel === 'BOTH') && template.alimtalk_code) {
                    msgType = 'ALIMTALK';

                    // Use shared library to send AlimTalk
                    const { sendAlimTalkMessage } = await import('../../../lib/alimtalk-sender');

                    const failoverYn = template.channel === 'BOTH' ? 'Y' : 'N';

                    result = await sendAlimTalkMessage(config, {
                        receiver: p.current_phone,
                        template: {
                            name: template.name,
                            content: template.content,
                            alimtalk_code: template.alimtalk_code,
                            buttons: template.buttons
                        },
                        variables: {
                            clinic_name: clinicName,
                            clinic_phone: clinicPhone,
                            patient_name: p.name || '',
                            patient_phone: p.current_phone,
                            reservation_date: resDate,
                            reservation_time: resTime,
                            reservation_datetime: resDateTime,
                            survey_url: surveyUrl
                        },
                        failover: failoverYn
                    });
                } else {
                    msgType = 'SMS';
                    result = await sendAligoMessage(config, {
                        receiver: p.current_phone,
                        msg: content,
                        destination: `${p.current_phone}| ${p.name} `,
                        title: '알림'
                    });
                }

                // Check success
                const rawResult = result as any;
                const isSuccess = (String(result.result_code) === '1') || (rawResult.code !== undefined && Number(rawResult.code) === 0);

                if (isSuccess) {
                    sentCount++;
                } else {
                    failCount++;
                    console.error(`Failed to send to ${p.name}: `, result.message);
                }

                // Log (Simplified - bulk insert is better but loop is safer for IDs)
                // Async logging? Or synchronous to be safe? Synchronous for now.
                // Note: db.prepare in loop is slow, but batch size is 50. OK for now.
                await db.prepare(`
                    INSERT INTO message_logs(campaign_id, patient_id, patient_name, phone, message_type, content, status, sent_at, type)
        VALUES(?, ?, ?, ?, ?, ?, ?, ?, 'campaign')
                `).bind(
                    campaign.id, p.id, p.name, p.current_phone, msgType, content,
                    isSuccess ? 'sent' : 'failed', now
                ).run();

            } catch (e) {
                console.error(`Error sending to ${p.id}: `, e);
                failCount++;
            }
        }

        // 6. Checkpoint & History Update
        const isBatchComplete = patients.length < batchSize;

        // Update Campaign Table
        let updateQuery = `
            UPDATE campaigns 
            SET sent_count = sent_count + ?,
            failed_count = failed_count + ?,
            last_processed_id = ?
                `;
        const updateParams = [sentCount, failCount, lastProcessedId];

        // Update Run History
        // Note: For batched runs, we incrementally update sent/failed counts.
        // For 'total_count', in this batch context, we just add processed row count.
        let runUpdateQuery = `
            UPDATE campaign_runs
            SET sent_count = sent_count + ?,
            failed_count = failed_count + ?,
            total_count = total_count + ?
                `;
        // sentCount + failCount = total processed in this batch (excluding skips? No, skips are fails if no phone)
        // Actually, patients.length is total attempted in this batch.
        const runUpdateParams: (string | number)[] = [sentCount, failCount, patients.length];

        if (isBatchComplete) {
            // Run Completed
            runUpdateQuery += `, status = 'completed', completed_at = ? `;
            runUpdateParams.push(now);

            // Campaign Finished Logic
            if (campaign.type === 'RECURRING') {
                let nextRun = now + 86400; // Default fallback
                try {
                    const { calculateNextRun } = await import('../../../lib/scheduler');
                    const config = JSON.parse(campaign.trigger_config || '{}');
                    nextRun = calculateNextRun(config, now);
                } catch (e) {
                    console.error('[Cron] Failed to calculate next run:', e);
                }

                updateQuery += `, status = 'active', next_run_at = ?, last_processed_id = 0, sent_at = ? `;
                updateParams.push(nextRun, now);
            } else {
                // ONE_TIME -> Done
                updateQuery += `, status = 'sent', sent_at = ? `;
                updateParams.push(now);
            }
        } else {
            // Still Sending
            updateQuery += `, status = 'sending'`;
        }

        runUpdateQuery += ` WHERE id = ? `;
        runUpdateParams.push(runId);

        updateQuery += ` WHERE id = ? `;
        updateParams.push(campaign.id);

        await db.prepare(updateQuery).bind(...updateParams).run();
        await db.prepare(runUpdateQuery).bind(...runUpdateParams).run();

        return new Response(JSON.stringify({
            processed: patients.length,
            sent: sentCount,
            failed: failCount,
            campaign: campaign.name,
            complete: isBatchComplete,
            runId: runId
        }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e) {
        console.error('[Cron] Error:', e);
        return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
    }
};
