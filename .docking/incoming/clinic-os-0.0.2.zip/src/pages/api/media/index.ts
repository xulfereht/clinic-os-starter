import type { APIRoute } from 'astro';

export const prerender = false;

// GET: List all uploaded files (Stubbed for R2 migration)
// GET: List all uploaded files
export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const bucket = locals.runtime?.env?.BUCKET;

    if (!bucket) {
        return new Response(JSON.stringify({ error: 'Bucket not found' }), { status: 500 });
    }

    try {
        const listed = await bucket.list();
        const files = listed.objects.map(obj => ({
            filename: obj.key,
            size: obj.size,
            uploaded: obj.uploaded,
            url: `/api/files/${obj.key}`
        }));

        return new Response(JSON.stringify({ files }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        console.error('List error:', e);
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};

// DELETE: Remove a file (Stubbed)
export const DELETE: APIRoute = async ({ request }) => {
    return new Response(JSON.stringify({ error: 'Not implemented in production' }), { status: 501 });
};
