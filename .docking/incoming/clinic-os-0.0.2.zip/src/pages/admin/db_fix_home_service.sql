-- Restore correct Korean content for Home Page Service Tiles
UPDATE pages 
SET sections = json_replace(sections, 
    -- Find the ServiceTiles section (assuming it's the second one, index 1)
    '$[1].data.title', '진료 서비스',
    '$[1].data.subtitle', '원하시는 서비스를 선택해주세요.',
    '$[1].data.items', json_array(
        json_object(
            'link', '/programs',
            'icon', '🏥',
            'title', '진료과목 전체',
            'desc', '백록담한의원의 모든 진료 프로그램을 확인하세요.',
            'bg', 'soft'
        ),
        json_object(
            'link', '/self-diagnosis',
            'icon', '📝',
            'title', '자가진단 하러가기',
            'desc', '내 증상을 체크하고 맞춤형 처방을 알아보세요.',
            'bg', 'white'
        ),
        json_object(
            'link', '/intake',
            'icon', '📅',
            'title', '진료 예약하기',
            'desc', '원하시는 시간에 간편하게 진료를 예약하세요.',
            'bg', 'soft'
        )
    )
)
WHERE slug = 'home';
