-- Restore complete Korean home page sections with items array
UPDATE pages 
SET sections = '[
  {
    "id": "hero-1",
    "type": "MainHero",
    "images": [
      {"url": "/images/hero/zen_hero_1.png", "alt": "Zen Hero 1"},
      {"url": "/images/hero/zen_hero_2.png", "alt": "Zen Hero 2"},
      {"url": "/images/hero/zen_hero_3.png", "alt": "Zen Hero 3"}
    ],
    "mainHeading": "백록담(白鹿潭),\n치유와 회복의 공간",
    "subHeading": "전통의 지혜와 현대한의학의 통합",
    "description": "검사로는 잘 잡히지 않는 고질적인 아픔,\n전통 한의학의 깊은 지혜와 현대한의학의 정밀한 데이터로\n당신의 무너진 균형을 체계적으로 바로잡습니다.",
    "ctaText": "진료 예약하기",
    "ctaLink": "/intake",
    "theme": "light"
  },
  {
    "id": "services-1",
    "type": "ServiceTiles",
    "title": "진료 서비스",
    "subtitle": "원하시는 서비스를 선택해주세요.",
    "items": [
      {
        "link": "/programs",
        "icon": "🏥",
        "title": "진료과목 전체",
        "desc": "백록담한의원의 모든 진료 프로그램을 확인하세요.",
        "bg": "soft"
      },
      {
        "link": "/self-diagnosis",
        "icon": "📝",
        "title": "자가진단 하러가기",
        "desc": "내 증상을 체크하고 맞춤형 처방을 알아보세요.",
        "bg": "white"
      },
      {
        "link": "/intake",
        "icon": "📅",
        "title": "진료 예약하기",
        "desc": "원하시는 시간에 간편하게 진료를 예약하세요.",
        "bg": "soft"
      }
    ]
  },
  {
    "id": "philosophy-1",
    "type": "Philosophy",
    "title": "지친 몸과 마음이\n온전히 쉴 수 있는 곳",
    "subtitle": "흰 사슴이 노니는 연못, 백록담(白鹿潭)",
    "description": "백록담은 예로부터 흰 사슴이 물을 마시며 쉬어가던 신비로운 치유의 공간이었습니다.\n저희는 그 이름처럼, 환자분들의 지친 일상에 진정한 쉼과 회복을 드리고자 합니다."
  },
  {
    "id": "info-1",
    "type": "HomeInfo"
  }
]'
WHERE slug = 'home';
