import type { APIRoute } from 'astro';
import { getClinicSettings } from "../../lib/clinic";
import { generateAIManifest } from "../../lib/aeo";

export const prerender = false;

export const GET: APIRoute = async ({ locals }) => {
    const db = locals.runtime?.env?.DB;
    const settings = await getClinicSettings(db);

    const manifest = generateAIManifest(settings);

    return new Response(JSON.stringify(manifest, null, 2), {
        headers: {
            'Content-Type': 'application/json',
            'Cache-Control': 'public, max-age=3600'
        }
    });
};
