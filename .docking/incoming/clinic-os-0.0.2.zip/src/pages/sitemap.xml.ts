import type { APIContext } from 'astro';
import { getClinicSettings } from '../lib/clinic';

export async function GET(context: APIContext) {
  // @ts-ignore
  const db = context.locals.runtime?.env?.DB;
  const settings = await getClinicSettings(db);
  const siteUrl = settings.url || context.site?.toString() || 'https://www.example.com';
  const site = siteUrl.endsWith('/') ? siteUrl.slice(0, -1) : siteUrl;

  // List of child sitemaps
  const sitemaps = [
    `${site}/sitemap-main.xml`,
    `${site}/sitemap-posts.xml`,
    `${site}/sitemap-knowledge.xml`,
  ];

  const sitemapIndex = `<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${sitemaps.map(url => `
    <sitemap>
      <loc>${url}</loc>
      <lastmod>${new Date().toISOString()}</lastmod>
    </sitemap>
  `).join('')}
</sitemapindex>`;

  return new Response(sitemapIndex, {
    headers: {
      'Content-Type': 'application/xml',
    },
  });
}
