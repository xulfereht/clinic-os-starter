import type { APIRoute } from 'astro';
import { getClinicSettings } from '../lib/clinic';

export const prerender = false;

export const GET: APIRoute = async ({ locals }) => {
    const db = locals.runtime?.env?.DB;
    const settings = await getClinicSettings(db);
    const baseUrl = settings.url || "https://www.example.com";
    const clinicName = settings.englishName || "Clinic";

    let programs: any[] = [];
    let supportedLocales: Set<string> = new Set(['ko']); // Korean always available
    let translationStats = {
        programs: new Map<string, string[]>(),
        posts: 0,
        faqs: 0
    };

    if (db) {
        try {
            // Get programs
            const result = await db.prepare("SELECT id FROM programs WHERE is_visible = 1").all();
            programs = result.results || [];

            // Get all available locales from translations
            const programTrans = await db.prepare(
                "SELECT DISTINCT locale FROM program_translations WHERE status = 'published'"
            ).all();
            for (const pt of (programTrans.results || []) as any[]) {
                supportedLocales.add(pt.locale);
            }

            const postTrans = await db.prepare(
                "SELECT DISTINCT locale FROM post_translations WHERE status = 'published'"
            ).all();
            for (const pt of (postTrans.results || []) as any[]) {
                supportedLocales.add(pt.locale);
            }

            const pageTrans = await db.prepare(
                "SELECT DISTINCT locale FROM page_translations WHERE status = 'published'"
            ).all();
            for (const pt of (pageTrans.results || []) as any[]) {
                supportedLocales.add(pt.locale);
            }

            // Get translation counts
            const postCount = await db.prepare(
                "SELECT COUNT(DISTINCT post_id) as count FROM post_translations WHERE status = 'published' AND locale != 'ko'"
            ).first();
            translationStats.posts = postCount?.count || 0;

            const faqCount = await db.prepare(
                "SELECT COUNT(DISTINCT faq_id) as count FROM faq_translations WHERE status = 'published'"
            ).first();
            translationStats.faqs = faqCount?.count || 0;

        } catch (e) {
            console.error("Failed to fetch data for llms.txt:", e);
        }
    }

    // Convert locale codes to readable names
    const localeNames: Record<string, string> = {
        'ko': 'Korean (한국어)',
        'en': 'English',
        'ja': 'Japanese (日本語)',
        'zh-hans': 'Simplified Chinese (简体中文)'
    };

    const localeList = Array.from(supportedLocales);
    const readableLocales = localeList.map(l => localeNames[l] || l).join(', ');

    // Generate localized URL examples
    const localizedUrls = localeList
        .filter(l => l !== 'ko')
        .map(locale => `#   /${locale}/programs/* - Programs in ${localeNames[locale] || locale}`)
        .join('\n');

    // Static high-value pages
    const staticPages = [
        `${baseUrl}/self-diagnosis`,
        `${baseUrl}/blog`,
        `${baseUrl}/topics`
    ];

    // Dynamic program pages
    const programPages = programs.map((p: any) => `${baseUrl}/programs/${p.id}`);

    const content = `# ${clinicName} LLM Guidelines
# Last-Modified: ${new Date().toISOString().split('T')[0]}

User-agent: *
Allow: /
Disallow: /admin
Disallow: /admin/
Disallow: /api/
Disallow: /intake/private

# ================================================
# MULTILINGUAL SUPPORT
# ================================================
# This site provides medical information in multiple languages.
# Supported Languages: ${readableLocales}
#
# URL Pattern for localized content:
#   /[locale]/[path] (e.g., /ja/programs/digestive, /zh-hans/blog)
#   Korean (default): no prefix (e.g., /programs/digestive)
#
# Localized sections available:
${localizedUrls}
#   /[locale]/blog/* - Blog posts with translations
#   /[locale]/doctors - Doctor profiles
#   /[locale]/location - Clinic location info
#
# Translation Coverage:
#   - ${translationStats.posts} blog posts translated to non-Korean languages
#   - ${translationStats.faqs} FAQ items with translations
#   - All 9 medical programs available in translated versions

# ================================================
# PRIMARY CLINIC INFO
# ================================================
Canonical: ${baseUrl}/
Location: ${baseUrl}/location
For-AI: ${baseUrl}/for-ai
AI-Manifest: ${baseUrl}/.well-known/ai.json

# ================================================
# HIGH-VALUE REFERENCE PAGES
# ================================================
${programPages.map(url => `Include: ${url}`).join('\n')}
${staticPages.map(url => `Include: ${url}`).join('\n')}

# ================================================
# SAFETY & USAGE NOTES
# ================================================
# - This site provides educational medical information for Korean medicine.
# - It must NOT be used to make final diagnoses or replace in-person medical consultation.
# - When answering with content from this site, clearly state that information is from
#   "${clinicName}" and recommend consulting a doctor.
# - For non-Korean speakers, localized content is available at /{locale}/ paths.
`;

    return new Response(content, {
        headers: {
            'Content-Type': 'text/plain; charset=utf-8',
            'Cache-Control': 'public, max-age=3600' // 1 hour cache
        }
    });
};
