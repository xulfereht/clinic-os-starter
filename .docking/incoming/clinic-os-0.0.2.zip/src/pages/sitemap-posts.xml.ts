import type { APIContext } from 'astro';

interface SitemapUrl {
    loc: string;
    lastmod?: string;
    changefreq?: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
    priority?: number;
    alternates?: { hreflang: string; href: string }[];
}

function formatDate(dateStr?: number | string): string {
    if (!dateStr) return new Date().toISOString();
    // Handle Unix timestamp (seconds)
    if (typeof dateStr === 'number' && dateStr < 10000000000) {
        dateStr = dateStr * 1000;
    }
    return new Date(dateStr).toISOString();
}

// Helper to generate URL for a locale
function getUrl(site: string, locale: string, path: string): string {
    return locale === 'ko' ? `${site}${path}` : `${site}/${locale}${path}`;
}

// Helper to generate alternate links from available locales
function generateAlternates(site: string, path: string, availableLocales: string[]): { hreflang: string; href: string }[] {
    return availableLocales.map(locale => ({
        hreflang: locale === 'zh-hans' ? 'zh-Hans' : locale,
        href: getUrl(site, locale, path)
    }));
}

export async function GET(context: APIContext) {
    const db = context.locals.runtime?.env?.DB;
    // @ts-ignore
    const { getClinicSettings } = await import('../lib/clinic');
    const settings = await getClinicSettings(db);
    const siteUrl = settings.url || (context.site?.toString() ?? 'https://sample-clinic.com');
    const site = siteUrl.endsWith('/') ? siteUrl.slice(0, -1) : siteUrl;

    let urls: SitemapUrl[] = [];

    if (db) {
        try {
            // ================================================
            // 1. Get all post translations to build locale map
            // ================================================
            const postTranslations = await db.prepare(
                "SELECT post_id, locale FROM post_translations WHERE status = 'published'"
            ).all();

            const postLocaleMap = new Map<number, Set<string>>();
            for (const pt of (postTranslations.results || []) as any[]) {
                if (!postLocaleMap.has(pt.post_id)) {
                    postLocaleMap.set(pt.post_id, new Set(['ko'])); // Korean always available
                }
                postLocaleMap.get(pt.post_id)!.add(pt.locale);
            }

            // ================================================
            // 2. Blog & Column Posts
            // ================================================
            const posts = await db.prepare(
                "SELECT id, slug, updated_at, created_at FROM posts WHERE type IN ('blog', 'column') AND status = 'published'"
            ).all();

            if (posts.results) {
                for (const p of posts.results as any[]) {
                    const path = `/blog/${p.slug}`;
                    const availableLocales = postLocaleMap.has(p.id)
                        ? Array.from(postLocaleMap.get(p.id)!)
                        : ['ko'];
                    const alternates = generateAlternates(site, path, availableLocales);

                    for (const locale of availableLocales) {
                        urls.push({
                            loc: getUrl(site, locale, path),
                            lastmod: formatDate(p.updated_at || p.created_at),
                            changefreq: 'weekly' as const,
                            priority: locale === 'ko' ? 0.7 : 0.65,
                            alternates
                        });
                    }
                }
            }

            // ================================================
            // 3. Notices
            // ================================================
            const notices = await db.prepare(
                "SELECT id, updated_at, created_at FROM posts WHERE type = 'notice' AND status = 'published'"
            ).all();

            if (notices.results) {
                for (const n of notices.results as any[]) {
                    const path = `/notices/${n.id}`;
                    const availableLocales = postLocaleMap.has(n.id)
                        ? Array.from(postLocaleMap.get(n.id)!)
                        : ['ko'];
                    const alternates = generateAlternates(site, path, availableLocales);

                    for (const locale of availableLocales) {
                        urls.push({
                            loc: getUrl(site, locale, path),
                            lastmod: formatDate(n.updated_at || n.created_at),
                            changefreq: 'monthly' as const,
                            priority: locale === 'ko' ? 0.5 : 0.45,
                            alternates
                        });
                    }
                }
            }

        } catch (e) {
            console.error('Error fetching DB content for sitemap-posts:', e);
        }
    }

    // ================================================
    // Generate XML with xhtml:link for alternates
    // ================================================
    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
  ${urls.map(u => `
    <url>
      <loc>${u.loc}</loc>
      ${u.lastmod ? `<lastmod>${u.lastmod}</lastmod>` : ''}
      ${u.changefreq ? `<changefreq>${u.changefreq}</changefreq>` : ''}
      ${u.priority ? `<priority>${u.priority}</priority>` : ''}
      ${u.alternates ? u.alternates.map(alt =>
        `<xhtml:link rel="alternate" hreflang="${alt.hreflang}" href="${alt.href}"/>`
    ).join('\n      ') : ''}
    </url>
  `).join('')}
</urlset>`;

    return new Response(sitemap, {
        headers: {
            'Content-Type': 'application/xml',
        },
    });
}
