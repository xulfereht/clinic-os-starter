import rss from '@astrojs/rss';
import type { APIContext } from 'astro';
import { clinicConfig } from '../config';

export async function GET(context: APIContext) {
    const db = context.locals.runtime?.env?.DB;
    let posts: any[] = [];
    // @ts-ignore
    const { getClinicSettings } = await import('../lib/clinic');
    const settings = await getClinicSettings(db);
    const clinicName = settings.name || clinicConfig.name;
    const siteUrl = settings.url || (context.site?.toString() ?? 'https://sample-clinic.com');

    if (db) {
        try {
            const { results } = await db.prepare(`
          SELECT p.*, d.name as doctor_name
          FROM posts p
          LEFT JOIN staff d ON p.doctor_id = d.id
          WHERE p.type IN ('blog', 'column') AND p.status = 'published'
          ORDER BY p.created_at DESC
      `).all();
            posts = results;
        } catch (e) {
            console.error('Error fetching posts for RSS:', e);
        }
    }

    return rss({
        title: `${clinicName} 블로그`,
        description: '최신 건강 정보와 칼럼을 만나보세요.',
        site: siteUrl,
        items: posts.map((post) => ({
            title: post.title,
            pubDate: new Date(post.published_at * 1000),
            description: post.excerpt,
            link: `/blog/${post.slug}/`, // Slash at the end is important for SEO?
            author: post.doctor_name || clinicName,
        })),
        customData: `<language>ko-KR</language>`,
    });
}
