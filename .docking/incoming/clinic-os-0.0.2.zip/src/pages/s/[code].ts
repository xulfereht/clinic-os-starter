interface ShortLink {
    id: number;
    code: string;
    original_url: string;
    created_at: number;
    expires_at: number | null;
    visits: number;
}

import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals, request }) => {
    const { code } = params;

    if (!code) {
        return new Response('Invalid Code', { status: 404 });
    }

    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) {
        // Fallback for dev without bindings? Or error.
        return new Response('Database Error', { status: 500 });
    }

    try {
        const result = await db.prepare('SELECT * FROM short_links WHERE code = ?').bind(code).first<ShortLink>();

        if (!result) {
            return new Response('Link Not Found', { status: 404 });
        }

        const now = Math.floor(Date.now() / 1000);
        if (result.expires_at && now > result.expires_at) {
            return new Response('Link Expired', { status: 410 }); // 410 Gone
        }

        // Async update visits (fire and forget logic in Pages functions isn't always reliable without waitUntil)
        // usage: context.waitUntil(promise)
        // @ts-ignore
        if (locals.runtime?.ctx?.waitUntil) {
            // @ts-ignore
            locals.runtime.ctx.waitUntil(
                db.prepare('UPDATE short_links SET visits = visits + 1 WHERE id = ?').bind(result.id).run()
            );
        } else {
            // Await if no context
            await db.prepare('UPDATE short_links SET visits = visits + 1 WHERE id = ?').bind(result.id).run();
        }

        return new Response(null, {
            status: 302,
            headers: {
                'Location': result.original_url as string
            }
        });

    } catch (e) {
        console.error('Redirect Error:', e);
        return new Response('Server Error', { status: 500 });
    }
};
