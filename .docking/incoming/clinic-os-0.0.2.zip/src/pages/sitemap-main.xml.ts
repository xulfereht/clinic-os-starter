import type { APIContext } from 'astro';

// Supported locales (ko is default, not prefixed)
const LOCALES = ['ko', 'en', 'ja', 'zh-hans', 'vi'];

const staticPages = [
    '',
    '/programs',
    '/self-diagnosis',
    '/intake',
    '/notices',
    '/blog',
    '/reviews',
    '/login',
    '/signup',
    '/doctors',
    '/telemedicine',
    '/location',
];

interface SitemapUrl {
    loc: string;
    lastmod?: string;
    changefreq?: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
    priority?: number;
    alternates?: { hreflang: string; href: string }[];
}

function formatDate(dateStr?: number | string): string {
    if (!dateStr) return new Date().toISOString();
    return new Date(dateStr).toISOString();
}

// Helper to generate URL for a locale
function getUrl(site: string, locale: string, path: string): string {
    return locale === 'ko' ? `${site}${path}` : `${site}/${locale}${path}`;
}

// Helper to generate alternate links from available locales
function generateAlternates(site: string, path: string, availableLocales: string[]): { hreflang: string; href: string }[] {
    return availableLocales.map(locale => ({
        hreflang: locale === 'zh-hans' ? 'zh-Hans' : locale,
        href: getUrl(site, locale, path)
    }));
}

export async function GET(context: APIContext) {
    const db = context.locals.runtime?.env?.DB;
    // @ts-ignore
    const { getClinicSettings } = await import('../lib/clinic');
    const settings = await getClinicSettings(db);
    // Use settings.url if available, otherwise context.site, then fallback
    const siteUrl = settings.url || (context.site?.toString() ?? 'https://sample-clinic.com');
    const site = siteUrl.endsWith('/') ? siteUrl.slice(0, -1) : siteUrl;

    let urls: SitemapUrl[] = [];

    // ================================================
    // 1. STATIC PAGES - Check which have translations
    // ================================================
    // Get all page translations to know which locales are available per page
    const pageTranslationMap = new Map<string, Set<string>>();
    if (db) {
        try {
            const pageTranslations = await db.prepare(
                "SELECT page_id, locale FROM page_translations WHERE status = 'published'"
            ).all();
            for (const pt of (pageTranslations.results || []) as any[]) {
                if (!pageTranslationMap.has(pt.page_id)) {
                    pageTranslationMap.set(pt.page_id, new Set(['ko'])); // Korean always available
                }
                pageTranslationMap.get(pt.page_id)!.add(pt.locale);
            }
        } catch (e) {
            console.error('Error fetching page translations for sitemap:', e);
        }
    }

    // Static pages - always include Korean, other locales based on translations
    for (const page of staticPages) {
        // For static pages, we check if any translation exists for that page path
        // Page IDs in DB might be like 'page_doctors', 'location-page', etc.
        // For simplicity, we'll include all locales for static pages since they use t() functions
        const availableLocales = ['ko', 'en', 'ja', 'zh-hans']; // Static pages use t() so all locales work
        const alternates = generateAlternates(site, page, availableLocales);

        for (const locale of availableLocales) {
            urls.push({
                loc: getUrl(site, locale, page),
                changefreq: 'daily' as const,
                priority: locale === 'ko' ? 1.0 : 0.9,
                alternates
            });
        }
    }

    // ================================================
    // 2. PROGRAMS - Check program_translations
    // ================================================
    if (db) {
        try {
            // Get all published programs
            const programs = await db.prepare("SELECT id FROM programs WHERE is_visible = 1").all();

            // Get all program translations
            const programTranslations = await db.prepare(
                "SELECT program_id, locale FROM program_translations WHERE status = 'published'"
            ).all();

            // Build map of program_id -> available locales
            const programLocaleMap = new Map<string, Set<string>>();
            for (const pt of (programTranslations.results || []) as any[]) {
                if (!programLocaleMap.has(pt.program_id)) {
                    programLocaleMap.set(pt.program_id, new Set(['ko']));
                }
                programLocaleMap.get(pt.program_id)!.add(pt.locale);
            }

            for (const p of (programs.results || []) as any[]) {
                const path = `/programs/${p.id}`;
                const availableLocales = programLocaleMap.has(p.id)
                    ? Array.from(programLocaleMap.get(p.id)!)
                    : ['ko'];
                const alternates = generateAlternates(site, path, availableLocales);

                for (const locale of availableLocales) {
                    urls.push({
                        loc: getUrl(site, locale, path),
                        changefreq: 'weekly' as const,
                        priority: locale === 'ko' ? 0.9 : 0.85,
                        alternates
                    });
                }
            }
        } catch (e) {
            console.error('Error fetching programs for sitemap:', e);
        }
    }

    // ================================================
    // 3. DOCTORS - Check staff_translations
    // ================================================
    if (db) {
        try {
            const doctors = await db.prepare(
                "SELECT id FROM staff WHERE type = 'doctor' AND is_active = 1"
            ).all();

            const staffTranslations = await db.prepare(
                "SELECT staff_id, locale FROM staff_translations WHERE status = 'published'"
            ).all();

            const staffLocaleMap = new Map<string, Set<string>>();
            for (const st of (staffTranslations.results || []) as any[]) {
                if (!staffLocaleMap.has(st.staff_id)) {
                    staffLocaleMap.set(st.staff_id, new Set(['ko']));
                }
                staffLocaleMap.get(st.staff_id)!.add(st.locale);
            }

            for (const d of (doctors.results || []) as any[]) {
                const path = `/doctors/${d.id}`;
                const availableLocales = staffLocaleMap.has(d.id)
                    ? Array.from(staffLocaleMap.get(d.id)!)
                    : ['ko'];
                const alternates = generateAlternates(site, path, availableLocales);

                for (const locale of availableLocales) {
                    urls.push({
                        loc: getUrl(site, locale, path),
                        changefreq: 'monthly' as const,
                        priority: locale === 'ko' ? 0.8 : 0.75,
                        alternates
                    });
                }
            }
        } catch (e) {
            console.error('Error fetching doctors for sitemap:', e);
        }
    }

    // ================================================
    // 4. SYMPTOMS (Content Collection - Korean only for now)
    // ================================================
    try {
        const { getCollection } = await import('astro:content');
        const symptoms = await getCollection('symptoms');
        urls.push(...symptoms.map(s => ({
            loc: `${site}/symptoms/${s.id}`,
            changefreq: 'monthly' as const,
            priority: 0.6
        })));
    } catch (e) {
        console.error('Error fetching symptoms for sitemap:', e);
    }

    // ================================================
    // Generate XML with xhtml:link for alternates
    // ================================================
    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
  ${urls.map(u => `
    <url>
      <loc>${u.loc}</loc>
      ${u.lastmod ? `<lastmod>${u.lastmod}</lastmod>` : ''}
      ${u.changefreq ? `<changefreq>${u.changefreq}</changefreq>` : ''}
      ${u.priority ? `<priority>${u.priority}</priority>` : ''}
      ${u.alternates ? u.alternates.map(alt =>
        `<xhtml:link rel="alternate" hreflang="${alt.hreflang}" href="${alt.href}"/>`
    ).join('\n      ') : ''}
    </url>
  `).join('')}
</urlset>`;

    return new Response(sitemap, {
        headers: {
            'Content-Type': 'application/xml',
        },
    });
}
