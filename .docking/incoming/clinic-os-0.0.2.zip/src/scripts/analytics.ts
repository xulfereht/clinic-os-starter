/**
 * BRD Clinic Analytics - Client-side tracking script
 * Tracks page views and custom events
 */

(function () {
    // Generate or retrieve session ID
    function getSessionId(): string {
        const key = 'brd_session_id';
        let sessionId = sessionStorage.getItem(key);
        if (!sessionId) {
            sessionId = 'ses_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
            sessionStorage.setItem(key, sessionId);
        }
        return sessionId;
    }

    // Generate or retrieve Visitor ID (Persistent)
    function getVisitorId(): string {
        const key = 'brd_visitor_id';
        let visitorId = localStorage.getItem(key);
        if (!visitorId) {
            visitorId = 'vis_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
            localStorage.setItem(key, visitorId);
        }
        return visitorId;
    }

    // Track page view
    function trackPageView() {
        const data = {
            type: 'pageview',
            sessionId: getSessionId(),
            visitorId: getVisitorId(),
            path: window.location.pathname,
            referrer: document.referrer || null,
            userAgent: navigator.userAgent
        };

        // Use sendBeacon for reliability (won't be cancelled on page unload)
        if (navigator.sendBeacon) {
            navigator.sendBeacon('/api/analytics/track', JSON.stringify(data));
        } else {
            // Fallback to fetch
            fetch('/api/analytics/track', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
                keepalive: true
            }).catch(() => { });
        }
    }

    // Track custom event
    function trackEvent(eventType: string, eventData?: Record<string, any>) {
        const data = {
            type: 'event',
            sessionId: getSessionId(),
            visitorId: getVisitorId(),
            path: window.location.pathname,
            eventType,
            eventData
        };

        if (navigator.sendBeacon) {
            navigator.sendBeacon('/api/analytics/track', JSON.stringify(data));
        } else {
            fetch('/api/analytics/track', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
                keepalive: true
            }).catch(() => { });
        }
    }

    // Expose trackEvent globally
    (window as any).trackEvent = trackEvent;

    // Track initial page view
    trackPageView();

    // Track SPA navigation (for client-side routing)
    let lastPath = window.location.pathname;

    // Listen for history changes
    const originalPushState = history.pushState;
    history.pushState = function (...args) {
        originalPushState.apply(this, args);
        if (window.location.pathname !== lastPath) {
            lastPath = window.location.pathname;
            trackPageView();
        }
    };

    window.addEventListener('popstate', () => {
        if (window.location.pathname !== lastPath) {
            lastPath = window.location.pathname;
            trackPageView();
        }
    });

    // Track time on page (send event when user leaves)
    const startTime = Date.now();
    window.addEventListener('beforeunload', () => {
        const timeOnPage = Math.round((Date.now() - startTime) / 1000);
        trackEvent('page_exit', { seconds: timeOnPage });
    });
})();
