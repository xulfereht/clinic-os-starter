/**
 * Demo Mode Dynamic Scanner (Refined)
 * Automatically detects and blurs PII (Personally Identifiable Information) in the DOM.
 * 
 * Activated only when document.body.dataset.demo === "true"
 */

(function initDemoScanner() {
    if (document.body.dataset.demo !== "true") return;

    console.log("🎭 Demo Scanner Activated: Smart PII Detection");

    // 1. Regex Patterns (Strict Formats Only)
    // Removed generic 'Name' regex to prevent UI blurring (e.g. "설정", "이벤트")
    const PATTERNS = [
        {
            // Phone: 010-xxxx-xxxx, 010xxxxxxxx
            regex: /(01[016789])[-.\s]?([0-9]{3,4})[-.\s]?([0-9]{4})/g,
            type: 'phone'
        },
        {
            // RRN/Birth: YYMMDD-1xxxxxx, YYYY.MM.DD
            regex: /(\d{2}([0]\d|[1][0-2])([0-2]\d|[3][01]))[-.\s]?[1-4]\d{6}/g,
            type: 'rrn'
        },
        {
            // Email
            regex: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g,
            type: 'email'
        }
    ];

    // Tags/Classes to totally ignore
    const IGNORE_SELECTORS = [
        'script', 'style', 'noscript',
        'nav', 'aside', '.admin-sidebar', // Sidebar
        'button', '.btn', 'a.btn', // Buttons
        'label', 'th', 'thead', // Headers
        '.no-blur' // Opt-out class
    ];

    function shouldIgnore(node) {
        if (node.nodeType !== 1) return false;
        return IGNORE_SELECTORS.some(sel => node.matches(sel) || node.closest(sel));
    }

    // 2. Scan for Pattern Matches (Phone/Email/RRN)
    function scanForPatterns(el) {
        if (shouldIgnore(el)) return;
        if (el.classList.contains('demo-blur')) return;

        // Input Values
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
            const val = el.value;
            for (const p of PATTERNS) {
                if (p.regex.test(val)) {
                    el.classList.add('demo-blur');
                    return;
                }
            }
            return;
        }

        // Text Content (Leaf nodes)
        if (el.children.length === 0 && el.textContent.trim().length > 0) {
            const text = el.textContent;
            for (const p of PATTERNS) {
                if (p.regex.test(text)) {
                    el.classList.add('demo-blur');
                    return;
                }
            }
        }
    }

    // 3. Smart Table Name Masking
    // Finds tables with headers containing "이름", "성명", "명" and blurs corresponding columns
    function scanTables(root) {
        const tables = (root.tagName === 'TABLE') ? [root] : root.querySelectorAll('table');

        tables.forEach(table => {
            const headers = table.querySelectorAll('thead th');
            const targetIndices = [];

            // Identify Name Columns
            headers.forEach((th, index) => {
                const text = th.innerText.trim();
                if (['이름', '성명', '환자명', '고객명', '신청자'].some(k => text.includes(k))) {
                    targetIndices.push(index);
                }
            });

            if (targetIndices.length > 0) {
                const rows = table.querySelectorAll('tbody tr');
                rows.forEach(row => {
                    const cells = row.cells;
                    targetIndices.forEach(idx => {
                        if (cells[idx]) {
                            // Only blur if it looks like a name (2-4 chars) AND not already blurred
                            // This double check prevents empty cells or long notes from being blurred
                            const content = cells[idx].innerText.trim();
                            if (content.length >= 2 && content.length <= 10) { // Slight flex for "Hong Gil Dong"
                                cells[idx].classList.add('demo-blur');
                            }
                        }
                    });
                });
            }
        });
    }

    // 4. Smart Heading Masking (h1, h2)
    // Detects names in page titles while ignoring common system words
    function scanHeadings(root) {
        const headings = root.querySelectorAll('h1, h2');
        const SYSTEM_WORDS = new Set([
            '관리', '설정', '목록', '통계', '현황', '정보', '상세',
            '이벤트', '캠페인', '예약', '결제', '배송', '설문', '상담',
            '접수', '내역', '리드', '환자', '멤버', '부서', '직원',
            '만들기', '수정', '로그인', '대시보드', '메신저', '게시판',
            '공지사항', '매뉴얼', '문서함', '프로그램', '운영', '검색'
        ]);

        headings.forEach(h => {
            if (shouldIgnore(h) || h.classList.contains('demo-blur')) return;

            // Check direct text content
            const text = h.innerText.trim();

            // Heuristic:
            // 1. Must be Hangul 2-4 chars
            // 2. Must NOT contain any system words
            // 3. Must NOT be a sentence (no spaces? actually some names might be "김 철수" but usually "김철수") - regex handles no space or single space
            // Let's stick to strict 2-4 chars for now to be safe.

            const isNamePattern = /^[가-힣]{2,4}$/.test(text);

            if (isNamePattern) {
                // Check if any system word is present (substring check)
                // Actually, if it's exactly 2-4 chars, substring check is effectively equality or close to it.
                // We want to avoid "이벤트" (3 chars) -> matches name pattern.
                // So we check if the text IS a system word.

                let isSystem = false;
                for (const word of SYSTEM_WORDS) {
                    if (text.includes(word)) { // "환자 관리" -> includes "관리"
                        isSystem = true;
                        break;
                    }
                }

                if (!isSystem) {
                    h.classList.add('demo-blur');
                }
            }
        });
    }

    // 5. Mutation Observer
    const observer = new MutationObserver((mutations) => {
        let needsRescan = false;

        for (const mutation of mutations) {
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === 1) { // Element
                        scanForPatterns(node);
                        node.querySelectorAll('*').forEach(scanForPatterns);

                        if (node.tagName === 'TABLE' || node.querySelector('table')) {
                            needsRescan = true;
                        }
                        if (['H1', 'H2'].includes(node.tagName) || node.querySelector('h1, h2')) {
                            needsRescan = true;
                        }
                    }
                });
            } else if (mutation.type === 'attributes' && mutation.attributeName === 'value') {
                scanForPatterns(mutation.target);
            }
        }

        if (needsRescan) {
            scanTables(document.body);
            scanHeadings(document.body);
        }
    });

    // Initial Run
    document.querySelectorAll('*').forEach(scanForPatterns);
    scanTables(document.body);
    scanHeadings(document.body);

    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['value']
    });

})();
