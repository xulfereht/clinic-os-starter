import type { APIRoute } from 'astro';
import fs from 'fs';
import path from 'path';

export const POST: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const migrationPath = path.join(process.cwd(), 'migrations', '0103_fix_sessions_rename_method.sql');
        const sql = fs.readFileSync(migrationPath, 'utf-8');
        const statements = sql.split(';').map(s => s.trim()).filter(s => s && !s.startsWith('--'));

        const results = [];

        for (const statement of statements) {
            try {
                await db.prepare(statement).run();
                results.push({ statement: statement.substring(0, 50) + '...', status: 'success' });
            } catch (e: any) {
                results.push({ statement: statement.substring(0, 50) + '...', status: 'error', error: e.message });
                // If RENAME fails, we should stop
                if (statement.toUpperCase().startsWith('ALTER TABLE')) {
                    throw new Error(`Failed to rename table: ${e.message}`);
                }
            }
        }

        return new Response(JSON.stringify({
            success: true,
            results
        }, null, 2), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message, stack: e.stack }), { status: 500 });
    }
};
