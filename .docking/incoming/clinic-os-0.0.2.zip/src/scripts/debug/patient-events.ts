import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ params, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // Get some patient events with staff info
        const { results } = await db.prepare(`
            SELECT pe.id, pe.type, pe.title, pe.patient_id, pe.staff_id, pe.event_date, s.name as staff_name, s.id as staff_full_id
            FROM patient_events pe
            LEFT JOIN staff s ON pe.staff_id = s.id
            WHERE pe.patient_id = 'patient_seed_1'
            ORDER BY pe.event_date DESC
            LIMIT 10
        `).run();

        return new Response(JSON.stringify({
            count: results.length,
            events: results
        }, null, 2), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
