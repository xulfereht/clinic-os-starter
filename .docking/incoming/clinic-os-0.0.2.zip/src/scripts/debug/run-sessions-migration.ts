import type { APIRoute } from 'astro';
import fs from 'fs';
import path from 'path';

export const POST: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // Read the migration file
        const migrationPath = path.join(process.cwd(), 'migrations', '0101_make_sessions_member_id_nullable.sql');
        const sql = fs.readFileSync(migrationPath, 'utf-8');

        // Split by semicolons and execute each statement
        const statements = sql.split(';').map(s => s.trim()).filter(s => s && !s.startsWith('--'));

        for (const statement of statements) {
            if (statement) {
                await db.prepare(statement).run();
            }
        }

        return new Response(JSON.stringify({
            success: true,
            message: 'Migration completed successfully'
        }, null, 2), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message, stack: e.stack }), { status: 500 });
    }
};
