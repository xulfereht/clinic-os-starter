import type { APIRoute } from 'astro';

// HMAC Signature for permanent access
async function generateSignature(key: string, secret: string): Promise<string> {
    const enc = new TextEncoder();
    const algorithm = { name: 'HMAC', hash: 'SHA-256' };
    const keyData = await crypto.subtle.importKey('raw', enc.encode(secret), algorithm, false, ['sign']);
    const signature = await crypto.subtle.sign(algorithm.name, keyData, enc.encode(key));
    return Array.from(new Uint8Array(signature))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}

// Convert base64 data URI to ArrayBuffer
function dataURItoArrayBuffer(dataURI: string): { buffer: ArrayBuffer; mimeType: string } {
    const [header, base64] = dataURI.split(',');
    const mimeType = header.match(/:(.*?);/)?.[1] || 'image/jpeg';
    const binary = atob(base64);
    const buffer = new ArrayBuffer(binary.length);
    const view = new Uint8Array(buffer);
    for (let i = 0; i < binary.length; i++) {
        view[i] = binary.charCodeAt(i);
    }
    return { buffer, mimeType };
}

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    // @ts-ignore
    const bucket = locals.runtime?.env?.BUCKET;
    // @ts-ignore
    const secret = locals.runtime?.env?.ADMIN_PASSWORD || 'clinic-admin';

    if (!db || !bucket) {
        return new Response(JSON.stringify({ error: 'DB or Bucket not available' }), { status: 500 });
    }

    try {
        // Find all images stored as base64 (data URI)
        const { results: images } = await db.prepare(`
            SELECT id, patient_id, file_name, mime_type, data, size 
            FROM patient_images 
            WHERE data LIKE 'data:%'
            LIMIT 50
        `).run();

        if (!images || images.length === 0) {
            return new Response(JSON.stringify({
                message: 'No base64 images to migrate',
                migrated: 0
            }), { status: 200 });
        }

        let migrated = 0;
        const errors: string[] = [];

        for (const img of images) {
            try {
                // Parse base64 data
                const { buffer, mimeType } = dataURItoArrayBuffer(img.data);

                // Determine extension from mime type
                const extMap: Record<string, string> = {
                    'image/jpeg': 'jpg',
                    'image/png': 'png',
                    'image/gif': 'gif',
                    'image/webp': 'webp'
                };
                const ext = extMap[mimeType] || 'jpg';

                // Upload to R2
                const filename = `patients/${img.patient_id}/images/${img.id}.${ext}`;
                await bucket.put(filename, buffer, {
                    httpMetadata: { contentType: mimeType },
                });

                // Generate signed URL
                const signature = await generateSignature(filename, secret);
                const signedUrl = `/api/files/${filename}?sig=${signature}`;

                // Update database with new URL
                await db.prepare(`
                    UPDATE patient_images 
                    SET data = ? 
                    WHERE id = ?
                `).bind(signedUrl, img.id).run();

                migrated++;
            } catch (e: any) {
                errors.push(`${img.id}: ${e.message}`);
            }
        }

        return new Response(JSON.stringify({
            message: `Migration complete`,
            migrated,
            remaining: images.length - migrated,
            errors: errors.length > 0 ? errors : undefined
        }), { status: 200 });

    } catch (error: any) {
        console.error('Migration error:', error);
        return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }
};
