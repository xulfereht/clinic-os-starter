import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // Check if super_admin staff exists
        const superAdmin = await db.prepare("SELECT * FROM staff WHERE email = ?").bind('admin@brd.clinic').first();

        if (superAdmin) {
            return new Response(JSON.stringify({
                exists: true,
                staff: {
                    id: superAdmin.id,
                    email: superAdmin.email,
                    name: superAdmin.name,
                    admin_role: superAdmin.admin_role
                }
            }, null, 2), {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            });
        } else {
            return new Response(JSON.stringify({
                exists: false,
                message: 'Super admin staff account not found'
            }, null, 2), {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            });
        }
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
