import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // Get Current Admin Session
        const adminSessionId = request.headers.get('Cookie')?.match(/admin_session=([^;]+)/)?.[1];

        let sessionInfo = {
            sessionId: adminSessionId || 'none',
            sessionFound: false,
            staffId: null,
            staffName: null
        };

        if (adminSessionId) {
            const session = await db.prepare("SELECT * FROM sessions WHERE id = ? AND expires_at > strftime('%s', 'now')").bind(adminSessionId).first();
            if (session) {
                sessionInfo.sessionFound = true;
                sessionInfo.staffId = session.staff_id;

                // Get staff info
                if (session.staff_id) {
                    const staff = await db.prepare("SELECT * FROM staff WHERE id = ?").bind(session.staff_id).first();
                    if (staff) {
                        sessionInfo.staffName = staff.name;
                    }
                }
            }
        }

        return new Response(JSON.stringify(sessionInfo, null, 2), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
