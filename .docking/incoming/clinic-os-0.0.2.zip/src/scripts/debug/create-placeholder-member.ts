import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // Insert a placeholder member for staff sessions
        // This allows us to satisfy the NOT NULL constraint on sessions.member_id
        // without changing the schema (which proved difficult)
        await db.prepare(`
            INSERT OR IGNORE INTO web_members (id, email, password_hash, name, created_at)
            VALUES ('staff_placeholder', 'staff_placeholder@brd.clinic', 'dummy_hash', 'Staff Session Placeholder', strftime('%s', 'now'))
        `).run();

        return new Response(JSON.stringify({
            success: true,
            message: 'Placeholder member created'
        }, null, 2), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
