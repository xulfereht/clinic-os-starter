import type { APIRoute } from 'astro';
import fs from 'fs';
import path from 'path';

export const POST: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const migrationPath = path.join(process.cwd(), 'migrations', '0102_fix_sessions_schema.sql');
        const sql = fs.readFileSync(migrationPath, 'utf-8');
        const statements = sql.split(';').map(s => s.trim()).filter(s => s && !s.startsWith('--'));

        const results = [];

        // Execute statements sequentially
        // Note: D1 might not support PRAGMA via prepare/run in the same way, but we'll try.
        // If PRAGMA fails, we might need to rely on the fact that D1 doesn't enforce FKs strictly during migration unless enabled.

        for (const statement of statements) {
            try {
                await db.prepare(statement).run();
                results.push({ statement: statement.substring(0, 50) + '...', status: 'success' });
            } catch (e: any) {
                results.push({ statement: statement.substring(0, 50) + '...', status: 'error', error: e.message });
                // If DROP TABLE fails, we should stop
                if (statement.toUpperCase().startsWith('DROP TABLE')) {
                    throw new Error(`Failed to drop table: ${e.message}`);
                }
            }
        }

        return new Response(JSON.stringify({
            success: true,
            results
        }, null, 2), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message, stack: e.stack }), { status: 500 });
    }
};
