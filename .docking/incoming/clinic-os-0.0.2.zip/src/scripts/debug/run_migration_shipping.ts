import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response('No DB', { status: 500 });

    try {
        // Drop existing tables to ensure clean schema
        await db.prepare("DROP TABLE IF EXISTS shipments").run();
        await db.prepare("DROP TABLE IF EXISTS shipping_orders").run();

        // Create shipping_orders table (Bucket Model)
        await db.prepare(`
            CREATE TABLE shipping_orders (
                id TEXT PRIMARY KEY,
                patient_id TEXT NOT NULL,
                product_name TEXT,
                total_quantity INTEGER DEFAULT 0,
                remaining_quantity INTEGER DEFAULT 0,
                last_shipped_at INTEGER,
                next_shipping_date INTEGER,
                status TEXT DEFAULT 'active',
                created_at INTEGER DEFAULT (unixepoch()),
                updated_at INTEGER DEFAULT (unixepoch()),
                FOREIGN KEY (patient_id) REFERENCES patients(id)
            );
        `).run();

        // Create shipments table
        await db.prepare(`
            CREATE TABLE shipments (
                id TEXT PRIMARY KEY,
                shipping_order_id TEXT NOT NULL,
                type TEXT DEFAULT 'courier',
                status TEXT DEFAULT 'shipped',
                shipped_at INTEGER DEFAULT (unixepoch()),
                tracking_number TEXT,
                notes TEXT,
                deducted_quantity INTEGER DEFAULT 1,
                created_at INTEGER DEFAULT (unixepoch()),
                FOREIGN KEY (shipping_order_id) REFERENCES shipping_orders(id)
            );
        `).run();

        await db.prepare("CREATE INDEX idx_shipping_orders_patient ON shipping_orders(patient_id)").run();
        await db.prepare("CREATE INDEX idx_shipping_orders_next_date ON shipping_orders(next_shipping_date)").run();

        return new Response('Migration applied: Shipping System (Bucket Model)', { status: 200 });
    } catch (e: any) {
        return new Response('Migration failed: ' + e.message, { status: 500 });
    }
};
