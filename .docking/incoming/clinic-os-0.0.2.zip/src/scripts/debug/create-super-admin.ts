import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        // Insert or update super admin staff
        await db.prepare(`
            INSERT OR REPLACE INTO staff (id, name, email, admin_role, is_active, created_at)
            VALUES ('super_admin', '관리자', 'admin@brd.clinic', 'super_admin', 1, strftime('%s', 'now'))
        `).run();

        // Verify it was created
        const superAdmin = await db.prepare("SELECT * FROM staff WHERE id = 'super_admin'").first();

        return new Response(JSON.stringify({
            success: true,
            staff: superAdmin
        }, null, 2), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
