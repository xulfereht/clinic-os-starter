import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals, cookies }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { email, password } = body;

        // 2. Staff (Admin) Login Check Logic (Copied from admin-login.ts)
        const staff = await db.prepare("SELECT * FROM staff WHERE email = ?").bind(email).first();

        if (!staff) {
            return new Response(JSON.stringify({ success: false, message: "Staff not found" }), { status: 404 });
        }

        if (!staff.password_hash) {
            return new Response(JSON.stringify({ success: false, message: "Password not set" }), { status: 400 });
        }

        const encoder = new TextEncoder();
        const data = encoder.encode(password);
        const inputHashBuffer = await crypto.subtle.digest('SHA-256', data);
        const inputHash = Array.from(new Uint8Array(inputHashBuffer))
            .map(b => b.toString(16).padStart(2, '0'))
            .join('');

        const isValid = inputHash === staff.password_hash;

        if (isValid) {
            // Create Session
            const sessionId = crypto.randomUUID();
            const expiresAt = Math.floor(Date.now() / 1000) + (24 * 60 * 60); // 1 day

            // Try to insert session (This is where the error might happen)
            try {
                // Using the updated query with member_id = NULL
                await db.prepare(`
                    INSERT INTO sessions (id, member_id, staff_id, expires_at)
                    VALUES (?, 'staff_placeholder', ?, ?)
                `).bind(sessionId, staff.id, expiresAt).run();

                return new Response(JSON.stringify({
                    success: true,
                    message: "Login successful",
                    sessionId: sessionId
                }), { status: 200 });

            } catch (dbError: any) {
                return new Response(JSON.stringify({
                    success: false,
                    message: "Database error during session creation: " + dbError.message
                }), { status: 500 });
            }
        } else {
            return new Response(JSON.stringify({ success: false, message: "Invalid password" }), { status: 401 });
        }

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
