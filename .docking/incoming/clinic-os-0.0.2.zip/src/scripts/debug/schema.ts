import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response('DB error', { status: 500 });

    try {
        const { results } = await db.prepare("PRAGMA table_info(staff)").all();
        return new Response(JSON.stringify(results), { headers: { 'Content-Type': 'application/json' } });
    } catch (e: any) {
        return new Response(e.message, { status: 500 });
    }
}
