import type { APIRoute } from 'astro';

export const POST: APIRoute = async ({ request, locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;

    if (!db) {
        return new Response(JSON.stringify({ error: 'Database not available' }), { status: 500 });
    }

    try {
        const body = await request.json();
        const { password } = body;

        if (!password) {
            return new Response(JSON.stringify({ error: 'Password required' }), { status: 400 });
        }

        // Hash the password using SHA-256
        const encoder = new TextEncoder();
        const data = encoder.encode(password);
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        const passwordHash = Array.from(new Uint8Array(hashBuffer))
            .map(b => b.toString(16).padStart(2, '0'))
            .join('');

        // Update super_admin staff with the password hash
        await db.prepare(`
            UPDATE staff 
            SET password_hash = ? 
            WHERE id = 'super_admin'
        `).bind(passwordHash).run();

        return new Response(JSON.stringify({
            success: true,
            message: 'Password set for super_admin',
            hash: passwordHash.substring(0, 16) + '...' // Show partial hash for verification
        }, null, 2), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
