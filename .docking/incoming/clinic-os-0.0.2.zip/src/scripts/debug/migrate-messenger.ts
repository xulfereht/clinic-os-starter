import type { APIRoute } from 'astro';

export const GET: APIRoute = async ({ locals }) => {
    // @ts-ignore
    const db = locals.runtime?.env?.DB;
    if (!db) return new Response('DB not available', { status: 500 });

    try {
        // 1. Migrate Public Messages
        await db.prepare(`
            UPDATE admin_messages 
            SET channel_id = 'global-public-channel' 
            WHERE recipient_id IS NULL AND channel_id IS NULL
        `).run();

        // 2. Fetch remaining messages to migrate (DM/Groups)
        const { results: messages } = await db.prepare(`
            SELECT * FROM admin_messages WHERE channel_id IS NULL
        `).all();

        let migratedCount = 0;

        for (const msg of messages) {
            const senderId = msg.sender_id;
            const recipientStr = msg.recipient_id; // "id1" or "id1,id2"

            if (!recipientStr) continue;

            const recipients = recipientStr.split(',').sort();
            const participants = [...recipients, senderId].sort();
            // Remove duplicates
            const uniqueParticipants = [...new Set(participants)];

            // Determine Channel Type
            const type = uniqueParticipants.length > 2 ? 'group' : 'direct';

            // Channel ID: Deterministic ID based on sorted participants
            // This ensures (A, B) and (B, A) land in the same channel
            const channelId = `ch_${uniqueParticipants.join('_')}`;

            // Create Channel if not exists
            const existingChannel = await db.prepare('SELECT id FROM channels WHERE id = ?').bind(channelId).first();

            if (!existingChannel) {
                // Create Channel
                await db.prepare(`
                    INSERT INTO channels (id, type, name, created_at, last_message_at)
                    VALUES (?, ?, ?, ?, ?)
                `).bind(
                    channelId,
                    type,
                    type === 'group' ? '그룹 대화' : null,
                    Math.floor(Date.now() / 1000),
                    Math.floor(Date.now() / 1000)
                ).run();

                // Add Members
                for (const uid of uniqueParticipants) {
                    await db.prepare(`
                        INSERT OR IGNORE INTO channel_members (channel_id, user_id, joined_at)
                        VALUES (?, ?, ?)
                    `).bind(channelId, uid, Math.floor(Date.now() / 1000)).run();
                }
            }

            // Update Message
            await db.prepare('UPDATE admin_messages SET channel_id = ? WHERE id = ?').bind(channelId, msg.id).run();
            migratedCount++;
        }

        return new Response(JSON.stringify({
            success: true,
            publicMigrated: 'Done via SQL',
            dmMigrated: migratedCount
        }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (e: any) {
        return new Response(JSON.stringify({ error: e.message }), { status: 500 });
    }
};
