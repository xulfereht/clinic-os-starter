import React, { useEffect, useRef } from 'react';
import flatpickr from 'flatpickr';
import { Korean } from 'flatpickr/dist/l10n/ko.js';
import 'flatpickr/dist/flatpickr.css';

interface DatePickerProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'value' | 'onChange' | 'min' | 'max'> {
    value?: Date | string | number | Date[];
    onChange?: (dates: Date[], dateStr: string, instance: flatpickr.Instance) => void;
    options?: flatpickr.Options.Options;
}

// Add global type
declare global {
    interface Window {
        setFlatpickrDate?: (id: string, date: any) => void;
    }
}

export const DatePicker: React.FC<DatePickerProps> = ({
    value,
    onChange,
    options,
    className = '',
    placeholder = '날짜 선택',
    disabled = false,
    min, // Extract to prevent hydration warning
    max, // Extract to prevent hydration warning
    ...props
}) => {
    const inputRef = useRef<HTMLInputElement>(null);
    const fpRef = useRef<flatpickr.Instance | null>(null);

    // Register global helper once
    useEffect(() => {
        if (!window.setFlatpickrDate) {
            window.setFlatpickrDate = (id, date) => {
                const el = document.getElementById(id) as any;
                if (el && el._flatpickr) {
                    el._flatpickr.setDate(date);
                }
            };
        }
    }, []);

    useEffect(() => {
        if (!inputRef.current) return;
        // ... rest of initialization


        const fp = flatpickr(inputRef.current, {
            locale: Korean,
            defaultDate: value,
            onChange: (dates, str, instance) => {
                if (onChange) onChange(dates, str, instance);
                // Dispatch native event for vanilla scripts listeners
                if (inputRef.current) {
                    inputRef.current.dispatchEvent(new Event('change', { bubbles: true }));
                    inputRef.current.dispatchEvent(new Event('input', { bubbles: true }));
                }
            },
            ...options,
        });

        fpRef.current = fp;

        return () => {
            fp.destroy();
        };
    }, []); // Initialize once

    useEffect(() => {
        if (fpRef.current && value !== undefined) {
            fpRef.current.setDate(value, false);
        }
    }, [value]);

    useEffect(() => {
        if (fpRef.current && options) {
            Object.entries(options).forEach(([key, val]) => {
                fpRef.current?.set(key as keyof flatpickr.Options.Options, val);
            });
        }
    }, [options]);

    return (
        <input
            ref={inputRef}
            className={`border border-gray-300 rounded px-3 py-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 ${className}`}
            placeholder={placeholder}
            disabled={disabled}
            suppressHydrationWarning={true}
            {...props}
        />
    );
};
