import React, { useEffect, useRef } from 'react';
import { MoveRight } from 'lucide-react';

interface SnowyMountainHeroProps {
    badge: string;
    title: string;
    description: string;
    primaryCta: {
        text: string;
        link: string;
    };
    secondaryCta?: {
        text: string;
        link: string;
    };
}

/**
 * 정적인 수묵화의 정취를 담은 설산 히어로 컴포넌트
 * 눈의 속도를 조절하여 더 고요하고 자연스러운 분위기를 연출했습니다.
 */
export default function SnowyMountainHero({
    badge,
    title,
    description,
    primaryCta,
    secondaryCta
}: SnowyMountainHeroProps) {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const particles = useRef<any[]>([]);
    const mountains = useRef<any[]>([]);
    const mouse = useRef({ x: -1000, y: -1000, active: false, targetX: 0, targetY: 0 });
    const rafId = useRef<number | null>(null);

    // Force Noto Serif for this component
    const fontStyle = { fontFamily: '"Noto Serif KR", "Batang", serif' };

    const SETTINGS = {
        particleCount: 140,
        mountainCount: 4,
        minRadius: 1.5,
        maxRadius: 3.5, // 너무 큰 눈송이 제외 (5.0 -> 3.5)
        minSpeedY: 0.2,
        maxSpeedY: 0.6,
        cursorRadius: 160,
        cursorForce: 0.03,
        snowColors: [
            'rgba(203, 213, 225, 0.8)', // Slate-300 (그림자)
            'rgba(148, 163, 184, 0.6)', // Slate-400 (진한 명암)
            'rgba(241, 245, 249, 0.9)', // Slate-100 (하이라이트)
            'rgba(191, 219, 254, 0.5)'  // Blue-200 (청량한 틴트)
        ],
    };

    useEffect(() => {
        const canvas = canvasRef.current;
        const container = containerRef.current;
        if (!canvas || !container) return;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let width = 0;
        let height = 0;
        let isMobile = false;

        let prevWidth = 0;
        let prevHeight = 0;

        // Visibility Check for Performance
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    if (!rafId.current) {
                        mouse.current.active = false;
                        animate(0);
                    }
                } else {
                    if (rafId.current) {
                        cancelAnimationFrame(rafId.current);
                        rafId.current = null;
                    }
                }
            });
        }, { threshold: 0 });

        observer.observe(container);

        const resize = () => {
            const rect = container.getBoundingClientRect();
            const newWidth = rect.width;
            const newHeight = rect.height;

            // Optimization: Ignore small height changes (like mobile address bar toggle) to prevent canvas reset/flicker
            // Only resize if width changes or height changes significantly
            if (Math.abs(newWidth - prevWidth) < 1 && Math.abs(newHeight - prevHeight) < 80) {
                return;
            }

            width = newWidth;
            height = newHeight;
            isMobile = width < 768;
            prevWidth = width;
            prevHeight = height;

            // Optimization: Clamp DPR to max 2 for performance on high-res screens
            const dpr = Math.min(window.devicePixelRatio || 1, 2);
            canvas.width = width * dpr;
            canvas.height = height * dpr;
            ctx.scale(dpr, dpr);

            createMountains();
            createParticles();
        };

        const createMountains = () => {
            mountains.current = Array.from({ length: SETTINGS.mountainCount }, (_, i) => {
                const points = [];
                const segments = 16;
                const segmentWidth = width / segments;

                // Mobile: Adjust base height (higher up -> smaller val)
                // Desktop: Keep original
                const mobileOffset = isMobile ? -0.15 : 0;

                // 뒤로 갈수록 높고 완만한 능선
                const baseHeight = height * ((0.38 + mobileOffset) + i * 0.1);
                const variance = height * (0.08 + (SETTINGS.mountainCount - i) * 0.04);

                const colors = [
                    '#cbd5e1', // 전경
                    '#e2e8f0',
                    '#f1f5f9',
                    '#f8fafc'  // 원경
                ];

                for (let s = 0; s <= segments; s++) {
                    points.push({
                        x: s * segmentWidth,
                        y: baseHeight + (Math.random() - 0.5) * variance
                    });
                }

                return {
                    points,
                    color: colors[i] || '#f8fafc',
                    parallaxFactor: 0.012 * (i + 1),
                    opacity: 1 - (i * 0.18)
                };
            });
        };

        const createParticles = () => {
            particles.current = Array.from({ length: SETTINGS.particleCount }, () => ({
                x: Math.random() * width,
                y: Math.random() * height,
                vx: (Math.random() - 0.5) * 0.05, // 바람 줄임 (0.15 -> 0.05)
                vy: Math.random() * (0.4 - 0.1) + 0.1, // 천천히 내리도록 속도 저하
                radius: Math.random() * (SETTINGS.maxRadius - SETTINGS.minRadius) + SETTINGS.minRadius,
                color: SETTINGS.snowColors[Math.floor(Math.random() * SETTINGS.snowColors.length)],
                phase: Math.random() * Math.PI * 2,
                // 수묵화 느낌: 크기에 비례한 부드러운 블러 (번짐 효과)
                blur: Math.random() * 2 + 1
            }));
        };

        const drawMountain = (m: any) => {
            // 모바일에서는 패럴랙스 효과 제거 (스크롤 덜컹거림 방지)
            const offsetX = isMobile ? 0 : (mouse.current.targetX - width / 2) * m.parallaxFactor;

            ctx.save();
            ctx.beginPath();
            ctx.moveTo(-100, height);

            ctx.lineTo(m.points[0].x + offsetX, m.points[0].y);
            for (let i = 0; i < m.points.length - 1; i++) {
                const xc = (m.points[i].x + m.points[i + 1].x) / 2 + offsetX;
                const yc = (m.points[i].y + m.points[i + 1].y) / 2;
                ctx.quadraticCurveTo(m.points[i].x + offsetX, m.points[i].y, xc, yc);
            }

            ctx.lineTo(width + 100, height);
            ctx.closePath();

            // 선염법 그라데이션
            const grad = ctx.createLinearGradient(0, height * 0.3, 0, height);
            grad.addColorStop(0, m.color);
            grad.addColorStop(0.75, '#ffffff');

            ctx.fillStyle = grad;
            ctx.globalAlpha = m.opacity;
            ctx.fill();
            ctx.restore();
        };

        const animate = (time: number) => {
            // Safety check if cleaned up
            if (!container) return;

            ctx.clearRect(0, 0, width, height);

            // 산 그리기 (원경 -> 전경)
            for (let i = SETTINGS.mountainCount - 1; i >= 1; i--) {
                drawMountain(mountains.current[i]);
            }

            // 수평 바람 세기 조절 (거의 없앰)
            const globalWind = Math.sin(time * 0.0003) * 0.01;

            particles.current.forEach((p) => {
                // ... (Interaction logic remains same)
                if (mouse.current.active) {
                    const dx = p.x - mouse.current.x;
                    const dy = p.y - mouse.current.y;
                    const dist = Math.sqrt(dx * dx + dy * dy);

                    if (dist < SETTINGS.cursorRadius) {
                        const force = (SETTINGS.cursorRadius - dist) / SETTINGS.cursorRadius;
                        const angle = Math.atan2(dy, dx);
                        p.vx += Math.cos(angle) * force * SETTINGS.cursorForce * 5;
                        p.vy += Math.sin(angle) * force * SETTINGS.cursorForce * 5;
                    }
                }

                const localWobble = Math.sin(p.phase + time * 0.0008) * 0.008;

                p.vx += globalWind + localWobble;
                p.vx *= 0.98;

                if (p.vy < 0.1) p.vy += 0.005; // minSpeedY 하드코딩 대응
                p.vy *= 0.995;

                p.x += p.vx;
                p.y += p.vy;

                if (p.y > height + 10) {
                    p.y = -10;
                    p.x = Math.random() * width;
                    p.vx = (Math.random() - 0.5) * 0.05;
                }
                if (p.x < -10) p.x = width + 10;
                if (p.x > width + 10) p.x = -10;

                ctx.save();
                ctx.beginPath();
                ctx.fillStyle = p.color;
                if (p.blur > 0.5) {
                    ctx.shadowBlur = p.blur;
                    ctx.shadowColor = p.color;
                }

                // Cluster Drawing: Draw 3 slight offsets to make irregular blob
                ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                ctx.arc(p.x + p.radius * 0.4, p.y + p.radius * 0.3, p.radius * 0.7, 0, Math.PI * 2);
                ctx.arc(p.x - p.radius * 0.3, p.y + p.radius * 0.5, p.radius * 0.6, 0, Math.PI * 2);

                ctx.fill();
                ctx.restore();
            });

            if (mountains.current[0]) {
                drawMountain(mountains.current[0]);
            }

            mouse.current.targetX += (mouse.current.x - mouse.current.targetX) * 0.03;
            rafId.current = requestAnimationFrame(animate);
        };

        const handlePointerMove = (e: PointerEvent) => {
            const rect = canvas.getBoundingClientRect();
            mouse.current.x = e.clientX - rect.left;
            mouse.current.y = e.clientY - rect.top;
            mouse.current.active = true;
        };

        const handlePointerLeave = () => {
            mouse.current.active = false;
        };

        resize();
        // Initial start handled by observer

        window.addEventListener('resize', resize);
        container.addEventListener('pointermove', handlePointerMove);
        container.addEventListener('pointerleave', handlePointerLeave);

        return () => {
            observer.disconnect();
            if (rafId.current) cancelAnimationFrame(rafId.current);
            window.removeEventListener('resize', resize);
            if (container) {
                container.removeEventListener('pointermove', handlePointerMove);
                container.removeEventListener('pointerleave', handlePointerLeave);
            }
        };
    }, []);



    // Update settings or keep as is...
    // ...

    return (
        <div
            ref={containerRef}
            className="relative w-full min-h-screen overflow-hidden bg-white flex items-center justify-center py-20" // Changed h-[95vh] to min-h-screen and added py-20
            style={fontStyle}
        >
            {/* ... texture ... */}
            <div className="absolute inset-0 z-0 opacity-[0.04] pointer-events-none"
                style={{ backgroundImage: `url('https://www.transparenttextures.com/patterns/natural-paper.png')` }}></div>

            <canvas
                ref={canvasRef}
                className="absolute inset-0 z-10 block pointer-events-none"
            />

            {/* Hero Content */}
            <div className="relative z-40 text-center px-6 pointer-events-auto select-none max-w-5xl mx-auto flex flex-col items-center justify-center h-full">
                {/* Badge / Subtitle */}
                <div className="mb-8 md:mb-12 flex flex-col items-center">
                    <div className="w-[1px] h-12 md:h-20 bg-gradient-to-b from-transparent via-slate-300 to-transparent mb-6 md:mb-8"></div>
                    <span className="text-[10px] tracking-[0.5em] md:tracking-[0.7em] text-slate-400 font-bold uppercase ml-[0.5em]" style={fontStyle}>
                        {badge}
                    </span>
                </div>

                {/* Main Heading */}
                {/* Main Heading */}
                <h1 className="text-5xl md:text-8xl lg:text-9xl text-slate-900 leading-tight mb-10 md:mb-14 tracking-tighter break-keep" style={{ ...fontStyle, fontWeight: 400 }}>
                    <span dangerouslySetInnerHTML={{ __html: title.replace(/\n/g, '<br/>') }} />
                </h1>

                {/* Description */}
                <p className="text-sm md:text-lg lg:text-xl text-slate-500 leading-loose mb-12 md:mb-16 max-w-2xl mx-auto break-keep font-light" style={fontStyle}>
                    <span dangerouslySetInnerHTML={{ __html: description.replace(/\n/g, '<br/>') }} />
                </p>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-6 md:gap-10 w-full px-4">
                    <a href={primaryCta.link} className="group relative w-full sm:w-auto px-10 md:px-14 py-4 md:py-5 bg-slate-900 text-white rounded-full transition-all hover:bg-black flex items-center justify-center gap-4 shadow-xl hover:shadow-2xl">
                        <span className="font-bold tracking-widest text-base">{primaryCta.text}</span>
                        <MoveRight className="w-5 h-5 transition-transform group-hover:translate-x-2" />
                    </a>
                </div>
            </div>

            {/* ... stamp ... */}
            <div className="absolute bottom-10 right-10 opacity-20 pointer-events-none hidden lg:block">
                {/* ... */}
            </div>

            {/* ... side text ... */}

            {/* Smooth transition to next section */}
            <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-white via-white/80 to-transparent pointer-events-none z-30"></div>
        </div>
    );
};
