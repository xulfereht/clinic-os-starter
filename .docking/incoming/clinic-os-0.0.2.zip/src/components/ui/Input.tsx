import React, { forwardRef } from "react";

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
    label?: string;
    error?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
    ({ className = "", label, error, ...props }, ref) => {
        return (
            <div className="w-full">
                {label && (
                    <label className="block text-sm font-medium text-[color:var(--text-muted)] mb-2">
                        {label}
                    </label>
                )}
                <input
                    ref={ref}
                    className={`w-full p-3 border border-[color:var(--border-subtle)] bg-[color:var(--bg-surface)] text-[color:var(--text-main)] rounded-lg focus:outline-none focus:border-[color:var(--accent)] transition-colors disabled:opacity-50 ${className}`}
                    {...props}
                />
                {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
            </div>
        );
    }
);

Input.displayName = "Input";
