import React, { forwardRef } from "react";

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
    label?: string;
    error?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
    ({ className = "", label, error, ...props }, ref) => {
        return (
            <div className="w-full">
                {label && (
                    <label className="block text-sm font-medium text-[color:var(--text-muted)] mb-2">
                        {label}
                    </label>
                )}
                <textarea
                    ref={ref}
                    className={`w-full p-3 border border-[color:var(--border-subtle)] bg-[color:var(--bg-surface)] text-[color:var(--text-main)] rounded-lg focus:outline-none focus:border-[color:var(--accent)] transition-colors disabled:opacity-50 min-h-[100px] ${className}`}
                    {...props}
                />
                {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
            </div>
        );
    }
);

Textarea.displayName = "Textarea";
