import { useState, useEffect, useRef } from 'react';
import type { Operator, Condition } from '../../../lib/segment-engine';
import { DatePicker } from '../../ui/DatePicker';
import ConfirmModal from '../../ui/ConfirmModal';

declare global {
    interface Window {
        notify: (message: string, type?: 'success' | 'error' | 'info' | 'warning', options?: any) => void;
    }
}

interface UICondition extends Condition {
    id: string;
}

const FIELDS = [
    // [기본 정보]
    { category: '기본 정보', value: 'name', label: '이름', type: 'string' },
    { category: '기본 정보', value: 'phone', label: '전화번호', type: 'string' },
    { category: '기본 정보', value: 'birth_date', label: '생년월일', type: 'date' },
    {
        category: '기본 정보', value: 'gender', label: '성별', type: 'select', options: [
            { value: 'M', label: '남성' },
            { value: 'F', label: '여성' }
        ]
    },
    { category: '기본 정보', value: 'address', label: '주소', type: 'string' },
    { category: '기본 정보', value: 'created_at', label: '등록일', type: 'date' },

    // [방문/진료]
    {
        category: '방문/진료', value: 'status', label: '상태', type: 'select', options: [
            { value: 'active', label: '활성 (기존환자)' },
            { value: 'visit_first_visit', label: '초진 접수 (내원)' },
            { value: 'remote_first_visit', label: '초진 접수 (비대면)' }
        ]
    },
    { category: '방문/진료', value: 'last_visit_date', label: '최근 방문일', type: 'date' },
    { category: '방문/진료', value: 'visit_count', label: '방문 횟수', type: 'number' },
    {
        category: '방문/진료', value: 'first_source', label: '유입 경로', type: 'select', options: [
            { value: '지인/가족 소개', label: '지인/가족 소개' },
            { value: '네이버 검색', label: '네이버 검색' },
            { value: '블로그/카페 글', label: '블로그/카페 글' },
            { value: '인스타그램/페이스북', label: 'SNS (인스타/페북)' },
            { value: '유튜브', label: '유튜브' },
            { value: '지나가다/간판 보고', label: '간판' },
            { value: '타 병원 소개', label: '타 병원 소개' },
            { value: '기타', label: '기타' }
        ]
    },
    { category: '방문/진료', value: 'legacy_medical_history', label: '과거 진료 이력', type: 'string' },

    // [매출/결제]
    { category: '매출/결제', value: 'total_payment', label: '총 결제금액', type: 'number' },
    { category: '매출/결제', value: 'payment_count', label: '결제 횟수', type: 'number' },
    { category: '매출/결제', value: 'average_transaction', label: '평균 결제액 (객단가)', type: 'number' },

    // [활동/기타]
    { category: '활동/기타', value: 'tags', label: '태그 (세그먼트)', type: 'string' },
    { category: '활동/기타', value: 'referral_count', label: '지인 추천 수', type: 'number' },
    { category: '활동/기타', value: 'last_shipping_date', label: '마지막 배송일', type: 'date' },
    { category: '활동/기타', value: 'sms_consent', label: '마케팅 수신동의 (SMS)', type: 'boolean' },
    { category: '활동/기타', value: 'email_consent', label: '마케팅 수신동의 (이메일)', type: 'boolean' },

    // [예약 (Reservation)]
    { category: '예약 (Reservation)', value: 'reservation_date', label: '예약일', type: 'date' },
];

const OPERATORS = {
    string: [
        { value: 'contains', label: '포함' },
        { value: 'equals', label: '일치' },
        { value: 'starts_with', label: '시작' }
    ],
    number: [
        { value: 'gt', label: '>' },
        { value: 'lt', label: '<' },
        { value: 'gte', label: '>=' },
        { value: 'lte', label: '<=' },
        { value: 'equals', label: '=' },
        { value: 'between', label: '범위' }
    ],
    date: [
        { value: 'relative_date', label: '상대 날짜 (예: +1 내일)' },
        { value: 'gte', label: '이후 (특정 날짜)' },
        { value: 'lte', label: '이전 (특정 날짜)' },
        { value: 'between', label: '기간 (특정 기간)' },
        { value: 'older_than_days', label: 'N일 이상 경과 (과거)' },
        { value: 'within_days', label: 'N일 이내 (최근)' }
    ],
    select: [
        { value: 'equals', label: '일치' },
        { value: 'in', label: '포함 (다중)' }
    ],
    boolean: [
        { value: 'is_true', label: '참 (True)' },
        { value: 'is_false', label: '거짓 (False)' }
    ]
};

interface Patient {
    id: string;
    chart_number?: string;
    name: string;
    current_phone: string;
    status: string;
    last_visit_date: string;
    total_payment: number;
    payment_count?: number;
    visit_count: number;
    last_activity_at?: number;
    computed_status?: string;
}

// Custom Field Selector Component with Categories & Search
const FieldSelector = ({ value, onChange }: { value: string, onChange: (val: string) => void }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const wrapperRef = useRef<HTMLDivElement>(null);

    // Close on click outside
    useEffect(() => {
        function handleClickOutside(event: any) {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const selectedField = FIELDS.find(f => f.value === value);

    // Group fields by category
    const filteredFields = FIELDS.filter(f =>
        f.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
        f.value.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const groupedFields: Record<string, typeof FIELDS> = {};
    filteredFields.forEach(f => {
        if (!groupedFields[f.category]) groupedFields[f.category] = [];
        groupedFields[f.category].push(f);
    });

    const categories = Object.keys(groupedFields);

    return (
        <div className="relative w-[220px]" ref={wrapperRef}>
            <button
                type="button"
                onClick={() => setIsOpen(!isOpen)}
                className="w-full text-left px-3 py-2 rounded border border-slate-300 text-sm font-bold bg-white hover:border-blue-500 focus:border-blue-500 outline-none flex justify-between items-center"
            >
                <span className="truncate">{selectedField?.label || '필드 선택'}</span>
                <svg className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
            </button>

            {isOpen && (
                <div className="absolute z-50 top-full left-0 w-[240px] mt-1 bg-white rounded-lg shadow-xl border border-slate-200 max-h-[400px] overflow-hidden flex flex-col">
                    <div className="p-2 border-b border-slate-100 bg-slate-50 sticky top-0">
                        <input
                            type="text"
                            placeholder="필터 검색..."
                            className="w-full px-2 py-1.5 text-sm border border-slate-200 rounded focus:outline-none focus:border-blue-500"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            autoFocus
                        />
                    </div>
                    <div className="overflow-y-auto flex-1 custom-scrollbar">
                        {categories.length === 0 ? (
                            <div className="p-3 text-center text-sm text-slate-400">검색 결과가 없습니다.</div>
                        ) : (
                            categories.map(cat => (
                                <div key={cat} className="border-b border-slate-50 last:border-0">
                                    <div className="px-3 py-1.5 bg-slate-50/50 text-xs font-bold text-slate-500">{cat}</div>
                                    <div>
                                        {groupedFields[cat].map(field => (
                                            <button
                                                key={field.value}
                                                type="button"
                                                onClick={() => {
                                                    onChange(field.value);
                                                    setIsOpen(false);
                                                    setSearchTerm('');
                                                }}
                                                className={`w-full text-left px-4 py-2 text-sm hover:bg-blue-50 transition-colors ${field.value === value ? 'bg-blue-50 text-blue-700 font-bold' : 'text-slate-700'}`}
                                            >
                                                {field.label}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};

export default function FilterBuilder() {
    const [conditions, setConditions] = useState<UICondition[]>([]);
    const [conditionOperator, setConditionOperator] = useState<'AND' | 'OR'>('AND');
    const [patients, setPatients] = useState<Patient[]>([]);
    const [totalCount, setTotalCount] = useState<number>(0);
    const [isSearching, setIsSearching] = useState(false);
    const [segmentName, setSegmentName] = useState('');
    const [isSaving, setIsSaving] = useState(false);
    const [isExporting, setIsExporting] = useState(false);
    const [savedSegments, setSavedSegments] = useState<any[]>([]);
    const [activeSegmentId, setActiveSegmentId] = useState<string | null>(null);
    const [hasMore, setHasMore] = useState<boolean>(false);
    const [currentOffset, setCurrentOffset] = useState<number>(0);

    const [currentInput, setCurrentInput] = useState<{ field: string; operator: Operator; value: any }>({
        field: 'name',
        operator: 'contains',
        value: ''
    });
    const [editingId, setEditingId] = useState<string | null>(null);

    // AI Builder State
    const [aiQuery, setAiQuery] = useState('');
    const [isAiLoading, setIsAiLoading] = useState(false);

    // Modal State
    const [confirmModal, setConfirmModal] = useState<{
        isOpen: boolean;
        title: string;
        message: string;
        onConfirm: () => void;
        variant?: 'danger' | 'warning' | 'info';
    }>({
        isOpen: false,
        title: '',
        message: '',
        onConfirm: () => { },
        variant: 'danger'
    });

    const handleAiBuild = async () => {
        if (!aiQuery.trim()) return;
        setIsAiLoading(true);
        try {
            const res = await fetch('/api/admin/ai/segment-builder', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query: aiQuery })
            });
            const data = await res.json();

            if (res.ok && data.success) {
                // Merge or Replace? Let's Replace for now as it's "Build with AI"
                if (data.criteria) {
                    setConditionOperator(data.criteria.operator || 'AND');
                    setConditions(data.criteria.conditions.map((c: any) => ({ ...c, id: Math.random().toString() })));
                    window.notify(data.message || '조건이 생성되었습니다.', 'success');

                    // Trigger search automatically?
                    setTimeout(() => {
                        document.getElementById('segment-search-btn')?.click();
                    }, 500);
                }
            } else {
                window.notify(data.message || 'AI가 조건을 생성하지 못했습니다.', 'warning');
            }
        } catch (e) {
            console.error(e);
            window.notify('AI 호출 중 오류가 발생했습니다.', 'error');
        } finally {
            setIsAiLoading(false);
        }
    };

    // ... (Rest of handlers) ...

    useEffect(() => {
        loadSavedSegments();
        checkAiAvailability();

        // Listen for segment selection from StatsCardSection
        const handleLoadSegment = (e: CustomEvent) => {
            // ... existing handler ...
            const segment = e.detail;
            if (segment && segment.criteria) {
                try {
                    const parsed = JSON.parse(segment.criteria);
                    setConditionOperator(parsed.operator || 'AND');
                    setConditions(parsed.conditions.map((c: any) => ({ ...c, id: Math.random().toString() })));
                    setSegmentName(segment.name);
                    setActiveSegmentId(segment.id);
                    // Auto-search after loading
                    setTimeout(() => {
                        document.getElementById('segment-search-btn')?.click();
                    }, 100);
                } catch (err) {
                    console.error('Failed to parse segment criteria:', err);
                }
            }
        };

        window.addEventListener('loadSegment', handleLoadSegment as EventListener);
        return () => window.removeEventListener('loadSegment', handleLoadSegment as EventListener);
    }, []);

    const [aiAvailable, setAiAvailable] = useState(true); // Default true to avoid flash
    const checkAiAvailability = async () => {
        try {
            const res = await fetch('/api/admin/ai/status?feature=segment_builder');
            const data = await res.json();
            setAiAvailable(!!data.available);
        } catch (e) {
            console.error('Failed to check AI status', e);
        }
    };

    const loadSavedSegments = async () => {
        try {
            const res = await fetch('/api/admin/segments');
            if (res.ok) {
                const data = await res.json();
                setSavedSegments(data);
            }
        } catch (e) {
            console.error(e);
        }
    };

    const addOrUpdateCondition = () => {
        if (!currentInput.value) {
            window.notify('값을 입력해주세요.', 'warning');
            return;
        }

        if (editingId) {
            // Update existing condition
            setConditions(conditions.map(c =>
                c.id === editingId ? { ...currentInput, id: editingId } : c
            ));
            setEditingId(null);
        } else {
            // Add new condition
            setConditions([...conditions, { ...currentInput, id: Math.random().toString() }]);
        }

        // Reset input form
        setCurrentInput({ field: 'name', operator: 'contains', value: '' });
    };

    const editCondition = (cond: UICondition) => {
        setCurrentInput({ field: cond.field, operator: cond.operator, value: cond.value });
        setEditingId(cond.id);
    };

    const cancelEdit = () => {
        setEditingId(null);
        setCurrentInput({ field: 'name', operator: 'contains', value: '' });
    };

    const deleteCondition = (id: string) => {
        setConfirmModal({
            isOpen: true,
            title: '조건 삭제',
            message: '이 조건을 삭제하시겠습니까?',
            variant: 'danger',
            onConfirm: () => {
                setConditions(prev => {
                    const next = prev.filter(c => c.id !== id);
                    return next;
                });
                if (editingId === id) {
                    cancelEdit();
                }
            }
        });
    };

    const updateCurrentInputField = (field: string) => {
        const fieldConfig = FIELDS.find(f => f.value === field);
        const newOperator = OPERATORS[(fieldConfig?.type || 'string') as keyof typeof OPERATORS][0].value as Operator;
        setCurrentInput({ field, operator: newOperator, value: '' });
    };

    const handleSearch = async (reset: boolean = true) => {
        // Allow empty search to show everyone or validation?
        // Usually filtering requires at least one condition, but let's allow it if we want 'All'
        // But UI says '필터 조건을 추가해주세요'
        if (conditions.length === 0) {
            window.notify('필터 조건을 추가해주세요.', 'warning');
            return;
        }
        setIsSearching(true);
        const offset = reset ? 0 : currentOffset;
        try {
            const criteria = {
                operator: conditionOperator,
                conditions: conditions.map(({ id, ...rest }) => rest)
            };

            const res = await fetch('/api/admin/segments/preview', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ criteria, limit: 20, offset })
            });

            if (res.ok) {
                const data = await res.json();
                if (reset) {
                    setPatients(data.patients || []);
                } else {
                    setPatients(prev => [...prev, ...(data.patients || [])]);
                }
                setTotalCount(data.count || 0);
                setHasMore(data.hasMore || false);
                setCurrentOffset(data.nextOffset || 0);
            } else {
                window.notify('검색 실패', 'error');
            }
        } catch (e) {
            console.error(e);
            window.notify('검색 중 오류 발생', 'error');
        } finally {
            setIsSearching(false);
        }
    };

    const loadMore = () => {
        handleSearch(false);
    };

    const handleExport = async (format: 'csv' | 'excel') => {
        if (conditions.length === 0) {
            window.notify('필터 조건을 추가해주세요.', 'warning');
            return;
        }
        setIsExporting(true);
        try {
            const criteria = {
                operator: conditionOperator,
                conditions: conditions.map(({ id, ...rest }) => rest)
            };

            const res = await fetch('/api/admin/segments/preview', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ criteria, export: format })
            });

            if (res.ok) {
                const blob = await res.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `segment_export_${Date.now()}.${format === 'excel' ? 'xls' : 'csv'}`;
                document.body.appendChild(a);
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
            } else {
                window.notify('내보내기 실패', 'error');
            }
        } catch (e) {
            console.error(e);
            window.notify('내보내기 중 오류 발생', 'error');
        } finally {
            setIsExporting(false);
        }
    };

    const handleSave = async () => {
        if (!segmentName) return window.notify('세그먼트 이름을 입력하세요', 'warning');
        setIsSaving(true);
        try {
            const criteria = {
                operator: 'AND',
                conditions: conditions.map(({ id, ...rest }) => rest)
            };

            let res;
            if (activeSegmentId) {
                // Update existing segment
                res = await fetch(`/api/admin/segments/${activeSegmentId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: segmentName, criteria })
                });
            } else {
                // Create new segment
                res = await fetch('/api/admin/segments', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: segmentName, criteria })
                });
            }

            if (res.ok) {
                window.notify(activeSegmentId ? '수정되었습니다.' : '저장되었습니다.', 'success');
                setSegmentName('');
                setConditions([]);
                setActiveSegmentId(null);
                loadSavedSegments();
            } else {
                window.notify('저장 실패', 'error');
            }
        } finally {
            setIsSaving(false);
        }
    };

    const handleDeleteSegment = async (segmentId: string) => {
        setConfirmModal({
            isOpen: true,
            title: '세그먼트 삭제',
            message: '이 세그먼트를 삭제하시겠습니까?',
            variant: 'danger',
            onConfirm: async () => {
                try {
                    const res = await fetch(`/api/admin/segments/${segmentId}`, {
                        method: 'DELETE'
                    });

                    if (res.ok) {
                        loadSavedSegments();
                        window.notify('삭제되었습니다.', 'success');
                    } else {
                        window.notify('삭제에 실패했습니다.', 'error');
                    }
                } catch (e) {
                    console.error('Delete segment error:', e);
                    window.notify('오류가 발생했습니다.', 'error');
                }
            }
        });
    };

    // Helper to close modal
    const closeConfirmModal = () => {
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
    };

    return (
        <div className="space-y-6">
            {/* Builder */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-900">🔍 조건 입력</h3>
                    {editingId && (
                        <span className="text-xs text-orange-600 font-bold bg-orange-50 px-2 py-1 rounded">수정 중</span>
                    )}
                </div>

                {/* AI Builder Input */}
                <div className={`mb-6 p-4 rounded-lg border ${aiAvailable ? 'bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-100' : 'bg-slate-50 border-slate-200'}`}>
                    <div className="flex justify-between items-center mb-2">
                        <label className={`block text-xs font-bold ${aiAvailable ? 'text-indigo-800' : 'text-slate-400'}`}>✨ AI로 조건 만들기 (Beta)</label>
                        {!aiAvailable && (
                            <a href="/admin/settings/ai" className="text-xs text-blue-600 hover:underline font-medium">
                                ⚠️ AI 설정 바로가기
                            </a>
                        )}
                    </div>

                    <div className="flex gap-2 relative">
                        {!aiAvailable && (
                            <div className="absolute inset-0 bg-slate-50/50 z-10 flex items-center justify-center backdrop-blur-[1px] rounded-lg border border-slate-200 border-dashed">
                                <span className="text-sm text-slate-500 font-medium">AI 서비스가 활성화되지 않았습니다.</span>
                            </div>
                        )}
                        <input
                            type="text"
                            value={aiQuery}
                            onChange={(e) => setAiQuery(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleAiBuild()}
                            disabled={!aiAvailable}
                            placeholder="예: 내일 예약 있는 남자 환자, VIP 환자..."
                            className="flex-1 px-4 py-2 border border-indigo-200 rounded-lg text-sm focus:outline-none focus:border-indigo-500 shadow-sm disabled:bg-slate-100 disabled:border-slate-200"
                        />
                        <button
                            onClick={handleAiBuild}
                            disabled={isAiLoading || !aiQuery.trim() || !aiAvailable}
                            className="px-4 py-2 bg-indigo-600 text-white text-sm font-bold rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:bg-slate-400 flex items-center gap-1"
                        >
                            {isAiLoading ? '생성 중...' : '🪄 생성'}
                        </button>
                    </div>
                    {aiAvailable && (
                        <p className="text-[10px] text-indigo-400 mt-1.5 ml-1">
                            * 자연어로 입력하면 자동으로 필터가 생성됩니다. (아직 학습 중이에요!)
                        </p>
                    )}
                </div>

                {/* Single Input Form */}
                <div className="flex flex-wrap items-center gap-2 p-4 bg-slate-50 rounded-lg border border-slate-200 mb-4">
                    {(() => {
                        const fieldConfig = FIELDS.find(f => f.value === currentInput.field);
                        const fieldType = fieldConfig?.type || 'string';
                        const wOperators = OPERATORS[fieldType as keyof typeof OPERATORS];

                        return (
                            <>
                                {/* Field Select (Replaced with Custom Selector) */}
                                <FieldSelector
                                    value={currentInput.field}
                                    onChange={(val) => updateCurrentInputField(val)}
                                />

                                {/* Operator Select */}
                                <select
                                    value={currentInput.operator}
                                    onChange={(e) => setCurrentInput({ ...currentInput, operator: e.target.value as Operator })}
                                    className="px-3 py-2 rounded border border-slate-300 text-sm bg-white focus:border-blue-500 outline-none"
                                >
                                    {wOperators.map(op => <option key={op.value} value={op.value}>{op.label}</option>)}
                                </select>

                                {/* Value Input */}
                                <div className="flex-1 min-w-[200px]">
                                    {['is_true', 'is_false'].includes(currentInput.operator) ? (
                                        <div className="text-sm text-slate-500 italic py-2">값을 입력할 필요가 없습니다.</div>
                                    ) : currentInput.operator === 'relative_date' ? (
                                        <div className="flex items-center gap-2">
                                            <input
                                                type="number"
                                                value={currentInput.value}
                                                onChange={(e) => setCurrentInput({ ...currentInput, value: e.target.value })}
                                                placeholder="일수 (예: +1, -1)"
                                                className="w-full px-3 py-2 rounded border border-slate-300 text-sm outline-none focus:border-blue-500 bg-white"
                                            />
                                            <div className="text-xs text-slate-500 whitespace-nowrap min-w-[60px]">
                                                {parseInt(currentInput.value) === 1 ? '(내일)' :
                                                    parseInt(currentInput.value) === 0 ? '(오늘)' :
                                                        parseInt(currentInput.value) === -1 ? '(어제)' :
                                                            parseInt(currentInput.value) > 1 ? `(${currentInput.value}일 후)` :
                                                                parseInt(currentInput.value) < -1 ? `(${Math.abs(parseInt(currentInput.value))}일 전)` : ''}
                                            </div>
                                        </div>
                                    ) : fieldType === 'select' ? (
                                        <select
                                            value={currentInput.value}
                                            onChange={(e) => setCurrentInput({ ...currentInput, value: e.target.value })}
                                            className="w-full px-3 py-2 rounded border border-slate-300 text-sm bg-white"
                                        >
                                            <option value="">선택하세요</option>
                                            {fieldConfig?.options?.map(opt => (
                                                <option key={opt.value} value={opt.value}>{opt.label}</option>
                                            ))}
                                        </select>
                                    ) : (
                                        <input
                                            type={fieldType === 'number' ? 'number' : 'text'}
                                            value={currentInput.value}
                                            onChange={(e) => setCurrentInput({ ...currentInput, value: e.target.value })}
                                            placeholder={fieldType === 'date' ? 'YYYY-MM-DD' : '값 입력'}
                                            className="w-full px-3 py-2 rounded border border-slate-300 text-sm outline-none focus:border-blue-500 bg-white"
                                        />
                                    )}
                                </div>

                                {/* Add/Update Button */}
                                <button
                                    onClick={addOrUpdateCondition}
                                    className={`px-4 py-2 font-bold rounded-lg transition-colors ${editingId ? 'bg-orange-500 hover:bg-orange-600 text-white' : 'bg-slate-900 hover:bg-slate-800 text-white'}`}
                                >
                                    {editingId ? '수정' : '+ 추가'}
                                </button>
                                {editingId && (
                                    <button
                                        onClick={cancelEdit}
                                        className="px-3 py-2 text-slate-500 hover:text-slate-700 font-bold"
                                    >
                                        취소
                                    </button>
                                )}
                            </>
                        );
                    })()}
                </div>

                {/* Query Preview with Edit/Delete */}
                {conditions.length > 0 && (
                    <div className="bg-gradient-to-r from-slate-50 to-blue-50 p-4 rounded-xl border border-slate-200 mb-4">
                        <div className="flex items-center justify-between mb-3">
                            <div className="text-xs font-bold text-slate-500 uppercase">적용된 조건</div>
                            {conditions.length > 1 && (
                                <div className="flex items-center gap-2 bg-white rounded-lg p-1 border border-slate-200">
                                    <button
                                        onClick={() => setConditionOperator('AND')}
                                        className={`px-3 py-1 rounded text-xs font-bold transition-colors ${conditionOperator === 'AND' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-700'}`}
                                    >
                                        AND
                                    </button>
                                    <button
                                        onClick={() => setConditionOperator('OR')}
                                        className={`px-3 py-1 rounded text-xs font-bold transition-colors ${conditionOperator === 'OR' ? 'bg-purple-600 text-white' : 'text-slate-500 hover:text-slate-700'}`}
                                    >
                                        OR
                                    </button>
                                </div>
                            )}
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                            {conditions.map((cond, index) => {
                                const fieldConfig = FIELDS.find(f => f.value === cond.field);
                                const operatorConfig = OPERATORS[(fieldConfig?.type || 'string') as keyof typeof OPERATORS]?.find(o => o.value === cond.operator);
                                const displayValue = fieldConfig?.type === 'select'
                                    ? (fieldConfig.options?.find(o => o.value === cond.value)?.label || cond.value)
                                    : cond.value;

                                return (
                                    <div key={cond.id} className="flex items-center gap-2">
                                        {index > 0 && (
                                            <span className={`px-2 py-1 rounded text-xs font-bold ${conditionOperator === 'AND' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}`}>
                                                {conditionOperator}
                                            </span>
                                        )}
                                        <div className={`group flex items-center gap-1 px-3 py-1.5 bg-white rounded-lg border shadow-sm text-sm ${editingId === cond.id ? 'border-orange-300 bg-orange-50' : 'border-slate-200'}`}>
                                            <span className="font-bold text-slate-700">{fieldConfig?.label || cond.field}</span>
                                            <span className="text-slate-400">{operatorConfig?.label || cond.operator}</span>
                                            <span className="text-blue-600 font-medium">"{displayValue}"</span>
                                            <div className="flex items-center gap-0.5 ml-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button
                                                    onClick={() => editCondition(cond)}
                                                    className="text-slate-400 hover:text-blue-600 p-1"
                                                    title="수정"
                                                >
                                                    ✏️
                                                </button>
                                                <button
                                                    onClick={() => deleteCondition(cond.id)}
                                                    className="text-slate-400 hover:text-red-600 p-1"
                                                    title="삭제"
                                                >
                                                    🗑️
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}

                {/* Actions */}
                <div className="flex flex-col md:flex-row justify-between items-center gap-4 pt-4 border-t border-slate-100">
                    <div className="flex items-center gap-3 flex-wrap">
                        <button
                            id="segment-search-btn"
                            onClick={() => handleSearch(true)}
                            disabled={isSearching || conditions.length === 0}
                            className="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 shadow-sm transition-colors disabled:opacity-50 flex items-center gap-2"
                        >
                            {isSearching ? '검색 중...' : '🔍 검색하기'}
                        </button>
                        <button
                            onClick={() => handleExport('csv')}
                            disabled={isExporting || patients.length === 0}
                            className="px-4 py-2 bg-emerald-600 text-white font-bold rounded-lg hover:bg-emerald-700 shadow-sm transition-colors disabled:opacity-50"
                        >
                            CSV 내보내기
                        </button>
                        <button
                            onClick={() => handleExport('excel')}
                            disabled={isExporting || patients.length === 0}
                            className="px-4 py-2 bg-green-700 text-white font-bold rounded-lg hover:bg-green-800 shadow-sm transition-colors disabled:opacity-50"
                        >
                            Excel 내보내기
                        </button>
                    </div>

                    <div className="flex items-center gap-2 w-full md:w-auto border-l border-slate-100 pl-4">
                        {activeSegmentId && (
                            <span className="text-xs text-orange-600 font-bold bg-orange-50 px-2 py-1 rounded">편집 중</span>
                        )}
                        <input
                            type="text"
                            placeholder="세그먼트 이름..."
                            value={segmentName}
                            onChange={(e) => setSegmentName(e.target.value)}
                            className="px-3 py-2 border border-slate-200 rounded-lg text-sm outline-none focus:border-slate-400"
                        />
                        <button onClick={handleSave} disabled={isSaving || conditions.length === 0} className={`px-4 py-2 font-bold rounded-lg shadow-sm transition-colors disabled:opacity-50 whitespace-nowrap ${activeSegmentId ? 'bg-orange-600 hover:bg-orange-700 text-white' : 'bg-slate-800 hover:bg-slate-900 text-white'}`}>
                            {isSaving ? '저장 중...' : activeSegmentId ? '수정' : '새로 저장'}
                        </button>
                        {activeSegmentId && (
                            <button
                                onClick={() => {
                                    setActiveSegmentId(null);
                                    setSegmentName('');
                                    // Notify StatsCardSection to deselect
                                    window.dispatchEvent(new CustomEvent('deselectSegment'));
                                }}
                                className="px-3 py-2 text-slate-500 hover:text-slate-700 text-sm font-bold"
                            >
                                취소
                            </button>
                        )}
                    </div>
                </div>
            </div>

            {/* Patient Results */}
            {patients.length > 0 && (
                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="font-bold text-slate-900">
                            검색 결과 <span className="text-blue-600">{totalCount.toLocaleString()}명</span>
                            {totalCount > 500 && <span className="text-sm text-slate-500 font-normal ml-2">(최대 500명 표시)</span>}
                        </h3>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="bg-slate-50 border-b border-slate-200">
                                <tr className="text-slate-500 border-b border-slate-200/60 text-xs uppercase tracking-wider">
                                    <th className="px-4 py-3 text-left font-semibold w-16">#</th>
                                    <th className="px-4 py-3 text-left font-semibold">이름</th>
                                    <th className="px-4 py-3 text-left font-bold text-slate-600">연락처</th>
                                    <th className="px-4 py-3 text-center font-bold text-slate-600">상태</th>
                                    <th className="px-4 py-3 text-right font-bold text-slate-600">방문수</th>
                                    <th className="px-4 py-3 text-right font-bold text-slate-600">결제수</th>
                                    <th className="px-4 py-3 text-right font-bold text-slate-600">총결제</th>
                                    <th className="px-4 py-3 text-center font-bold text-slate-600">관리</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {patients.map(p => (
                                    <tr key={p.id} className="hover:bg-slate-50 group transition-colors">
                                        <td className="px-4 py-3 text-slate-400 font-mono text-xs">{p.chart_number || '-'}</td>
                                        <td className="px-4 py-3 font-medium text-slate-900 group-hover:text-blue-600 transition-colors">{p.name}</td>
                                        <td className="px-4 py-3 text-slate-600">{p.current_phone || '-'}</td>
                                        <td className="px-4 py-3 text-center">
                                            {(() => {
                                                const statusLabels: Record<string, { label: string; style: string }> = {
                                                    'active': { label: '활성', style: 'bg-emerald-100 text-emerald-700' },
                                                    'visit_first_visit': { label: '초진 (내원)', style: 'bg-blue-100 text-blue-700' },
                                                    'remote_first_visit': { label: '초진 (비대면)', style: 'bg-purple-100 text-purple-700' },
                                                    'inactive': { label: '비활성', style: 'bg-slate-100 text-slate-600' },
                                                    'inquiry': { label: '문의', style: 'bg-amber-100 text-amber-700' }
                                                };
                                                const info = statusLabels[(p as any).computed_status || p.status] || { label: p.status || '-', style: 'bg-slate-100 text-slate-600' };
                                                return (
                                                    <span className={`px-2 py-1 rounded text-xs font-medium ${info.style}`}>
                                                        {info.label}
                                                    </span>
                                                );
                                            })()}
                                        </td>
                                        <td className="px-4 py-3 text-right font-mono text-slate-600">{p.visit_count ? `${p.visit_count}회` : '-'}</td>
                                        <td className="px-4 py-3 text-right font-mono text-slate-600">{p.payment_count ? `${p.payment_count}회` : '0회'}</td>
                                        <td className="px-4 py-3 text-right font-mono text-slate-900 font-medium">{p.total_payment ? `${p.total_payment.toLocaleString()}원` : '-'}</td>
                                        <td className="px-4 py-3 text-center">
                                            <a
                                                href={`/admin/patients/${p.id}`}
                                                className="text-blue-600 hover:text-blue-800 font-medium text-xs"
                                            >
                                                상세보기
                                            </a>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    {/* Load More Button */}
                    {hasMore && (
                        <div className="mt-4 flex justify-center">
                            <button
                                onClick={loadMore}
                                disabled={isSearching}
                                className="px-6 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg transition-colors disabled:opacity-50"
                            >
                                {isSearching ? '로딩 중...' : `더 보기 (${patients.length}/${totalCount}명)`}
                            </button>
                        </div>
                    )}
                </div>
            )}

            {/* Modals */}
            <ConfirmModal
                isOpen={confirmModal.isOpen}
                onClose={closeConfirmModal}
                onConfirm={confirmModal.onConfirm}
                title={confirmModal.title}
                message={confirmModal.message}
                variant={confirmModal.variant as any}
            />
        </div>
    );
}
