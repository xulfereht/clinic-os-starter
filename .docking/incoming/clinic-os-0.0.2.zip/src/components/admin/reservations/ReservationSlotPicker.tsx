import React, { useState, useEffect } from 'react';
import { DatePicker } from '../../ui/DatePicker'; // Assuming relative path correct

interface Slot {
    time: string;
    remaining: number;
    isLunch: boolean;
}

interface ReservationSlotPickerProps {
    onChange?: (data: { date: string, time: string, doctorId: string }) => void;
    doctors: { id: string; name: string }[];
    namePrefix?: string;
    initialDoctorId?: string;
}

export const ReservationSlotPicker: React.FC<ReservationSlotPickerProps> = ({ onChange, doctors, namePrefix, initialDoctorId }) => {
    const [date, setDate] = useState(() => {
        // Default to today
        const now = new Date();
        const yyyy = now.getFullYear();
        const mm = String(now.getMonth() + 1).padStart(2, '0');
        const dd = String(now.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
    });
    const [time, setTime] = useState('');
    const [doctorId, setDoctorId] = useState(initialDoctorId || '');
    const [slots, setSlots] = useState<Slot[]>([]);
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState('');

    useEffect(() => {
        onChange?.({ date, time, doctorId });
    }, [date, time, doctorId]);

    useEffect(() => {
        if (date) {
            fetchSlots();
        } else {
            setSlots([]);
            setMessage('날짜를 선택하세요');
        }
    }, [date, doctorId]);

    const fetchSlots = async () => {
        setLoading(true);
        setMessage('');
        setTime(''); // Reset time on reload
        try {
            const res = await fetch(`/api/reservations/available-slots?date=${date}&doctorId=${doctorId}`);
            const data = await res.json();

            if (data.closed) {
                setSlots([]);
                setMessage(data.message || '휴진입니다.');
            } else if (!data.slots || data.slots.length === 0) {
                setSlots([]);
                setMessage('예약 가능한 시간이 없습니다.');
            } else {
                setSlots(data.slots);
            }
        } catch (e) {
            console.error(e);
            setMessage('시간대를 불러오는데 실패했습니다.');
            setSlots([]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-4 border border-slate-900 rounded-2xl p-4 bg-white">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">담당의 선택</label>
                    <select
                        value={doctorId}
                        onChange={(e) => setDoctorId(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:border-blue-500 outline-none text-sm bg-white"
                    >
                        <option value="">전체 / 미지정</option>
                        {doctors.map(d => (
                            <option key={d.id} value={d.id}>{d.name}</option>
                        ))}
                    </select>
                </div>

                <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">예약 날짜</label>
                    <DatePicker
                        value={date}
                        onChange={(dates, dateStr) => setDate(dateStr)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:border-blue-500 outline-none text-sm bg-white"
                        placeholder="YYYY-MM-DD"
                        options={{ minDate: 'today' }}
                    />
                </div>
            </div>

            <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">시간 선택</label>
                <div className="min-h-[100px] bg-white border border-slate-200 rounded-lg p-3">
                    {loading ? (
                        <div className="text-center py-4 text-slate-400 text-xs">로딩 중...</div>
                    ) : message ? (
                        <div className="text-center py-4 text-slate-400 text-xs">{message}</div>
                    ) : (
                        <div className="grid grid-cols-4 gap-2">
                            {/* Grouping logic could be added here similar to vanilla JS, simplified for now */}
                            {slots.map((slot, idx) => {
                                if (slot.isLunch) return null; // Or show lunch separator
                                const isDisabled = slot.remaining === 0;
                                return (
                                    <button
                                        key={slot.time}
                                        type="button"
                                        disabled={isDisabled}
                                        onClick={() => setTime(slot.time)}
                                        className={`
                                            px-1 py-2 rounded text-xs font-bold transition-all relative
                                            ${time === slot.time ? 'ring-2 ring-blue-500 bg-blue-50 text-blue-700' : ''}
                                            ${isDisabled
                                                ? 'bg-slate-100 text-slate-300 cursor-not-allowed'
                                                : slot.remaining === 1
                                                    ? 'bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100'
                                                    : 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                                            }
                                         `}
                                    >
                                        {slot.time}
                                        {!isDisabled && <span className="block text-[9px] opacity-70">잔여 {slot.remaining}</span>}
                                    </button>
                                );
                            })}
                        </div>
                    )}
                </div>
            </div>
            {namePrefix && (
                <>
                    <input type="hidden" name={`${namePrefix}DoctorId`} value={doctorId} />
                    <input type="hidden" name={`${namePrefix}Date`} value={date} />
                    <input type="hidden" name={`${namePrefix}Time`} value={time} />
                </>
            )}
        </div>
    );
};
