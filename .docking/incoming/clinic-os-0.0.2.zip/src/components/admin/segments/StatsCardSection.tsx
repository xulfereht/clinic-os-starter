import { useState, useEffect } from 'react';
import StatsModal from './StatsModal';
import SegmentEditModal from './SegmentEditModal';
import ConfirmModal from '../../ui/ConfirmModal';

declare global {
    interface Window {
        notify: (message: string, type?: 'success' | 'error' | 'info' | 'warning', options?: any) => void;
    }
}

interface Segment {
    id: string;
    name: string;
    criteria: string;
}

interface StatsCardSectionProps {
    total: number;
    inquiry: number;
    active: number;
    inactive: number;
}

export default function StatsCardSection({ total, inquiry, active, inactive }: StatsCardSectionProps) {
    const [statsModalOpen, setStatsModalOpen] = useState(false);
    const [statsModalType, setStatsModalType] = useState<'total' | 'inquiry' | 'active' | 'inactive'>('total');

    const [editModalOpen, setEditModalOpen] = useState(false);
    const [editingSegment, setEditingSegment] = useState<Segment | null>(null);

    const [savedSegments, setSavedSegments] = useState<Segment[]>([]);
    const [activeSegmentId, setActiveSegmentId] = useState<string | null>(null);

    // Delete confirmation modal state
    const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
    const [deletingSegmentId, setDeletingSegmentId] = useState<string | null>(null);
    const [deletingSegmentName, setDeletingSegmentName] = useState<string>('');

    useEffect(() => {
        loadSavedSegments();

        // Listen for segment deselection from FilterBuilder
        const handleDeselect = () => {
            setActiveSegmentId(null);
        };

        window.addEventListener('deselectSegment', handleDeselect);
        return () => window.removeEventListener('deselectSegment', handleDeselect);
    }, []);

    const loadSavedSegments = async () => {
        try {
            const res = await fetch('/api/admin/segments');
            if (res.ok) {
                const data = await res.json();
                setSavedSegments(data);
            }
        } catch (e) {
            console.error('Failed to load segments:', e);
        }
    };

    const openStatsModal = (type: 'total' | 'inquiry' | 'active' | 'inactive') => {
        setStatsModalType(type);
        setStatsModalOpen(true);
    };

    const openEditModal = (segment: Segment | null) => {
        setEditingSegment(segment);
        setEditModalOpen(true);
    };

    // Select segment: dispatch event to FilterBuilder, set as active
    const selectSegment = (segment: Segment) => {
        setActiveSegmentId(segment.id);
        // Dispatch custom event for FilterBuilder to listen
        window.dispatchEvent(new CustomEvent('loadSegment', { detail: segment }));
    };

    const openDeleteConfirm = (segment: Segment) => {
        setDeletingSegmentId(segment.id);
        setDeletingSegmentName(segment.name);
        setDeleteConfirmOpen(true);
    };

    const handleDeleteSegment = async () => {
        if (!deletingSegmentId) return;

        try {
            const res = await fetch(`/api/admin/segments/${deletingSegmentId}`, { method: 'DELETE' });
            if (res.ok) {
                loadSavedSegments();
                window.notify('삭제되었습니다.', 'success');
            } else {
                window.notify('삭제 실패', 'error');
            }
        } catch (e) {
            console.error('Delete error:', e);
            window.notify('오류가 발생했습니다.', 'error');
        } finally {
            setDeletingSegmentId(null);
        }
    };

    return (
        <>
            {/* Quick Stats - Clickable */}
            <div className="grid grid-cols-4 gap-4 mb-6">
                <button
                    onClick={() => openStatsModal('total')}
                    className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm text-left hover:border-slate-400 hover:shadow-md transition-all cursor-pointer"
                >
                    <div className="text-xs font-bold text-slate-500 uppercase">전체</div>
                    <div className="text-2xl font-bold text-slate-900">{total.toLocaleString()}명</div>
                </button>
                <button
                    onClick={() => openStatsModal('inquiry')}
                    className="bg-blue-50 p-4 rounded-xl border border-blue-200 text-left hover:border-blue-400 hover:shadow-md transition-all cursor-pointer"
                >
                    <div className="text-xs font-bold text-blue-600 uppercase">신규/잠재</div>
                    <div className="text-2xl font-bold text-blue-700">{inquiry.toLocaleString()}명</div>
                </button>
                <button
                    onClick={() => openStatsModal('active')}
                    className="bg-emerald-50 p-4 rounded-xl border border-emerald-200 text-left hover:border-emerald-400 hover:shadow-md transition-all cursor-pointer"
                >
                    <div className="text-xs font-bold text-emerald-600 uppercase">활성고객</div>
                    <div className="text-2xl font-bold text-emerald-700">{active.toLocaleString()}명</div>
                </button>
                <button
                    onClick={() => openStatsModal('inactive')}
                    className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-left hover:border-slate-400 hover:shadow-md transition-all cursor-pointer"
                >
                    <div className="text-xs font-bold text-slate-500 uppercase">비활성/이탈</div>
                    <div className="text-2xl font-bold text-slate-600">{inactive.toLocaleString()}명</div>
                </button>
            </div>

            {/* Saved Segments with Edit */}
            <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-6">
                <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xs font-bold text-slate-500 uppercase">저장된 세그먼트</h3>
                    <button
                        onClick={() => openEditModal(null)}
                        className="text-xs font-bold text-blue-600 hover:text-blue-800"
                    >
                        + 새 세그먼트
                    </button>
                </div>
                <div className="flex flex-wrap gap-2">
                    {savedSegments.map((seg) => (
                        <div key={seg.id} className={`inline-flex items-center group ${activeSegmentId === seg.id ? 'ring-2 ring-blue-500 ring-offset-1 rounded-full' : ''}`}>
                            <button
                                onClick={() => selectSegment(seg)}
                                className={`px-3 py-1.5 rounded-l-full border text-sm font-bold transition-colors ${activeSegmentId === seg.id
                                    ? 'bg-blue-600 text-white border-blue-600'
                                    : 'bg-blue-50 text-blue-600 border-blue-100 hover:bg-blue-100'
                                    }`}
                            >
                                ⚡ {seg.name}
                            </button>
                            <button
                                onClick={() => openEditModal(seg)}
                                className={`px-2 py-1.5 rounded-r-full border border-l-0 transition-colors ${activeSegmentId === seg.id
                                    ? 'bg-blue-500 text-white border-blue-600 hover:bg-blue-400'
                                    : 'bg-blue-50 text-slate-400 border-blue-100 hover:bg-slate-100 hover:text-slate-600'
                                    }`}
                                title="수정"
                            >
                                ✎
                            </button>
                        </div>
                    ))}
                    {savedSegments.length === 0 && (
                        <span className="text-sm text-slate-400">저장된 세그먼트가 없습니다.</span>
                    )}
                </div>
            </div>

            {/* Modals */}
            <StatsModal
                isOpen={statsModalOpen}
                onClose={() => setStatsModalOpen(false)}
                filterType={statsModalType}
            />
            <SegmentEditModal
                isOpen={editModalOpen}
                onClose={() => setEditModalOpen(false)}
                segment={editingSegment}
                onSave={loadSavedSegments}
            />
            <ConfirmModal
                isOpen={deleteConfirmOpen}
                onClose={() => setDeleteConfirmOpen(false)}
                onConfirm={handleDeleteSegment}
                title="세그먼트 삭제"
                message={`"${deletingSegmentName}" 세그먼트를 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.`}
                confirmText="삭제"
                cancelText="취소"
                variant="danger"
            />
        </>
    );
}
