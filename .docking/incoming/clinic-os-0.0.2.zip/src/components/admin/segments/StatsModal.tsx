import { useState, useEffect } from 'react';

interface Patient {
    id: string;
    name: string;
    current_phone: string;
    chart_number: string;
    status: string;
    visit_count: number;
    payment_count?: number;
    total_payment: number;
}

interface StatsModalProps {
    isOpen: boolean;
    onClose: () => void;
    filterType: 'total' | 'inquiry' | 'active' | 'inactive';
}

const titles: Record<string, string> = {
    'total': '전체 환자',
    'inquiry': '신규/잠재 환자',
    'active': '활성 고객',
    'inactive': '비활성/이탈 고객'
};

const statusLabels: Record<string, { label: string; style: string }> = {
    'active': { label: '활성', style: 'bg-emerald-100 text-emerald-700' },
    'visit_first_visit': { label: '초진 (내원)', style: 'bg-blue-100 text-blue-700' },
    'remote_first_visit': { label: '초진 (비대면)', style: 'bg-purple-100 text-purple-700' },
    'inactive': { label: '비활성', style: 'bg-slate-100 text-slate-600' },
    'inquiry': { label: '문의', style: 'bg-amber-100 text-amber-700' }
};

export default function StatsModal({ isOpen, onClose, filterType }: StatsModalProps) {
    const [patients, setPatients] = useState<Patient[]>([]);
    const [count, setCount] = useState(0);
    const [hasMore, setHasMore] = useState(false);
    const [offset, setOffset] = useState(0);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (isOpen) {
            loadPatients(true);
        } else {
            // Reset when closed
            setPatients([]);
            setOffset(0);
            setHasMore(false);
        }
    }, [isOpen, filterType]);

    const loadPatients = async (reset: boolean = false) => {
        setLoading(true);
        const currentOffset = reset ? 0 : offset;

        try {
            const res = await fetch(`/api/admin/segments/stats-preview?type=${filterType}&limit=20&offset=${currentOffset}`);
            const data = await res.json();

            if (reset) {
                setPatients(data.patients || []);
            } else {
                setPatients(prev => [...prev, ...(data.patients || [])]);
            }
            setCount(data.count || 0);
            setHasMore(data.hasMore || false);
            setOffset(data.nextOffset || 0);
        } catch (e) {
            console.error('Failed to load patients:', e);
        } finally {
            setLoading(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center"
            onClick={(e) => e.target === e.currentTarget && onClose()}
        >
            <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full mx-4 max-h-[80vh] overflow-hidden">
                <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                    <h3 className="font-bold text-slate-900 text-lg">{titles[filterType]}</h3>
                    <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-lg transition-colors">
                        <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>

                <div className="p-4 overflow-y-auto max-h-[60vh]">
                    {loading && patients.length === 0 ? (
                        <div className="flex items-center justify-center py-12">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                        </div>
                    ) : patients.length > 0 ? (
                        <>
                            <div className="text-sm text-slate-500 mb-3">
                                {patients.length}/{count.toLocaleString()}명 표시
                            </div>
                            <table className="w-full text-sm">
                                <thead className="bg-slate-50 border-b">
                                    <tr>
                                        <th className="px-3 py-2 text-left font-bold text-slate-600 w-20">차트번호</th>
                                        <th className="px-3 py-2 text-left font-bold text-slate-600">이름</th>
                                        <th className="px-3 py-2 text-left font-bold text-slate-600">연락처</th>
                                        <th className="px-3 py-2 text-center font-bold text-slate-600">상태</th>
                                        <th className="px-3 py-2 text-right font-bold text-slate-600">방문수</th>
                                        <th className="px-3 py-2 text-right font-bold text-slate-600">결제수</th>
                                        <th className="px-3 py-2 text-right font-bold text-slate-600">총결제</th>
                                        <th className="px-3 py-2 text-center font-bold text-slate-600"></th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                    {patients.map(p => {
                                        const displayStatus = (p as any).computed_status || p.status;
                                        const info = statusLabels[displayStatus] || { label: displayStatus || '-', style: 'bg-slate-100 text-slate-600' };
                                        return (
                                            <tr key={p.id} className="hover:bg-slate-50">
                                                <td className="px-3 py-2 text-slate-400 font-mono text-xs">{p.chart_number || '-'}</td>
                                                <td className="px-3 py-2 font-medium text-slate-900">{p.name}</td>
                                                <td className="px-3 py-2 text-slate-600">{p.current_phone || '-'}</td>
                                                <td className="px-3 py-2 text-center">
                                                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${info.style}`}>
                                                        {info.label}
                                                    </span>
                                                </td>
                                                <td className="px-3 py-2 text-right text-slate-600">{p.visit_count || 0}회</td>
                                                <td className="px-3 py-2 text-right text-slate-600">{p.payment_count || 0}회</td>
                                                <td className="px-3 py-2 text-right text-slate-600">{(p.total_payment || 0).toLocaleString()}원</td>
                                                <td className="px-3 py-2 text-center">
                                                    <a
                                                        href={`/admin/patients/${p.id}`}
                                                        className="text-blue-600 hover:text-blue-800 text-xs font-medium"
                                                    >
                                                        상세
                                                    </a>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>

                            {hasMore && (
                                <div className="mt-4 flex justify-center">
                                    <button
                                        onClick={() => loadPatients(false)}
                                        disabled={loading}
                                        className="px-6 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg transition-colors disabled:opacity-50"
                                    >
                                        {loading ? '로딩 중...' : `더 보기 (${patients.length}/${count}명)`}
                                    </button>
                                </div>
                            )}
                        </>
                    ) : (
                        <div className="text-center py-12 text-slate-500">
                            해당하는 환자가 없습니다.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
