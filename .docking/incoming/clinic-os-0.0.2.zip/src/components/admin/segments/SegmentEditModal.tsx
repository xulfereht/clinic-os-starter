import { useState, useEffect } from 'react';
import type { Operator } from '../../../lib/segment-engine';
import ConfirmModal from '../../ui/ConfirmModal';

declare global {
    interface Window {
        showToast?: (message: string, type?: 'success' | 'error' | 'info' | 'warning', options?: any) => void;
    }
}

interface Condition {
    id: string;
    field: string;
    operator: Operator;
    value: any;
}

interface Segment {
    id: string;
    name: string;
    criteria: string;
}

interface SegmentEditModalProps {
    isOpen: boolean;
    onClose: () => void;
    segment: Segment | null;
    onSave: () => void;
}

const FIELDS = [
    { value: 'name', label: '이름', type: 'string' },
    { value: 'phone', label: '연락처', type: 'string' },
    { value: 'status', label: '상태', type: 'select' },
    { value: 'total_payment', label: '총 결제금액', type: 'number' },
    { value: 'visit_count', label: '내원 횟수', type: 'number' },
    { value: 'last_visit_date', label: '최근 내원일', type: 'date' },
    { value: 'created_at', label: '등록일', type: 'date' },
    { value: 'tags', label: '세그먼트 태그', type: 'string' },
    { value: 'first_source', label: '유입채널', type: 'string' },
    { value: 'gender', label: '성별', type: 'select' },
    { value: 'referral_count', label: '소개환자 수', type: 'number' }
];

const OPERATORS: Record<string, Array<{ value: Operator; label: string }>> = {
    string: [
        { value: 'contains', label: '포함' },
        { value: 'equals', label: '일치' },
        { value: 'starts_with', label: '시작' }
    ],
    number: [
        { value: 'gt', label: '>' },
        { value: 'lt', label: '<' },
        { value: 'gte', label: '>=' },
        { value: 'lte', label: '<=' },
        { value: 'equals', label: '=' }
    ],
    date: [
        { value: 'older_than_days', label: 'N일 이상 경과' },
        { value: 'within_days', label: 'N일 이내' }
    ],
    select: [
        { value: 'equals', label: '일치' }
    ]
};

export default function SegmentEditModal({ isOpen, onClose, segment, onSave }: SegmentEditModalProps) {
    const [name, setName] = useState('');
    const [conditions, setConditions] = useState<Condition[]>([]);
    const [currentInput, setCurrentInput] = useState({ field: 'name', operator: 'contains' as Operator, value: '' });
    const [saving, setSaving] = useState(false);
    const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
    const [deleting, setDeleting] = useState(false);

    useEffect(() => {
        if (segment) {
            setName(segment.name);
            try {
                const parsed = JSON.parse(segment.criteria);
                setConditions(parsed.conditions.map((c: any) => ({ ...c, id: Math.random().toString() })));
            } catch (e) {
                console.error('Failed to parse criteria:', e);
                setConditions([]);
            }
        } else {
            setName('');
            setConditions([]);
        }
    }, [segment, isOpen]);

    const addCondition = () => {
        if (!currentInput.value) {
            window.showToast?.('값을 입력해주세요.', 'warning');
            return;
        }
        setConditions([...conditions, { ...currentInput, id: Math.random().toString() }]);
        setCurrentInput({ field: 'name', operator: 'contains', value: '' });
    };

    const removeCondition = (id: string) => {
        setConditions(conditions.filter(c => c.id !== id));
    };

    const handleSave = async () => {
        if (!name.trim()) {
            window.showToast?.('세그먼트 이름을 입력해주세요.', 'warning');
            return;
        }
        if (conditions.length === 0) {
            window.showToast?.('조건을 하나 이상 추가해주세요.', 'warning');
            return;
        }

        setSaving(true);
        try {
            const criteria = {
                operator: 'AND',
                conditions: conditions.map(({ id, ...rest }) => rest)
            };

            const url = segment ? `/api/admin/segments/${segment.id}` : '/api/admin/segments';
            const method = segment ? 'PUT' : 'POST';

            const res = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, criteria })
            });

            if (res.ok) {
                onSave();
                onClose();
            } else {
                window.showToast?.('저장에 실패했습니다.', 'error');
            }
        } catch (e) {
            console.error('Save error:', e);
            window.showToast?.('오류가 발생했습니다.', 'error');
        } finally {
            setSaving(false);
        }
    };

    const getFieldLabel = (field: string) => FIELDS.find(f => f.value === field)?.label || field;
    const getOperatorLabel = (op: Operator) => {
        for (const ops of Object.values(OPERATORS)) {
            const found = ops.find(o => o.value === op);
            if (found) return found.label;
        }
        return op;
    };

    const handleDelete = async () => {
        if (!segment) return;
        setDeleting(true);
        try {
            const res = await fetch(`/api/admin/segments/${segment.id}`, { method: 'DELETE' });
            if (res.ok) {
                onSave();
                onClose();
            }
        } catch (e) {
            console.error('Delete error:', e);
        } finally {
            setDeleting(false);
        }
    };

    if (!isOpen) return null;

    const currentFieldConfig = FIELDS.find(f => f.value === currentInput.field);
    const currentOperators = OPERATORS[currentFieldConfig?.type || 'string'] || OPERATORS.string;

    return (
        <div
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center"
            onClick={(e) => e.target === e.currentTarget && onClose()}
        >
            <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full mx-4 max-h-[85vh] overflow-hidden">
                <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                    <h3 className="font-bold text-slate-900 text-lg">
                        {segment ? '세그먼트 편집' : '새 세그먼트 만들기'}
                    </h3>
                    <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-lg transition-colors">
                        <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>

                <div className="p-5 overflow-y-auto max-h-[65vh] space-y-5">
                    {/* Name */}
                    <div>
                        <label className="block text-sm font-bold text-slate-700 mb-1">세그먼트 이름</label>
                        <input
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="예: 장기 미내원 환자"
                            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:border-blue-500 outline-none"
                        />
                    </div>

                    {/* Current Conditions */}
                    {conditions.length > 0 && (
                        <div>
                            <label className="block text-sm font-bold text-slate-700 mb-2">조건 목록</label>
                            <div className="space-y-2">
                                {conditions.map((c, i) => (
                                    <div key={c.id} className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg">
                                        {i > 0 && <span className="text-xs font-bold text-slate-400">AND</span>}
                                        <span className="text-sm font-medium text-slate-700">
                                            {getFieldLabel(c.field)} {getOperatorLabel(c.operator as Operator)} "{c.value}"
                                        </span>
                                        <button
                                            onClick={() => removeCondition(c.id)}
                                            className="ml-auto text-red-500 hover:text-red-700 text-sm"
                                        >
                                            ×
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Add Condition */}
                    <div>
                        <label className="block text-sm font-bold text-slate-700 mb-2">조건 추가</label>
                        <div className="flex flex-wrap gap-2">
                            <select
                                value={currentInput.field}
                                onChange={(e) => {
                                    const newField = e.target.value;
                                    const fieldConfig = FIELDS.find(f => f.value === newField);
                                    const ops = OPERATORS[fieldConfig?.type || 'string'];
                                    setCurrentInput({
                                        field: newField,
                                        operator: ops[0].value,
                                        value: ''
                                    });
                                }}
                                className="px-3 py-2 border border-slate-300 rounded-lg bg-white text-sm"
                            >
                                {FIELDS.map(f => (
                                    <option key={f.value} value={f.value}>{f.label}</option>
                                ))}
                            </select>

                            <select
                                value={currentInput.operator}
                                onChange={(e) => setCurrentInput({ ...currentInput, operator: e.target.value as Operator })}
                                className="px-3 py-2 border border-slate-300 rounded-lg bg-white text-sm"
                            >
                                {currentOperators.map(op => (
                                    <option key={op.value} value={op.value}>{op.label}</option>
                                ))}
                            </select>

                            <input
                                type={currentFieldConfig?.type === 'number' ? 'number' : 'text'}
                                value={currentInput.value}
                                onChange={(e) => setCurrentInput({ ...currentInput, value: e.target.value })}
                                placeholder="값 입력..."
                                className="flex-1 min-w-[120px] px-3 py-2 border border-slate-300 rounded-lg text-sm"
                            />

                            <button
                                onClick={addCondition}
                                className="px-4 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 text-sm"
                            >
                                + 추가
                            </button>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-between">
                    {segment ? (
                        <button
                            onClick={() => setDeleteConfirmOpen(true)}
                            disabled={deleting}
                            className="px-4 py-2 text-red-600 font-bold hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                        >
                            {deleting ? '삭제 중...' : '세그먼트 삭제'}
                        </button>
                    ) : <div />}
                    <div className="flex gap-3">
                        <button
                            onClick={onClose}
                            className="px-4 py-2 text-slate-600 font-bold hover:bg-slate-100 rounded-lg transition-colors"
                        >
                            취소
                        </button>
                        <button
                            onClick={handleSave}
                            disabled={saving}
                            className="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
                        >
                            {saving ? '저장 중...' : segment ? '수정 저장' : '저장'}
                        </button>
                    </div>
                </div>
            </div>

            <ConfirmModal
                isOpen={deleteConfirmOpen}
                onClose={() => setDeleteConfirmOpen(false)}
                onConfirm={handleDelete}
                title="세그먼트 삭제"
                message={`"${name}" 세그먼트를 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.`}
                confirmText="삭제"
                cancelText="취소"
                variant="danger"
            />
        </div>
    );
}
