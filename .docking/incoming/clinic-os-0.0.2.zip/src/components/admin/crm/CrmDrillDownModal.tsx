
import React, { useEffect, useState } from 'react';

interface Props {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    metric: string;
    startDate: string;
    endDate: string;
    mode: string | null;
}

interface PatientRow {
    id: string;
    name: string;
    chart_number: number;
    phone: string;
    created_at: number;
    care_mode: string;
    last_activity?: number;
    visit_count?: number;
    retention_days?: number;
    source?: string;
}

export const CrmDrillDownModal: React.FC<Props> = ({
    isOpen, onClose, title, metric, startDate, endDate, mode
}) => {
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState<PatientRow[]>([]);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (isOpen && metric) {
            fetchData();
        }
    }, [isOpen, metric, startDate, endDate, mode]);

    const fetchData = async () => {
        setLoading(true);
        setError(null);
        try {
            const params = new URLSearchParams({
                metric,
                startDate,
                endDate,
                mode: mode || 'ALL'
            });
            const res = await fetch(`/api/admin/crm/breakdown?${params.toString()}`);
            if (!res.ok) throw new Error('Failed to fetch data');
            const json = await res.json();
            setData(json.data || []);
        } catch (e: any) {
            setError(e.message);
        } finally {
            setLoading(false);
        }
    };

    if (!isOpen) return null;

    const formatTime = (ts: number) => new Date(ts * 1000).toLocaleDateString();

    return (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[80vh] flex flex-col">
                <div className="p-5 border-b flex justify-between items-center">
                    <h3 className="font-bold text-lg text-slate-800">{title} <span className="text-slate-500 text-sm font-normal">({data.length}명)</span></h3>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600">✕</button>
                </div>

                <div className="p-0 overflow-auto flex-1 custom-scrollbar">
                    {loading ? (
                        <div className="p-10 text-center text-slate-500">로딩 중...</div>
                    ) : error ? (
                        <div className="p-10 text-center text-red-500">{error}</div>
                    ) : data.length === 0 ? (
                        <div className="p-10 text-center text-slate-400">데이터가 없습니다.</div>
                    ) : (
                        <table className="w-full text-sm text-left">
                            <thead className="bg-slate-50 sticky top-0 border-b">
                                <tr>
                                    <th className="px-4 py-3 text-slate-500 font-medium">이름</th>
                                    <th className="px-4 py-3 text-slate-500 font-medium">차트번호</th>
                                    <th className="px-4 py-3 text-slate-500 font-medium">연락처</th>
                                    <th className="px-4 py-3 text-slate-500 font-medium">등록일</th>
                                    <th className="px-4 py-3 text-slate-500 font-medium">관리유형</th>
                                    {metric === 'new_patients' && <th className="px-4 py-3 text-slate-500 font-medium">유입경로</th>}
                                    {(metric === 'active_patients' || metric === 'returning_visits') && <th className="px-4 py-3 text-slate-500 font-medium">최근활동</th>}
                                    {metric === 'cohort_visits' && <th className="px-4 py-3 text-slate-500 font-medium text-right">방문수</th>}
                                    {metric === 'cohort_visits' && <th className="px-4 py-3 text-slate-500 font-medium text-right">유지기간</th>}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {data.map((row) => (
                                    <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                                        <td className="px-4 py-3 font-medium text-slate-900">
                                            <a href={`/admin/patients/${row.id}`} target="_blank" className="hover:underline hover:text-blue-600">
                                                {row.name}
                                            </a>
                                        </td>
                                        <td className="px-4 py-3 text-slate-600">{row.chart_number}</td>
                                        <td className="px-4 py-3 text-slate-600">{row.phone}</td>
                                        <td className="px-4 py-3 text-slate-600">{formatTime(row.created_at)}</td>
                                        <td className="px-4 py-3">
                                            <span className={`px-2 py-0.5 rounded text-xs ${row.care_mode === 'INPERSON' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>
                                                {row.care_mode === 'INPERSON' ? '내원' : '비대면'}
                                            </span>
                                        </td>
                                        {metric === 'new_patients' && <td className="px-4 py-3 text-slate-600">{row.source || '-'}</td>}
                                        {(metric === 'active_patients' || metric === 'returning_visits') && (
                                            <td className="px-4 py-3 text-slate-600">
                                                {row.last_activity ? formatTime(row.last_activity) : '-'}
                                            </td>
                                        )}
                                        {metric === 'cohort_visits' && <td className="px-4 py-3 text-slate-900 font-bold text-right">{row.visit_count}회</td>}
                                        {metric === 'cohort_visits' && <td className="px-4 py-3 text-slate-600 text-right">{row.retention_days}일</td>}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>

                <div className="p-4 border-t bg-slate-50 rounded-b-xl flex justify-end">
                    <button onClick={onClose} className="px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm hover:bg-slate-50 font-medium">닫기</button>
                </div>
            </div>
        </div>
    );
};
