
import React, { useState } from 'react';
import { CrmDrillDownModal } from './CrmDrillDownModal';

interface SummaryData {
    newPatients: number;
    activePatients: number;
    totalVisits: number;
    returningRatio: number; // 0-100
    retention30dRate: number | null;
}

interface CohortStats {
    avgVisits: number;
    avgRetentionDays: number;
}

interface Props {
    summary: SummaryData;
    cohortStats: CohortStats;
    startDate: string;
    endDate: string;
    mode: string;
}

export const CrmSummaryCards: React.FC<Props> = ({
    summary, cohortStats, startDate, endDate, mode
}) => {
    const [modalConfig, setModalConfig] = useState<{
        isOpen: boolean;
        title: string;
        metric: string;
    }>({ isOpen: false, title: '', metric: '' });

    const openModal = (metric: string, title: string) => {
        setModalConfig({ isOpen: true, metric, title });
    };

    const closeModal = () => {
        setModalConfig(prev => ({ ...prev, isOpen: false }));
    };

    return (
        <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                {/* New Patients */}
                <div
                    onClick={() => openModal('new_patients', '기간 내 신규 환자')}
                    className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm cursor-pointer hover:border-blue-400 hover:shadow-md transition-all"
                >
                    <div className="text-slate-500 text-sm font-medium mb-1">기간 내 신규 환자</div>
                    <div className="text-3xl font-bold text-slate-900">
                        {summary.newPatients.toLocaleString()}
                        <span className="text-lg text-slate-400 ml-1">명</span>
                    </div>
                    <div className="text-xs text-slate-400 mt-1">선택 기간 가입</div>
                </div>

                {/* Active Patients */}
                <div
                    onClick={() => openModal('active_patients', '기간 내 활동 환자')}
                    className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm cursor-pointer hover:border-blue-400 hover:shadow-md transition-all"
                >
                    <div className="text-slate-500 text-sm font-medium mb-1">기간 내 활동 환자</div>
                    <div className="text-3xl font-bold text-emerald-600">
                        {summary.activePatients.toLocaleString()}
                        <span className="text-lg text-slate-400 ml-1">명</span>
                    </div>
                    <div className="text-xs text-slate-400 mt-1">방문/접수 등 이력 존재</div>
                </div>

                {/* Cohort Avg Visits */}
                <div
                    onClick={() => openModal('cohort_visits', '코호트 평균 방문수')}
                    className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm cursor-pointer hover:border-blue-400 hover:shadow-md transition-all relative overflow-hidden"
                >
                    <div className="relative z-10">
                        <div className="text-slate-500 text-sm font-medium mb-1">코호트 평균 방문수</div>
                        <div className="text-3xl font-bold text-blue-600">
                            {cohortStats.avgVisits.toFixed(1)}
                            <span className="text-lg text-slate-400 ml-1">회</span>
                        </div>
                        <div className="text-xs text-slate-400 mt-1">기간 내 가입자의 현재까지 방문수</div>
                    </div>
                </div>

                {/* Returning Ratio */}
                <div
                    onClick={() => openModal('active_patients', '활동 환자 구성 (신규/재방문)')} // Reuse active_patients list, simplified
                    className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm cursor-pointer hover:border-blue-400 hover:shadow-md transition-all"
                >
                    <div className="text-slate-500 text-sm font-medium mb-1">재방문(활동) 비중</div>
                    <div className="flex items-end gap-2">
                        <div className="text-3xl font-bold text-purple-600">{summary.returningRatio}%</div>
                        <div className="text-sm text-slate-400 mb-1.5 flex flex-col leading-none">
                            <span>신규 {(100 - summary.returningRatio)}%</span>
                        </div>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full mt-2 overflow-hidden flex">
                        <div className="bg-purple-500 h-full" style={{ width: `${summary.returningRatio}%` }}></div>
                        <div className="bg-slate-300 h-full flex-1"></div>
                    </div>
                </div>
            </div>

            <CrmDrillDownModal
                isOpen={modalConfig.isOpen}
                onClose={closeModal}
                title={modalConfig.title}
                metric={modalConfig.metric}
                startDate={startDate}
                endDate={endDate}
                mode={mode}
            />
        </>
    );
};
