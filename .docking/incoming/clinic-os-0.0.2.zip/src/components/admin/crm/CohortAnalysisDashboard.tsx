/**
 * CRM 코호트 분석 대시보드 컴포넌트
 * 
 * 기능:
 * - 코호트 선택기 (기간, 분석 유형, 휴면 기준)
 * - 핵심 지표 카드 (리텐션, 평균 재진, 첫 재진 리드타임)
 * - 비교 분석 테이블 (원장별/진료유형별)
 */

import { useState, useEffect } from 'react';

interface CohortParams {
    weeksAgo: number;
    windowWeeks: number;
    analysisType: 'first_ever' | 'episode_start' | 'restart_only';
    dormantDays: number;
    followUpWeeks: number;
}

interface CohortMetrics {
    cohortSize: number;
    retention: {
        week4: number;
        week8: number;
        week12: number;
    };
    avgRevisits: number;
    medianFirstRevisitDays: number | null;
    breakdown: {
        firstEverCount: number;
        reStartCount: number;
    };
}

interface CohortResponse {
    success: boolean;
    params: {
        intakeStart: string;
        intakeEnd: string;
        analysisDate: string;
    } & CohortParams;
    metrics: CohortMetrics;
}

interface ComparisonResult {
    splitValue: string;
    label: string;
    cohortSize: number;
    retention: { week4: number; week8: number; week12: number };
    avgRevisits: number;
    medianFirstRevisitDays: number | null;
}

interface CompareResponse {
    success: boolean;
    splitBy: string;
    results: ComparisonResult[];
    totalCohortSize: number;
}

const ANALYSIS_TYPES = [
    { value: 'episode_start', label: '에피소드 초진 (신규+재초진)', desc: '서비스 품질 분석용' },
    { value: 'first_ever', label: '생애 초진만', desc: '신규 유입 분석용' },
    { value: 'restart_only', label: '재초진만', desc: '휴면 재활성화 분석용' },
];

const DORMANT_PRESETS = [
    { value: 60, label: '60일' },
    { value: 90, label: '90일 (권장)' },
    { value: 180, label: '180일' },
];

const SPLIT_OPTIONS = [
    { value: 'provider', label: '담당 원장별' },
    { value: 'care_mode', label: '진료 유형별 (대면/비대면)' },
    { value: 'business_type', label: '급여 유형별 (급여/비급여)' },
];

export default function CohortAnalysisDashboard() {
    const [params, setParams] = useState<CohortParams>({
        weeksAgo: 8,
        windowWeeks: 4,
        analysisType: 'episode_start',
        dormantDays: 90,
        followUpWeeks: 12,
    });

    const [data, setData] = useState<CohortResponse | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    // Comparison state
    const [splitBy, setSplitBy] = useState('provider');
    const [compareData, setCompareData] = useState<CompareResponse | null>(null);
    const [compareLoading, setCompareLoading] = useState(false);

    const fetchData = async () => {
        setLoading(true);
        setError(null);

        try {
            const searchParams = new URLSearchParams({
                weeksAgo: params.weeksAgo.toString(),
                windowWeeks: params.windowWeeks.toString(),
                analysisType: params.analysisType,
                dormantDays: params.dormantDays.toString(),
                followUpWeeks: params.followUpWeeks.toString(),
            });

            const res = await fetch(`/api/admin/crm/cohort/metrics?${searchParams}`);
            if (!res.ok) throw new Error('Failed to fetch cohort data');

            const json = await res.json();
            setData(json);

            // Also fetch comparison data
            fetchComparison();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Unknown error');
        } finally {
            setLoading(false);
        }
    };

    const fetchComparison = async () => {
        setCompareLoading(true);
        try {
            const searchParams = new URLSearchParams({
                weeksAgo: params.weeksAgo.toString(),
                windowWeeks: params.windowWeeks.toString(),
                analysisType: params.analysisType,
                dormantDays: params.dormantDays.toString(),
                followUpWeeks: params.followUpWeeks.toString(),
                splitBy,
            });

            const res = await fetch(`/api/admin/crm/cohort/compare?${searchParams}`);
            if (!res.ok) throw new Error('Failed to fetch comparison');

            const json = await res.json();
            setCompareData(json);
        } catch (err) {
            console.error('Comparison error:', err);
        } finally {
            setCompareLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    useEffect(() => {
        if (data) {
            fetchComparison();
        }
    }, [splitBy]);

    const handleApply = () => {
        fetchData();
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">📊 환자 DB 분석</h1>
                    <p className="text-sm text-slate-500 mt-1">
                        초진 유입 환자의 재방문 패턴과 이탈을 분석합니다
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    <a
                        href="/admin/crm/segments"
                        className="px-4 py-2 bg-white text-blue-600 text-sm font-bold rounded-lg border border-blue-100 hover:bg-blue-50 flex items-center gap-2 transition-all"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                        </svg>
                        세그먼트 빌더
                    </a>
                </div>
            </div>


            {/* Control Panel */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
                <h2 className="text-sm font-bold text-slate-700 mb-4 flex items-center gap-2">
                    <span>⚙️</span> 코호트 설정
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* 분석 유형 */}
                    <div>
                        <label className="block text-xs font-medium text-slate-500 mb-1.5">분석 유형</label>
                        <select
                            value={params.analysisType}
                            onChange={(e) => setParams({ ...params, analysisType: e.target.value as any })}
                            className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        >
                            {ANALYSIS_TYPES.map((t) => (
                                <option key={t.value} value={t.value}>{t.label}</option>
                            ))}
                        </select>
                        <p className="text-[10px] text-slate-400 mt-1">
                            {ANALYSIS_TYPES.find(t => t.value === params.analysisType)?.desc}
                        </p>
                    </div>

                    {/* 코호트 기간 */}
                    <div>
                        <label className="block text-xs font-medium text-slate-500 mb-1.5">코호트 기준</label>
                        <div className="flex gap-2">
                            <input
                                type="number"
                                value={params.weeksAgo}
                                onChange={(e) => setParams({ ...params, weeksAgo: parseInt(e.target.value) || 4 })}
                                min={2}
                                max={52}
                                className="w-16 px-2 py-2 text-sm border border-slate-200 rounded-lg text-center"
                            />
                            <span className="flex items-center text-sm text-slate-500">주 전부터</span>
                            <input
                                type="number"
                                value={params.windowWeeks}
                                onChange={(e) => setParams({ ...params, windowWeeks: parseInt(e.target.value) || 4 })}
                                min={1}
                                max={12}
                                className="w-16 px-2 py-2 text-sm border border-slate-200 rounded-lg text-center"
                            />
                            <span className="flex items-center text-sm text-slate-500">주간</span>
                        </div>
                    </div>

                    {/* 휴면 기준 */}
                    <div>
                        <label className="block text-xs font-medium text-slate-500 mb-1.5">휴면 판정 기준</label>
                        <select
                            value={params.dormantDays}
                            onChange={(e) => setParams({ ...params, dormantDays: parseInt(e.target.value) })}
                            className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500"
                        >
                            {DORMANT_PRESETS.map((p) => (
                                <option key={p.value} value={p.value}>{p.label}</option>
                            ))}
                        </select>
                        <p className="text-[10px] text-slate-400 mt-1">마지막 방문 후 무방문 시 새 에피소드</p>
                    </div>

                    {/* 적용 버튼 */}
                    <div className="flex items-end">
                        <button
                            onClick={handleApply}
                            disabled={loading}
                            className="w-full px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm rounded-lg transition-colors disabled:opacity-50"
                        >
                            {loading ? '분석 중...' : '분석 시작'}
                        </button>
                    </div>
                </div>

                {/* 분석 기간 표시 */}
                {data?.params && (
                    <div className="mt-4 pt-4 border-t border-slate-100 text-xs text-slate-500">
                        📅 분석 대상: <span className="font-mono font-medium">{data.params.intakeStart}</span> ~
                        <span className="font-mono font-medium"> {data.params.intakeEnd}</span> 기간 초진 환자
                        <span className="ml-3 text-slate-400">(데이터 기준일: {data.params.analysisDate})</span>
                    </div>
                )}
            </div>

            {/* Error State */}
            {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700 text-sm">
                    오류: {error}
                </div>
            )}

            {/* Metrics Cards */}
            {data?.metrics && (
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* 코호트 크기 */}
                    <div className="bg-white rounded-xl border border-slate-200 p-5">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-2xl">👥</span>
                            <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                                코호트
                            </span>
                        </div>
                        <div className="text-3xl font-bold text-slate-800">{data.metrics.cohortSize}</div>
                        <div className="text-xs text-slate-500 mt-1">분석 대상 환자</div>
                        {params.analysisType === 'episode_start' && data.metrics.breakdown && (
                            <div className="mt-2 pt-2 border-t border-slate-100 text-[10px] text-slate-400">
                                신규 {data.metrics.breakdown.firstEverCount} / 재초진 {data.metrics.breakdown.reStartCount}
                            </div>
                        )}
                    </div>

                    {/* 12주 리텐션 */}
                    <div className="bg-white rounded-xl border border-slate-200 p-5">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-2xl">🔄</span>
                            <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                                리텐션
                            </span>
                        </div>
                        <div className="text-3xl font-bold text-slate-800">{data.metrics.retention.week12}%</div>
                        <div className="text-xs text-slate-500 mt-1">12주 재방문률</div>
                        <div className="mt-2 pt-2 border-t border-slate-100 flex gap-3 text-[10px]">
                            <span className="text-slate-500">4주 <span className="font-bold text-slate-700">{data.metrics.retention.week4}%</span></span>
                            <span className="text-slate-500">8주 <span className="font-bold text-slate-700">{data.metrics.retention.week8}%</span></span>
                        </div>
                    </div>

                    {/* 평균 재진 횟수 */}
                    <div className="bg-white rounded-xl border border-slate-200 p-5">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-2xl">📈</span>
                        </div>
                        <div className="text-3xl font-bold text-slate-800">{data.metrics.avgRevisits}</div>
                        <div className="text-xs text-slate-500 mt-1">평균 재진 횟수</div>
                        <div className="text-[10px] text-slate-400 mt-2">12주 내, 초진 제외</div>
                    </div>

                    {/* 첫 재진 리드타임 */}
                    <div className="bg-white rounded-xl border border-slate-200 p-5">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-2xl">⏱️</span>
                        </div>
                        <div className="text-3xl font-bold text-slate-800">
                            {data.metrics.medianFirstRevisitDays !== null
                                ? `${Math.round(data.metrics.medianFirstRevisitDays)}일`
                                : '-'}
                        </div>
                        <div className="text-xs text-slate-500 mt-1">첫 재진까지 (중앙값)</div>
                        <div className="text-[10px] text-slate-400 mt-2">초진→첫 재방문 간격</div>
                    </div>
                </div>
            )}

            {/* Comparison Analysis Table */}
            {data?.metrics && data.metrics.cohortSize > 0 && (
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
                    <div className="flex items-center justify-between mb-4">
                        <h2 className="text-sm font-bold text-slate-700 flex items-center gap-2">
                            <span>📊</span> 비교 분석
                        </h2>
                        <select
                            value={splitBy}
                            onChange={(e) => setSplitBy(e.target.value)}
                            className="px-3 py-1.5 text-sm border border-slate-200 rounded-lg"
                        >
                            {SPLIT_OPTIONS.map((opt) => (
                                <option key={opt.value} value={opt.value}>{opt.label}</option>
                            ))}
                        </select>
                    </div>

                    {compareLoading ? (
                        <div className="py-8 text-center text-slate-400">분석 중...</div>
                    ) : compareData?.results && compareData.results.length > 0 ? (
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead>
                                    <tr className="border-b border-slate-200 text-left">
                                        <th className="py-2 px-3 font-medium text-slate-600">
                                            {SPLIT_OPTIONS.find(o => o.value === splitBy)?.label.replace('별', '')}
                                        </th>
                                        <th className="py-2 px-3 font-medium text-slate-600 text-right">코호트</th>
                                        <th className="py-2 px-3 font-medium text-slate-600 text-right">4주</th>
                                        <th className="py-2 px-3 font-medium text-slate-600 text-right">8주</th>
                                        <th className="py-2 px-3 font-medium text-slate-600 text-right">12주</th>
                                        <th className="py-2 px-3 font-medium text-slate-600 text-right">평균 재진</th>
                                        <th className="py-2 px-3 font-medium text-slate-600 text-right">첫 재진</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {compareData.results.map((row, i) => (
                                        <tr
                                            key={row.splitValue}
                                            className={`border-b border-slate-100 ${i === 0 ? 'bg-indigo-50/50' : ''}`}
                                        >
                                            <td className="py-2.5 px-3 font-medium text-slate-800">
                                                {row.label}
                                                {row.cohortSize < 10 && (
                                                    <span className="ml-2 text-[10px] text-amber-600 bg-amber-50 px-1 py-0.5 rounded">
                                                        표본 적음
                                                    </span>
                                                )}
                                            </td>
                                            <td className="py-2.5 px-3 text-right text-slate-600">{row.cohortSize}명</td>
                                            <td className="py-2.5 px-3 text-right font-mono text-slate-600">{row.retention.week4}%</td>
                                            <td className="py-2.5 px-3 text-right font-mono text-slate-600">{row.retention.week8}%</td>
                                            <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-800">{row.retention.week12}%</td>
                                            <td className="py-2.5 px-3 text-right text-slate-600">{row.avgRevisits}회</td>
                                            <td className="py-2.5 px-3 text-right text-slate-600">
                                                {row.medianFirstRevisitDays !== null
                                                    ? `${Math.round(row.medianFirstRevisitDays)}일`
                                                    : '-'}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    ) : (
                        <div className="py-8 text-center text-slate-400">
                            비교할 데이터가 없습니다
                        </div>
                    )}

                    <div className="mt-3 pt-3 border-t border-slate-100 text-[10px] text-slate-400">
                        💡 표본이 적은 그룹은 결과 변동이 클 수 있습니다. 케이스 믹스(환자 유형)가 다르면 단순 비교에 주의하세요.
                    </div>
                </div>
            )}

            {/* Empty State */}
            {data?.metrics && data.metrics.cohortSize === 0 && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-8 text-center">
                    <div className="text-4xl mb-3">📭</div>
                    <h3 className="text-lg font-bold text-slate-700">분석 대상 없음</h3>
                    <p className="text-sm text-slate-500 mt-1">
                        선택한 기간에 해당하는 초진 환자가 없습니다.<br />
                        기간을 조정하거나 분석 유형을 변경해 보세요.
                    </p>
                </div>
            )}

            {/* Info Card */}
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-5">
                <h3 className="font-bold flex items-center gap-2 text-blue-800">
                    <span>💡</span> 코호트 분석 가이드
                </h3>
                <div className="mt-3 text-sm text-slate-700 space-y-2">
                    <p><strong className="text-blue-700">생애초진</strong>: 환자가 병원에 처음 온 1회. 신규 유입 품질 분석에 적합.</p>
                    <p><strong className="text-blue-700">에피소드초진</strong>: {params.dormantDays}일 이상 방문이 없다가 다시 온 경우도 포함. 서비스 품질 분석에 적합.</p>
                    <p><strong className="text-blue-700">재초진</strong>: 휴면 후 다시 온 환자만. 휴면 재활성화 캠페인 효과 측정에 적합.</p>
                </div>
            </div>
        </div>
    );
}

