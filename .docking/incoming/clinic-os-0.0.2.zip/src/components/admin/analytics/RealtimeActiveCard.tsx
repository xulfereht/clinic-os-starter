import React, { useState, useEffect } from 'react';

interface RealtimeData {
    activeUsers: number;
    topPages: { path: string; views: number }[];
    activeCountries: { country: string; count: number }[];
    trend: { minute: string; views: number }[];
}

export default function RealtimeActiveCard() {
    const [data, setData] = useState<RealtimeData | null>(null);
    const [loading, setLoading] = useState(true);

    const fetchData = async () => {
        try {
            const res = await fetch('/api/admin/analytics/realtime');
            if (res.ok) {
                const json = await res.json();
                setData(json);
            }
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
        const interval = setInterval(fetchData, 10000); // Poll every 10 seconds
        return () => clearInterval(interval);
    }, []);

    if (loading && !data) {
        return (
            <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm h-[200px] animate-pulse">
                <div className="h-4 bg-slate-200 rounded w-1/3 mb-4"></div>
                <div className="h-12 bg-slate-200 rounded w-1/4 mb-8"></div>
            </div>
        );
    }

    if (!data) return null;

    const maxViews = Math.max(...(data.trend?.map(t => t.views) || [0]), 1);

    return (
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm relative overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 relative z-10">
                {/* Left: Big Number & Trend */}
                <div className="flex flex-col justify-between h-full">
                    <div>
                        <h2 className="text-slate-500 text-xs font-bold mb-3 uppercase tracking-wider flex items-center gap-2">
                            <span className="relative flex h-2.5 w-2.5">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
                            </span>
                            실시간 활성 사용자 (최근 30분)
                        </h2>
                        <div className="flex items-end gap-2 mb-4">
                            <div className="text-6xl font-extrabold text-slate-800 tracking-tighter leading-none">{data.activeUsers}</div>
                            <div className="text-sm text-slate-500 font-medium mb-1.5">명 접속 중</div>
                        </div>
                        <p className="text-xs text-slate-400">
                            지금 이 순간 병원을 보고 있는 방문자 수입니다.
                        </p>
                    </div>

                    {/* Sparkline anchored to bottom */}
                    <div className="mt-6 pt-4 border-t border-slate-100">
                        <div className="relative h-12 w-full flex items-end gap-0.5">
                            {data.trend?.map((t, i) => (
                                <div
                                    key={i}
                                    className="bg-indigo-500 rounded-t-sm w-full transition-all hover:bg-indigo-600"
                                    style={{ height: `${Math.max((t.views / maxViews) * 100, 15)}%`, opacity: 0.15 + ((i / (data.trend?.length || 1)) * 0.85) }}
                                    title={`${t.minute}: ${t.views} views`}
                                ></div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Right: Top Pages */}
                <div className="bg-slate-50 rounded-lg p-5 border border-slate-100 flex flex-col h-full">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-sm font-bold text-slate-700 flex items-center gap-2">
                            <span>🔥</span> 지금 많이 보는 페이지
                        </h3>
                        <span className="text-[10px] font-mono text-slate-400 uppercase border border-slate-200 px-1.5 py-0.5 rounded bg-white">
                            Real-time
                        </span>
                    </div>

                    <div className="flex-1 space-y-2">
                        {data.topPages.length > 0 ? data.topPages.slice(0, 3).map((page, i) => {
                            const name = page.path === '/' ? '메인 홈' :
                                page.path.replace('/programs/', '').replace(/-/g, ' ');
                            // Calc pct
                            const totalViews = data.topPages.reduce((acc, curr) => acc + curr.views, 0);
                            const pct = totalViews > 0 ? (page.views / totalViews) * 100 : 0;

                            return (
                                <div key={i} className="relative group">
                                    <div className="flex justify-between items-center text-sm relative z-10 py-1.5 px-2">
                                        <div className="truncate flex-1 pr-4 flex items-center gap-2">
                                            <span className={`text-[10px] w-4 h-4 flex items-center justify-center rounded font-bold ${i === 0 ? 'bg-amber-100 text-amber-700' : 'bg-slate-200 text-slate-500'}`}>
                                                {i + 1}
                                            </span>
                                            <span className="capitalize text-slate-700 font-medium truncate group-hover:text-indigo-600 transition-colors">
                                                {name}
                                            </span>
                                        </div>
                                        <div className="font-mono font-bold text-slate-600 text-xs">{page.views}</div>
                                    </div>
                                    {/* Background Bar */}
                                    <div className="absolute left-0 top-0 bottom-0 bg-white border border-slate-100 rounded md:rounded-r-md -z-0 transition-all duration-500 shadow-sm" style={{ width: `100%` }}></div>
                                    <div className="absolute left-0 top-0 bottom-0 bg-indigo-50/50 rounded -z-0" style={{ width: `${pct}%` }}></div>
                                </div>
                            )
                        }) : (
                            <div className="flex flex-col items-center justify-center h-24 text-slate-400">
                                <svg className="w-8 h-8 opacity-20 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                                </svg>
                                <span className="text-xs">데이터 수집 중...</span>
                            </div>
                        )}
                    </div>

                    <div className="mt-auto pt-3 border-t border-slate-200/60 flex flex-wrap gap-1.5 justify-end">
                        {data.activeCountries.length > 0 ? data.activeCountries.slice(0, 3).map((c, i) => (
                            <span key={i} className="text-[10px] bg-white border border-slate-200 px-2 py-0.5 rounded-full text-slate-500 shadow-sm">
                                {c.country === 'KR' ? '🇰🇷' : c.country || '🌍'} {c.count}
                            </span>
                        )) : (
                            <span className="text-[10px] text-slate-300">위치 정보 없음</span>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
