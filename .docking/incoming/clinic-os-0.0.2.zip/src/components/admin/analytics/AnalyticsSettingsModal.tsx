import React, { useState, useEffect } from 'react';

interface Props {
    isOpen: boolean;
    onClose: () => void;
}

declare global {
    interface Window {
        showToast?: (message: string, type?: 'success' | 'error' | 'info' | 'warning', options?: any) => void;
    }
}

export default function AnalyticsSettingsModal({ isOpen, onClose }: Props) {
    const [blockedIps, setBlockedIps] = useState<string[]>([]);
    const [newIp, setNewIp] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [currentIp, setCurrentIp] = useState('');

    // Fetch config on open
    useEffect(() => {
        if (isOpen) {
            fetchConfig();
            fetchCurrentIp();
        }
    }, [isOpen]);

    const fetchConfig = async () => {
        setIsLoading(true);
        try {
            const res = await fetch('/api/admin/analytics/config');
            const data = await res.json();
            if (data.blockedIps) {
                setBlockedIps(data.blockedIps);
            }
        } catch (e) {
            console.error(e);
            window.showToast?.('설정을 불러오는데 실패했습니다.', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    const fetchCurrentIp = async () => {
        try {
            const res = await fetch('https://api.ipify.org?format=json');
            const data = await res.json();
            setCurrentIp(data.ip);
        } catch (e) {
            // Ignore error
        }
    }

    const handleSave = async () => {
        setIsSaving(true);
        try {
            const res = await fetch('/api/admin/analytics/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ blockedIps })
            });
            if (res.ok) {
                window.showToast?.('저장되었습니다. (반영까지 최대 1분이 소요될 수 있습니다)', 'success');
                onClose();
                window.location.reload(); // To reflect changes in dashboard stats immediately if applicable
            } else {
                window.showToast?.('저장에 실패했습니다.', 'error');
            }
        } catch (e) {
            console.error(e);
            window.showToast?.('저장 중 오류가 발생했습니다.', 'error');
        } finally {
            setIsSaving(false);
        }
    };

    const addIp = () => {
        if (!newIp) return;
        if (blockedIps.includes(newIp)) {
            window.showToast?.('이미 등록된 IP입니다.', 'warning');
            return;
        }
        setBlockedIps([...blockedIps, newIp]);
        setNewIp('');
    };

    const removeIp = (ipToRemove: string) => {
        setBlockedIps(blockedIps.filter(ip => ip !== ipToRemove));
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                    <h3 className="text-lg font-bold text-slate-800">분석 설정</h3>
                    <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
                        ✕
                    </button>
                </div>

                <div className="p-6 space-y-6">
                    <div>
                        <h4 className="text-sm font-bold text-slate-800 mb-2">내부 트래픽 차단 (Blocked IPs)</h4>
                        <p className="text-xs text-slate-500 mb-4">
                            아래 등록된 IP에서의 접속은 통계에 집계되지 않습니다. (병원 내부, 관리자 등)
                        </p>

                        <div className="flex gap-2 mb-4">
                            <input
                                type="text"
                                value={newIp}
                                onChange={(e) => setNewIp(e.target.value)}
                                placeholder="IP 주소 입력 (예: 123.456.789.0)"
                                className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-indigo-500"
                                onKeyDown={(e) => e.key === 'Enter' && addIp()}
                            />
                            <button
                                onClick={addIp}
                                className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-lg text-sm font-medium hover:bg-indigo-100"
                            >
                                추가
                            </button>
                        </div>

                        {currentIp && (
                            <div className="mb-4 text-xs text-slate-500 flex items-center gap-2">
                                <span>현재 접속중인 IP: <strong className="text-indigo-600">{currentIp}</strong></span>
                                <button
                                    onClick={() => setNewIp(currentIp)}
                                    className="text-xs underline hover:text-indigo-600"
                                >
                                    입력하기
                                </button>
                            </div>
                        )}

                        <div className="bg-slate-50 rounded-lg border border-slate-200 divide-y divide-slate-200 max-h-[200px] overflow-y-auto">
                            {isLoading ? (
                                <div className="p-4 text-center text-xs text-slate-400">불러오는 중...</div>
                            ) : blockedIps.length === 0 ? (
                                <div className="p-4 text-center text-xs text-slate-400">등록된 차단 IP가 없습니다.</div>
                            ) : (
                                blockedIps.map(ip => (
                                    <div key={ip} className="px-4 py-3 flex justify-between items-center text-sm">
                                        <span className="font-mono text-slate-600">{ip}</span>
                                        <button
                                            onClick={() => removeIp(ip)}
                                            className="text-red-400 hover:text-red-600 text-xs"
                                        >
                                            삭제
                                        </button>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>

                <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end gap-2">
                    <button
                        onClick={onClose}
                        className="px-4 py-2 text-slate-600 text-sm font-medium hover:bg-slate-100 rounded-lg"
                    >
                        취소
                    </button>
                    <button
                        onClick={handleSave}
                        disabled={isSaving}
                        className="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 disabled:opacity-50"
                    >
                        {isSaving ? '저장 중...' : '저장하기'}
                    </button>
                </div>
            </div>
        </div>
    );
}
