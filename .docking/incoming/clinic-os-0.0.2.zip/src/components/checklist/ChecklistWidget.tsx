import React, { useState } from 'react';

export interface Question {
    id: string;
    text: string;
    options: { label: string; score: number }[];
}

export interface ResultType {
    minScore: number;
    maxScore: number;
    title: string;
    description: string;
    recommendation: string;
}

interface ChecklistWidgetProps {
    id: string;
    title: string;
    questions: Question[];
    results: ResultType[];
}

declare global {
    interface Window {
        showToast?: (message: string, type?: 'success' | 'error' | 'info' | 'warning', options?: any) => void;
    }
}

export default function ChecklistWidget({ id, title, questions, results }: ChecklistWidgetProps) {
    const [answers, setAnswers] = useState<Record<string, number>>({});
    const [showResult, setShowResult] = useState(false);
    const [loading, setLoading] = useState(false);

    const currentScore = Object.values(answers).reduce((a, b) => a + b, 0);
    const isComplete = questions.every(q => answers[q.id] !== undefined);

    const handleSelect = (questionId: string, score: number) => {
        setAnswers(prev => ({ ...prev, [questionId]: score }));
    };

    const submit = async () => {
        setLoading(true);
        try {
            // Find the matching result
            const result = results.find(r => currentScore >= r.minScore && currentScore <= r.maxScore);

            // Send to API
            await fetch('/api/checklist', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    checklistId: id,
                    score: currentScore,
                    answers,
                    resultTitle: result?.title,
                    timestamp: new Date().toISOString()
                })
            });

            setShowResult(true);
        } catch (e) {
            console.error(e);
            window.showToast?.('오류가 발생했습니다.', 'error');
        } finally {
            setLoading(false);
        }
    };

    const getResult = () => {
        return results.find(r => currentScore >= r.minScore && currentScore <= r.maxScore);
    };

    if (showResult) {
        const result = getResult();
        if (!result) return <div>결과를 찾을 수 없습니다.</div>;

        return (
            <div className="bg-[color:var(--bg-surface)] p-8 rounded-2xl shadow-lg border border-[color:var(--border-subtle)] text-center animate-fade-in">
                <div className="inline-block px-4 py-1 mb-4 text-sm font-bold text-[color:var(--accent-strong)] bg-[color:var(--accent-soft)] rounded-full">
                    진단 결과
                </div>
                <h2 className="text-2xl font-bold text-[color:var(--text-main)] mb-2">{result.title}</h2>
                <div className="w-16 h-1 bg-[color:var(--accent)] mx-auto mb-6 rounded-full"></div>

                <p className="text-[color:var(--text-muted)] mb-8 leading-relaxed whitespace-pre-line">
                    {result.description}
                </p>

                <div className="bg-[color:var(--surface-elevated)] p-6 rounded-xl mb-8 text-left border border-[color:var(--border-subtle)]">
                    <h3 className="font-bold text-[color:var(--text-main)] mb-2">💡 닥터의 조언</h3>
                    <p className="text-[color:var(--text-muted)]">{result.recommendation}</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                    <button
                        onClick={() => window.location.reload()}
                        className="px-6 py-3 border border-[color:var(--border-subtle)] text-[color:var(--text-muted)] rounded-lg hover:bg-[color:var(--bg-surface)] transition-colors"
                    >
                        다시 하기
                    </button>
                    <button
                        onClick={() => window.location.href = '/intake'}
                        className="px-6 py-3 bg-[color:var(--accent)] text-[color:var(--text-on-accent)] rounded-lg hover:opacity-90 transition-colors font-bold shadow-md"
                    >
                        상담 예약하기
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="max-w-2xl mx-auto">
            <div className="bg-[color:var(--bg-surface)] p-6 md:p-8 rounded-2xl shadow-sm border border-[color:var(--border-subtle)]">
                <h2 className="text-2xl font-bold text-[color:var(--text-main)] mb-6 text-center">{title}</h2>

                <div className="space-y-8">
                    {questions.map((q, idx) => (
                        <div key={q.id} className="pb-6 border-b border-[color:var(--border-subtle)] last:border-0">
                            <h3 className="text-lg font-medium text-[color:var(--text-main)] mb-4">
                                <span className="text-[color:var(--accent)] mr-2">Q{idx + 1}.</span>
                                {q.text}
                            </h3>
                            <div className="flex gap-3">
                                {q.options.map((opt, i) => (
                                    <button
                                        key={i}
                                        onClick={() => handleSelect(q.id, opt.score)}
                                        className={`flex-1 py-3 px-4 rounded-xl transition-all font-medium ${answers[q.id] === opt.score
                                            ? 'bg-[color:var(--accent)] text-[color:var(--text-on-accent)] shadow-md transform scale-[1.02]'
                                            : 'bg-[color:var(--surface-elevated)] text-[color:var(--text-muted)] hover:bg-[color:var(--accent-soft)] border border-[color:var(--border-subtle)]'
                                            }`}
                                    >
                                        {opt.label}
                                    </button>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>

                <div className="mt-8 pt-6 border-t border-[color:var(--border-subtle)] text-center">
                    <button
                        onClick={submit}
                        disabled={!isComplete || loading}
                        className="w-full md:w-auto px-10 py-4 bg-[color:var(--accent)] text-[color:var(--text-on-accent)] rounded-xl font-bold text-lg hover:opacity-90 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
                    >
                        {loading ? '분석 중...' : '결과 보기'}
                    </button>
                    {!isComplete && (
                        <p className="text-sm text-[color:var(--text-subtle)] mt-3">모든 문항에 답변해 주세요.</p>
                    )}
                </div>
            </div>
        </div>
    );
}
