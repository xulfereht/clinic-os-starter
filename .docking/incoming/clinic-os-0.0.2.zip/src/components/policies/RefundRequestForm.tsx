import { useState } from 'react';

interface RefundRequestFormProps {
    locale: 'ko' | 'en' | 'ja' | 'zh-hans' | 'vi';
}

const translations = {
    ko: {
        title: '환불/취소 요청',
        nameLabel: '이름',
        namePlaceholder: '홍길동',
        phoneLabel: '연락처',
        phonePlaceholder: '010-1234-5678',
        orderInfoLabel: '결제 정보 (주문 일자, 결제 금액 등)',
        orderInfoPlaceholder: '예: 2024년 12월 25일 결제, 150,000원',
        reasonLabel: '환불/취소 사유',
        reasonPlaceholder: '환불 또는 취소를 원하시는 사유를 자세히 설명해주세요.',
        submitBtn: '환불 요청하기',
        submitting: '요청 중...',
        successTitle: '요청 완료',
        successMessage: '환불/취소 요청이 정상적으로 접수되었습니다. 담당자가 확인 후 연락드리겠습니다.',
        errorMessage: '요청 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.',
        requiredField: '필수 입력 항목입니다.',
    },
    en: {
        title: 'Refund/Cancellation Request',
        nameLabel: 'Name',
        namePlaceholder: 'John Doe',
        phoneLabel: 'Phone',
        phonePlaceholder: '+82-10-1234-5678',
        orderInfoLabel: 'Payment Info (order date, amount, etc.)',
        orderInfoPlaceholder: 'e.g., Paid on Dec 25, 2024, KRW 150,000',
        reasonLabel: 'Reason for Refund/Cancellation',
        reasonPlaceholder: 'Please explain the reason for your refund or cancellation request.',
        submitBtn: 'Submit Request',
        submitting: 'Submitting...',
        successTitle: 'Request Submitted',
        successMessage: 'Your refund/cancellation request has been received. We will contact you shortly.',
        errorMessage: 'An error occurred. Please try again later.',
        requiredField: 'This field is required.',
    },
    ja: {
        title: '返金/キャンセルリクエスト',
        nameLabel: 'お名前',
        namePlaceholder: '山田太郎',
        phoneLabel: '電話番号',
        phonePlaceholder: '010-1234-5678',
        orderInfoLabel: '決済情報（注文日、金額など）',
        orderInfoPlaceholder: '例：2024年12月25日決済、150,000ウォン',
        reasonLabel: '返金/キャンセル理由',
        reasonPlaceholder: '返金またはキャンセルを希望する理由を詳しく説明してください。',
        submitBtn: 'リクエストを送信',
        submitting: '送信中...',
        successTitle: 'リクエスト完了',
        successMessage: '返金/キャンセルリクエストが正常に受け付けられました。担当者が確認後、ご連絡いたします。',
        errorMessage: 'エラーが発生しました。しばらくしてからもう一度お試しください。',
        requiredField: '必須入力項目です。',
    },
    'zh-hans': {
        title: '退款/取消申请',
        nameLabel: '姓名',
        namePlaceholder: '张三',
        phoneLabel: '联系电话',
        phonePlaceholder: '010-1234-5678',
        orderInfoLabel: '支付信息（订单日期、金额等）',
        orderInfoPlaceholder: '例如：2024年12月25日支付，150,000韩元',
        reasonLabel: '退款/取消原因',
        reasonPlaceholder: '请详细说明您希望退款或取消的原因。',
        submitBtn: '提交申请',
        submitting: '提交中...',
        successTitle: '申请已提交',
        successMessage: '您的退款/取消申请已成功提交。我们会尽快与您联系。',
        errorMessage: '发生错误，请稍后重试。',
        requiredField: '此项为必填项。',
    },
    vi: {
        title: 'Yêu cầu hoàn tiền/hủy',
        nameLabel: 'Họ tên',
        namePlaceholder: 'Nguyễn Văn A',
        phoneLabel: 'Số điện thoại',
        phonePlaceholder: '010-1234-5678',
        orderInfoLabel: 'Thông tin thanh toán (ngày, số tiền)',
        orderInfoPlaceholder: 'Ví dụ: Thanh toán ngày 25/12/2024, 150,000 KRW',
        reasonLabel: 'Lý do hoàn tiền/hủy',
        reasonPlaceholder: 'Vui lòng giải thích lý do bạn muốn hoàn tiền hoặc hủy.',
        submitBtn: 'Gửi yêu cầu',
        submitting: 'Đang gửi...',
        successTitle: 'Đã gửi yêu cầu',
        successMessage: 'Yêu cầu hoàn tiền/hủy của bạn đã được tiếp nhận. Chúng tôi sẽ liên hệ với bạn sớm.',
        errorMessage: 'Đã xảy ra lỗi. Vui lòng thử lại sau.',
        requiredField: 'Trường này là bắt buộc.',
    }
};

export default function RefundRequestForm({ locale }: RefundRequestFormProps) {
    const t = translations[locale] || translations.ko;

    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [orderInfo, setOrderInfo] = useState('');
    const [reason, setReason] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setIsSubmitting(true);

        try {
            const payload = {
                patient: {
                    name,
                    contact: { phone }
                },
                meta: {
                    leadType: 'refund',
                    serviceType: 'refund',
                    patientType: 'returning'
                },
                chiefComplaints: [{
                    description: `[환불/취소 요청]\n결제 정보: ${orderInfo}\n사유: ${reason}`
                }],
                context: {}
            };

            const res = await fetch('/api/intake', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!res.ok) throw new Error('Server error');

            setSubmitted(true);
        } catch (err) {
            setError(t.errorMessage);
        } finally {
            setIsSubmitting(false);
        }
    };

    if (submitted) {
        return (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-8 text-center">
                <div className="text-4xl mb-4">✅</div>
                <h3 className="text-xl font-bold text-emerald-800 mb-2">{t.successTitle}</h3>
                <p className="text-emerald-700">{t.successMessage}</p>
            </div>
        );
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-5">
            <h3 className="text-lg font-bold text-slate-900 mb-4">{t.title}</h3>

            <div className="grid sm:grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">{t.nameLabel} *</label>
                    <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                        placeholder={t.namePlaceholder}
                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-slate-500 focus:ring-2 focus:ring-slate-100 outline-none transition-colors"
                    />
                </div>
                <div>
                    <label className="block text-sm font-bold text-slate-700 mb-1">{t.phoneLabel} *</label>
                    <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        required
                        placeholder={t.phonePlaceholder}
                        className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-slate-500 focus:ring-2 focus:ring-slate-100 outline-none transition-colors"
                    />
                </div>
            </div>

            <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">{t.orderInfoLabel} *</label>
                <input
                    type="text"
                    value={orderInfo}
                    onChange={(e) => setOrderInfo(e.target.value)}
                    required
                    placeholder={t.orderInfoPlaceholder}
                    className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-slate-500 focus:ring-2 focus:ring-slate-100 outline-none transition-colors"
                />
            </div>

            <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">{t.reasonLabel} *</label>
                <textarea
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    required
                    rows={4}
                    placeholder={t.reasonPlaceholder}
                    className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-slate-500 focus:ring-2 focus:ring-slate-100 outline-none transition-colors resize-none"
                />
            </div>

            {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                    {error}
                </div>
            )}

            <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto px-10 py-3.5 bg-slate-900 text-white font-bold rounded-full hover:bg-black hover:-translate-y-0.5 shadow-md hover:shadow-lg disabled:bg-slate-300 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center gap-2"
            >
                {isSubmitting ? (
                    <>
                        <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        {t.submitting}
                    </>
                ) : t.submitBtn}
            </button>
        </form>
    );
}
