import { useState, useEffect } from "react";
import type { IntakePayload, IntakeResponse } from "../../lib/intake-schema";
import { Input } from "../ui/Input";
import { Select } from "../ui/Select";
import { Textarea } from "../ui/Textarea";
import { Button } from "../ui/Button";

type Step = "SERVICE" | "PATIENT_TYPE" | "BASIC_INFO" | "SUCCESS" | "DETAILED_INFO";
type ServiceType = "diet" | "general";
type PatientType = "new" | "returning";

interface Program {
    id: string;
    title: string;
}

declare global {
    interface Window {
        showToast?: (message: string, type?: 'success' | 'error' | 'info' | 'warning', options?: any) => void;
    }
}

export default function IntakeWizard() {
    const [step, setStep] = useState<Step>("SERVICE");
    const [serviceType, setServiceType] = useState<ServiceType | null>(null);
    const [patientType, setPatientType] = useState<PatientType | null>(null);
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState<IntakeResponse | null>(null);
    const [programs, setPrograms] = useState<Program[]>([]);

    // Source Tracking
    const [diagnosisResult, setDiagnosisResult] = useState<string | null>(null);
    const [source, setSource] = useState<string>("direct");

    // Basic Form Data
    const [basicForm, setBasicForm] = useState({
        name: "",
        phone: "",
        gender: "",
        age: "",
        preferredTime: "",
        program: "" // New field for specific program
    });

    // Detailed Form Data
    const [detailedForm, setDetailedForm] = useState({
        // Diet
        height: "",
        weight: "",
        weightHistory: "",
        dietPattern: "",
        sleepStress: "",
        pastDiet: "",
        riskFlags: "",
        goal: "",
        weightChange: "",
        compliance: "",
        sideEffects: "",
        nextGoal: "",
        // General
        visitPurpose: [] as string[],
        chiefComplaint: "",
        duration: "",
        symptomUpdate: ""
    });

    useEffect(() => {
        // Fetch programs
        fetch("/api/programs")
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) {
                    setPrograms(data);
                }
            })
            .catch(console.error);

        // Check for diagnosis result and source in URL
        const params = new URLSearchParams(window.location.search);
        const diagnosis = params.get("diagnosis_result");
        const src = params.get("source");

        if (diagnosis) {
            setDiagnosisResult(decodeURIComponent(diagnosis));
            // If diagnosis exists, we might want to default to a specific service type
            // For now, let's assume diet if it comes from diet mini-diagnosis
            // But better to let user choose or pass service type in URL too
        }
        if (src) {
            setSource(src);
        }
    }, []);

    const updateBasic = (field: string, value: any) => {
        setBasicForm((prev) => ({ ...prev, [field]: value }));
    };

    const updateDetailed = (field: string, value: any) => {
        setDetailedForm((prev) => ({ ...prev, [field]: value }));
    };

    const handleServiceSelect = (type: ServiceType) => {
        setServiceType(type);
        // If diet, program is automatically 'diet'
        if (type === 'diet') {
            updateBasic('program', 'diet');
        } else {
            updateBasic('program', ''); // Reset for general to let user choose
        }
        setStep("PATIENT_TYPE");
    };

    const handlePatientTypeSelect = (type: PatientType) => {
        setPatientType(type);
        setStep("BASIC_INFO");
    };

    // Phone Validation
    const isValidPhone = (phone: string) => {
        const regex = /^010-\d{4}-\d{4}$/;
        return regex.test(phone);
    };

    const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        let value = e.target.value.replace(/[^0-9]/g, "");
        if (value.length > 3 && value.length <= 7) {
            value = value.slice(0, 3) + "-" + value.slice(3);
        } else if (value.length > 7) {
            value = value.slice(0, 3) + "-" + value.slice(3, 7) + "-" + value.slice(7, 11);
        }
        updateBasic("phone", value);
    };

    const submitBasic = async () => {
        setLoading(true);
        try {
            let leadType = "";
            let label = "";

            if (serviceType === "diet") {
                leadType = patientType === "new" ? "tele-diet-first" : "tele-diet-followup";
                label = patientType === "new" ? "비대면 다이어트 초진" : "비대면 다이어트 재진";
            } else {
                leadType = patientType === "new" ? "inperson-first" : "inperson-followup";
                label = patientType === "new" ? "내원 초진 예약" : "내원 재진 예약";
            }

            // Step 1 only has Name and Phone now.
            let description = `[기본정보] 이름:${basicForm.name}, 연락처:${basicForm.phone}`;

            // Add Program info if selected
            if (basicForm.program && basicForm.program !== 'diet') {
                const selectedProgram = programs.find(p => p.id === basicForm.program);
                const programName = selectedProgram ? selectedProgram.title : basicForm.program;
                description += `\n[관심프로그램] ${programName}`;
            }

            // Add Source and Diagnosis Context
            if (source !== "direct") {
                description += `\n[유입경로] ${source}`;
            }
            if (diagnosisResult) {
                description += `\n[진단결과] ${diagnosisResult}`;
            }

            const payload: any = {
                patient: {
                    name: basicForm.name,
                    contact: { phone: basicForm.phone, channel: "kakao" }
                },
                meta: {
                    source, // Track source in meta
                    serviceType: basicForm.program || serviceType, // Send specific program as serviceType if available
                    patientType,
                    leadType
                },
                chiefComplaints: [{
                    label,
                    description
                }],
                context: {
                    visitType: serviceType === "diet" ? "remote" : "visit",
                    preferredTime: null // Will be updated in Step 2
                }
            };

            const res = await fetch("/api/intake", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            const data = await res.json();
            setResult(data); // Contains leadId
            setStep("SUCCESS");
        } catch (e) {
            window.showToast?.("전송 중 오류가 발생했습니다.", 'error');
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const submitDetailed = async () => {
        if (!result?.leadId) return;
        setLoading(true);
        try {
            // Construct detailed description based on service/patient type
            let details = "";
            let tags: string[] = [];

            // Common info (Gender, Age, Time) - Now in Step 2
            const commonInfo = `[상세정보] 성별:${basicForm.gender}, 나이:${basicForm.age}\n[희망예약] ${basicForm.preferredTime}`;

            if (serviceType === "diet") {
                if (patientType === "new") {
                    details = `[신체] ${detailedForm.height}cm/${detailedForm.weight}kg\n[변화] ${detailedForm.weightHistory}\n[패턴] ${detailedForm.dietPattern}\n[수면/스트레스] ${detailedForm.sleepStress}\n[과거력] ${detailedForm.pastDiet}\n[위험군] ${detailedForm.riskFlags}\n[목표] ${detailedForm.goal}`;
                } else {
                    details = `[체중변화] ${detailedForm.weightChange}\n[복약순응] ${detailedForm.compliance}\n[불편사항] ${detailedForm.sideEffects}\n[다음목표] ${detailedForm.nextGoal}`;
                }
            } else {
                if (patientType === "new") {
                    details = `[주증상] ${detailedForm.chiefComplaint}\n[기간] ${detailedForm.duration}`;
                    tags = detailedForm.visitPurpose;
                } else {
                    details = `[증상메모] ${detailedForm.symptomUpdate}`;
                }
            }

            // Reconstruct initial summary to append
            // We need to preserve what was sent in Step 1
            let initialSummary = `[기본정보] 이름:${basicForm.name}, 연락처:${basicForm.phone}`;
            if (source !== "direct") {
                initialSummary += `\n[유입경로] ${source}`;
            }
            if (diagnosisResult) {
                initialSummary += `\n[진단결과] ${diagnosisResult}`;
            }

            const fullSummary = initialSummary + "\n\n" + commonInfo + "\n" + details;

            const res = await fetch(`/api/leads/${result.leadId}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    summary: fullSummary,
                    symptoms: tags, // This will update the symptoms column (JSON array)
                    visit_date: basicForm.preferredTime // Update visit_date if possible (API might need update or we just rely on summary)
                })
            });

            if (!res.ok) throw new Error("Failed to update");

            await new Promise(r => setTimeout(r, 500)); // Small delay for UX

            window.showToast?.("상세 정보가 추가되었습니다. 꼼꼼하게 진료해 드리겠습니다!", 'success');
            setTimeout(() => window.location.reload(), 1000);

        } catch (e) {
            console.error(e);
            window.showToast?.("오류가 발생했습니다.", 'error');
        } finally {
            setLoading(false);
        }
    };

    if (step === "SUCCESS") {
        return (
            <div className="bg-[color:var(--bg-surface)] p-8 rounded-xl text-center animate-fade-in border border-[color:var(--border-subtle)]">
                <div className="text-5xl mb-4">✅</div>
                <h2 className="text-2xl font-bold text-[color:var(--text-main)] mb-2">접수가 완료되었습니다!</h2>
                <p className="text-[color:var(--text-muted)] mb-8">
                    {serviceType === "diet"
                        ? "담당 의료진이 확인 후 연락드리겠습니다."
                        : "예약 확정을 위해 알림을 보내드렸습니다."}
                </p>

                <div className="bg-[color:var(--bg-subtle)] p-6 rounded-xl mb-6 text-left">
                    <h3 className="font-bold text-[color:var(--text-main)] mb-2">더 정확한 진료를 원하시나요?</h3>
                    <p className="text-sm text-[color:var(--text-muted)] mb-4">
                        추가 정보를 입력해주시면, 진료 시간이 단축되고 더 깊이 있는 상담이 가능합니다.
                    </p>
                    <Button onClick={() => setStep("DETAILED_INFO")} className="w-full">
                        상세 정보 입력하기 (권장)
                    </Button>
                </div>

                <button
                    onClick={() => window.location.reload()}
                    className="text-[color:var(--text-subtle)] hover:text-[color:var(--text-main)] text-sm underline"
                >
                    다음에 입력하기 (홈으로)
                </button>
            </div>
        );
    }

    if (step === "DETAILED_INFO") {
        return (
            <div className="max-w-xl mx-auto bg-[color:var(--bg-surface)] p-6 rounded-xl shadow-lg border border-[color:var(--border-subtle)]">
                <h2 className="text-xl font-bold text-[color:var(--text-main)] mb-6">상세 정보 입력</h2>

                <div className="space-y-6">
                    {/* Common Fields Moved from Step 1 */}
                    <div className="p-4 bg-[color:var(--bg-subtle)] rounded-lg space-y-4">
                        <h3 className="font-bold text-sm text-[color:var(--text-muted)]">필수 추가 정보</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <Select
                                value={basicForm.gender}
                                onChange={e => updateBasic("gender", e.target.value)}
                                placeholder="성별 선택"
                                options={[
                                    { value: "male", label: "남성" },
                                    { value: "female", label: "여성" }
                                ]}
                            />
                            <Input type="number" placeholder="나이 (만)" value={basicForm.age} onChange={e => updateBasic("age", e.target.value)} />
                        </div>
                        <Input
                            label="희망 예약/상담 시간"
                            placeholder="예: 평일 오후 2시 이후, 토요일 오전 등"
                            value={basicForm.preferredTime}
                            onChange={e => updateBasic("preferredTime", e.target.value)}
                        />
                    </div>

                    {/* Dynamic Detailed Form based on Service/Patient Type */}
                    {serviceType === "diet" && patientType === "new" && (
                        <>
                            <div className="grid grid-cols-2 gap-4">
                                <Input type="number" placeholder="키 (cm)" value={detailedForm.height} onChange={e => updateDetailed("height", e.target.value)} />
                                <Input type="number" placeholder="몸무게 (kg)" value={detailedForm.weight} onChange={e => updateDetailed("weight", e.target.value)} />
                            </div>
                            <Textarea className="h-20" placeholder="최근 체중 변화" value={detailedForm.weightHistory} onChange={e => updateDetailed("weightHistory", e.target.value)} />
                            <Textarea className="h-20" placeholder="식사 패턴 (야식, 음주 등)" value={detailedForm.dietPattern} onChange={e => updateDetailed("dietPattern", e.target.value)} />
                            <Textarea className="h-20" placeholder="수면/스트레스" value={detailedForm.sleepStress} onChange={e => updateDetailed("sleepStress", e.target.value)} />
                            <Textarea className="h-20" placeholder="과거 다이어트 경험" value={detailedForm.pastDiet} onChange={e => updateDetailed("pastDiet", e.target.value)} />
                            <Textarea className="h-20" placeholder="질환/복용약" value={detailedForm.riskFlags} onChange={e => updateDetailed("riskFlags", e.target.value)} />
                            <Input placeholder="목표 체중" value={detailedForm.goal} onChange={e => updateDetailed("goal", e.target.value)} />
                        </>
                    )}

                    {serviceType === "diet" && patientType === "returning" && (
                        <>
                            <Textarea className="h-20" placeholder="지난 기간 체중 변화" value={detailedForm.weightChange} onChange={e => updateDetailed("weightChange", e.target.value)} />
                            <Textarea className="h-20" placeholder="약 복용 순응도" value={detailedForm.compliance} onChange={e => updateDetailed("compliance", e.target.value)} />
                            <Textarea className="h-20" placeholder="불편사항" value={detailedForm.sideEffects} onChange={e => updateDetailed("sideEffects", e.target.value)} />
                            <Input placeholder="다음 목표" value={detailedForm.nextGoal} onChange={e => updateDetailed("nextGoal", e.target.value)} />
                        </>
                    )}

                    {serviceType === "general" && patientType === "new" && (
                        <>
                            <Textarea className="h-24" placeholder="주증상" value={detailedForm.chiefComplaint} onChange={e => updateDetailed("chiefComplaint", e.target.value)} />
                            <Input placeholder="증상 기간" value={detailedForm.duration} onChange={e => updateDetailed("duration", e.target.value)} />
                        </>
                    )}

                    {serviceType === "general" && patientType === "returning" && (
                        <>
                            <Textarea className="h-24" placeholder="증상 변화 및 하실 말씀" value={detailedForm.symptomUpdate} onChange={e => updateDetailed("symptomUpdate", e.target.value)} />
                        </>
                    )}

                    <Button onClick={submitDetailed} isLoading={loading} className="w-full py-4 text-lg shadow-lg">
                        상세 정보 저장하기
                    </Button>
                    <button onClick={() => window.location.reload()} className="w-full py-3 text-gray-500 mt-2">
                        건너뛰기
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="max-w-xl mx-auto bg-[color:var(--bg-surface)] p-6 rounded-xl shadow-lg border border-[color:var(--border-subtle)] min-h-[400px]">
            {/* Step 1: Service Selection */}
            {step === "SERVICE" && (
                <div className="animate-fade-in space-y-6">
                    <h2 className="text-2xl font-bold text-[color:var(--text-main)] text-center">어떤 진료를 원하시나요?</h2>
                    <div className="grid grid-cols-1 gap-4">
                        <button
                            onClick={() => handleServiceSelect("diet")}
                            className="p-6 border-2 border-[color:var(--border-subtle)] rounded-xl hover:border-[color:var(--theme-primary)] hover:bg-[color:var(--bg-subtle)] transition-all text-left group"
                        >
                            <div className="text-xl font-bold text-[color:var(--text-main)] group-hover:text-[color:var(--theme-primary)] mb-1">💊 비대면 다이어트</div>
                            <p className="text-[color:var(--text-muted)] text-sm">집에서 편하게 처방받는 다이어트 한약</p>
                        </button>
                        <button
                            onClick={() => handleServiceSelect("general")}
                            className="p-6 border-2 border-[color:var(--border-subtle)] rounded-xl hover:border-[color:var(--theme-primary)] hover:bg-[color:var(--bg-subtle)] transition-all text-left group"
                        >
                            <div className="text-xl font-bold text-[color:var(--text-main)] group-hover:text-[color:var(--theme-primary)] mb-1">🏥 일반 진료 / 통증</div>
                            <p className="text-[color:var(--text-muted)] text-sm">통증, 소화기, 피부질환 등 내원 치료</p>
                        </button>
                    </div>
                </div>
            )}

            {/* Step 2: Patient Type */}
            {step === "PATIENT_TYPE" && (
                <div className="animate-fade-in space-y-6">
                    <button onClick={() => setStep("SERVICE")} className="text-sm text-[color:var(--text-subtle)] hover:text-[color:var(--text-main)]">← 뒤로</button>
                    <h2 className="text-2xl font-bold text-[color:var(--text-main)] text-center">방문하신 적이 있나요?</h2>
                    <div className="grid grid-cols-2 gap-4">
                        <button
                            onClick={() => handlePatientTypeSelect("new")}
                            className="p-8 border border-[color:var(--border-subtle)] rounded-xl hover:bg-[color:var(--bg-subtle)] hover:border-[color:var(--theme-primary)] text-[color:var(--text-main)] font-bold text-lg transition-all"
                        >
                            처음입니다 (초진)
                        </button>
                        <button
                            onClick={() => handlePatientTypeSelect("returning")}
                            className="p-8 border border-[color:var(--border-subtle)] rounded-xl hover:bg-[color:var(--bg-subtle)] hover:border-[color:var(--theme-primary)] text-[color:var(--text-main)] font-bold text-lg transition-all"
                        >
                            재진입니다
                        </button>
                    </div>
                </div>
            )}

            {/* Step 3: Basic Info (Mandatory) */}
            {step === "BASIC_INFO" && (
                <div className="animate-fade-in space-y-4">
                    <button onClick={() => setStep("PATIENT_TYPE")} className="text-sm text-[color:var(--text-subtle)] hover:text-[color:var(--text-main)]">← 뒤로</button>
                    <h2 className="text-xl font-bold text-[color:var(--text-main)]">기본 정보 입력</h2>

                    {diagnosisResult && (
                        <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mb-4">
                            <p className="text-sm text-blue-800 font-bold">💡 진단 결과가 연동되었습니다</p>
                            <p className="text-sm text-blue-600">{diagnosisResult}</p>
                        </div>
                    )}

                    {/* Program Selection for General Treatment */}
                    {serviceType === 'general' && (
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-[color:var(--text-muted)] mb-2">
                                진료 희망 분야 (선택)
                            </label>
                            <div className="grid grid-cols-3 gap-2">
                                {programs.map((prog) => (
                                    <button
                                        key={prog.id}
                                        onClick={() => updateBasic('program', prog.id)}
                                        className={`py-2 px-1 rounded-lg text-sm border transition-all ${basicForm.program === prog.id
                                            ? 'bg-blue-50 border-blue-500 text-blue-700 font-bold'
                                            : 'bg-[color:var(--bg-surface)] border-[color:var(--border-subtle)] text-[color:var(--text-muted)] hover:bg-[color:var(--bg-subtle)]'
                                            }`}
                                    >
                                        {prog.title}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}

                    <div className="grid grid-cols-1 gap-4">
                        <Input placeholder="이름" value={basicForm.name} onChange={e => updateBasic("name", e.target.value)} />
                        <Input
                            placeholder="연락처 (010-0000-0000)"
                            value={basicForm.phone}
                            onChange={handlePhoneChange}
                            error={basicForm.phone && !isValidPhone(basicForm.phone) ? "올바른 전화번호 형식이 아닙니다" : undefined}
                        />
                    </div>

                    <Button
                        onClick={submitBasic}
                        disabled={loading || !basicForm.name || !isValidPhone(basicForm.phone)}
                        isLoading={loading}
                        className="w-full py-4 text-lg shadow-lg mt-4"
                    >
                        간편 접수하기
                    </Button>
                    <p className="text-xs text-center text-[color:var(--text-subtle)] mt-2">
                        접수 후 상세 정보를 추가로 입력하실 수 있습니다.
                    </p>
                </div>
            )}
        </div>
    );
}
