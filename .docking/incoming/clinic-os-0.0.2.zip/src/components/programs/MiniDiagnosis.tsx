import { useState } from "react";
import { type DiagnosisResult, type DiagnosisQuestion, DIAGNOSIS_DATA } from "../../lib/diagnosis-data";

interface MiniDiagnosisProps {
    programId: string;
    title: string;
    questions: DiagnosisQuestion[];
    results?: DiagnosisResult[];
    disclaimer?: string;
    locale?: string;
}

// Translations for UI strings
const translations: Record<string, Record<string, string>> = {
    diagnosisResult: {
        ko: '진단 결과',
        en: 'Diagnosis Result',
        ja: '診断結果',
        'zh-hans': '诊断结果',
        vi: 'Kết Quả Chẩn Đoán'
    },
    disclaimer: {
        ko: '* 이 결과는 간이 진단이며, 정확한 상태는 의료진과의 상담이 필요합니다.',
        en: '* This is a simple screening result. Please consult with a medical professional for accurate assessment.',
        ja: '* この結果は簡易診断です。正確な状態については医療スタッフにご相談ください。',
        'zh-hans': '* 此结果仅为简易诊断，准确情况请咨询医生。',
        vi: '* Đây là kết quả sàng lọc đơn giản. Vui lòng tham khảo ý kiến chuyên gia y tế để đánh giá chính xác.'
    },
    ctaButton: {
        ko: '맞춤 상담 신청하기 (무료)',
        en: 'Request Free Consultation',
        ja: '無料相談を申し込む',
        'zh-hans': '申请免费咨询',
        vi: 'Đăng Ký Tư Vấn Miễn Phí'
    },
    retryButton: {
        ko: '다시 하기',
        en: 'Try Again',
        ja: 'もう一度',
        'zh-hans': '再试一次',
        vi: 'Thử Lại'
    },
    scoreUnit: {
        ko: '점',
        en: 'pts',
        ja: '点',
        'zh-hans': '分',
        vi: 'điểm'
    }
};

export default function MiniDiagnosis({ programId, title, questions, results, disclaimer, locale = 'ko' }: MiniDiagnosisProps) {
    // Translation helper
    const t = (key: string) => translations[key]?.[locale] || translations[key]?.['ko'] || '';
    const [step, setStep] = useState(0);
    const [scores, setScores] = useState<number[]>([]);
    const [selectedOptions, setSelectedOptions] = useState<{ score: number, redFlag?: boolean, value?: string }[]>([]);
    const [finished, setFinished] = useState(false);
    const [resultState, setResultState] = useState<{
        level: string,
        title: string,
        subtitle?: string,
        description: string,
        score: number,
        params: string,
        tags?: string[],
        ctaHeadline?: string,
        ctaBody?: string,
        ctaLink?: string
    } | null>(null);

    const handleAnswer = (option: { score: number, redFlag?: boolean, value?: string }) => {
        const newScores = [...scores, option.score];
        const newSelectedOptions = [...selectedOptions, option];

        setScores(newScores);
        setSelectedOptions(newSelectedOptions);

        if (step < questions.length - 1) {
            setStep(step + 1);
        } else {
            finish(newScores, newSelectedOptions);
        }
    };

    const finish = (finalScores: number[], finalOptions: { score: number, redFlag?: boolean, value?: string }[]) => {
        setFinished(true);
        const totalScore = finalScores.reduce((a, b) => a + b, 0);
        const hasRedFlag = finalOptions.some(o => o.redFlag);

        let match: DiagnosisResult | undefined;

        if (results && results.length > 0) {
            if (hasRedFlag) {
                // Force High Risk if Red Flag exists
                match = results.find(r => r.level === 'high');
            }

            if (!match) {
                // Find matching result by score
                match = results.find(r => totalScore >= r.minScore && totalScore <= r.maxScore);
            }

            // Fallback
            if (!match) {
                match = results[results.length - 1];
            }
        }

        if (!match) {
            return;
        }

        // --- Deepening Logic: Apply Program Variants based on Q1 ---
        // We assume Q1 (index 0) determines the "Category" or "Symptom Type"
        // ONLY apply for Korean locale - variant titles/tags are not translated
        const q1Value = finalOptions[0]?.value;
        let finalResult = { ...match }; // Clone to avoid mutating original data

        if (locale === 'ko' && q1Value && DIAGNOSIS_DATA[programId]?.programVariants) {
            const variant = DIAGNOSIS_DATA[programId].programVariants?.find(v => v.id === q1Value);
            if (variant && variant.resultOverrides && variant.resultOverrides[match.level]) {
                const override = variant.resultOverrides[match.level];
                finalResult = { ...finalResult, ...override };
            }
        }
        // -----------------------------------------------------------

        // Set result state for display
        const params = new URLSearchParams();
        const resultSummary = `[${title}] ${finalResult.title} (${finalResult.level.toUpperCase()}) - ${totalScore}${t('scoreUnit')}${hasRedFlag ? ' (Red Flag)' : ''}`;
        params.set("diagnosis_result", resultSummary);

        setResultState({
            level: finalResult.level,
            title: finalResult.title,
            subtitle: finalResult.subtitle,
            description: finalResult.description,
            score: totalScore,
            params: params.toString(),
            tags: finalResult.tags,
            ctaHeadline: finalResult.ctaHeadline,
            ctaBody: finalResult.ctaBody,
            ctaLink: finalResult.ctaLink
        });
    };

    if (resultState) {
        return (
            <div className="card card--elevated p-8 max-w-2xl mx-auto border-2 border-[color:var(--accent)] animate-fade-in text-center">
                <h3 className="text-xl font-bold text-[color:var(--text-muted)] mb-1">{t('diagnosisResult')}</h3>
                <div className="text-3xl font-bold text-[color:var(--accent)] mb-2">{resultState.title}</div>
                {resultState.subtitle && <div className="text-lg font-medium text-[color:var(--text-main)] mb-6">{resultState.subtitle}</div>}

                {resultState.tags && resultState.tags.length > 0 && (
                    <div className="flex flex-wrap justify-center gap-2 mb-6">
                        {resultState.tags.map(tag => (
                            <span key={tag} className="px-3 py-1 bg-[color:var(--accent-soft)] text-[color:var(--accent-strong)] rounded-full text-sm font-medium">
                                #{tag}
                            </span>
                        ))}
                    </div>
                )}

                <p className="text-lg text-[color:var(--text-muted)] mb-8 leading-relaxed whitespace-pre-line">{resultState.description}</p>

                <div className="bg-[color:var(--bg-subtle)] p-6 rounded-xl mb-8 text-left border border-[color:var(--border-subtle)]">
                    {resultState.ctaHeadline && <div className="font-bold text-[color:var(--text-main)] mb-1">{resultState.ctaHeadline}</div>}
                    {resultState.ctaBody && <div className="text-sm text-[color:var(--text-muted)] mb-4">{resultState.ctaBody}</div>}
                    <div className="text-xs text-[color:var(--text-subtle)] mt-4 pt-4 border-t border-[color:var(--border-subtle)]">
                        {disclaimer || t('disclaimer')}
                    </div>
                </div>

                <button
                    onClick={() => {
                        const intakePath = locale === 'ko' ? '/intake' : `/${locale}/intake`;
                        window.location.href = resultState.ctaLink ? resultState.ctaLink : `${intakePath}?${resultState.params}`;
                    }}
                    className="w-full btn btn--primary py-4 text-lg shadow-lg hover:opacity-90 transition-all transform hover:-translate-y-1"
                >
                    {t('ctaButton')}
                </button>
                <button
                    onClick={() => window.location.reload()}
                    className="mt-4 text-[color:var(--text-subtle)] hover:underline text-sm"
                >
                    {t('retryButton')}
                </button>
            </div>
        );
    }

    return (
        <div className="card card--plain border border-[color:var(--border-subtle)] p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-center mb-6 text-[color:var(--text-main)]">{title}</h3>

            <div className="mb-8">
                <div className="w-full bg-[color:var(--bg-subtle)] rounded-full h-2">
                    <div
                        className="bg-[color:var(--accent)] h-2 rounded-full transition-all duration-300"
                        style={{ width: `${((step + 1) / questions.length) * 100}%` }}
                    ></div>
                </div>
                <p className="text-right text-sm text-[color:var(--text-muted)] mt-2">{step + 1} / {questions.length}</p>
            </div>

            <div className="animate-fade-in">
                <h4 className="text-xl font-medium mb-6 text-[color:var(--text-main)]">{questions[step].text}</h4>
                <div className="space-y-3">
                    {questions[step].options.map((option, idx) => (
                        <button
                            key={idx}
                            onClick={() => handleAnswer(option)}
                            className="w-full p-4 text-left border border-[color:var(--border-subtle)] rounded-lg hover:bg-[color:var(--accent-soft)] hover:border-[color:var(--accent)] transition-all text-[color:var(--text-main)] hover:text-[color:var(--accent-strong)]"
                        >
                            {option.label}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
}
