// Content collection schemas for multilingual content
import { z, defineCollection } from 'astro:content';

const pagesCollection = defineCollection({
    type: 'content',
    schema: z.object({
        title: z.string(),
        description: z.string().optional(),
        lang: z.enum(['ko', 'en', 'ja', 'zh-hans']),
        translationOf: z.string().optional(), // Reference to original Korean slug
        lastUpdated: z.date().optional(),
    }),
});

const programsCollection = defineCollection({
    type: 'content',
    schema: z.object({
        title: z.string(),
        description: z.string(),
        lang: z.enum(['ko', 'en', 'ja', 'zh-hans']),
        category: z.string().optional(),
        icon: z.string().optional(),
        translationOf: z.string().optional(),
        lastUpdated: z.date().optional(),
    }),
});

export const collections = {
    pages: pagesCollection,
    programs: programsCollection,
};
