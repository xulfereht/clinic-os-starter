import { defineMiddleware } from "astro:middleware";
import { SUPPORTED_LOCALES } from "./lib/i18n";

export const onRequest = defineMiddleware(async (context, next) => {
    const { url, cookies, locals, redirect } = context;

    // 0. Global Language Preference Handling
    const langParam = url.searchParams.get('lang');
    if (langParam) {
        // Set preference cookie (valid for 1 year) whenever 'lang' param is present
        cookies.set('brd_locale', langParam, {
            path: '/',
            maxAge: 31536000, // 1 year
            httpOnly: false   // Allow client access if needed
        });
    }

    // 1. Language Redirection for Landing Page
    if (url.pathname === '/') {
        const acceptLanguage = context.request.headers.get('accept-language');
        const localeCookie = cookies.get('brd_locale')?.value;

        // Determine Primary Locale (Query Param > Cookie > Browser)
        // Note: langParam is already captured above
        let primaryLocale = langParam || localeCookie;

        // Fallback to browser header if no preference set
        if (!primaryLocale && acceptLanguage) {
            // Parse & Sort (e.g., "en-US,en;q=0.9")
            primaryLocale = acceptLanguage
                .split(',')
                .map(part => {
                    const [code, q] = part.split(';');
                    return {
                        code: code.trim().toLowerCase(),
                        q: q ? parseFloat(q.split('=')[1]) : 1.0
                    };
                })
                .sort((a, b) => b.q - a.q)[0]?.code; // Get highest priority
        }

        if (primaryLocale) {
            const params = new URLSearchParams(url.search);
            params.delete('lang'); // Clean up the param for the redirect URL
            const queryString = params.toString() ? `?${params.toString()}` : '';

            let targetLocale = null;

            // 1. Determine Target Mapping
            // Check for explicit Korean match first to prevent redirection
            if (primaryLocale === 'ko' || primaryLocale.startsWith('ko')) {
                // Korean -> Stay on '/'
                return next(); // Explicitly stop redirection logic
            } else if (primaryLocale.startsWith('ja')) {
                targetLocale = 'ja';
            } else if (primaryLocale.startsWith('zh')) {
                targetLocale = 'zh-hans';
            } else if (primaryLocale.startsWith('vi')) {
                targetLocale = 'vi';
            } else if (primaryLocale.startsWith('en')) {
                targetLocale = 'en';
            } else {
                // Unsupported Foreign -> Fallback to English (only if driven by Browser Header)
                // If it was a cookie/param 'fr', we probably shouldn't force 'en' if 'fr' isn't supported?
                // But for now, safe default is English for foreigners.
                // UNLESS the user explicitly asked for 'ko' (handled above).

                // If the user's browser is 'fr' (unknown), we default to 'en'.
                targetLocale = 'en';
            }

            // 2. Validate Target against SUPPORTED_LOCALES
            if (targetLocale) {
                // Check if the target locale is actually supported by the system
                // @ts-ignore
                const isSupported = SUPPORTED_LOCALES.includes(targetLocale);

                if (isSupported) {
                    return redirect(`/${targetLocale}${queryString}`);
                }
            }
        }
    }

    // 1. Try to populate user from session cookie (Global)
    const adminSessionId = cookies.get('admin_session')?.value;

    if (adminSessionId) {
        // @ts-ignore
        const db = locals.runtime?.env?.DB;
        if (db) {
            try {
                // First try staff table
                let session = await db.prepare(`
                    SELECT s.*, st.name, st.role, st.permissions, st.image, st.id as staff_id, st.position
                    FROM sessions s
                    JOIN staff st ON s.staff_id = st.id
                    WHERE s.id = ? AND s.expires_at > strftime('%s', 'now')
                `).bind(adminSessionId).first();

                // If not found in staff, check super_admins
                if (!session) {
                    session = await db.prepare(`
                        SELECT s.*, sa.name, 'super_admin' as role, NULL as image, sa.id as staff_id, '최고관리자' as position
                        FROM sessions s
                        JOIN super_admins sa ON s.staff_id = sa.id
                        WHERE s.id = ? AND s.expires_at > strftime('%s', 'now')
                    `).bind(adminSessionId).first();
                }

                if (session) {
                    // Valid session, store in locals
                    let permissions = {};
                    try {
                        // @ts-ignore - permissions column might be missing in types but exists in DB
                        permissions = session.permissions ? JSON.parse(session.permissions) : {};
                    } catch (e) {
                        console.error("Failed to parse permissions", e);
                    }

                    locals.user = {
                        name: session.name as string,
                        role: session.role as string,
                        position: (session.role === 'super_admin' ? '최고관리자' : (session.position || session.role || '관리자')) as string,
                        permissions,
                        image: session.image as string | null,
                        id: session.staff_id as string
                    };
                }
            } catch (e) {
                console.error("Middleware Auth Error:", e);
            }
        }
    }

    // 2. Admin Route Protection
    if (url.pathname.startsWith('/admin')) {
        // Skip checks for login page and static assets
        if (url.pathname === '/admin/login' || url.pathname.startsWith('/admin/api')) {
            return next();
        }

        if (!locals.user) {
            return redirect('/admin/login');
        }

        // 3. Permission Checks
        const { hasPermission, RESOURCES } = await import('./lib/permissions');

        // Map URL paths to Resources
        const routePermissions: Record<string, string> = {
            '/admin/leads': RESOURCES.LEADS,
            '/admin/intake': RESOURCES.INTAKE,
            '/admin/patients': RESOURCES.PATIENTS,
            '/admin/members': RESOURCES.MEMBERS,
            '/admin/messages': RESOURCES.MESSAGES,
            '/admin/reservations': RESOURCES.RESERVATIONS,
            '/admin/payments': RESOURCES.PAYMENTS,
            '/admin/shipping': RESOURCES.SHIPPING,
            '/admin/settings/schedule': RESOURCES.SCHEDULE,
            '/admin/products': RESOURCES.PRODUCTS, // Note: some might be under settings
            '/admin/settings/products': RESOURCES.PRODUCTS,
            '/admin/settings/promotions': RESOURCES.PROMOTIONS,
            '/admin/inventory': RESOURCES.INVENTORY,
            '/admin/tasks': RESOURCES.TASKS,
            '/admin/manuals': RESOURCES.MANUALS,
            '/admin/documents': RESOURCES.DOCUMENTS,
            '/admin/expenses': RESOURCES.EXPENSES,
            '/admin/crm': RESOURCES.CRM, // covers /crm/segments too if strictly prefix
            '/admin/campaigns': RESOURCES.CAMPAIGNS,
            '/admin/analytics': RESOURCES.ANALYTICS,
            '/admin/programs': RESOURCES.PROGRAMS,
            '/admin/posts': RESOURCES.POSTS,
            '/admin/reviews': RESOURCES.REVIEWS,
            '/admin/notices': RESOURCES.NOTICES,
            '/admin/surveys': RESOURCES.SURVEYS,
            '/admin/media': RESOURCES.MEDIA,
            // '/admin/topics': RESOURCES.KNOWLEDGE, // AEO Topics
            '/admin/settings': RESOURCES.SETTINGS, // General settings
            '/admin/staff': RESOURCES.STAFF,
            '/admin/design': RESOURCES.DESIGN,
            '/admin/data-hub': RESOURCES.DATA_HUB,
            '/admin/trash': RESOURCES.TRASH,
            '/admin/aeo': RESOURCES.AEO
        };

        // Find matching resource requirement
        // Sort keys by length desc to match most specific first (though prefix should be fine mostly)
        const matchedPath = Object.keys(routePermissions).find(path => url.pathname.startsWith(path));

        if (matchedPath) {
            const requiredResource = routePermissions[matchedPath];
            if (!hasPermission(locals.user, requiredResource, 'view')) {
                console.warn(`[Access Denied] User ${locals.user.name} tried to access ${url.pathname} without ${requiredResource}`);
                return redirect('/admin?error=unauthorized');
                // Or render a 403 page? Redirect is safer for now.
            }
        }
    }

    return next();
});
