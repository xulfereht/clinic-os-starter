/// <reference path="../.astro/types.d.ts" />
/// <reference types="astro/client" />

type D1Database = import('@cloudflare/workers-types').D1Database;
type R2Bucket = import('@cloudflare/workers-types').R2Bucket;
type ENV = {
    DB: D1Database;
    BUCKET: R2Bucket;
    ADMIN_PASSWORD?: string;
};

type Runtime = import('@astrojs/cloudflare').Runtime<ENV>;

declare namespace App {
    interface Locals extends Runtime {
        user?: {
            name: string;
            role: string;
            position?: string;
            permissions: Record<string, string[]>;
            image: string | null;
            id: string;
        }
    }
}
