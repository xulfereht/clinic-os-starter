/**
 * Clinic-OS Configuration Template
 * 
 * 이 파일은 한의원별 기본 설정을 정의합니다.
 * 실제 데이터는 DB의 clinics, site_settings 테이블에서 로드됩니다.
 * 아래 값들은 DB 에러 시 폴백용입니다.
 */

const CLINIC_NAME = "샘플한의원";

export const clinicConfig = {
    // 기본 정보 (DB의 clinics 테이블에서 로드됨)
    name: CLINIC_NAME,
    englishName: "Sample Clinic",
    description: "한의원 통합 관리 시스템 데모",
    url: "https://sample-clinic.com",
    businessLicenseNumber: "000-00-00000",
    representativeName: "홍길동",

    contact: {
        phone: "02-0000-0000",
        address: "서울특별시 강남구 테헤란로 123",
        kakaoChannel: `@${CLINIC_NAME}`,
        email: "contact@sample-clinic.com",
        bookingUrl: "/intake"
    },

    hours: {
        weekdays: "09:00 - 18:00",
        saturday: "09:00 - 13:00",
        lunch: "12:00 - 13:00",
        closed: "일요일/공휴일 휴진"
    },

    theme: {
        primaryColor: "teal", // Tailwind color name: blue, green, teal, indigo, violet, purple, pink, rose
        logoText: "S"
    },

    features: {
        intake: true,
        checklists: true,
        symptoms: true
    }
};
