-- Migration number: 0501 	 2024-01-22T00:00:00.000Z
-- Add password_change_required column to super_admins and staff

ALTER TABLE super_admins ADD COLUMN password_change_required INTEGER DEFAULT 0;
ALTER TABLE staff ADD COLUMN password_change_required INTEGER DEFAULT 0;

-- Force password change for default admin (if exists and matches default)
UPDATE super_admins 
SET password_change_required = 1 
WHERE email = 'admin@sample-clinic.com';
