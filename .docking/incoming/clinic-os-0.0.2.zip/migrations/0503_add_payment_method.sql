-- Add method column to payments table
ALTER TABLE payments ADD COLUMN method TEXT DEFAULT 'card';
