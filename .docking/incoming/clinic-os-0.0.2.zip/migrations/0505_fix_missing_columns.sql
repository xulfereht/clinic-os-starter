-- Fix missing is_sample column in payments
ALTER TABLE payments ADD COLUMN is_sample INTEGER DEFAULT 0;
