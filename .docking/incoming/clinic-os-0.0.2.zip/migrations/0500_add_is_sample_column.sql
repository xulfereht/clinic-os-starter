-- =============================================
-- Add is_sample column to main tables
-- For distinguishing sample data from real data
-- =============================================

-- Patients
ALTER TABLE patients ADD COLUMN is_sample INTEGER DEFAULT 0;

-- Reservations
ALTER TABLE reservations ADD COLUMN is_sample INTEGER DEFAULT 0;

-- Medical Records
ALTER TABLE medical_records ADD COLUMN is_sample INTEGER DEFAULT 0;

-- Payments
ALTER TABLE payments ADD COLUMN is_sample INTEGER DEFAULT 0;

-- Posts (reviews, blog posts)
ALTER TABLE posts ADD COLUMN is_sample INTEGER DEFAULT 0;

-- Programs
ALTER TABLE programs ADD COLUMN is_sample INTEGER DEFAULT 0;

-- Knowledge Cards
ALTER TABLE knowledge_cards ADD COLUMN is_sample INTEGER DEFAULT 0;

-- Staff (doctors)
ALTER TABLE staff ADD COLUMN is_sample INTEGER DEFAULT 0;

-- Create index for faster filtering
CREATE INDEX IF NOT EXISTS idx_patients_sample ON patients(is_sample);
CREATE INDEX IF NOT EXISTS idx_reservations_sample ON reservations(is_sample);
CREATE INDEX IF NOT EXISTS idx_posts_sample ON posts(is_sample);
