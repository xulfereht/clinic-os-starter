CREATE TABLE admin_favorites (
    id TEXT PRIMARY KEY,
    admin_id TEXT NOT NULL,
    path TEXT NOT NULL,
    label TEXT NOT NULL,
    icon TEXT,
    display_order INTEGER DEFAULT 0,
    created_at INTEGER,
    UNIQUE(admin_id, path)
);

CREATE TABLE admin_messages (
                    id TEXT PRIMARY KEY,
                    sender_id TEXT NOT NULL,
                    recipient_id TEXT,
                    content TEXT,
                    file_url TEXT,
                    file_type TEXT,
                    created_at INTEGER DEFAULT (unixepoch())
                , channel_id TEXT, deleted_at INTEGER, file_name TEXT);

CREATE TABLE admins (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    is_active BOOLEAN DEFAULT 1,
    permissions TEXT, -- JSON string of permissions
    admin_role TEXT DEFAULT 'staff', -- 'super_admin', 'admin', 'editor', 'staff'
    last_seen INTEGER, -- Timestamp of last activity
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER DEFAULT (strftime('%s', 'now')),
    deleted_at INTEGER DEFAULT NULL
);

CREATE TABLE aeo_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    bot_type TEXT, -- 'GPTBot', 'ClaudeBot', 'OAI-SearchBot', 'Unknown'
    user_agent TEXT,
    path TEXT,
    ip_address TEXT,
    referer TEXT,
    status_code INTEGER
);

CREATE TABLE ai_configs (id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT NOT NULL UNIQUE, api_key TEXT, model TEXT, is_active INTEGER DEFAULT 0, organization_id TEXT, base_url TEXT, created_at INTEGER DEFAULT (unixepoch()), updated_at INTEGER DEFAULT (unixepoch()));

CREATE TABLE analytics_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    event_data TEXT, -- JSON string for flexible event properties
    path TEXT,
    created_at TEXT DEFAULT (datetime('now'))
, visitor_id TEXT);

CREATE TABLE business_lines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    description TEXT,
    default_care_mode TEXT,
    kpi_config_json TEXT,
    campaign_config_json TEXT,
    sort_order INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    created_at INTEGER DEFAULT (strftime('%s', 'now'))
);

CREATE TABLE campaign_runs (
    id TEXT PRIMARY KEY,          -- UUID
    campaign_id INTEGER NOT NULL,
    started_at INTEGER,           -- Execution start time
    completed_at INTEGER,         -- Execution end time
    status TEXT,                  -- 'running', 'completed', 'failed'
    total_count INTEGER DEFAULT 0,
    sent_count INTEGER DEFAULT 0,
    failed_count INTEGER DEFAULT 0,
    trigger_type TEXT,            -- 'SCHEDULED', 'MANUAL', 'TRIGGER'
    log_details TEXT,             -- JSON: e.g., error messages or trigger payload summary
    FOREIGN KEY (campaign_id) REFERENCES campaigns(id)
);

CREATE TABLE campaigns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    template_id INTEGER NOT NULL,
    segment_id INTEGER,           -- 타겟 세그먼트
    scheduled_at INTEGER,         -- 예약 발송 시간 (NULL = 즉시)
    status TEXT DEFAULT 'draft',  -- draft | scheduled | sending | sent | failed
    total_count INTEGER DEFAULT 0,
    sent_count INTEGER DEFAULT 0,
    failed_count INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    sent_at INTEGER, type TEXT DEFAULT 'ONE_TIME', trigger_type TEXT, trigger_config TEXT, start_at INTEGER, end_at INTEGER, last_processed_id INTEGER DEFAULT 0, next_run_at INTEGER, batch_size INTEGER DEFAULT 50, is_active INTEGER DEFAULT 1, trigger_event TEXT,
    FOREIGN KEY (template_id) REFERENCES message_templates(id),
    FOREIGN KEY (segment_id) REFERENCES segments(id)
);

CREATE TABLE channel_members (
    channel_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    last_read_at INTEGER DEFAULT 0,
    joined_at INTEGER NOT NULL, is_hidden INTEGER DEFAULT 0,
    PRIMARY KEY (channel_id, user_id),
    FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES staff(id) ON DELETE CASCADE
);

CREATE TABLE channels (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL DEFAULT 'group', -- public, direct, group
    name TEXT,
    last_message_at INTEGER,
    created_at INTEGER NOT NULL
, lead_id TEXT, source TEXT DEFAULT 'internal', status TEXT DEFAULT 'active', last_message TEXT, translation_enabled BOOLEAN DEFAULT 0);

CREATE TABLE chatbot_nodes (
    id TEXT PRIMARY KEY,
    parent_id TEXT,               -- NULL = root node
    node_type TEXT NOT NULL,      -- 'menu', 'answer', 'action'
    title TEXT,                   -- Button text for this option
    message TEXT NOT NULL,        -- Bot message when entering this node
    options TEXT,                 -- JSON array of child options
    action TEXT,                  -- 'link', 'handoff', 'back', 'restart'
    action_data TEXT,             -- URL or target node ID
    keywords TEXT,                -- Keywords that jump directly to this node
    order_index INTEGER DEFAULT 0,
    enabled INTEGER DEFAULT 1,
    program_id TEXT,              -- Link to programs table
    created_at INTEGER
);

CREATE TABLE chatbot_sessions (
    channel_id TEXT PRIMARY KEY,
    current_node_id TEXT DEFAULT 'root',
    history TEXT,                 -- JSON array of visited nodes
    updated_at INTEGER
);

CREATE TABLE chatbot_settings (
    id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    enabled INTEGER DEFAULT 0,
    mode TEXT DEFAULT 'always', -- 'always', 'away', 'outside_hours'
    greeting TEXT DEFAULT '안녕하세요! 백록담 한의원입니다. 무엇을 도와드릴까요?',
    fallback_message TEXT DEFAULT '해당 문의는 담당자가 직접 답변드리겠습니다. 잠시만 기다려주세요.',
    away_message TEXT DEFAULT '현재 상담 가능 시간이 아닙니다. 영업시간에 다시 연락드리겠습니다.',
    response_delay INTEGER DEFAULT 1000, -- milliseconds
    work_hours_start TEXT DEFAULT '09:00',
    work_hours_end TEXT DEFAULT '18:00',
    work_days TEXT DEFAULT '1,2,3,4,5', -- 0=Sun, 1=Mon, ...
    updated_at INTEGER
);

CREATE TABLE checklists (id TEXT PRIMARY KEY, deleted_at INTEGER DEFAULT NULL);

CREATE TABLE clinic_holidays (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL UNIQUE, description TEXT, created_at INTEGER DEFAULT (unixepoch()));

CREATE TABLE clinic_special_work_days (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL UNIQUE, description TEXT, created_at INTEGER DEFAULT (unixepoch()));

CREATE TABLE clinic_weekly_schedules (day_of_week INTEGER PRIMARY KEY, is_closed INTEGER DEFAULT 0, open_time TEXT, close_time TEXT, created_at INTEGER DEFAULT (unixepoch()), updated_at INTEGER DEFAULT (unixepoch()));

CREATE TABLE clinical_tests (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL,
    test_type TEXT NOT NULL,
    test_date INTEGER,
    data TEXT,
    images TEXT,
    note TEXT,
    created_at INTEGER DEFAULT (unixepoch())
, deleted_at INTEGER DEFAULT NULL);

CREATE TABLE clinics (id TEXT PRIMARY KEY, deleted_at INTEGER DEFAULT NULL, theme_style TEXT DEFAULT 'minimal', logo_url TEXT, favicon_url TEXT, name TEXT, address TEXT, phone TEXT, hours TEXT, theme_color TEXT, updated_at INTEGER DEFAULT (strftime('%s', 'now')), theme_config TEXT, map_url TEXT, business_license_number TEXT, representative_name TEXT, description TEXT, ai_config TEXT, integrations TEXT, analytics_config TEXT, bank_info TEXT DEFAULT '');

CREATE TABLE condition_translations (
  id INTEGER PRIMARY KEY,
  condition_id INTEGER NOT NULL,
  locale TEXT NOT NULL,
  name TEXT,
  description TEXT,
  status TEXT DEFAULT 'draft',
  created_at INTEGER DEFAULT (unixepoch()),
  updated_at INTEGER DEFAULT (unixepoch())
);

CREATE TABLE consent_log (
  id TEXT PRIMARY KEY,
  patient_id TEXT,
  consent_type TEXT NOT NULL,
  consent BOOLEAN NOT NULL,
  channels TEXT,
  consent_version TEXT,
  consent_text_snapshot TEXT,
  term_version_id TEXT,
  source TEXT NOT NULL,
  ip_address TEXT,
  user_agent TEXT,
  created_at INTEGER DEFAULT (strftime('%s', 'now'))
);

CREATE TABLE contact_history (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL,
    field TEXT NOT NULL CHECK(field IN ('phone', 'email', 'address')),
    old_value TEXT,
    new_value TEXT NOT NULL,
    changed_at INTEGER DEFAULT (strftime('%s', 'now')),
    changed_by TEXT,
    reason TEXT,
    
    FOREIGN KEY (patient_id) REFERENCES patients(id)
);

CREATE TABLE data_converters (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    target_type TEXT NOT NULL, -- 'tracking', 'patients', 'leads'
    config TEXT NOT NULL, -- JSON config with column mappings and transforms
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);

CREATE TABLE doctors (id TEXT PRIMARY KEY, name TEXT NOT NULL, role TEXT, bio TEXT, image TEXT, specialties TEXT, created_at INTEGER DEFAULT (strftime('%s', 'now')), updated_at INTEGER DEFAULT (strftime('%s', 'now')), education TEXT, career TEXT);

CREATE TABLE documents (
    id TEXT PRIMARY KEY,
    filename TEXT NOT NULL,
    url TEXT NOT NULL,
    size INTEGER NOT NULL,
    mime_type TEXT NOT NULL,
    category TEXT DEFAULT 'general',
    uploaded_at INTEGER NOT NULL,
    description TEXT,
    metadata TEXT -- JSON string for extra data
);

CREATE TABLE event_campaigns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    products TEXT, -- JSON string
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE expense_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    color TEXT DEFAULT 'slate', -- orange, lime, blue, etc.
    created_at INTEGER DEFAULT (unixepoch())
);

CREATE TABLE expense_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_date TEXT NOT NULL,         -- Request Date (YYYY-MM-DD or ISO)
    title TEXT NOT NULL,                -- Expense Description/Title
    amount INTEGER NOT NULL DEFAULT 0,  -- Payment Amount
    category TEXT,                      -- Expense Category (e.g. 'logistics', 'office')
    
    -- Bank Account Info
    account_bank TEXT,                  -- Bank Name
    account_number TEXT,                -- Account Number
    account_holder TEXT,                -- Account Holder Name
    
    requester_name TEXT,                -- Staff Name requesting payment
    due_date TEXT,                      -- Payment Deadline (Optional)
    
    status TEXT DEFAULT 'PENDING',      -- PENDING, PAID, REJECTED
    is_paid INTEGER DEFAULT 0,          -- 0: Unpaid, 1: Paid
    paid_date TEXT,                     -- Date of payment completion
    
    proof_image TEXT,                   -- URL or Path to receipt image
    memo TEXT,                          -- Additional notes
    
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch())
);

CREATE TABLE expense_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,                 -- Template Name (e.g. "Office Rent")
    title TEXT,                         -- Default Title
    amount INTEGER,                     -- Default Amount
    category TEXT,
    
    -- Bank Account Info
    account_bank TEXT,
    account_number TEXT,
    account_holder TEXT,
    
    created_at INTEGER DEFAULT (unixepoch())
);

CREATE TABLE faq_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id INTEGER NOT NULL,
    question TEXT NOT NULL,
    answer_short TEXT, -- Direct concise answer for AI
    answer_detail TEXT, -- Rich HTML for user
    tags TEXT, -- JSON array of tags: ["insurance", "cost", "recovery"]
    author_id TEXT,
    supervisor_id TEXT,
    status TEXT DEFAULT 'draft', -- draft, review, published
    view_count INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch()),
    last_reviewed_at INTEGER, category TEXT, condition_id INTEGER REFERENCES topic_conditions(id), slug TEXT, cluster TEXT, -- Critical for AEO freshness signal
    FOREIGN KEY (topic_id) REFERENCES topics(id) ON DELETE CASCADE
);

CREATE TABLE faq_translations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    faq_id INTEGER NOT NULL,     -- FK to faq_items.id
    locale TEXT NOT NULL,        -- 'en', 'ja', 'zh-hans'
    question TEXT NOT NULL,      -- 번역된 질문
    answer_short TEXT,           -- AI용 짧은 답변
    answer_detail TEXT,          -- 사용자용 상세 답변 (HTML)
    status TEXT DEFAULT 'draft', -- 'draft', 'review', 'published'
    priority INTEGER DEFAULT 5,  -- 1(높음) ~ 10(낮음)
    translator_id TEXT,
    reviewer_id TEXT,
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch()), tags TEXT,
    UNIQUE(faq_id, locale),
    FOREIGN KEY (faq_id) REFERENCES faq_items(id) ON DELETE CASCADE
);

CREATE TABLE intake_submissions (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL,
    intake_data TEXT NOT NULL, 
    submitted_at INTEGER NOT NULL,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'confirmed', 'cancelled')),
    created_at INTEGER DEFAULT (strftime('%s', 'now')), deleted_at INTEGER DEFAULT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
);

CREATE TABLE intakes (id TEXT PRIMARY KEY, deleted_at INTEGER DEFAULT NULL);

CREATE TABLE inventory_items (id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT, vendor_id TEXT, stock_level INTEGER DEFAULT 0, min_stock_level INTEGER DEFAULT 5, unit TEXT DEFAULT 'ea', location TEXT, memo TEXT, created_at INTEGER DEFAULT (unixepoch()), updated_at INTEGER DEFAULT (unixepoch()), deleted_at INTEGER DEFAULT NULL);

CREATE TABLE inventory_transactions (id TEXT PRIMARY KEY, item_id TEXT NOT NULL, quantity_change INTEGER NOT NULL, reason TEXT, created_by TEXT, created_at INTEGER DEFAULT (unixepoch()), transaction_date INTEGER, type TEXT DEFAULT 'restock');

CREATE TABLE kakao_messages (
    id TEXT PRIMARY KEY,
    kakao_user_id TEXT NOT NULL,  -- kakao_users.id
    direction TEXT NOT NULL,  -- 'inbound' | 'outbound'
    content TEXT,
    message_type TEXT DEFAULT 'text',  -- text, image, etc.
    created_at INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY (kakao_user_id) REFERENCES kakao_users(id)
);

CREATE TABLE kakao_users (
    id TEXT PRIMARY KEY,
    kakao_user_id TEXT NOT NULL UNIQUE,  -- 카카오 i 오픈빌더 user.id
    patient_id TEXT,  -- 연결된 환자 (나중에 매핑)
    nickname TEXT,  -- 카카오 닉네임 (제공시)
    first_message_at INTEGER,
    last_message_at INTEGER,
    message_count INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY (patient_id) REFERENCES patients(id)
);

CREATE TABLE knowledge_cards (
    id TEXT PRIMARY KEY,
    topic TEXT NOT NULL,
    card_type TEXT NOT NULL, -- 'One-Liner', 'Explanation', 'Risk Management'
    role TEXT NOT NULL, -- 'Desk', 'Therapist', 'All'
    tags TEXT, -- JSON array
    level TEXT NOT NULL DEFAULT 'L1', -- 'L1', 'L2', 'L3'
    content TEXT NOT NULL, -- JSON object
    status TEXT NOT NULL DEFAULT 'draft', -- 'draft', 'review', 'approved', 'archived'
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch()),
    created_by TEXT
, category TEXT DEFAULT 'General', revision_note TEXT DEFAULT NULL);

CREATE TABLE knowledge_categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    is_enabled BOOLEAN DEFAULT TRUE,
    display_order INTEGER DEFAULT 0,
    created_at INTEGER,
    updated_at INTEGER
);

CREATE TABLE knowledge_interactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    staff_id TEXT NOT NULL,
    card_id TEXT NOT NULL,
    type TEXT NOT NULL, -- 'view', 'save', 'helpful', 'not_helpful'
    created_at INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY (card_id) REFERENCES knowledge_cards(id) ON DELETE CASCADE
);

CREATE TABLE lead_events (
    id TEXT PRIMARY KEY,
    lead_id TEXT NOT NULL,
    type TEXT NOT NULL, 
    content TEXT,
    created_by TEXT DEFAULT 'admin',
    created_at INTEGER DEFAULT (strftime('%s', 'now')), staff_id TEXT,
    FOREIGN KEY (lead_id) REFERENCES leads(id)
);

CREATE TABLE leads (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  contact TEXT NOT NULL,
  consent BOOLEAN NOT NULL DEFAULT 0,
  summary TEXT,
  risk_flags TEXT,
  channel TEXT DEFAULT 'chatgpt_app',
  status TEXT DEFAULT 'new',
  created_at INTEGER DEFAULT (unixepoch())
, type TEXT DEFAULT 'remote', patient_type TEXT DEFAULT 'new', symptoms TEXT, visit_date TEXT, notes TEXT, patient_id TEXT, closed_at INTEGER, intake_data TEXT, updated_at INTEGER, channel_id TEXT, user_agent TEXT, ip_address TEXT, location TEXT, device_type TEXT, referrer TEXT, last_seen INTEGER, consulting_at INTEGER, deleted_at INTEGER DEFAULT NULL, tags TEXT, dedupe_key TEXT, provider_msg_id TEXT, source_data TEXT, language TEXT DEFAULT 'ko');

CREATE TABLE manual_pages (id TEXT PRIMARY KEY, title TEXT NOT NULL, content TEXT, category TEXT, updated_by TEXT, created_at INTEGER DEFAULT (unixepoch()), updated_at INTEGER DEFAULT (unixepoch()));

CREATE TABLE message_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id INTEGER,
    patient_id TEXT,
    phone TEXT NOT NULL,
    content TEXT,
    status TEXT DEFAULT 'pending', -- pending | sent | failed
    error_message TEXT,
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    sent_at INTEGER, lead_id TEXT, channel_id TEXT, admin_id TEXT, type TEXT DEFAULT 'campaign', patient_name TEXT, message_type TEXT DEFAULT 'SMS', result_code TEXT, deleted_at INTEGER DEFAULT NULL,
    FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
    FOREIGN KEY (patient_id) REFERENCES patients(id)
);

CREATE TABLE message_reads (
    id TEXT PRIMARY KEY,
    message_id TEXT NOT NULL REFERENCES admin_messages(id) ON DELETE CASCADE,
    reader_id TEXT NOT NULL REFERENCES staff(id),
    read_at INTEGER NOT NULL,
    UNIQUE(message_id, reader_id)
);

CREATE TABLE message_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    content TEXT NOT NULL,
    segment_id INTEGER,           -- 연결된 세그먼트 (NULL = 범용)
    channel TEXT DEFAULT 'SMS',   -- SMS | KAKAO | BOTH
    variables TEXT,               -- JSON: ["name", "next_visit_date"]
    is_active INTEGER DEFAULT 1,
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER DEFAULT (strftime('%s', 'now')), alimtalk_code TEXT, buttons TEXT, category TEXT DEFAULT 'general', approval_status TEXT, alimtalk_status TEXT DEFAULT NULL,
    FOREIGN KEY (segment_id) REFERENCES segments(id)
);

CREATE TABLE message_translations (id INTEGER PRIMARY KEY AUTOINCREMENT, message_id TEXT NOT NULL, locale TEXT NOT NULL, translated_text TEXT NOT NULL, created_at INTEGER DEFAULT (unixepoch()), engine TEXT DEFAULT 'google', confidence REAL DEFAULT 1.0, UNIQUE(message_id, locale), FOREIGN KEY (message_id) REFERENCES admin_messages(id) ON DELETE CASCADE);

CREATE TABLE notices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    category TEXT DEFAULT '공지',
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch())
);

CREATE TABLE page_translations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    page_type TEXT NOT NULL,     -- 'home', 'program', 'topic', 'faq', 'static'
    page_id TEXT NOT NULL,       -- 페이지 식별자 (slug 또는 ID)
    locale TEXT NOT NULL,        -- 'en', 'ja', 'zh-hans'
    title TEXT,                  -- 번역된 제목
    description TEXT,            -- 번역된 설명 (meta description)
    content TEXT,                -- 번역된 본문 (JSON 또는 HTML)
    sections TEXT,               -- 번역된 섹션 데이터 (JSON)
    status TEXT DEFAULT 'draft', -- 'draft', 'review', 'published'
    priority INTEGER DEFAULT 5,  -- 1(높음) ~ 10(낮음)
    translator_id TEXT,
    reviewer_id TEXT,
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch()),
    published_at INTEGER,
    UNIQUE(page_type, page_id, locale)
);

CREATE TABLE page_views (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    path TEXT NOT NULL,
    referrer TEXT,
    user_agent TEXT,
    ip_hash TEXT,
    country TEXT,
    device_type TEXT, -- 'mobile', 'tablet', 'desktop'
    created_at TEXT DEFAULT (datetime('now'))
, visitor_id TEXT);

CREATE TABLE pages (
    id TEXT PRIMARY KEY,
    slug TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    description TEXT,
    sections TEXT DEFAULT '[]', -- JSON Array of section data
    is_published INTEGER DEFAULT 1,
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER DEFAULT (strftime('%s', 'now'))
);

CREATE TABLE patient_events (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL,
    type TEXT NOT NULL, 
    title TEXT,
    content TEXT,
    event_date INTEGER, 
    created_at INTEGER DEFAULT (strftime('%s', 'now')), staff_id TEXT, care_mode TEXT DEFAULT 'INPERSON', business_type TEXT DEFAULT 'INSURED', deleted_at INTEGER,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
);

CREATE TABLE patient_images (id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, file_name TEXT, mime_type TEXT, data TEXT, size INTEGER, uploaded_at INTEGER DEFAULT (unixepoch()), description TEXT, FOREIGN KEY (patient_id) REFERENCES patients(id));

CREATE TABLE patient_labels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id TEXT NOT NULL,
    category TEXT NOT NULL,
    value TEXT NOT NULL,
    is_active BOOLEAN DEFAULT 1,
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    created_by TEXT,
    
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    UNIQUE(patient_id, category, value)
);

CREATE TABLE patient_tags (
    id TEXT PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    color TEXT DEFAULT 'blue',
    created_at INTEGER,
    deleted_at INTEGER DEFAULT NULL
, category TEXT DEFAULT '일반');

CREATE TABLE "patients" (
    id TEXT PRIMARY KEY,              
    patient_number INTEGER,           
    
    name TEXT NOT NULL,
    name_english TEXT,
    birth_date TEXT,
    gender TEXT CHECK(gender IN ('M', 'F', '')),
    
    current_phone TEXT NOT NULL,
    current_email TEXT,
    address TEXT,
    emergency_contact TEXT,
    emergency_phone TEXT,
    
    source TEXT DEFAULT 'offline',    
    channel TEXT,                     
    referral_source TEXT,
    
    has_account BOOLEAN DEFAULT 0,
    password_hash TEXT,
    email_verified BOOLEAN DEFAULT 0,
    role TEXT DEFAULT 'patient',
    
    status TEXT DEFAULT 'inquiry',
    tier TEXT DEFAULT 'standard',
    
    first_visit_date TEXT,
    last_visit_date TEXT,
    last_contact_date TEXT,
    visit_count INTEGER DEFAULT 0,
    
    primary_doctor TEXT,
    assigned_staff TEXT,
    
    preferred_time TEXT,
    sms_consent BOOLEAN DEFAULT 1,
    email_consent BOOLEAN DEFAULT 1,
    
    notes TEXT,
    tags TEXT,                        
    
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER DEFAULT (strftime('%s', 'now')), 
    member_id TEXT REFERENCES web_members(id), 
    total_payment INTEGER DEFAULT 0, 
    average_transaction INTEGER DEFAULT 0, 
    region TEXT, 
    occupation TEXT, 
    referral_detail TEXT, 
    consultant_id TEXT, 
    next_contact_date INTEGER, 
    last_contact_type TEXT, 
    marketing_consent_date INTEGER, 
    campaign_id TEXT, 
    zipcode TEXT, 
    address_road TEXT, 
    address_detail TEXT, 
    referrer_id TEXT, 
    segments TEXT DEFAULT '[]', first_source TEXT, chart_number TEXT, legacy_medical_history TEXT, deleted_at INTEGER DEFAULT NULL, last_activity_at INTEGER DEFAULT NULL, lifecycle_stage TEXT DEFAULT 'potential', address_zip TEXT, payment_count INTEGER DEFAULT 0, last_shipping_date TEXT,
    
    FOREIGN KEY (primary_doctor) REFERENCES staff(id)
);

CREATE TABLE payments (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL,
    product_id TEXT,
    amount INTEGER NOT NULL,
    status TEXT DEFAULT 'completed', 
    paid_at INTEGER DEFAULT (strftime('%s', 'now')),
    notes TEXT, original_amount INTEGER, discount_amount INTEGER DEFAULT 0, promotion_id TEXT, quantity INTEGER DEFAULT 1, shipping_status TEXT DEFAULT 'pending', shipping_courier TEXT, shipping_tracking_number TEXT, shipped_at INTEGER, delivered_at INTEGER, happy_call_status TEXT DEFAULT 'not_scheduled', happy_call_scheduled_at INTEGER, happy_call_completed_at INTEGER, happy_call_notes TEXT, shipping_due_date INTEGER, revenue_line TEXT DEFAULT 'INSURED', deleted_at INTEGER DEFAULT NULL, refund_amount INTEGER DEFAULT 0, refunded_at INTEGER, original_payment_id TEXT, created_by TEXT, created_at INTEGER, updated_at INTEGER,
    FOREIGN KEY (patient_id) REFERENCES patients(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE post_translations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL,    -- FK to posts.id
    locale TEXT NOT NULL,        -- 'en', 'ja', 'zh-hans'
    title TEXT NOT NULL,         -- 번역된 제목
    content TEXT,                -- 번역된 본문 (HTML/Markdown)
    excerpt TEXT,                -- 번역된 요약
    status TEXT DEFAULT 'draft', -- 'draft', 'review', 'published'
    priority INTEGER DEFAULT 5,  -- 1(높음) ~ 10(낮음)
    translator_id TEXT,
    reviewer_id TEXT,
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch()),
    UNIQUE(post_id, locale),
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
);

CREATE TABLE posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    slug TEXT UNIQUE,
    content TEXT,
    author_id TEXT, 
    type TEXT DEFAULT 'column', 
    status TEXT DEFAULT 'draft', 
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER DEFAULT (strftime('%s', 'now')), doctor_id TEXT REFERENCES "staff"(id), patient_id TEXT REFERENCES patients(id), featured_image TEXT, excerpt TEXT, is_pinned INTEGER DEFAULT 0, view_count INTEGER DEFAULT 0, category TEXT, patient_name TEXT,
    FOREIGN KEY (author_id) REFERENCES "staff"(id)
);

CREATE TABLE products (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT, 
    price INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT 1,
    created_at INTEGER DEFAULT (strftime('%s', 'now'))
, deleted_at INTEGER DEFAULT NULL);

CREATE TABLE program_translations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    program_id TEXT NOT NULL,    -- FK to programs.id
    locale TEXT NOT NULL,        -- 'en', 'ja', 'zh-hans'
    title TEXT NOT NULL,
    description TEXT,
    pricing TEXT,                -- JSON: 번역된 가격 정보
    features TEXT,               -- JSON: 번역된 특징
    sections TEXT,               -- JSON: 번역된 섹션 데이터
    status TEXT DEFAULT 'draft',
    priority INTEGER DEFAULT 3,  -- 프로그램은 우선순위 높음
    translator_id TEXT,
    reviewer_id TEXT,
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch()),
    UNIQUE(program_id, locale),
    FOREIGN KEY (program_id) REFERENCES programs(id) ON DELETE CASCADE
);

CREATE TABLE programs (
  id TEXT PRIMARY KEY, 
  title TEXT NOT NULL,
  description TEXT,
  pricing TEXT, 
  features TEXT, 
  updated_at INTEGER DEFAULT (strftime('%s', 'now'))
, sections TEXT, doctor_id TEXT, category TEXT DEFAULT 'special', treatable_conditions TEXT DEFAULT '[]', doctor_ids TEXT DEFAULT '[]', is_visible INTEGER DEFAULT 1, order_index INTEGER DEFAULT 0, deleted_at INTEGER DEFAULT NULL);

CREATE TABLE promotions (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL, 
    type TEXT NOT NULL, 
    value INTEGER NOT NULL, 
    is_active BOOLEAN DEFAULT 1,
    created_at INTEGER DEFAULT (strftime('%s', 'now'))
, deleted_at INTEGER DEFAULT NULL);

CREATE TABLE reservations (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL,
    doctor_id TEXT,
    program_id TEXT,
    reserved_at INTEGER NOT NULL,
    status TEXT DEFAULT 'scheduled',
    cancel_reason TEXT,
    notes TEXT,
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER DEFAULT (strftime('%s', 'now')), deleted_at INTEGER DEFAULT NULL, created_by TEXT,
    
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES staff(id)
);

CREATE TABLE saved_diagnosis_results (
    id TEXT PRIMARY KEY,
    template_id TEXT NOT NULL,
    member_id TEXT NOT NULL,
    answers TEXT,
    result_summary TEXT,
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    
    FOREIGN KEY (template_id) REFERENCES self_diagnosis_templates(id),
    FOREIGN KEY (member_id) REFERENCES web_members(id)
);

CREATE TABLE segments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    query_sql TEXT NOT NULL,  -- SQL that returns patient_id list
    is_active INTEGER DEFAULT 1,
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER DEFAULT (strftime('%s', 'now'))
, criteria TEXT);

CREATE TABLE self_diagnosis_results (
    id TEXT PRIMARY KEY,
    template_id TEXT NOT NULL,
    answers TEXT, 
    result_summary TEXT, 
    converted INTEGER DEFAULT 0, 
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    FOREIGN KEY (template_id) REFERENCES self_diagnosis_templates(id)
);

CREATE TABLE self_diagnosis_template_translations (
  id INTEGER PRIMARY KEY,
  template_id TEXT NOT NULL,
  locale TEXT NOT NULL,
  title TEXT NOT NULL,
  disclaimer TEXT,
  questions TEXT, -- JSON
  results TEXT, -- JSON
  status TEXT DEFAULT 'draft',
  created_at INTEGER DEFAULT (unixepoch()),
  updated_at INTEGER DEFAULT (unixepoch())
);

CREATE TABLE self_diagnosis_templates (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    type TEXT DEFAULT 'custom',
    
    
    program_id TEXT,
    
    
    questions TEXT NOT NULL,
    
    
    calculation_script TEXT,
    
    
    result_templates_json TEXT,
    
    
    cta_config TEXT,
    
    
    thumbnail_image TEXT,
    estimated_time INTEGER DEFAULT 5,
    
    
    status TEXT DEFAULT 'active',
    order_index INTEGER DEFAULT 0,
    
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER DEFAULT (strftime('%s', 'now')),
    
    FOREIGN KEY (program_id) REFERENCES programs(id)
);

CREATE TABLE "sessions" (
    id TEXT PRIMARY KEY,
    member_id TEXT,  -- Now nullable for staff-only sessions
    staff_id INTEGER,
    expires_at INTEGER NOT NULL,
    created_at INTEGER DEFAULT (strftime('%s', 'now'))
);

CREATE TABLE settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at INTEGER DEFAULT (strftime('%s', 'now'))
);

CREATE TABLE shipments (
    id TEXT PRIMARY KEY,
    shipping_order_id TEXT NOT NULL,
    type TEXT DEFAULT 'courier', 
    status TEXT DEFAULT 'shipped', 
    shipped_at INTEGER DEFAULT (unixepoch()),
    tracking_number TEXT,
    notes TEXT,
    deducted_quantity INTEGER DEFAULT 1,
    created_at INTEGER DEFAULT (unixepoch()), sms_sent_at INTEGER, sms_status TEXT,
    FOREIGN KEY (shipping_order_id) REFERENCES shipping_orders(id)
);

CREATE TABLE shipping_orders (
    id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL,
    product_name TEXT,
    total_quantity INTEGER DEFAULT 0, 
    remaining_quantity INTEGER DEFAULT 0, 
    last_shipped_at INTEGER,
    next_shipping_date INTEGER, 
    status TEXT DEFAULT 'active', 
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch()), message TEXT,
    FOREIGN KEY (patient_id) REFERENCES patients(id)
);

CREATE TABLE short_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    original_url TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    expires_at INTEGER,
    visits INTEGER DEFAULT 0
);

CREATE TABLE site_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    key TEXT NOT NULL UNIQUE,
    value TEXT,
    updated_at INTEGER DEFAULT (unixepoch()),
    UNIQUE(category, key)
);

CREATE TABLE "staff" (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    role TEXT,
    bio TEXT,
    image TEXT,
    specialties TEXT, 
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER DEFAULT (strftime('%s', 'now'))
, education TEXT DEFAULT '', career TEXT DEFAULT '', position TEXT DEFAULT '원장', order_index INTEGER DEFAULT 0, type TEXT DEFAULT 'doctor', department TEXT, is_active BOOLEAN DEFAULT 1, email TEXT, password_hash TEXT, permissions TEXT DEFAULT '[]', last_seen INTEGER, join_date TEXT, total_leaves INTEGER DEFAULT 15, phone TEXT, birth_date TEXT, deleted_at INTEGER DEFAULT NULL, admin_role TEXT DEFAULT 'staff', name_en TEXT, name_hanja TEXT);

CREATE TABLE staff_leaves (id INTEGER PRIMARY KEY AUTOINCREMENT, staff_id TEXT NOT NULL, start_date TEXT NOT NULL, end_date TEXT NOT NULL, type TEXT DEFAULT 'annual', reason TEXT, status TEXT DEFAULT 'approved', created_at INTEGER DEFAULT (unixepoch()));

CREATE TABLE staff_schedules (id INTEGER PRIMARY KEY AUTOINCREMENT, staff_id TEXT NOT NULL, day_of_week INTEGER NOT NULL, start_time TEXT, end_time TEXT, is_working INTEGER DEFAULT 1, created_at INTEGER DEFAULT (unixepoch()), updated_at INTEGER DEFAULT (unixepoch()), UNIQUE(staff_id, day_of_week));

CREATE TABLE staff_translations (
  id INTEGER PRIMARY KEY,
  staff_id TEXT NOT NULL,
  locale TEXT NOT NULL,
  name TEXT,
  position TEXT,
  bio TEXT,
  education TEXT,
  career TEXT,
  specialties TEXT,
  status TEXT DEFAULT 'draft',
  created_at INTEGER DEFAULT (unixepoch()),
  updated_at INTEGER DEFAULT (unixepoch())
);

CREATE TABLE super_admins (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    name TEXT,
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER
);

CREATE TABLE supported_locales (
    code TEXT PRIMARY KEY,               -- 'en', 'ja', 'zh-hans', 'vi', etc.
    name TEXT NOT NULL,                  -- 'English', 'Japanese', '简体中文'
    native_name TEXT,                    -- Native name: 'English', '日本語', '简体中文'
    flag TEXT NOT NULL DEFAULT '🌐',     -- Emoji flag: '🇺🇸', '🇯🇵', '🇨🇳'
    is_active INTEGER DEFAULT 0,         -- 0 = inactive (hidden from public), 1 = active
    sort_order INTEGER DEFAULT 100,      -- Display order
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch())
);

CREATE TABLE survey_responses (
  id TEXT PRIMARY KEY,
  patient_id TEXT NOT NULL,
  survey_type TEXT NOT NULL,
  response_data TEXT, 
  created_at INTEGER DEFAULT (strftime('%s', 'now')),
  FOREIGN KEY (patient_id) REFERENCES patients(id)
);

CREATE TABLE survey_results (id TEXT PRIMARY KEY, survey_id TEXT NOT NULL, patient_id TEXT NOT NULL, responses TEXT, submitted_at INTEGER DEFAULT (unixepoch()));

CREATE TABLE surveys (
    id TEXT PRIMARY KEY,
    label TEXT NOT NULL,
    description TEXT,
    path_template TEXT NOT NULL,
    is_public INTEGER DEFAULT 0,
    tags TEXT DEFAULT '[]',
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch())
, definition TEXT, deleted_at INTEGER DEFAULT NULL);

CREATE TABLE task_templates (id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT, content TEXT, subtasks TEXT DEFAULT '[]', frequency TEXT DEFAULT 'once', created_at INTEGER DEFAULT (unixepoch()));

CREATE TABLE tasks (id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT, status TEXT DEFAULT 'todo', assignee_id TEXT, due_date INTEGER, created_by TEXT, created_at INTEGER DEFAULT (unixepoch()), updated_at INTEGER DEFAULT (unixepoch()), frequency TEXT DEFAULT 'once', subtasks TEXT DEFAULT '[]', content TEXT, last_generated INTEGER, deleted_at INTEGER DEFAULT NULL);

CREATE TABLE terms_definitions (
  id TEXT PRIMARY KEY,
  slug TEXT UNIQUE NOT NULL, -- e.g., 'privacy-policy', 'marketing-consent'
  title TEXT NOT NULL,
  description TEXT,
  created_at INTEGER DEFAULT (strftime('%s', 'now'))
);

CREATE TABLE terms_versions (
  id TEXT PRIMARY KEY,
  term_id TEXT NOT NULL,
  version TEXT NOT NULL, -- e.g., '1.0', '2025-01-01'
  content TEXT NOT NULL, -- HTML or Markdown
  is_active BOOLEAN DEFAULT 0,
  effective_date INTEGER,
  created_at INTEGER DEFAULT (strftime('%s', 'now')), locale TEXT DEFAULT 'ko',
  FOREIGN KEY (term_id) REFERENCES terms_definitions(id)
);

CREATE TABLE topic_conditions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id INTEGER NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    name_en TEXT,
    description TEXT,
    icon TEXT,
    display_order INTEGER DEFAULT 0,
    faq_count INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY (topic_id) REFERENCES topics(id)
);

CREATE TABLE topic_translations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id INTEGER NOT NULL,   -- FK to topics.id
    locale TEXT NOT NULL,        -- 'en', 'ja', 'zh-hans'
    title TEXT NOT NULL,         -- 번역된 토픽 제목
    summary TEXT,                -- 번역된 요약
    status TEXT DEFAULT 'draft', -- 'draft', 'review', 'published'
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch()), seo_title TEXT,
    UNIQUE(topic_id, locale),
    FOREIGN KEY (topic_id) REFERENCES topics(id) ON DELETE CASCADE
);

CREATE TABLE topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    summary TEXT, -- 5-line summary or Hero description
    thumbnail_url TEXT,
    manager_id TEXT, -- Medical staff who 'manages' this topic (e.g. Doctor ID)
    supervisor_id TEXT, -- Medical supervisor ID for AEO Trust
    related_program_id TEXT, -- Funnel Link: FK to programs.id
    config TEXT, -- JSON: Filter options (insurance, cost tags, etc.)
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch())
, seo_title TEXT);

CREATE TABLE translation_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content_type TEXT NOT NULL,          -- 'program', 'page', 'post', 'faq', 'staff'
    content_id TEXT NOT NULL,            -- ID of the content being translated
    locale TEXT NOT NULL,                -- 'en', 'ja', 'zh-hans'
    field_name TEXT NOT NULL,            -- 'title', 'content', 'sections', etc.
    old_value TEXT,                       -- Previous value (NULL for new)
    new_value TEXT,                       -- New value
    changed_by TEXT,                      -- User who made the change (staff_id)
    changed_at INTEGER DEFAULT (unixepoch())
);

CREATE TABLE translation_progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type TEXT NOT NULL,   -- 'page', 'faq', 'program', 'ui'
    entity_id TEXT NOT NULL,     -- 해당 엔티티의 ID
    locale TEXT NOT NULL,        -- 'en', 'ja', 'zh-hans'
    status TEXT DEFAULT 'pending', -- 'pending', 'in_progress', 'review', 'published'
    progress_percent INTEGER DEFAULT 0,
    word_count INTEGER DEFAULT 0,
    notes TEXT,
    assigned_to TEXT,
    due_date INTEGER,
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch()),
    UNIQUE(entity_type, entity_id, locale)
);

CREATE TABLE ui_translations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT NOT NULL,           -- 'nav.home', 'btn.submit', 'label.phone'
    locale TEXT NOT NULL,        -- 'en', 'ja', 'zh-hans' (ko는 기본값이므로 저장 안함)
    value TEXT NOT NULL,         -- 번역된 텍스트
    context TEXT,                -- 사용 맥락 설명 (번역가 참고용)
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch()),
    UNIQUE(key, locale)
);

CREATE TABLE vendor_notes (
    id TEXT PRIMARY KEY,
    vendor_id TEXT NOT NULL,
    content TEXT NOT NULL,
    note_type TEXT DEFAULT 'general', -- general, issue, inquiry, order
    created_by TEXT,
    created_at INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY (vendor_id) REFERENCES vendors(id)
);

CREATE TABLE vendors (id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT, contact_person TEXT, phone TEXT, email TEXT, website TEXT, bank_info TEXT, memo TEXT, created_at INTEGER DEFAULT (unixepoch()), updated_at INTEGER DEFAULT (unixepoch()), deleted_at INTEGER DEFAULT NULL);

CREATE TABLE web_members (
    id TEXT PRIMARY KEY,
    
    
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    
    
    name TEXT,
    phone TEXT,
    birth_year INTEGER,
    
    
    email_verified BOOLEAN DEFAULT 0,
    
    
    last_login_at INTEGER,
    login_count INTEGER DEFAULT 0,
    
    
    marketing_consent BOOLEAN DEFAULT 0,
    
    
    source TEXT,
    
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    
    
    patient_id TEXT,
    
    FOREIGN KEY (patient_id) REFERENCES patients(id)
);

CREATE TABLE webhook_logs (
    id TEXT PRIMARY KEY,
    received_at INTEGER NOT NULL,
    source TEXT NOT NULL,
    payload_preview TEXT,
    status TEXT NOT NULL,
    message TEXT,
    lead_id TEXT,
    created_at INTEGER DEFAULT (unixepoch())
);
