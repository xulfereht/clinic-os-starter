# Docking Instructions for v0.0.2
  
## Overview
This is a full update to version 0.0.2.

## Key Changes
- [List changes here]

## Installation
1. Antigravity will extract this package.
2. Core files in 'src/' will be updated.
3. Migrations will be applied.
  