import fs from 'fs-extra';
import archiver from 'archiver';
import yaml from 'js-yaml';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.join(__dirname, '..');

// --- Configuration ---
const OUTPUT_DIR = path.join(PROJECT_ROOT, 'dist-packages');
const MANIFEST_FILENAME = 'manifest.yaml';

// Safe Zones (Files NOT to include in the package, or handled specially)
const EXCLUDE_LIST = [
    'node_modules',
    '.git',
    '.gitignore',
    '.env',
    '.docking', // Don't pack the docking station itself
    'dist',
    'dist-packages', // Don't pack the output folder
    'archive',
    'data', // User data
    'tests',
    'wrangler.toml', // User config! We provide wrangler.sample.toml instead
    'clinic_setup.yaml', // User setup file
    'db_local.sqlite',
    'brd-clinic-db.sqlite',
    'seeds/sample_clinic.sql' // Don't overwrite user seeds? Maybe include as reference?
];

// --- Helpers ---

function getVersion() {
    const pkg = fs.readJsonSync(path.join(PROJECT_ROOT, 'package.json'));
    return pkg.version;
}

function calculateHash(filePath) {
    const fileBuffer = fs.readFileSync(filePath);
    const hashSum = crypto.createHash('sha256');
    hashSum.update(fileBuffer);
    return hashSum.digest('hex');
}

async function generateManifest(version, type = 'full', files = [], migrations = []) {
    const manifest = {
        version: version,
        type: type,
        release_date: new Date().toISOString(),
        required_base_version: "0.0.0", // TODO: Determine this logically
        files: files, // List of { path, hash }
        migrations: migrations
    };
    return yaml.dump(manifest);
}

// --- Main ---

async function packRelease(type = 'full') {
    const version = getVersion();
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const packageName = `clinic-os-v${version}-${type}-${timestamp}.zip`;

    await fs.ensureDir(OUTPUT_DIR);
    const outputPath = path.join(OUTPUT_DIR, packageName);
    const output = fs.createWriteStream(outputPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    console.log(`📦 Packaging ${type} release v${version}...`);

    output.on('close', () => {
        console.log(`✅ Package created: ${packageName} (${archive.pointer()} bytes)`);
    });

    archive.on('error', (err) => {
        throw err;
    });

    archive.pipe(output);

    // 1. Collect Files & Calculate Hashes
    const filesToPack = [];
    const migrationFiles = [];

    // Recursive walk function (simplified for this script, better to use glob)
    // For 'full' package, we include almost everything in src/ and migrations/
    // For 'patch', we would selectively pick files (to be implemented)

    if (type === 'full') {
        // Add entire src directory
        archive.directory(path.join(PROJECT_ROOT, 'src'), 'src');

        // Add public directory
        archive.directory(path.join(PROJECT_ROOT, 'public'), 'public');

        // Add migrations
        archive.directory(path.join(PROJECT_ROOT, 'migrations'), 'migrations');

        // Add scripts (core scripts only? for now all)
        archive.directory(path.join(PROJECT_ROOT, 'scripts'), 'scripts');

        // Add root files
        archive.file(path.join(PROJECT_ROOT, 'package.json'), { name: 'package.json' });
        archive.file(path.join(PROJECT_ROOT, 'GEMINI.md'), { name: 'GEMINI.md' });

        // Provide a sample config instead of the user's active one
        // archive.file(path.join(PROJECT_ROOT, 'wrangler.toml'), { name: 'wrangler.sample.toml' });
    }

    // 2. Generate Manifest
    // Note: Real hash calculation would require iterating the archiver entries or walking fs.
    // For MVP, we'll just put a placeholder or basic list.

    const manifestContent = await generateManifest(version, type, [], []);
    archive.append(manifestContent, { name: MANIFEST_FILENAME });

    // 3. Add Instructions for Agent
    const instructions = `# Docking Instructions for v${version}
  
## Overview
This is a ${type} update to version ${version}.

## Key Changes
- [List changes here]

## Installation
1. Antigravity will extract this package.
2. Core files in 'src/' will be updated.
3. Migrations will be applied.
  `;
    archive.append(instructions, { name: 'instructions.md' });

    await archive.finalize();
}

// Run
const args = process.argv.slice(2);
const typeArg = args.find(arg => arg.startsWith('--type='));
const type = typeArg ? typeArg.split('=')[1] : 'full';

packRelease(type).catch(err => console.error(err));
