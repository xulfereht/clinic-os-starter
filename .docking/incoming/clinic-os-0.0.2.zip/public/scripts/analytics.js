/**
 * BRD Clinic Analytics - Client-side tracking script
 * Tracks page views and custom events
 */
(function () {
    function getSessionId() {
        var key = 'brd_session_id';
        var sessionId = sessionStorage.getItem(key);
        if (!sessionId) {
            sessionId = 'ses_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
            sessionStorage.setItem(key, sessionId);
        }
        return sessionId;
    }

    function trackPageView() {
        var data = {
            type: 'pageview',
            sessionId: getSessionId(),
            path: window.location.pathname,
            referrer: document.referrer || null,
            userAgent: navigator.userAgent
        };

        if (navigator.sendBeacon) {
            navigator.sendBeacon('/api/analytics/track', JSON.stringify(data));
        } else {
            fetch('/api/analytics/track', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
                keepalive: true
            }).catch(function () { });
        }
    }

    function trackEvent(eventType, eventData) {
        var data = {
            type: 'event',
            sessionId: getSessionId(),
            path: window.location.pathname,
            eventType: eventType,
            eventData: eventData
        };

        if (navigator.sendBeacon) {
            navigator.sendBeacon('/api/analytics/track', JSON.stringify(data));
        } else {
            fetch('/api/analytics/track', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
                keepalive: true
            }).catch(function () { });
        }
    }

    window.trackEvent = trackEvent;
    trackPageView();

    var lastPath = window.location.pathname;
    var originalPushState = history.pushState;
    history.pushState = function () {
        originalPushState.apply(this, arguments);
        if (window.location.pathname !== lastPath) {
            lastPath = window.location.pathname;
            trackPageView();
        }
    };

    window.addEventListener('popstate', function () {
        if (window.location.pathname !== lastPath) {
            lastPath = window.location.pathname;
            trackPageView();
        }
    });

    var startTime = Date.now();
    window.addEventListener('beforeunload', function () {
        var timeOnPage = Math.round((Date.now() - startTime) / 1000);
        trackEvent('page_exit', { seconds: timeOnPage });
    });
})();
