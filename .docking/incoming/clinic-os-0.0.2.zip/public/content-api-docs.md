# Unified Content API Documentation

## Endpoint
`POST /api/content/[type]`

Where `[type]` is one of:
- `blog`
- `column`
- `notice`
- `review`

## Request Body (JSON)

| Field | Type | Required | Description |
|---|---|---|---|
| `title` | string | Yes | Title of the post |
| `content` | string | No | HTML or Markdown content |
| `slug` | string | No | URL slug (auto-generated if empty) |
| `excerpt` | string | No | Short summary |
| `featured_image` | string | No | URL of the cover image |
| `status` | string | No | `draft` (default) or `published` |
| `category` | string | No | Category code (e.g., `diet`, `skin`) |
| `doctor_id` | string | No | ID of the authoring doctor |
| `patient_id` | string | No | ID of the patient (for reviews) |
| `is_new` | boolean | No | `true` (default) for create, `false` for update |
| `id` | string | No | UUID (required for update, optional for create) |

## Examples

### Create a Blog Post
```bash
curl -X POST https://brd-clinic.pages.dev/api/content/blog \
  -H "Content-Type: application/json" \
  -d '{
    "title": "New Diet Tips",
    "content": "# Hello World",
    "doctor_id": "doc_choi",
    "category": "diet",
    "status": "published"
  }'
```

### Update a Post
```bash
curl -X POST https://brd-clinic.pages.dev/api/content/blog \
  -H "Content-Type: application/json" \
  -d '{
    "is_new": false,
    "id": "EXISTING_UUID",
    "title": "Updated Title",
    "content": "Updated content..."
  }'
```

## Deletion
`DELETE /api/content/[type]?id=[UUID]`

```bash
curl -X DELETE "https://brd-clinic.pages.dev/api/content/blog?id=12345"
```
