// Chart initialization script for Survey Report
// This script is loaded after ApexCharts CDN and reads data from #chart-data element

document.addEventListener('DOMContentLoaded', function () {
    const dataEl = document.getElementById('chart-data');
    if (!dataEl) return;

    const organScores = JSON.parse(dataEl.dataset.organScores || '[]');
    const organLabels = JSON.parse(dataEl.dataset.organLabels || '[]');
    const axisScores = JSON.parse(dataEl.dataset.axisScores || '[]');

    const fontFamily = 'Pretendard, sans-serif';

    // Radar Chart
    if (document.querySelector("#radarChart")) {
        new ApexCharts(document.querySelector("#radarChart"), {
            series: [{ name: 'Vitality', data: organScores }],
            chart: {
                height: '100%',
                type: 'radar',
                toolbar: { show: false },
                animations: { enabled: false }
            },
            dataLabels: {
                enabled: true,
                style: { fontSize: '10px', colors: ['#334155'], fontWeight: 700, fontFamily: fontFamily },
                background: { enabled: true, borderRadius: 2 }
            },
            plotOptions: {
                radar: {
                    size: 85,
                    polygons: {
                        strokeColors: '#e2e8f0',
                        connectorColors: '#e2e8f0',
                        fill: { colors: ['#f8fafc', '#fff'] }
                    }
                }
            },
            xaxis: {
                categories: organLabels,
                labels: {
                    show: true,
                    style: {
                        colors: Array(5).fill('#475569'),
                        fontSize: '10px',
                        fontWeight: 700,
                        fontFamily: fontFamily
                    }
                }
            },
            yaxis: { show: false, min: 0, max: 100 },
            colors: ['#2563eb'],
            fill: { opacity: 0.2, colors: ['#3b82f6'] },
            stroke: { show: true, width: 2, colors: ['#2563eb'] },
            markers: { size: 3, colors: ['#fff'], strokeColors: '#2563eb', strokeWidth: 2 },
            tooltip: { enabled: false },
            grid: {
                padding: { top: 20, bottom: 20, left: 20, right: 20 } // Prevent clipping
            }
        }).render();
    }

    // Bar Chart
    if (document.querySelector("#barChart")) {
        const axisColors = ['#f59e0b', '#dc2626', '#0ea5e9', '#f97316'];
        new ApexCharts(document.querySelector("#barChart"), {
            series: [{ name: 'Vitality Level', data: axisScores }],
            chart: {
                type: 'bar',
                height: '100%',
                toolbar: { show: false },
                animations: { enabled: false }
            },
            plotOptions: {
                bar: {
                    borderRadius: 2,
                    horizontal: false,
                    columnWidth: '40%',
                    distributed: true,
                    dataLabels: { position: 'top' }
                }
            },
            dataLabels: {
                enabled: true,
                offsetY: -20,
                style: { fontSize: '10px', colors: ['#475569'], fontFamily: fontFamily },
                formatter: function (val) { return val + "%"; }
            },
            legend: { show: false },
            stroke: { show: true, width: 0, colors: ['transparent'] },
            xaxis: {
                categories: ['기(Qi)', '혈(Blood)', '음(Yin)', '양(Yang)'],
                labels: {
                    style: { fontSize: '11px', fontWeight: 600, colors: ['#334155'], fontFamily: fontFamily }
                },
                axisBorder: { show: false },
                axisTicks: { show: false }
            },
            yaxis: {
                max: 100,
                tickAmount: 5,
                labels: { style: { fontSize: '9px', colors: ['#94a3b8'], fontFamily: fontFamily } },
                opposite: true // Move labels to right
            },
            annotations: {
                yaxis: [
                    {
                        y: 50,
                        borderColor: '#94a3b8',
                        strokeDashArray: 4,
                        opacity: 0.5,
                        label: {
                            borderColor: 'transparent',
                            style: { color: '#94a3b8', background: 'transparent', fontSize: '9px' },
                            text: '표준 (Standard)',
                            position: 'right',
                            offsetX: -5,
                            offsetY: 5
                        }
                    },
                    {
                        y: 20,
                        borderColor: 'transparent',
                        label: {
                            borderColor: 'transparent',
                            style: { color: '#ea580c', background: 'transparent', fontSize: '9px', fontWeight: 700 },
                            text: '▼ 결핍 (Deficiency)',
                            position: 'right',
                            offsetX: -5,
                            offsetY: 0
                        }
                    },
                    {
                        y: 80,
                        borderColor: 'transparent',
                        label: {
                            borderColor: 'transparent',
                            style: { color: '#10b981', background: 'transparent', fontSize: '9px', fontWeight: 700 },
                            text: '▲ 활력 양호 (Good)',
                            position: 'right',
                            offsetX: -5,
                            offsetY: 0
                        }
                    }
                ]
            },
            colors: axisColors,
            grid: {
                borderColor: '#f1f5f9',
                strokeDashArray: 4,
                padding: { top: 0, bottom: 0, left: 10, right: 35 } // Increased right padding for labels
            },
            tooltip: { enabled: false }
        }).render();
    }
});
