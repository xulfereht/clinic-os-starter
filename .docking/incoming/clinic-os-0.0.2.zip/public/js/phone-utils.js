/**
 * Phone Number Formatting Utilities
 * Provides auto-formatting for Korean phone numbers (010-XXXX-XXXX)
 */

/**
 * Format phone number with hyphens (Korean format: 010-1234-5678)
 * @param {string} value - Raw phone number input
 * @returns {string} - Formatted phone number
 */
function formatPhoneNumber(value) {
    // Remove all non-digit characters
    const digits = value.replace(/\D/g, '');

    // Format as XXX-XXXX-XXXX for 11 digits (mobile)
    // or XXX-XXX-XXXX for 10 digits (some landlines)
    if (digits.length <= 3) {
        return digits;
    } else if (digits.length <= 7) {
        return `${digits.slice(0, 3)}-${digits.slice(3)}`;
    } else if (digits.length <= 11) {
        // For 10-digit numbers (like some area codes): 02-XXX-XXXX or 0XX-XXX-XXXX
        // For 11-digit numbers (mobile): 010-XXXX-XXXX
        const midLength = digits.length === 11 ? 4 : 3;
        return `${digits.slice(0, 3)}-${digits.slice(3, 3 + midLength)}-${digits.slice(3 + midLength)}`;
    }
    // Cap at 11 digits
    return `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7, 11)}`;
}

/**
 * Normalize phone number to digits only (for database comparison)
 * @param {string} value - Phone number with possible formatting
 * @returns {string} - Digits only
 */
function normalizePhone(value) {
    return value.replace(/\D/g, '');
}

/**
 * Attach phone formatting to an input element
 * @param {HTMLInputElement} input - The input element to format
 */
function attachPhoneFormatter(input) {
    input.addEventListener('input', function (e) {
        const cursorPos = e.target.selectionStart;
        const prevLength = e.target.value.length;

        // Format the value
        e.target.value = formatPhoneNumber(e.target.value);

        // Adjust cursor position after formatting
        const newLength = e.target.value.length;
        const diff = newLength - prevLength;
        const newCursorPos = Math.max(0, cursorPos + diff);
        e.target.setSelectionRange(newCursorPos, newCursorPos);
    });
}

// Auto-attach to phone inputs when DOM is ready
document.addEventListener('DOMContentLoaded', function () {
    // Find all phone inputs by type="tel" or data-phone-format attribute
    const phoneInputs = document.querySelectorAll('input[type="tel"][name="phone"], input[data-phone-format]');
    phoneInputs.forEach(attachPhoneFormatter);
});

// Export for module usage if needed
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { formatPhoneNumber, normalizePhone, attachPhoneFormatter };
}
