/**
 * BRD Clinic Chat Widget
 * Modern design with gradient UI and settings integration
 */

(function () {
    // Configuration
    const API_BASE = '/api/widget';
    let settings = {
        primaryColor: '#334155', // Slate 700 - Softer, matching the new bubble standard
        position: 'right',
        welcomeMessage: '안녕하세요! 무엇을 도와드릴까요?',
        businessHours: '평일 09:00 - 18:00',
        showBusinessHours: true,
        collectName: true
    };

    let state = {
        isOpen: false,
        step: 'init', // init, chat
        channelId: localStorage.getItem('brd_chat_channel_id'),
        leadId: localStorage.getItem('brd_chat_lead_id'),
        customerName: localStorage.getItem('brd_chat_customer_name'),
        messages: [],
        pollingInterval: null
    };

    // 🌐 Localization
    const I18N = {
        ko: {
            title: '한의원',
            welcome: '안녕하세요! 무엇을 도와드릴까요?',
            subtitle: '실시간 상담',
            desc: '간단한 정보를 입력해주세요.',
            name_placeholder: '이름 (선택)',
            contact_placeholder: '연락처 (필수)',
            email_placeholder: '이메일 (선택)',
            start_btn: '상담 시작하기',
            sending: '연결 중...',
            input_placeholder: '메시지를 입력하세요...',
            logout_confirm: '상담을 종료하고 로그아웃 하시겠습니까?',
            error_contact: '연락처를 입력해주세요.',
            error_email: '이메일을 입력해주세요.',
            hours_prefix: '⏰ ',
            weekdays: '평일',
            weekend: '주말',
            everyday: '매일',
            session_closed: '현재 상담이 마무리되었습니다. 궁금한 점이 있으시면 언제든 메시지를 남겨주세요.',
            staff_joined: '{name}님이 상담에 참여했습니다.',
            staff_label_format: '{name} {role}' // e.g. 최연승 원장
        },
        en: {
            title: 'Clinic',
            welcome: 'Hello! How can we help you?',
            subtitle: 'Live Chat',
            desc: 'Please provide your info to start.',
            name_placeholder: 'Name (Optional)',
            contact_placeholder: 'Phone Number (Required)',
            email_placeholder: 'Email Address (for ID)',
            start_btn: 'Start Chat',
            sending: 'Connecting...',
            input_placeholder: 'Type a message...',
            logout_confirm: 'End chat and logout?',
            error_contact: 'Please enter your phone number.',
            error_email: 'Please enter your email.',
            hours_prefix: '⏰ Open: ',
            weekdays: 'Weekdays',
            weekend: 'Weekend',
            everyday: 'Everyday',
            session_closed: 'The consultation has ended. Feel free to leave a message anytime if you have questions.',
            staff_joined: '{name} joined the chat.',
            staff_label_format: '{role} {name}', // e.g. Director Choi,
            days: { '월': 'Mon', '화': 'Tue', '수': 'Wed', '목': 'Thu', '금': 'Fri', '토': 'Sat', '일': 'Sun' }
        },
        zh: {
            title: '韩医院',
            welcome: '您好！有什么可以帮您？',
            subtitle: '实时咨询',
            desc: '请输入您的信息以开始对话。',
            name_placeholder: '姓名 (选填)',
            contact_placeholder: '电话号码 (必填)',
            email_placeholder: '电子邮箱 (必填)',
            start_btn: '开始咨询',
            sending: '连接中...',
            input_placeholder: '请输入消息...',
            logout_confirm: '确定要结束咨询并退出吗？',
            error_contact: '请输入电话号码。',
            error_email: '请输入电子邮箱。',
            hours_prefix: '⏰ 营业时间: ',
            weekdays: '工作日',
            weekend: '周末',
            everyday: '每天',
            session_closed: '咨询已结束。如有疑问，请随时留言。',
            staff_joined: '{name} 加入了对话。',
            staff_label_format: '{name}{role}', // e.g. 崔院长,
            days: { '월': '周一', '화': '周二', '수': '周三', '목': '周四', '금': '周五', '토': '周六', '일': '周日' }
        },
        ja: {
            title: '韓医院',
            welcome: 'こんにちは！どのようなご用件でしょうか？',
            subtitle: 'リアルタイム相談',
            desc: '相談を開始するための情報を入力してください。',
            name_placeholder: 'お名前 (任意)',
            contact_placeholder: '電話番号 (必須)',
            email_placeholder: 'メールアドレス',
            start_btn: '相談を開始する',
            sending: '接続中...',
            input_placeholder: 'メッセージを入力...',
            logout_confirm: '相談を終了してログアウトしますか？',
            error_contact: '電話番号を入力してください。',
            error_email: 'メールアドレスを入力してください。',
            hours_prefix: '⏰ 営業時間: ',
            weekdays: '平日',
            weekend: '週末',
            everyday: '毎日',
            session_closed: '相談が終了しました。ご質問があればいつでもメッセージを残してください。',
            staff_joined: '{name}さんが参加しました。',
            staff_label_format: '{name} {role}', // e.g. 崔院長,
            days: { '월': '月', '화': '火', '수': '水', '목': '木', '金': '金', '土': '土', '日': '日' }
        },
        vi: {
            title: 'Phòng khám',
            welcome: 'Xin chào! Chúng tôi có thể giúp gì cho bạn?',
            subtitle: 'Trò chuyện trực tuyến',
            desc: 'Vui lòng nhập thông tin để bắt đầu.',
            name_placeholder: 'Tên (Tùy chọn)',
            contact_placeholder: 'Số điện thoại (Bắt buộc)',
            email_placeholder: 'Email (Để xác nhận)',
            start_btn: 'Bắt đầu',
            sending: 'Đang kết nối...',
            input_placeholder: 'Nhập tin nhắn...',
            logout_confirm: 'Kết thúc trò chuyện và đăng xuất?',
            error_contact: 'Vui lòng nhập số điện thoại.',
            error_email: 'Vui lòng nhập email.',
            hours_prefix: '⏰ Giờ mở cửa: ',
            weekdays: 'Các ngày trong tuần',
            weekend: 'Cuối tuần',
            everyday: 'Hằng ngày',
            session_closed: 'Phiên tư vấn đã kết thúc. Hãy để lại tin nhắn nếu bạn có thắc mắc.',
            staff_joined: '{name} đã tham gia cuộc trò chuyện.',
            staff_label_format: '{role} {name}', // e.g. Bác sĩ Choi,
            days: { '월': 'T2', '화': 'T3', '수': 'T4', '목': 'T5', '금': 'T6', '토': 'T7', '일': 'CN' }
        }
    };

    // Detect Language (Priority: HTML Lang > URL > Browser)
    function getLanguage() {
        let detected = 'en';

        // 1. HTML Lang Attribute (Most Reliable for SSG/SSR)
        const htmlLang = document.documentElement.lang;
        if (htmlLang) {
            if (htmlLang === 'zh-hans' || htmlLang === 'zh-CN') return 'zh';
            if (['ko', 'en', 'zh', 'ja', 'vi'].includes(htmlLang)) return htmlLang;
        }

        // 2. URL Check (Fallback)
        const pathSegments = window.location.pathname.split('/');
        const urlLang = pathSegments[1];
        if (urlLang === 'zh-hans' || urlLang === 'zh-CN') return 'zh';
        if (['en', 'zh', 'ja', 'vi', 'ko'].includes(urlLang)) return urlLang;

        // 3. Browser Check (Last Resort)
        const browserLang = navigator.language || navigator.userLanguage;
        const code = browserLang.split('-')[0];

        // Default to English for foreigners, Korean if browser is ko
        if (code === 'zh') return 'zh';
        return ['ko', 'en', 'ja', 'vi'].includes(code) ? code : 'en';
    }

    // Dynamic State for Language
    let currentLang = 'en';
    let t = I18N['en'];
    let isKorean = false;

    function updateLanguageState() {
        currentLang = getLanguage();
        t = I18N[currentLang] || I18N['en'];
        isKorean = currentLang === 'ko';
    }

    // Helper: Localize Business Hours
    function getLocalizedHours() {
        if (!settings.businessHours) return '';

        let hours = settings.businessHours;

        // Debug log for troubleshooting
        // console.log('Raw Hours:', hours, 'Lang:', currentLang);

        // 1. Replace Keywords using Unicode to avoid encoding issues
        // 평일: \uD3C9\uC77C, 주말: \uC8FC\uB9D0, 매일: \uB9E4\uC77C
        hours = hours.replace(/(\uD3C9\s*\uC77C)/g, t.weekdays)
            .replace(/(\uC8FC\s*\uB9D0)/g, t.weekend)
            .replace(/(\uB9E4\s*\uC77C)/g, t.everyday || 'Everyday');

        // 2. Replace Day Names
        if (!isKorean) {
            const dayMap = {
                '월': 'Mon', '화': 'Tue', '수': 'Wed', '목': 'Thu', '금': 'Fri', '토': 'Sat', '일': 'Sun',
                '월요일': 'Monday', '화요일': 'Tuesday', '수요일': 'Wednesday', '목요일': 'Thursday',
                '금요일': 'Friday', '토요일': 'Saturday', '일요일': 'Sunday'
            };

            Object.keys(dayMap).forEach(key => {
                const replacement = t.days ? t.days[key.charAt(0)] : dayMap[key];
                hours = hours.split(key).join(replacement);
            });
        }

        return hours;
    }


    // DOM Elements
    let container, button, windowEl, contentEl;

    // Styles
    const STYLES = `
        #brd-chat-container {
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 9999;
            font-family: 'Pretendard', 'Noto Sans KR', -apple-system, BlinkMacSystemFont, sans-serif;
            font-size: 14px;
            line-height: 1.5;
        }
        #brd-chat-container.left {
            right: auto;
            left: 24px;
        }
        
        /* 🎨 Launcher Button */
        #brd-chat-button {
            width: 60px;
            height: 60px;
            border-radius: 24px; /* Squircle */
            background: linear-gradient(135deg, var(--brd-primary, #0f172a) 0%, var(--brd-secondary, #334155) 100%);
            box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.4), 0 8px 10px -6px rgba(15, 23, 42, 0.1);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        #brd-chat-button:hover {
            transform: scale(1.05) translateY(-2px);
            box-shadow: 0 20px 35px -5px rgba(15, 23, 42, 0.5), 0 10px 10px -5px rgba(15, 23, 42, 0.2);
        }
        #brd-chat-button:active {
            transform: scale(0.95);
        }
        #brd-chat-button svg {
            width: 28px;
            height: 28px;
            stroke-width: 2px;
            filter: drop-shadow(0 2px 3px rgba(0,0,0,0.1));
        }

        /* 🔴 Unread Badge */
        #brd-chat-button.has-unread::after {
            content: '';
            position: absolute;
            top: -2px;
            right: -2px;
            width: 14px;
            height: 14px;
            background: #ef4444;
            border-radius: 50%;
            border: 2px solid white;
            animation: pulse-red 2s infinite;
        }
        @keyframes pulse-red {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 6px rgba(239, 68, 68, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }
        
        /* 🪟 Chat Window */
        #brd-chat-window {
            position: absolute;
            bottom: 80px;
            right: 0;
            width: 380px;
            height: 600px;
            max-height: calc(100vh - 120px);
            background: #ffffff;
            border-radius: 24px;
            box-shadow: 
                0 4px 6px -1px rgba(0, 0, 0, 0.05), /* Tiny shadow */
                0 20px 25px -5px rgba(0, 0, 0, 0.05), /* Medium shadow */
                0 40px 60px -15px rgba(50, 50, 93, 0.15); /* Large shadow */
            display: none;
            flex-direction: column;
            overflow: hidden;
            border: 1px solid rgba(226, 232, 240, 0.8);
            transform-origin: bottom right;
        }
        #brd-chat-container.left #brd-chat-window {
            right: auto;
            left: 0;
            transform-origin: bottom left;
        }
        #brd-chat-window.open {
            display: flex;
            animation: openWindow 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        @keyframes openWindow {
            0% { opacity: 0; transform: scale(0.9) translateY(20px); }
            100% { opacity: 1; transform: scale(1) translateY(0); }
        }

        /* 📱 Mobile Optimization */
        @media (max-width: 600px) {
            #brd-chat-window {
                position: fixed !important;
                bottom: 0 !important;
                right: 0 !important;
                left: 0 !important;
                top: 0 !important;
                width: 100% !important;
                height: 100% !important;
                max-height: 100vh !important;
                border-radius: 0 !important;
                transform-origin: center center !important;
                z-index: 10000;
            }
            #brd-chat-container {
                z-index: 10000; /* Ensure container is on top */
            }
            .brd-close-btn {
                background: rgba(255,255,255,0.2) !important;
                width: 40px !important;
                height: 40px !important;
            }
        }
        
        /* 🎩 Header */
        .brd-chat-header {
            padding: 20px 24px;
            background: linear-gradient(135deg, var(--brd-primary, #0f172a) 0%, var(--brd-secondary, #334155) 100%);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            position: relative;
            z-index: 10;
        }
        .brd-chat-header-info {
            display: flex;
            flex-direction: column;
        }
        .brd-chat-title {
            font-weight: 700;
            font-size: 18px;
            margin-bottom: 4px;
            letter-spacing: -0.02em;
        }
        .brd-chat-subtitle {
            font-size: 13px;
            opacity: 0.9;
            font-weight: 400;
        }
        .brd-header-actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .brd-close-btn, .brd-logout-btn {
            background: rgba(255,255,255,0.15);
            border: none;
            color: white;
            cursor: pointer;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s;
            backdrop-filter: blur(5px);
        }
        .brd-close-btn:hover, .brd-logout-btn:hover {
            background: rgba(255,255,255,0.25);
        }
        .brd-logout-btn {
            font-size: 11px;
            width: auto;
            padding: 0 12px;
            border-radius: 16px;
        }

        /* ⏰ Hours Notice */
        .brd-hours-notice {
            background: #f8fafc;
            color: #64748b;
            padding: 8px 16px;
            font-size: 11px;
            text-align: center;
            font-weight: 500;
            border-bottom: 1px solid #f1f5f9;
        }

        /* 📜 Body */
        .brd-chat-body {
            flex: 1;
            overflow-y: auto;
            background: #f8fafc;
            padding: 20px;
            scroll-behavior: smooth;
        }
        .brd-chat-body::-webkit-scrollbar {
            width: 5px;
        }
        .brd-chat-body::-webkit-scrollbar-track {
            background: transparent;
        }
        .brd-chat-body::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }

        /* 📝 Init Form */
        .brd-init-form {
            display: flex;
            flex-direction: column;
            gap: 16px;
            margin-top: 32px;
            padding: 0 10px;
        }
        .brd-welcome {
            text-align: center;
            margin-bottom: 24px;
            animation: fadeIn 0.5s ease-out;
        }
        .brd-welcome-icon {
            font-size: 48px;
            margin-bottom: 16px;
            display: inline-block;
            filter: drop-shadow(0 4px 6px rgba(0,0,0,0.1));
        }
        .brd-welcome-text {
            font-size: 20px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 8px;
            letter-spacing: -0.02em;
        }
        .brd-welcome-sub {
            font-size: 14px;
            color: #64748b;
            line-height: 1.4;
        }
        .brd-input {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            font-size: 15px;
            outline: none;
            transition: all 0.2s;
            background: white;
            color: #1e293b;
            box-sizing: border-box; /* Fix width overflow */
        }
        .brd-input:focus {
            border-color: var(--brd-primary, #0f172a);
            box-shadow: 0 0 0 3px rgba(15, 23, 42, 0.1);
        }
        .brd-btn {
            padding: 16px;
            background: linear-gradient(135deg, var(--brd-primary, #0f172a) 0%, var(--brd-secondary, #334155) 100%);
            color: white;
            border: none;
            border-radius: 16px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            margin-top: 8px;
            transition: all 0.2s;
            box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.2);
        }
        .brd-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 15px -3px rgba(15, 23, 42, 0.3);
        }
        .brd-btn:active {
            transform: scale(0.98);
        }
        .brd-btn:disabled {
            background: #94a3b8;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        /* 💬 Messages */
        .brd-message-list {
            display: flex;
            flex-direction: column;
            gap: 16px; /* Spacing between message groups */
            padding-bottom: 10px;
        }
        .brd-msg {
            max-width: 85%;
            padding: 12px 16px;
            font-size: 14px;
            line-height: 1.5;
            position: relative;
            animation: msgSlideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }
        @keyframes msgSlideIn {
            from { opacity: 0; transform: translateY(10px) scale(0.98); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }
        
        .brd-msg-in {
            align-self: flex-start;
            background: white;
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
            border-bottom-right-radius: 20px;
            border-bottom-left-radius: 4px;
            color: #334155;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02), 0 1px 2px rgba(0,0,0,0.03);
            border: 1px solid #f1f5f9;
        }
        /* Staff name style */
        .brd-msg-in .sender-name {
            font-size: 11px;
            font-weight: 600;
            color: var(--brd-primary);
            margin-bottom: 4px;
            margin-left: 2px;
        }

        .brd-msg-out {
            align-self: flex-end;
            background: #f1f5f9; /* Slate 100 - Light gray */
            color: #334155; /* Slate 700 - Dark text */
            border: 1px solid #e2e8f0;
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
            border-bottom-left-radius: 20px;
            border-bottom-right-radius: 4px; /* Tail bottom right */
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        }
        .brd-msg-system {
            align-self: center;
            background: transparent;
            color: #94a3b8;
            font-size: 11px;
            padding: 0;
            border-radius: 0;
            margin: 16px 0;
            font-weight: 500;
            text-align: center;
            width: 100%;
        }
        
        .brd-time {
            font-size: 11px; /* Slightly larger for readability */
            margin-top: 4px;
            color: #94a3b8; /* Slate 400 - Explicit gray */
            text-align: right;
            font-feature-settings: "tnum";
            font-variant-numeric: tabular-nums;
            font-weight: 400;
        }
        
        /* Ensure contrast in light bubble */
        .brd-msg-out .brd-time {
            color: #64748b !important; /* Slate 500 - Slightly darker for contrast on Slate 100 bg */
        }

            /* Date Separator */
        .brd-date-separator {
            text-align: center;
            font-size: 11px;
            color: #94a3b8;
            margin: 20px 0 10px 0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        .brd-date-separator::before,
        .brd-date-separator::after {
            content: '';
            height: 1px;
            background: #e2e8f0;
            flex: 1;
            max-width: 60px;
        }

        /* 🦶 Footer */
        .brd-chat-footer {
            padding: 16px;
            background: white;
            border-top: 1px solid #f1f5f9;
            display: flex;
            gap: 12px;
            align-items: center;
        }
        .brd-chat-input {
            flex: 1;
            border: 1px solid #e2e8f0;
            padding: 12px 18px;
            border-radius: 24px;
            font-size: 14px;
            outline: none;
            transition: all 0.2s;
            background: #f8fafc;
            color: #334155;
        }
        .brd-chat-input:focus {
            background: white;
            border-color: var(--brd-primary, #0f172a);
            box-shadow: 0 0 0 3px rgba(15, 23, 42, 0.1);
        }
        .brd-send-btn {
            background: linear-gradient(135deg, var(--brd-primary, #0f172a) 0%, var(--brd-secondary, #334155) 100%);
            color: white;
            border: none;
            width: 44px;
            height: 44px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
            box-shadow: 0 2px 5px rgba(15, 23, 42, 0.3);
        }
        .brd-send-btn:hover {
            transform: scale(1.08);
            box-shadow: 0 4px 8px rgba(15, 23, 42, 0.4);
        }
        .brd-send-btn:active {
            transform: scale(0.95);
        }
        .brd-send-btn svg {
            margin-left: 2px; /* Visual centering adjustment */
        }
        
        /* ⌨️ Typing indicator */
        .brd-typing {
            display: flex;
            gap: 4px;
            padding: 12px 16px;
            background: white;
            border-radius: 18px;
            border-bottom-left-radius: 4px;
            width: fit-content;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
            border: 1px solid #f1f5f9;
            margin-bottom: 12px;
        }
        .brd-typing span {
            width: 6px;
            height: 6px;
            background: #94a3b8;
            border-radius: 50%;
            animation: typing 1.4s infinite ease-in-out both;
        }
        .brd-typing span:nth-child(1) { animation-delay: -0.32s; }
        .brd-typing span:nth-child(2) { animation-delay: -0.16s; }
        @keyframes typing {
            0%, 80%, 100% { transform: scale(0); }
            40% { transform: scale(1); }
        }
    `;

    // Track last fetched language for cache invalidation
    let lastFetchedLang = null;

    // Initialize
    async function init() {
        // 1. Update Language State on every Init
        updateLanguageState();

        // 2. Check existence
        const existingContainer = document.getElementById('brd-chat-container');
        if (existingContainer) {
            container = existingContainer;
            button = container.querySelector('#brd-chat-button');
            windowEl = container.querySelector('#brd-chat-window');
            contentEl = container.querySelector('#brd-chat-body');

            // Re-fetch settings if language changed since last fetch
            if (lastFetchedLang !== currentLang) {
                try {
                    const res = await fetch(`/api/admin/settings/widget?lang=${currentLang}`);
                    if (res.ok) {
                        const data = await res.json();
                        settings = { ...settings, ...data };
                        lastFetchedLang = currentLang;
                    }
                } catch (e) { /* Ignore fetch errors */ }
            }

            // Force re-render of static texts
            updateDOMText();
            return;
        }

        // Inject styles first (before anything else)
        injectStyles();

        // Create DOM but keep it hidden initially
        createDOM();
        container.style.opacity = '0';
        container.style.transition = 'opacity 0.3s ease';

        // Load settings from API
        try {
            const res = await fetch(`/api/admin/settings/widget?lang=${currentLang}`);
            if (res.ok) {
                const data = await res.json();
                settings = { ...settings, ...data };
                lastFetchedLang = currentLang;

                // Check if widget is disabled
                if (settings.enabled === false) {
                    container.remove();
                    return;
                }
            }
        } catch (e) {
            console.log('Using default widget settings');
        }

        // Apply theme colors as CSS variables
        container.style.setProperty('--brd-primary', settings.primaryColor);
        container.style.setProperty('--brd-secondary', adjustColor(settings.primaryColor, -30));

        // Position
        if (settings.position === 'left') {
            container.classList.add('left');
        }

        // Update header with business hours if changed
        updateBusinessHoursDOM();

        bindEvents();

        // Check if session exists
        if (state.channelId) {
            state.step = 'chat';
            render();
            startPolling();
        } else {
            render();
        }

        // Fade in after everything is ready
        requestAnimationFrame(() => {
            container.style.opacity = '1';
        });
    }

    function updateBusinessHoursDOM() {
        if (!container) return;
        const hoursNotice = container.querySelector('.brd-hours-notice');
        if (hoursNotice && settings.showBusinessHours) {
            const localizedHours = getLocalizedHours();
            hoursNotice.textContent = `${t.hours_prefix}${localizedHours}`;
        } else if (hoursNotice && !settings.showBusinessHours) {
            hoursNotice.remove();
        }
    }

    function updateDOMText() {
        if (!container) return;
        // Update Title/Subtitle
        const titleEl = container.querySelector('.brd-chat-title');
        const subEl = container.querySelector('.brd-chat-subtitle');
        if (titleEl) titleEl.textContent = settings.title || t.title;
        if (subEl) subEl.textContent = t.subtitle;

        updateBusinessHoursDOM();

        // Update input placeholder
        const input = container.querySelector('.brd-chat-input');
        if (input) input.placeholder = t.input_placeholder;

        // Re-render body if in init (welcome screen)
        if (state.step === 'init') render();
    }

    // Trigger Init on Astro Page Load (Unconditional) to update language
    document.addEventListener('astro:page-load', init);

    function adjustColor(hex, percent) {
        // Simple color adjustment
        const num = parseInt(hex.replace('#', ''), 16);
        const r = Math.min(255, Math.max(0, (num >> 16) + percent));
        const g = Math.min(255, Math.max(0, ((num >> 8) & 0x00FF) + percent));
        const b = Math.min(255, Math.max(0, (num & 0x0000FF) + percent));
        return '#' + (b | (g << 8) | (r << 16)).toString(16).padStart(6, '0');
    }

    function injectStyles() {
        // Prevent duplicate style injection
        if (document.getElementById('brd-chat-styles')) return;

        const style = document.createElement('style');
        style.id = 'brd-chat-styles';
        style.innerHTML = STYLES;
        document.head.appendChild(style);
    }

    function createDOM() {
        container = document.createElement('div');
        container.id = 'brd-chat-container';

        // Chat Window with improved header
        container.innerHTML = `
            <div id="brd-chat-window">
                <div class="brd-chat-header">
                    <div class="brd-chat-header-info">
                        <div class="brd-chat-title">${t.title}</div>
                        <div class="brd-chat-subtitle">${t.subtitle}</div>
                    </div>
                    <div class="brd-header-actions">
                        <button class="brd-logout-btn" style="display:none;">로그아웃</button>
                        <button class="brd-close-btn">✕</button>
                    </div>
                </div>
                ${settings.showBusinessHours ? `
                <div class="brd-hours-notice">
                    ${t.hours_prefix}${getLocalizedHours()}
                </div>
                ` : ''}
                <div class="brd-chat-body" id="brd-chat-body"></div>
                <div class="brd-chat-footer" id="brd-chat-footer" style="display: none;">
                    <input type="text" class="brd-chat-input" placeholder="${t.input_placeholder}" />
                    <button class="brd-send-btn">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/>
                        </svg>
                    </button>
                </div>
            </div>
            <button id="brd-chat-button">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2-2z"></path>
                </svg>
                <div id="brd-unread-badge" style="display:none; position:absolute; top:-2px; right:-2px; width:14px; height:14px; background:#ef4444; border-radius:50%; border:2px solid white; animation:pulse-red 2s infinite;"></div>
            </button>
        `;

        document.body.appendChild(container);

        button = container.querySelector('#brd-chat-button');
        windowEl = container.querySelector('#brd-chat-window');
        contentEl = container.querySelector('#brd-chat-body');
    }

    function bindEvents() {
        button.addEventListener('click', toggleChat);
        container.querySelector('.brd-close-btn').addEventListener('click', toggleChat);
        container.querySelector('.brd-logout-btn').addEventListener('click', logout);

        const input = container.querySelector('.brd-chat-input');
        const sendBtn = container.querySelector('.brd-send-btn');

        sendBtn.addEventListener('click', sendMessage);
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendMessage();
        });
    }

    function toggleChat() {
        state.isOpen = !state.isOpen;
        if (state.isOpen) {
            windowEl.classList.add('open');
            button.style.display = 'none';
            if (state.step === 'chat') {
                scrollToBottom();
                startPolling();
            }
        } else {
            windowEl.classList.remove('open');
            button.style.display = 'flex';
            stopPolling();
        }
    }

    function logout() {
        if (!confirm(t.logout_confirm)) return;

        // Clear Storage
        localStorage.removeItem('brd_chat_channel_id');
        localStorage.removeItem('brd_chat_lead_id');
        localStorage.removeItem('brd_chat_customer_name');

        // Reset State
        state.channelId = null;
        state.leadId = null;
        state.customerName = null;
        state.step = 'init';
        state.messages = [];

        stopPolling();
        render();
    }

    async function handleInitSubmit(e) {
        e.preventDefault();
        const name = container.querySelector('#brd-init-name').value;
        const contact = container.querySelector('#brd-init-contact').value;
        const submitBtn = container.querySelector('button[type="submit"]');

        if (!contact) return alert(isKorean ? t.error_contact : t.error_email);

        submitBtn.disabled = true;
        submitBtn.innerText = t.sending;

        // Capture device info
        const deviceInfo = {
            userAgent: navigator.userAgent,
            referrer: document.referrer || window.location.href,
            deviceType: /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent) ? 'mobile' : 'desktop',
            language: navigator.language,
            screenSize: `${window.screen.width}x${window.screen.height} `
        };

        try {
            const res = await fetch(`${API_BASE}/init`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, contact, deviceInfo })
            });
            const data = await res.json();

            if (data.success) {
                state.channelId = data.channelId;
                state.leadId = data.leadId;
                state.customerName = data.customerName;
                state.step = 'chat';

                localStorage.setItem('brd_chat_channel_id', data.channelId);
                localStorage.setItem('brd_chat_lead_id', data.leadId);
                localStorage.setItem('brd_chat_customer_name', data.customerName);

                render();
                startPolling();
            } else {
                alert('연결 실패: ' + (data.error || '알 수 없는 오류'));
            }
        } catch (e) {
            console.error(e);
            alert('오류가 발생했습니다.');
        } finally {
            submitBtn.disabled = false;
        }
    }

    async function sendMessage() {
        const input = container.querySelector('.brd-chat-input');
        const content = input.value.trim();
        if (!content) return;

        input.value = '';

        // Optimistic append
        appendMessage({
            id: 'temp-' + Date.now(),
            content: content,
            sender_id: state.leadId, // Me
            created_at: Math.floor(Date.now() / 1000)
        });

        try {
            const res = await fetch(`${API_BASE}/messages`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    channelId: state.channelId,
                    content: content,
                    senderId: state.leadId
                })
            });
            await fetchMessages();
        } catch (e) {
            console.error(e);
        }
    }

    async function fetchMessages() {
        if (!state.channelId) return;

        try {
            const res = await fetch(`${API_BASE}/messages?channelId=${state.channelId}`);
            const data = await res.json();

            if (data.success) {
                state.messages = data.messages;
                renderMessages();
            }
        } catch (e) {
            console.error(e);
        }
    }

    function startPolling() {
        if (state.pollingInterval) return;
        fetchMessages();
        state.pollingInterval = setInterval(fetchMessages, 3000);
    }

    function stopPolling() {
        if (state.pollingInterval) {
            clearInterval(state.pollingInterval);
            state.pollingInterval = null;
        }
    }

    function render() {
        const body = container.querySelector('#brd-chat-body');
        const footer = container.querySelector('#brd-chat-footer');
        const logoutBtn = container.querySelector('.brd-logout-btn');

        // Update Headers (Always)
        container.querySelector('.brd-chat-subtitle').textContent = t.subtitle;
        container.querySelector('.brd-chat-input').placeholder = t.input_placeholder;
        if (settings.showBusinessHours) {
            const hoursNotice = container.querySelector('.brd-hours-notice');
            if (hoursNotice) hoursNotice.textContent = t.hours_prefix + settings.businessHours;
        }

        if (state.step === 'init') {
            footer.style.display = 'none';
            logoutBtn.style.display = 'none';

            // Dynamic Form based on Language
            const contactInputHtml = isKorean
                ? `<input type="tel" id="brd-init-contact" class="brd-input" placeholder="${t.contact_placeholder}" required />`
                : `<input type="email" id="brd-init-contact" class="brd-input" placeholder="${t.email_placeholder}" required />`;

            body.innerHTML = `
                <div class="brd-welcome">
                    <div class="brd-welcome-icon">💬</div>
                    <div class="brd-welcome-text">${t.welcome}</div>
                    <div class="brd-welcome-sub">${t.desc}</div>
                </div>
                <form class="brd-init-form">
                    ${settings.collectName ? `
                    <input type="text" id="brd-init-name" class="brd-input" placeholder="${t.name_placeholder}" />
                    ` : ''}
                    ${contactInputHtml}
                    <button type="submit" class="brd-btn">${t.start_btn}</button>
                </form>
            `;

            body.querySelector('form').addEventListener('submit', handleInitSubmit);
        } else {
            footer.style.display = 'flex';
            logoutBtn.style.display = 'flex';
            if (state.messages.length === 0) {
                body.innerHTML = '<div class="brd-message-list"></div>';
                fetchMessages(); // Initial fetch
            }
        }
    }

    function renderMessages() {
        let listContainer = container.querySelector('#brd-message-list');
        if (!listContainer) {
            listContainer = document.createElement('div');
            listContainer.className = 'brd-message-list';
            listContainer.id = 'brd-message-list';
            contentEl.innerHTML = '';
            contentEl.appendChild(listContainer);
        }

        // Remove pending (optimistic) messages - they'll be replaced by real ones
        listContainer.querySelectorAll('[data-pending="true"]').forEach(el => el.remove());

        // Get existing message IDs (only real messages)
        const existingIds = new Set(
            Array.from(listContainer.querySelectorAll('[data-msg-id]'))
                .map(el => el.dataset.msgId)
        );

        // Date Tracking Helper
        const dateOptions = { year: 'numeric', month: 'long', day: 'numeric', weekday: 'short' };

        // Only add new messages (incremental update)
        let lastDateString = null;

        // Find the last date displayed in the list if any
        const lastSeparator = listContainer.lastElementChild?.previousElementSibling; // Check loosely
        if (listContainer.children.length > 0) {
            // Simple hack: We re-process date headers for the entire list to be safe,
            // or just check the last message's date.
            // Better approach: Clear and re-render all to ensure correct date placement?
            // Since we append, let's keep it simple. If we append, we check against the last rendered message.
            const lastMsg = Array.from(listContainer.querySelectorAll('.brd-msg')).pop();
            if (lastMsg && lastMsg.dataset.date) {
                lastDateString = lastMsg.dataset.date;
            }
        }

        state.messages.forEach(msg => {
            if (existingIds.has(msg.id)) return; // Skip existing

            // Date Separator Logic
            const msgDate = new Date(msg.created_at * 1000);
            const dateStr = msgDate.toLocaleDateString(currentLang, dateOptions);

            if (dateStr !== lastDateString) {
                const dateDiv = document.createElement('div');
                dateDiv.className = 'brd-date-separator';
                dateDiv.textContent = dateStr;
                listContainer.appendChild(dateDiv);
                lastDateString = dateStr;
            }

            const isMe = msg.sender_id === state.leadId;
            const isSystem = msg.sender_id === 'system';
            const isStaff = msg.is_staff;
            const time = new Date(msg.created_at * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

            const div = document.createElement('div');
            div.dataset.msgId = msg.id;
            div.dataset.date = dateStr; // Store date for comparison
            div.className = `brd-msg ${isSystem ? 'brd-msg-system' : (isMe ? 'brd-msg-out' : 'brd-msg-in')}`;

            // Staff Name Formatting & Fallback
            let displayName = msg.sender_name;

            // Multilingual Fallback
            if (currentLang === 'en' && msg.sender_name_en) {
                displayName = msg.sender_name_en;
            } else if ((currentLang === 'zh' || currentLang === 'ja') && msg.sender_name_hanja) {
                displayName = msg.sender_name_hanja;
            }

            if (isStaff && displayName && msg.sender_role && t.staff_label_format) {
                // If role exists, apply localized format
                displayName = t.staff_label_format
                    .replace('{name}', displayName)
                    .replace('{role}', msg.sender_role);
            }

            const senderLabel = isStaff && displayName ?
                `<div style="font-size: 11px; font-weight: 600; color: #334155; margin-bottom: 4px;">${displayName}</div>` : '';

            // System Message Localization
            let content = msg.content;
            if (isSystem && content.startsWith('SYSTEM:')) {
                const parts = content.split('|');
                const key = parts[0].replace('SYSTEM:', '').toLowerCase();

                if (key === 'closed') {
                    content = t.session_closed;
                } else if (key === 'joined') {
                    const name = parts[1] || 'Staff'; // Default fallback
                    content = t.staff_joined.replace('{name}', name);
                }
            }

            // Translation Block for Staff Messages (if available)
            // Show translation as main content, original Korean in purple box
            let translationHtml = '';
            let displayContent = content;

            if (!isMe && !isSystem && msg.translation) {
                // Swap: show translation as main content
                displayContent = msg.translation;
                // Show original Korean in purple reference box
                translationHtml = `
                    <div style="margin-top: 6px; padding: 6px 10px; background: rgba(139, 92, 246, 0.08); border-radius: 8px; border: 1px solid rgba(139, 92, 246, 0.15);">
                        <div style="display: flex; align-items: center; gap: 6px; font-size: 12px; color: #7c3aed;">
                            <span>🇰🇷</span>
                            <span>${content}</span>
                        </div>
                    </div>
                `;
            }

            div.innerHTML = `
                ${senderLabel}
                ${displayContent}
                ${translationHtml}
            <div class="brd-time" style="color: ${isMe ? 'rgba(255,255,255,0.8)' : '#94a3b8'}">${time}</div>
            `;
            listContainer.appendChild(div);
        });

        // Only scroll if we added new messages
        if (state.messages.length > existingIds.size) {
            scrollToBottom();
        }
    }

    function appendMessage(msg) {
        // Optimistic UI helper - add temporary message
        const list = container.querySelector('#brd-message-list');
        if (!list) return;

        const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        const div = document.createElement('div');
        div.className = `brd - msg brd - msg - out brd - msg - pending`;
        div.dataset.msgId = msg.id; // Track temp id
        div.dataset.pending = 'true';
        div.innerHTML = `${msg.content} <div class="brd-time" style="color: rgba(255,255,255,0.8)">${time}</div>`;

        list.appendChild(div);
        scrollToBottom();
    }

    function scrollToBottom() {
        const body = container.querySelector('#brd-chat-body');
        body.scrollTop = body.scrollHeight;
    }

    // Load
    if (document.readyState === 'complete') {
        init();
    } else {
        window.addEventListener('load', init);
    }

    // ============================================================
    // 🔄 Astro View Transitions Support
    // Persist chat widget across page navigations
    // ============================================================

    // Store widget reference for persistence
    let detachedWidget = null;

    // Before page swap: detach widget from DOM to preserve it
    document.addEventListener('astro:before-swap', (e) => {
        const existingContainer = document.getElementById('brd-chat-container');
        if (existingContainer) {
            // Detach from old document, store for re-attachment
            detachedWidget = existingContainer;
            existingContainer.remove();
        }
    });

    // After page swap: re-attach widget to new document
    document.addEventListener('astro:after-swap', () => {
        // Re-inject styles if they were lost during swap
        injectStyles();

        if (detachedWidget) {
            document.body.appendChild(detachedWidget);
            // Re-bind references to existing elements
            container = detachedWidget;
            button = container.querySelector('#brd-chat-button');
            windowEl = container.querySelector('#brd-chat-window');
            contentEl = container.querySelector('#brd-chat-body');
            detachedWidget = null;
        } else {
            // Fallback: if widget was somehow lost, reinitialize
            if (!document.getElementById('brd-chat-container')) {
                init();
            }
        }
    });

    // Alternative: page-load event as fallback for full page loads
    document.addEventListener('astro:page-load', () => {
        // Only init if container doesn't exist (first load or lost widget)
        if (!document.getElementById('brd-chat-container')) {
            init();
        }
    });

})();
